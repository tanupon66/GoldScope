#!/data/data/com.termux/files/usr/bin/sh
set -eu
command -v node >/dev/null 2>&1 || { echo "Install Node.js first: pkg install nodejs-lts"; exit 1; }
npm ci
npm run check
npm run test:e2e
npx wrangler deploy --dry-run
cat <<'MSG'

Preflight passed. Complete CLOUDFLARE_DEPLOY_TH.md before the real deploy:
  1) create D1 and Queues
  2) apply D1 migrations
  3) set ADMIN_CREDENTIAL_HASH and SESSION_SIGNING_SECRET
  4) set Capital.com secrets
  5) run: npx wrangler deploy

The script intentionally does not deploy before secrets and resources exist.
MSG
