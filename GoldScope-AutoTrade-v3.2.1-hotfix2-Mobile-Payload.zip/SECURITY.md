# Security Design — v3.2

## Implemented

- PBKDF2-SHA256 admin hash; ไม่มี plaintext credential ใน repository.
- Signed short-lived `Secure`, `HttpOnly`, `SameSite=Strict` session cookie.
- Session-bound CSRF + same-origin enforcement สำหรับ state-changing routes.
- Login throttling/temporary lockout, logout และ session revocation.
- Live unlock ผูก session/account/deployment version/expiry และถูกยกเลิกเมื่อ config/environment เปลี่ยน.
- CSP, frame denial, MIME protection, referrer/permissions policy และ `no-store` สำหรับ API/session.
- Broker/provider tokens อยู่ server-side; public state redacts Broker session.
- Secret scanner ครอบคลุม source/tests/docs และ build excludes sensitive files.
- Structured audit/system/queue/reconciliation/notification records ใน D1.
- Notification payload redaction สำหรับ key/token/password/secret.
- Queue idempotency, execution lock และ no blind order POST retry.

## Secrets

ตั้งด้วย `wrangler secret put` ตาม `SECRETS_REQUIRED_TH.md`. ห้ามใส่ใน frontend, GitHub, localStorage, screenshots หรือ artifact documentation.

## Recommended perimeter

สำหรับ private deployment ให้เพิ่ม Cloudflare Access/MFA, จำกัดสมาชิกบัญชี Cloudflare, เปิด audit logs/alerts และ rotate signing/Broker/provider secrets ตามนโยบายองค์กร.

## Residual risks

ยังไม่มี external penetration test, production WAF/load test หรือ credential-based Broker test ใน environment นี้. Generic webhook endpoint และ news providers ต้องตรวจ licensing/TLS/authentication ก่อนเปิดใช้.


## Static asset security (v3.2)

- `public/_headers` กำหนด CSP, `frame-ancestors 'none'`, `X-Frame-Options: DENY`, no-sniff, referrer และ permissions policy.
- Production build ไม่สร้าง source map.
- `/api/market` และ `/api/quote` ต้องมี signed session cookie ก่อนใช้ provider quota.
- `NEWS_API_BASE_URL` และ `ECONOMIC_CALENDAR_API_BASE_URL` เป็น endpoint configuration ไม่ใช่ Secret; API keys ยังคงเป็น Wrangler Secrets.
