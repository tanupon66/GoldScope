# วิธีติดตั้งแพตช์ GoldScope AutoTrade v3.2.1

แพตช์นี้ใช้กับ **Source v3.2.0** เท่านั้น

1. สำรอง v3.2.0 และ export config/journal.
2. จาก root ของ v3.2.0 ใช้ `patch -p1 < GoldScope-AutoTrade-v3.2.1.patch` หรือคัดลอกไฟล์จาก Patch ZIP ทับตามโครงสร้าง.
3. รัน `npm ci`, `npm run check` และ `npm run test:e2e`.
4. สำหรับโทรศัพท์ แนะนำใช้ Mobile Payload + GitHub Actions ตาม `MOBILE_ONE_CLICK_INSTALL_TH.md`.
5. Deploy ด้วย `safe_update` เพื่อรักษา Cloudflare Secrets เดิม.
