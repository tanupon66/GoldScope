# Adaptive Learning and Model Governance

GoldScope ใช้ explainable bounded score adjustment ไม่ใช่ AI ที่ส่งคำสั่งเอง. Completed outcomes ถูกถ่วงด้วย source policy, recency decay, shrinkage และ effective sample size.

## Guardrails

- Demo/Live แยกตามบัญชีและถ่วงน้ำหนักตาม policy.
- Sample ต่ำถูก shrink และ adjustment ถูกจำกัด.
- Backtest model frozen; ผล run เดียวกันไม่ย้อนกลับไป train.
- Model ห้ามเพิ่ม risk limits หรือข้าม Kill Switch.
- ทุก order ผ่าน deterministic Risk Engine และ pre-submit recheck.

## Champion/Challenger

Promotion checks ครอบคลุม sample size, positive out-of-sample expectancy หลังต้นทุน, drawdown, stability, recent degradation, no leakage, Shadow days, schema compatibility และ unchanged risk limits. Registry รองรับ promote/rollback และ D1 มี `model_governance_events` สำหรับ audit.

## Current production policy

Automatic promotion ถูกปิดโดยตั้งใจ. Runtime monitor เปรียบเทียบ recent/baseline expectancy, win rate และ regime distribution; เมื่อเสื่อมรุนแรงจะหยุด Adaptive adjustment และแจ้งเตือน โดยกลยุทธ์ฐานกับ Risk Engine ยังทำงานต่อ. Automated retraining, feature-level PSI และ automatic promotion ยังเป็นงานภายหลังและเป็น blocker สำหรับการอ้าง Live model governance เต็มรูปแบบ.
