# News and Economic Event Engine — v3.2

## Provider adapter

Optional licensed JSON providers:

```text
NEWS_API_BASE_URL + NEWS_API_KEY
ECONOMIC_CALENDAR_API_BASE_URL + ECONOMIC_CALENDAR_API_KEY
```

ไม่มี website scraping. Articles/events ถูก normalize, timestamp ด้วย publish/scheduled time, deduplicate, decay และเก็บใน D1 ผ่าน `news-ingestion` consumer.

## Decision use

ค่าเริ่มต้น `RISK_FILTER`. ข่าวห้ามเป็นเหตุผลเดียวในการเข้า order และใช้ได้เพื่อ warning, confidence adjustment, delay, position-size policy หรือ high-impact blackout. ระหว่าง blackout ระบบยัง reconcile, ตรวจ position/SL/TP และใช้ Kill Switch ได้.

## Reliability

- Deduplication และ duplicate group
- Publish-time decay ไม่ใช้ received time แทน
- High-impact USD/event windows ก่อน/หลัง
- Provider health/error ถูกเก็บและแสดงใน Cloud Health
- Provider failure ไม่สร้างข่าวปลอม
- No provider → `NOT_CONFIGURED` และระบบใช้ behavior ที่ระบุชัด

## Backtest boundary

Backtest ปัจจุบันยังไม่มี historical point-in-time news archive ครบ จึงไม่อ้างผล news-aware historical acceptance. ห้ามใช้ข่าวที่ publish หลัง candle time เมื่อต่อ historical provider ในอนาคต.
