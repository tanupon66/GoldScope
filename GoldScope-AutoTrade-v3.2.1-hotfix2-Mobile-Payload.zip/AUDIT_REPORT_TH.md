# รายงาน Audit v2.0.3 ก่อนแก้ไข

## Architecture/Data flow เดิม

Vite PWA เรียก Worker และเก็บการตั้งค่าหลายส่วนใน browser. Worker ใช้ Cron ทุก 1 นาทีและ Durable Object ชื่อ `primary` เพียงตัวเดียว. Capital.com เป็น Broker, Twelve Data เป็น fallback และ mock dataset เติมข้อมูลที่ขาด. Backtest/adaptive learning ทำงานใน frontend/core.

## ประเด็นสำคัญที่พบ

- ใช้ ADMIN PIN คงที่เป็น bearer credential และส่งจาก frontend ทุก request.
- Durable Object `primary` ทำให้ Demo/Live/หลายบัญชีมีโอกาสแชร์ state.
- ไม่มี order-intent state machine/checkpoint ก่อน Broker POST.
- ไม่มี execution lock ที่ชัดเจน จึงเสี่ยง Cron/manual ซ้อนกัน.
- Broker session login ใหม่บ่อยและ retry policy ไม่แยก GET กับ order POST.
- เมื่อ timeframe ขาด ระบบเติม mock candles ทำให้แหล่งข้อมูลผสมโดยไม่ block execution path.
- ข้อมูล forming/closed candle, duplicate/gap/out-of-order/stale ไม่ถูก gate อย่างครบถ้วน.
- Reconciliation เดิมใช้ balance delta ประเมิน P/L ซึ่งอาจรวม deposit/withdrawal/financing/position อื่น.
- Live unlock phrase อยู่ใน config flow และไม่ผูก session/account/deploy.
- PWA Service Worker cache GET กว้างเกินไปและเรียก `skipWaiting` ทันที.
- Backtest metrics จำกัดและไม่มี Monte Carlo/stress report.
- Adaptive learning ไม่มี Champion/Challenger promotion/rollback governance.
- ไม่มี D1 long-term trace, Queue receipt dedup, news/economic adapter หรือ audit log ระยะยาว.

## Baseline จริง

ก่อนแก้ไข `npm ci` สำเร็จ และ `npm run check` ผ่าน 47 tests พร้อม production build. การที่ baseline ผ่าน tests ไม่ได้หมายความว่าความเสี่ยงข้างต้นถูกครอบคลุม.
