# Deterministic Risk Engine — v3.2

Strategy, news และ adaptive scores เป็นข้อมูลประกอบเท่านั้น คำสั่งส่ง Broker ได้เมื่อ deterministic guards ผ่านทั้งรอบวิเคราะห์และรอบ Queue ก่อน submit.

## Gate order

1. Authenticated route + valid CSRF สำหรับคำสั่งจากผู้ใช้.
2. System enabled และ Kill Switch ไม่ทำงาน.
3. Broker secrets/session/account พร้อมและ environment ตรงกัน.
4. Account ID/Epic ตรงกับ Intent เดิม.
5. Market `TRADEABLE`, quote/candles สด และ data quality ผ่าน.
6. News blackout ตาม mode.
7. Spread และ Broker latency.
8. Existing position, working order, unresolved intent และ duplicate signal.
9. Max trades/hour/day, daily/weekly loss, consecutive losses และ cooldown.
10. Current drawdown, margin usage และ reconciliation mismatch.
11. Broker minimum size/step, minimum stop และ calibration.
12. Entry zone ยังไม่หมดอายุ และ latest-price risk ไม่เกิน budget.
13. Live unlock + Live Readiness สำหรับคำสั่งเงินจริง.

## Two-stage enforcement

Signal cycle สร้าง `RISK_APPROVED/QUEUED` intent แต่ยังไม่แตะ Broker. `order-execution` consumer refresh account/quote/positions/orders แล้วรัน guards ซ้ำก่อนเปลี่ยนเป็น `SUBMITTING`. การปิด Auto, กด Kill Switch, เปลี่ยน environment/account หรือราคาออกจากโซนระหว่างรอ Queue จะบล็อกออเดอร์.

## Calibration and small accounts

ระบบเปรียบเทียบ contract/size/tick/P&L conversion กับ observed Demo result. หาก mismatch จะคืน `BROKER_CALIBRATION_REQUIRED`. เมื่อ minimum size ทำให้ risk เกินเพดาน ระบบคืน `MINIMUM_SIZE_EXCEEDS_RISK` แทนการบีบ stop ให้แคบผิดโครงสร้าง.

## Circuit breakers

- Max loss per trade
- Daily/weekly loss
- Maximum drawdown
- Consecutive losses
- Open/pending/trades limits
- Spread/slippage/latency/API error streak
- Margin usage
- Data staleness/quality
- Reconciliation mismatch
- News blackout/shock
- Manual Kill Switch

## Kill Switch

Kill Switch ปิด Auto/Live unlock, เปลี่ยนกลับ Paper/Demo, ยกเลิก unsubmitted intents และล้าง pending execution ทันที. ไม่ force-close position ที่ Broker เพื่อหลีกเลี่ยงการปิดผิดบัญชี/ราคา; ผู้ใช้ต้องตรวจ Broker โดยตรง. Reconciliation ยังทำได้เมื่อเริ่ม controlled run ใหม่.

## Verified P/L

P/L ถูกบันทึกจาก Broker history row ที่ match deal/reference เท่านั้น. Position ที่หายโดยไม่มีหลักฐานจะอยู่ `RECONCILIATION_REQUIRED`; balance delta ไม่ถูกใช้ train model.
