# แก้ Cloudflare Build ค้างที่ npm ci

เอกสารนี้ใช้เมื่อ Cloudflare Build ติดตั้ง dependency ไม่สำเร็จ. v3.2 ใช้ public npm registry และต้องรัน Worker deployment ไม่ใช่ Static Pages อย่างเดียว

## ค่าปกติ (สร้างจาก source)

Build variable:

```text
SKIP_DEPENDENCY_INSTALL=true
```

Build command:

```bash
npm ci --registry=https://registry.npmjs.org/ --no-audit --no-fund --prefer-online && npm run build
```

Deploy command:

```bash
npm_config_registry=https://registry.npmjs.org/ npx --yes wrangler@latest deploy
```

## วิธีฉุกเฉิน (ใช้ dist ที่ build มาแล้ว)

ใช้ได้เมื่อ repository มี `dist/index.html`

Build command:

```bash
node scripts/validate-build.mjs
```

Deploy command:

```bash
npm_config_registry=https://registry.npmjs.org/ npx --yes wrangler@latest deploy
```

จากนั้น Clear Cache และ Retry deployment
