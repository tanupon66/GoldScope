#!/usr/bin/env sh
set -eu
command -v node >/dev/null 2>&1 || { echo "Node.js 20–22 is required."; exit 1; }
npm ci
npm run check
npm run test:e2e
npx wrangler deploy --dry-run
printf '\nPreflight passed. Follow CLOUDFLARE_DEPLOY_TH.md to create D1/Queues, apply migrations, set ADMIN_CREDENTIAL_HASH, SESSION_SIGNING_SECRET and Broker secrets, then run npx wrangler deploy.\n'
