# คู่มือ Deploy รุ่นเดิมถูกแทนที่แล้ว

เอกสารนี้คงชื่อเดิมไว้เพื่อไม่ให้ลิงก์เก่าขาด แต่ขั้นตอน v2.0.3 ที่ใช้ `ADMIN_PIN` ไม่ปลอดภัยและห้ามนำมาใช้กับ v3.

โปรดใช้เอกสารหลัก:

- `CLOUDFLARE_DEPLOY_TH.md`
- `SECRETS_REQUIRED_TH.md`
- `LIVE_READINESS_CHECKLIST_TH.md`

ลำดับสำคัญคือสร้าง D1/Queues, ตั้ง `ADMIN_CREDENTIAL_HASH` และ `SESSION_SIGNING_SECRET`, apply migration, ทำ dry-run แล้วจึง deploy. ห้ามใส่ Secret ใน source, GitHub, frontend หรือ localStorage.
