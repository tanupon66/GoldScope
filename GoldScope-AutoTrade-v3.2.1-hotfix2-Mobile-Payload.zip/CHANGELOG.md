# Changelog

## 3.2.1 — 2026-06-27

- เพิ่ม GitHub Actions Mobile One-Click Deploy ที่ทำงานได้จาก repository ซึ่งมีเพียง Payload ZIP โดยไม่ต้องใช้ Codespaces หรือ Terminal.
- เพิ่มโหมด `first_install` และ `safe_update`; safe update ไม่หมุน Cloudflare Secrets เดิม.
- เพิ่ม Cloudflare resource bootstrap แบบ idempotent สำหรับ D1 และ Queues ทั้ง 7 รายการ พร้อม generated Wrangler config ชั่วคราว.
- เพิ่มการ hash รหัสผู้ดูแล, สร้าง session secret และส่ง Secret ผ่าน `wrangler deploy --secrets-file` โดยไม่ commit ค่า Secret.
- เพิ่ม tests สำหรับ D1/Queue reuse, deployment config และ secret payload รวมทั้ง static workflow validation.
- เปลี่ยน Service Worker cache generation เป็น `goldscope-autotrade-shell-v321`.

## 3.2.0 — 2026-06-27

### Production hardening
- เปลี่ยน Service Worker cache generation เป็น `goldscope-autotrade-shell-v320` และเพิ่ม build validation ป้องกัน cache รุ่นเก่าหรือ source map หลุดในแพ็กเกจ.
- ปิด production sourcemap; hashed JavaScript/CSS ไม่มีไฟล์ `.map` ใน `dist`.
- เพิ่ม CSP, `X-Frame-Options: DENY`, anti-MIME-sniffing, referrer/permissions/cross-origin headers ใน `public/_headers` และยังคง security headers ฝั่ง Worker.
- ย้าย `/api/market` และ `/api/quote` เข้า authenticated route เพื่อป้องกันบุคคลภายนอกใช้ quota ของ Twelve Data ผ่าน Worker.
- ประกาศ `NEWS_API_BASE_URL` และ `ECONOMIC_CALENDAR_API_BASE_URL` ใน `wrangler.jsonc` เป็น non-secret vars.

### UX and PWA
- แทน `window.confirm()` ทั้งหมดด้วย confirmation dialog รูปแบบเดียวกัน รองรับ keyboard, focus, ข้อความเตือน และ typed confirmation สำหรับ Kill Switch/ล้างข้อมูล.
- ปรับหน้า Auto Trade เป็น Setup Wizard 4 ขั้น: พื้นฐาน, ความเสี่ยง, Forward Test และขั้นสูง โดยใช้ฟอร์มเดียวเพื่อรักษาค่าที่กรอกเมื่อเปลี่ยนขั้น.
- เพิ่ม progress navigation, mobile horizontal step navigation, sticky save summary และคำอธิบายที่เน้น Demo-first/NO_TRADE.
- อัปเดตภาพหน้าจอในชุดเอกสารจาก source ปัจจุบันที่ใช้ “รหัสผ่านผู้ดูแล”.

### Validation
- เพิ่ม Production hardening tests สำหรับ market authentication, CSP/anti-framing, Service Worker generation และ source-map policy.
- Unit/Integration/Fault tests รวม 27 files / 87 tests ก่อน final packaging.

## 3.1.0 — 2026-06-27

### Production execution
- แยกการวิเคราะห์ออกจากการส่ง Broker order: signal cycle สร้าง `Order Intent` และ Queue เท่านั้น ส่วน `order-execution` consumer เป็นจุดเดียวที่เรียก Broker POST.
- ตรวจ Kill Switch, enabled mode, environment, account, Epic, market status, quote freshness, entry zone, open position, working order, spread, latency และ Risk Gate ซ้ำด้วยราคาล่าสุดก่อนส่งจริง.
- Queue replay และ duplicate delivery คืนผลเดิมโดยไม่ส่ง POST ซ้ำ; timeout หลัง submit เปลี่ยนเป็น `UNKNOWN/RECONCILIATION_REQUIRED` และส่งไป reconcile ก่อน.
- Kill Switch ยกเลิก `CREATED/RISK_APPROVED/QUEUED` intents และล้าง pending execution ทันที แต่ไม่ปิด position ที่ Broker โดยอัตโนมัติ.
- Cron จะไม่สร้างงานให้บัญชี `setup` เมื่อไม่มี active account จึงไม่สะสม error/DLQ โดยไม่จำเป็น.

### Broker and reconciliation
- บังคับสลับไปยัง Capital.com `accountId` ที่ตั้งไว้ก่อนอ่านยอด/สถานะหรือส่งคำสั่ง.
- Reuse session และ refresh token metadata จาก response headers.
- เพิ่ม positions, working orders, activity history และ transaction history adapters.
- ยืนยัน P/L จากรายการ Broker ที่ match deal/reference เท่านั้น; เลิกเดาจากผลต่าง balance.
- เพิ่ม reconciliation events และ mismatch circuit breaker.

### Cloud pipeline
- เปิดใช้งาน consumers สำหรับ market ingestion, news ingestion, signal analysis, order execution, broker reconciliation, notification delivery และ dead-letter queue.
- เพิ่ม retry lease, exponential delay, idempotent queue receipts และหน้า DLQ สำหรับ retry/dismiss.
- เพิ่ม account → Durable Object mapping เพื่อให้ Cron และ Control Panel ใช้ state object เดียวกัน.
- เพิ่ม D1 migration `0002_operational_readiness.sql` สำหรับ Forward Test, DLQ, provider health, notifications, reconciliation และ model-governance events.

### Forward Test, health and notifications
- เพิ่ม Shadow Forward Test ด้วยข้อมูล Broker จริงโดยไม่ส่งออเดอร์เพิ่ม พร้อม spread/slippage assumption และ conservative same-candle handling.
- เพิ่ม System Health/Cloud Health, provider status, last scan, Queue/DLQ และ deployment version ใน UI.
- เพิ่ม Browser notification, Telegram และ signed webhook adapters พร้อม deduplication/cooldown ฝั่ง event store.

### Risk
- เพิ่ม weekly loss, current drawdown, margin usage และ reconciliation mismatch guards.
- เพิ่ม pre-submit latest-price risk recalculation และ entry-window expiry.
- Minimum-size/calibration/live-readiness rules เดิมยังมีอำนาจบล็อกคำสั่งทั้งหมด.

### Validation
- 26 Vitest files / 83 tests.
- Secret scan, production build, desktop/mobile E2E, two D1 migrations, Wrangler dry-run และ production dependency audit ผ่าน.

### Safety status
- พร้อม Deploy เพื่อ Paper, Forward Test, Confirm Demo และ Demo Auto หลังตั้ง Cloudflare/Broker จริง.
- Live Auto ยังถูกบล็อกจนมีหลักฐาน Readiness จากระบบที่ Deploy จริง; ไม่มีการรับประกันกำไร.

## 3.0.0 — 2026-06-26

### Security
- PBKDF2 admin credential, signed short-lived HttpOnly session, CSRF, logout/revocation and login lockout.
- Same-origin policy, security headers, secret redaction and D1 audit logging.
- Session/account/deploy-bound Live unlock with readiness gate.

### Execution safety
- Account-scoped Durable Object names.
- Persistent execution lock and deterministic order idempotency key.
- Order-intent state machine/checkpoints and reconciliation-required handling.
- Capital session reuse, bounded GET retry/backoff and no blind order POST retry.
- Removed balance-delta P/L learning when close confirmation is unknown.

### Data and intelligence
- Closed-candle/data-quality checks and no mock fill in Broker data path.
- News/economic-event adapter, deduplication, decay and high-impact blackout.
- Calibration and Live Readiness modules.
- Champion/Challenger promotion/rollback primitives.
