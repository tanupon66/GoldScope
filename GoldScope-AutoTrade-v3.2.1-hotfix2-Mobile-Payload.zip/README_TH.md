# GoldScope AutoTrade v3.2.1 — Mobile One-Click Cloudflare Candidate

PWA วิเคราะห์ XAU/USD พร้อม secure session, account-scoped Durable Objects, D1, Queue pipeline, Shadow Forward Test, single-submit order execution, Broker reconciliation, System Health/DLQ และ gated Live Readiness.

## ติดตั้งจากโทรศัพท์โดยไม่ใช้ Codespaces

ใช้ `GoldScope-AutoTrade-v3.2.1-Mobile-Payload.zip` และ workflow `GoldScope-Mobile-One-Click-Deploy.yml` ตาม `MOBILE_ONE_CLICK_INSTALL_TH.md`. Workflow สามารถสร้าง/reuse D1 และ Queues, apply migrations, test และ deploy จากปุ่ม Run workflow.

## ตรวจสอบก่อน Deploy

```bash
npm ci
npm run check
npm run test:e2e
npx wrangler deploy --dry-run
npm audit --omit=dev
```

อ่านตามลำดับ:

1. `TEST_REPORT.md`
2. `KNOWN_LIMITATIONS.md`
3. `ARCHITECTURE.md`
4. `SECURITY.md`
5. `RISK_ENGINE.md`
6. `CLOUDFLARE_DEPLOY_TH.md`
7. `USER_MANUAL_TH.md`
8. `LIVE_READINESS_CHECKLIST_TH.md`

**สถานะ:** พร้อมนำไป Deploy และพิสูจน์ Paper/Forward/Capital Demo. ยังไม่ถือว่า Live-ready จนมีหลักฐานจากบัญชีจริงตาม checklist และไม่มีการรับประกันผลตอบแทน.
