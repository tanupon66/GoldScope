# Delivery Manifest — GoldScope AutoTrade v3.2.1

## Mobile One-Click

- `GoldScope-AutoTrade-v3.2.1-Mobile-Installer.zip` — ชุดติดตั้งจากโทรศัพท์ ประกอบด้วย Payload ZIP, Workflow และคู่มือภาษาไทย.
- `GoldScope-AutoTrade-v3.2.1-Mobile-Payload.zip` — Source payload ไฟล์เดียวสำหรับอัปโหลดเข้า Private GitHub repository.
- `GoldScope-Mobile-One-Click-Deploy.yml` — ต้องสร้างใน GitHub path `.github/workflows/mobile-one-click-deploy.yml`.
- `MOBILE_ONE_CLICK_INSTALL_TH.md` — คู่มือติดตั้งแบบไม่ใช้ Codespaces/Terminal.

## Standard delivery

- `GoldScope-AutoTrade-v3.2.1-Source.zip` — source, Worker, PWA, tests, migrations, workflow และเอกสาร.
- `GoldScope-AutoTrade-v3.2.1-Build.zip` — static PWA build only; ไม่รวม Worker/D1/DO/Queues.
- `GoldScope-AutoTrade-v3.2.1-Patch.zip` — changed files สำหรับ Source v3.2.0.
- `GoldScope-AutoTrade-v3.2.1.patch` — unified text patch จาก v3.2.0.
- `GoldScope-AutoTrade-v3.2.1-Documentation.zip` — เอกสาร Markdown และคู่มือ Mobile One-Click.
- `GoldScope-AutoTrade-v3.2.1-Delivery.zip` — รวมชุดส่งมอบทั้งหมด.
- `GoldScope-AutoTrade-v3.2.1-SHA256SUMS.txt` — checksums.
- `GoldScope-AutoTrade-v3.2.1-FINAL_VALIDATION.txt` — validation summary.
