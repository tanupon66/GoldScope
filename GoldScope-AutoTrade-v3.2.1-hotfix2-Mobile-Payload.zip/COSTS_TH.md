# ค่าใช้จ่ายที่อาจเกิดขึ้น

ราคาและโควตา Cloudflare/API เปลี่ยนได้ จึงไม่ฝังค่าเงินตายตัวในเอกสารรุ่นนี้. ก่อน Deploy ให้ตรวจ pricing ปัจจุบันของ:

- Cloudflare Workers requests/CPU
- Durable Objects requests/storage
- D1 rows read/write/storage
- Queues operations, retention และ egress ที่เกี่ยวข้อง
- Log/observability retention
- Twelve Data/news/economic calendar provider
- Telegram หรือ webhook infrastructure

Cron ทุกนาที + market/news ทุก 5 นาที + Queue/D1 trace มีต้นทุนตามจำนวน active accounts. เริ่มหนึ่ง Demo account, ดู Usage Dashboard และตั้ง budget alert ก่อนเพิ่มบัญชี.

ต้นทุน Broker ยังรวม spread, slippage, commission และ overnight/financing ตาม instrument/account. Backtest/Forward assumptions ต้องเทียบกับ statement จริงเสมอ.
