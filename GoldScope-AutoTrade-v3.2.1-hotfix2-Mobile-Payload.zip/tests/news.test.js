import { describe, expect, it } from 'vitest';
import { newsAgeWeight, deduplicateNews, evaluateHighImpactBlackout } from '../src/core/news.js';

describe('news and event risk', () => {
  it('decays old news weight', () => {
    const now = Date.UTC(2026, 0, 1, 12);
    expect(newsAgeWeight(new Date(now).toISOString(), now)).toBeCloseTo(1, 4);
    expect(newsAgeWeight(new Date(now - 180 * 60_000).toISOString(), now, 180)).toBeCloseTo(0.5, 3);
  });

  it('deduplicates repeated provider stories', () => {
    const items = [
      { duplicateGroup: 'a', title: 'old', publishedAt: '2026-01-01T00:00:00Z' },
      { duplicateGroup: 'a', title: 'new', publishedAt: '2026-01-01T01:00:00Z' }
    ];
    expect(deduplicateNews(items)).toEqual([items[1]]);
  });

  it('blocks entries around a high-impact USD event', () => {
    const now = Date.UTC(2026, 0, 1, 12);
    const report = evaluateHighImpactBlackout([{ currency: 'USD', impactLevel: 'HIGH', eventName: 'NFP', scheduledAt: new Date(now + 10 * 60_000).toISOString() }], {}, now);
    expect(report.blocked).toBe(true);
  });
});
