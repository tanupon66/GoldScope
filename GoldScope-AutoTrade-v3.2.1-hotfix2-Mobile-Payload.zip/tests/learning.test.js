import { describe, expect, it } from 'vitest';
import { applyAdaptiveLearning, buildAdaptiveModel, learningLeaderboard } from '../src/core/learning.js';

const settings = {
  adaptiveLearning: true,
  learningMinSamples: 20,
  learningMaxAdjustment: 8,
  learningLookback: 400,
  learningUseDemo: false,
  learningResetAt: 0
};

function makeTrades({ wins = 0, losses = 0, mode = 'live', strategyKey = 'trend-pullback' } = {}) {
  const now = Date.now();
  return [
    ...Array.from({ length: wins }, (_, i) => ({
      id: `w-${i}`, strategyKey, strategy: 'Trend pullback', timeframe: '15min', regime: 'Trend', direction: 1,
      dataMode: mode, status: 'COMPLETED', resultR: 1.8, endedAt: now - i * 1000
    })),
    ...Array.from({ length: losses }, (_, i) => ({
      id: `l-${i}`, strategyKey, strategy: 'Trend pullback', timeframe: '15min', regime: 'Trend', direction: 1,
      dataMode: mode, status: 'STOPPED', resultR: -1, endedAt: now - (wins + i) * 1000
    }))
  ];
}

const candidate = {
  strategyKey: 'trend-pullback', strategy: 'Trend pullback', timeframe: '15min', regime: 'Trend', direction: 1,
  score: 70, evidence: [], warnings: []
};

describe('adaptive learning', () => {
  it('raises future scores for a sufficiently profitable pattern', () => {
    const model = buildAdaptiveModel(makeTrades({ wins: 28, losses: 12 }), settings, 'live');
    const learned = applyAdaptiveLearning([candidate], model, settings)[0];
    expect(model.eligibleTrades).toBe(40);
    expect(learned.adaptiveAdjustment).toBeGreaterThan(0);
    expect(learned.score).toBeGreaterThan(candidate.score);
    expect(learned.adaptiveAdjustment).toBeLessThanOrEqual(settings.learningMaxAdjustment);
    expect(learned.learnedWinRate).toBeGreaterThan(50);
  });

  it('reduces scores for a losing pattern and respects adjustment limit', () => {
    const model = buildAdaptiveModel(makeTrades({ wins: 7, losses: 33 }), settings, 'live');
    const learned = applyAdaptiveLearning([candidate], model, settings)[0];
    expect(learned.adaptiveAdjustment).toBeLessThan(0);
    expect(learned.score).toBeLessThan(candidate.score);
    expect(learned.adaptiveAdjustment).toBeGreaterThanOrEqual(-settings.learningMaxAdjustment);
  });

  it('does not learn from demo results by default', () => {
    const model = buildAdaptiveModel(makeTrades({ wins: 40, mode: 'demo' }), settings, 'demo');
    const learned = applyAdaptiveLearning([candidate], model, settings)[0];
    expect(model.eligibleTrades).toBe(0);
    expect(learned.adaptiveAdjustment).toBe(0);
    expect(learned.score).toBe(candidate.score);
  });

  it('uses gradual confidence and ignores cancelled/zero-R records', () => {
    const rows = [
      ...makeTrades({ wins: 8, losses: 1 }),
      { ...makeTrades({ wins: 1 })[0], id: 'cancelled', status: 'CANCELLED', resultR: 0 }
    ];
    const model = buildAdaptiveModel(rows, settings, 'live');
    const learned = applyAdaptiveLearning([candidate], model, settings)[0];
    expect(model.eligibleTrades).toBe(9);
    expect(model.overall.confidence).toBeGreaterThan(0);
    expect(model.overall.confidence).toBeLessThan(20);
    expect(Math.abs(learned.adaptiveAdjustment)).toBeLessThan(2);
  });

  it('creates a ranked strategy/timeframe learning table', () => {
    const model = buildAdaptiveModel(makeTrades({ wins: 28, losses: 12 }), settings, 'live');
    const rows = learningLeaderboard(model);
    expect(rows.length).toBeGreaterThan(0);
    expect(rows[0].key.startsWith('strategy-tf:')).toBe(true);
  });
});
