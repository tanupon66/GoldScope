import { describe, expect, it } from 'vitest';
import { expectedPnlPerUsdMove, evaluateBrokerCalibration } from '../src/core/calibration.js';

describe('broker calibration', () => {
  it('scales P/L by actual size', () => {
    expect(expectedPnlPerUsdMove({ size: 0.02, referenceSize: 0.01, pnlPerUsdMoveAtReferenceSize: 1 })).toBe(2);
  });

  it('detects a P/L conversion mismatch', () => {
    const result = evaluateBrokerCalibration({
      size: 0.01, referenceSize: 0.01, pnlPerUsdMoveAtReferenceSize: 1, observedPnlPerUsdMove: 0.1,
      minimumSize: 0.01, sizeStep: 0.01, currency: 'USD', tickSize: 0.01
    });
    expect(result.passed).toBe(false);
    expect(result.reasons).toContain('PNL_CONVERSION_MISMATCH');
  });
});
