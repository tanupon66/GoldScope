import { describe, expect, it } from 'vitest';
import { refreshIntervalMs, staleThresholdMs, isDataStale, secondsUntilRefresh, dataAgeSeconds } from '../src/core/sync.js';

describe('automatic refresh lifecycle helpers', () => {
  it('normalizes the refresh interval to at least 30 seconds', () => {
    expect(refreshIntervalMs({ refreshSeconds: 10 })).toBe(30_000);
    expect(refreshIntervalMs({ refreshSeconds: 90 })).toBe(90_000);
  });

  it('detects missed refreshes after the grace period', () => {
    const now = 1_000_000;
    const settings = { refreshSeconds: 60 };
    expect(staleThresholdMs(settings)).toBe(72_000);
    expect(isDataStale(now - 60_000, settings, now)).toBe(false);
    expect(isDataStale(now - 73_000, settings, now)).toBe(true);
  });

  it('calculates countdown and data age safely', () => {
    expect(secondsUntilRefresh(110_100, 100_000)).toBe(11);
    expect(secondsUntilRefresh(99_000, 100_000)).toBe(0);
    expect(dataAgeSeconds(95_500, 100_000)).toBe(4);
    expect(dataAgeSeconds(null, 100_000)).toBeNull();
  });
});
