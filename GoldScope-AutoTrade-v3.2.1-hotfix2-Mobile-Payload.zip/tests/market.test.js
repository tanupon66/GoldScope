import { describe, expect, it } from 'vitest';
import { generateMockCandles } from '../src/mock/generator.js';
import { analyzeTimeframe, combineMarketBias } from '../src/core/market.js';

it('analyzes all core market fields', () => {
  const a = analyzeTimeframe(generateMockCandles('15min', 500), '15min');
  expect(a.snapshot.close).toBeGreaterThan(0);
  expect(Number.isFinite(a.snapshot.atr)).toBe(true);
  expect(a.levels.supports).toBeInstanceOf(Array);
  expect(a.fvgs).toBeInstanceOf(Array);
  expect(a.directionStrength).toBeGreaterThanOrEqual(0);
});

it('combines multi-timeframe bias', () => {
  const analyses = Object.fromEntries(['5min','15min','1h','4h'].map((tf,i) => [tf, analyzeTimeframe(generateMockCandles(tf, 500, 100+i), tf)]));
  const bias = combineMarketBias(analyses);
  expect([-1,0,1]).toContain(bias.direction);
  expect(bias.conflict).toBeGreaterThanOrEqual(0);
  expect(bias.conflict).toBeLessThanOrEqual(100);
});

it('calculates finite buy and sell pressure that sums to 100', () => {
  const a = analyzeTimeframe(generateMockCandles('15min', 500), '15min');
  expect(Number.isFinite(a.snapshot.buyPressure)).toBe(true);
  expect(Number.isFinite(a.snapshot.sellPressure)).toBe(true);
  expect(a.snapshot.buyPressure + a.snapshot.sellPressure).toBeCloseTo(100, 6);
  expect(a.snapshot.pressureConfidence).toBeGreaterThanOrEqual(0);
  expect(a.snapshot.pressureConfidence).toBeLessThanOrEqual(100);
});
