import { describe, expect, it, vi } from 'vitest';
import worker from '../worker/index.js';

function d1WithNoAccounts() {
  return {
    prepare(sql) {
      return {
        bind() { return this; },
        async all() {
          if (String(sql).includes('FROM accounts WHERE active = 1')) return { results: [] };
          return { results: [] };
        },
        async run() { return { success: true, meta: { changes: 1 } }; },
        async first() { return null; }
      };
    }
  };
}

describe('cron scheduler safety', () => {
  it('does not enqueue setup-account jobs when no active account exists', async () => {
    const send = vi.fn(async () => { throw new Error('queue must not be called'); });
    const env = {
      DB: d1WithNoAccounts(),
      SIGNAL_ANALYSIS_QUEUE: { send }, MARKET_INGESTION_QUEUE: { send }, NEWS_INGESTION_QUEUE: { send }
    };
    let scheduledWork;
    await worker.scheduled({ cron: '*/1 * * * *' }, env, { waitUntil(promise) { scheduledWork = promise; } });
    await scheduledWork;
    expect(send).not.toHaveBeenCalled();
  });
});
