import { describe, expect, it } from 'vitest';
import { sma, ema, rsi, atr, macd } from '../src/core/indicators.js';

const candles = Array.from({ length: 60 }, (_, i) => ({
  time: i,
  open: 100 + i,
  high: 101 + i,
  low: 99 + i,
  close: 100.5 + i,
  volume: 100
}));

describe('indicators', () => {
  it('calculates SMA correctly', () => {
    const result = sma([1,2,3,4,5], 3);
    expect(result).toEqual([null,null,2,3,4]);
  });

  it('EMA converges and preserves length', () => {
    const result = ema([1,2,3,4,5,6,7], 3);
    expect(result).toHaveLength(7);
    expect(result.at(-1)).toBeGreaterThan(result.at(-2));
  });

  it('RSI reaches 100 on monotonic rise', () => {
    const result = rsi(Array.from({length:40}, (_,i)=>i+1), 14);
    expect(result.at(-1)).toBe(100);
  });

  it('ATR and MACD return finite latest values', () => {
    expect(Number.isFinite(atr(candles,14).at(-1))).toBe(true);
    const m = macd(candles.map(c=>c.close));
    expect(Number.isFinite(m.histogram.at(-1))).toBe(true);
  });
});
