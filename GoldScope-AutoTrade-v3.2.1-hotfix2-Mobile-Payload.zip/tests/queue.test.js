import { describe, expect, it } from 'vitest';
import { normalizeQueueEnvelope, queueIdempotencyKey, retryDelaySeconds } from '../src/core/queue.js';

describe('queue reliability primitives', () => {
  it('creates stable idempotency key for the same bucket', () => {
    expect(queueIdempotencyKey('ANALYZE_SIGNAL', 'capital:demo:abc', 42))
      .toBe(queueIdempotencyKey('ANALYZE_SIGNAL', 'capital:demo:abc', 42));
  });
  it('preserves the highest delivery attempt and state object mapping', () => {
    const message = normalizeQueueEnvelope({ eventType: 'EXECUTE_ORDER', accountKey: 'capital:demo:a', stateObjectKey: 'capital:demo:setup', attempt: 1 }, 3);
    expect(message.attempt).toBe(3);
    expect(message.stateObjectKey).toBe('capital:demo:setup');
  });
  it('backs off retries with a maximum cap', () => {
    expect(retryDelaySeconds(0)).toBe(30);
    expect(retryDelaySeconds(4)).toBe(480);
    expect(retryDelaySeconds(20)).toBe(900);
  });
});
