import { describe, expect, it } from 'vitest';
import { evaluatePlan } from '../src/core/plans.js';

const base = {
  id:'x', direction:1, status:'WAITING_ENTRY', sourceCandleTime:100,
  entryLow:99.8, entryHigh:100.2, entry:100, stopLoss:98, tp1:102, tp2:103, tp3:104,
  stopDistance:2, expiresAt:9999999999999, progress:{tp1:false,tp2:false,tp3:false}
};

it('activates then completes plan', () => {
  const candles = [
    {time:101,open:101,high:101.2,low:99.9,close:100.2},
    {time:102,open:100.2,high:104.2,low:100,close:104}
  ];
  const result = evaluatePlan(base,candles);
  expect(result.status).toBe('COMPLETED');
  expect(result.progress.tp3).toBe(true);
});

it('uses conservative stop when same candle hits stop and target', () => {
  const candles = [{time:101,open:100,high:105,low:97,close:101}];
  const result = evaluatePlan(base,candles);
  expect(result.status).toBe('STOPPED');
  expect(result.resultR).toBe(-1);
});
