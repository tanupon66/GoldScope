import { afterEach, describe, expect, it, vi } from 'vitest';
import { executeQueuedOrder } from '../worker/engine.js';
import { createOrderIntent, transitionOrderIntent } from '../src/core/idempotency.js';
import { defaultAutoTradeState, normalizeAutoTradeConfig } from '../src/core/autotrade.js';

afterEach(() => vi.unstubAllGlobals());

function makeState() {
  const now = 1000;
  const key = 'gsi_test';
  let intent = createOrderIntent({ idempotencyKey: key, signal: { id: 'sig' }, accountKey: 'capital:demo:A', now });
  intent = transitionOrderIntent(intent, 'RISK_APPROVED', { reason: 'test' }, now + 1);
  intent = transitionOrderIntent(intent, 'QUEUED', { reason: 'test' }, now + 2);
  const plan = { id: 'p1', direction: 1, directionLabel: 'BUY', entryLow: 2299, entryHigh: 2301, stopLoss: 2298, tp1: 2302, tp2: 2304, tp3: 2306, strategy: 'Trend', strategyKey: 'trend', timeframe: '5min', score: 80 };
  return {
    ...defaultAutoTradeState(now),
    activeAccountKey: 'capital:demo:A',
    brokerSession: { cst: 'c', securityToken: 's', createdAt: Date.now(), account: { accountId: 'A' } },
    orderIntents: { [key]: intent },
    pendingExecutions: {
      [key]: {
        idempotencyKey: key, plan, epic: 'GOLD', signal: { id: 'sig', currentPrice: 2300 },
        config: { brokerEnvironment: 'demo', accountId: 'A' },
        account: { accountId: 'A', balance: 100 }, orderSize: 0.01, entry: 2300, target: 2304,
        initialRiskUsd: 2, valuePerPriceUnit: 1,
        request: { epic: 'GOLD', direction: 'BUY', size: 0.01, stopLevel: 2298, profitLevel: 2304 }, createdAt: now
      }
    }
  };
}

const config = normalizeAutoTradeConfig({
  enabled: true, executionMode: 'auto', brokerEnvironment: 'demo', accountId: 'A',
  maxLossPerTradeUsd: 5, riskPercentPerTrade: 10, maxSpreadUsd: 1,
  cooldownMinutes: 0, maxMarginUsagePercent: 100, requireFreshCandleSeconds: 120
});
const env = { CAPITAL_API_KEY: 'test-api-key' };

function json(body, status = 200) { return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } }); }

describe('single-submit order execution consumer', () => {
  it('submits once, confirms, and makes a replay harmless', async () => {
    const calls = [];
    vi.stubGlobal('fetch', vi.fn(async (url, init = {}) => {
      calls.push({ url: String(url), method: init.method || 'GET' });
      if (String(url).endsWith('/accounts')) return json({ accounts: [{ accountId: 'A', status: 'ENABLED', currency: 'USD', balance: { balance: 100, available: 90 } }] });
      if (String(url).endsWith('/markets/GOLD')) return json({ instrument: { name: 'Gold' }, snapshot: { bid: 2299.9, offer: 2300.1, marketStatus: 'TRADEABLE', updateTime: new Date().toISOString() }, dealingRules: { minDealSize: { value: 0.01, unit: 'POINTS' } } });
      if (String(url).endsWith('/positions') && (init.method || 'GET') === 'GET') return json({ positions: [] });
      if (String(url).endsWith('/workingorders')) return json({ workingOrders: [] });
      if (String(url).endsWith('/positions') && init.method === 'POST') return json({ dealReference: 'R1' });
      if (String(url).endsWith('/confirms/R1')) return json({ dealStatus: 'ACCEPTED', affectedDeals: [{ status: 'OPENED', dealId: 'D1' }] });
      throw new Error(`unexpected ${url}`);
    }));
    const first = await executeQueuedOrder({ env, config, state: makeState(), idempotencyKey: 'gsi_test', services: {} });
    expect(first.state.orderIntents.gsi_test.state).toBe('OPEN');
    expect(first.state.pendingExecutions.gsi_test).toBeUndefined();
    expect(calls.filter(call => call.method === 'POST').length).toBe(1);
    const second = await executeQueuedOrder({ env, config, state: first.state, idempotencyKey: 'gsi_test', services: {} });
    expect(second.state.status).toBe('IDEMPOTENT_REPLAY');
    expect(calls.filter(call => call.method === 'POST').length).toBe(1);
  });

  it('marks UNKNOWN after a submit timeout and never retries the POST in the same execution', async () => {
    let postCount = 0;
    vi.stubGlobal('fetch', vi.fn(async (url, init = {}) => {
      if (String(url).endsWith('/accounts')) return json({ accounts: [{ accountId: 'A', status: 'ENABLED', currency: 'USD', balance: { balance: 100, available: 90 } }] });
      if (String(url).endsWith('/markets/GOLD')) return json({ instrument: { name: 'Gold' }, snapshot: { bid: 2299.9, offer: 2300.1, marketStatus: 'TRADEABLE', updateTime: new Date().toISOString() }, dealingRules: { minDealSize: { value: 0.01, unit: 'POINTS' } } });
      if (String(url).endsWith('/positions') && (init.method || 'GET') === 'GET') return json({ positions: [] });
      if (String(url).endsWith('/workingorders')) return json({ workingOrders: [] });
      if (String(url).endsWith('/positions') && init.method === 'POST') { postCount += 1; throw new Error('network timeout after submit'); }
      throw new Error(`unexpected ${url}`);
    }));
    const result = await executeQueuedOrder({ env, config, state: makeState(), idempotencyKey: 'gsi_test', services: {} });
    expect(result.state.orderIntents.gsi_test.state).toBe('UNKNOWN');
    expect(result.state.status).toBe('RECONCILIATION_REQUIRED');
    expect(postCount).toBe(1);
  });

  it('blocks a queued order after Kill Switch without calling Broker POST', async () => {
    let postCount = 0;
    vi.stubGlobal('fetch', vi.fn(async (url, init = {}) => {
      if (init.method === 'POST') postCount += 1;
      throw new Error(`Broker must not be called after Kill Switch: ${url}`);
    }));
    const state = { ...makeState(), status: 'KILLED' };
    const result = await executeQueuedOrder({ env, config, state, idempotencyKey: 'gsi_test', services: {} });
    expect(result.state.orderIntents.gsi_test.state).toBe('FAILED');
    expect(result.state.status).toBe('ORDER_BLOCKED');
    expect(result.state.pendingExecutions.gsi_test).toBeUndefined();
    expect(postCount).toBe(0);
  });

});
