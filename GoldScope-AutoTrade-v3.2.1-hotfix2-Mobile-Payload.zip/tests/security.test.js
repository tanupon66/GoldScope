import { describe, expect, it } from 'vitest';
import crypto from 'node:crypto';
import { timingSafeEqualBytes, verifyAdminCredential, createSessionToken, verifySessionToken } from '../worker/security.js';

const b64 = value => value.toString('base64url');

describe('authentication security', () => {
  it('compares byte arrays without early length exit', () => {
    expect(timingSafeEqualBytes(new Uint8Array([1, 2]), new Uint8Array([1, 2]))).toBe(true);
    expect(timingSafeEqualBytes(new Uint8Array([1, 2]), new Uint8Array([1, 3]))).toBe(false);
    expect(timingSafeEqualBytes(new Uint8Array([1]), new Uint8Array([1, 0]))).toBe(false);
  });

  it('verifies a PBKDF2 password hash', async () => {
    const password = 'strong-password';
    const salt = crypto.randomBytes(16);
    const iterations = 120000;
    const hash = crypto.pbkdf2Sync(password, salt, iterations, 32, 'sha256');
    const encoded = `pbkdf2-sha256$${iterations}$${b64(salt)}$${b64(hash)}`;
    await expect(verifyAdminCredential(password, encoded)).resolves.toBe(true);
    await expect(verifyAdminCredential('wrong', encoded)).resolves.toBe(false);
  });

  it('signs and expires short-lived sessions', async () => {
    const created = await createSessionToken({ secret: 'x'.repeat(40), ttlSeconds: 60, version: '3.0.0' });
    const valid = await verifySessionToken(created.token, 'x'.repeat(40), created.payload.iat + 10);
    expect(valid.ok).toBe(true);
    const expired = await verifySessionToken(created.token, 'x'.repeat(40), created.payload.exp + 1);
    expect(expired.code).toBe('SESSION_EXPIRED');
  });
});
