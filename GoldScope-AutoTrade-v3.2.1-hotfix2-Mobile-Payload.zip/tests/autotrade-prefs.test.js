import { describe, expect, it } from 'vitest';
import {
  AUTO_TRADE_DISPLAY_CACHE_KEY,
  createAutoTradeDisplaySnapshot,
  loadAutoTradeDisplaySnapshot,
  saveAutoTradeDisplaySnapshot,
  clearAutoTradeDisplaySnapshot
} from '../src/core/autotradePrefs.js';

function memoryStorage(initial = {}) {
  const data = new Map(Object.entries(initial));
  return {
    getItem: key => data.has(key) ? data.get(key) : null,
    setItem: (key, value) => data.set(key, String(value)),
    removeItem: key => data.delete(key),
    dump: () => data
  };
}

describe('Auto Trade display cache', () => {
  it('keeps display settings but excludes PIN, unlock phrase and model payloads', () => {
    const snapshot = createAutoTradeDisplaySnapshot({
      executionMode: 'auto', brokerEnvironment: 'demo', orderSize: 0.02,
      adminPin: '1234567890', liveUnlockPhrase: 'LIVE',
      learningRecords: [{ id: 'secret-ish' }], algorithmSettings: { accountSize: 20 }
    }, 1234);
    expect(snapshot.savedAt).toBe(1234);
    expect(snapshot.config.executionMode).toBe('auto');
    expect(snapshot.config.orderSize).toBe(0.02);
    expect(snapshot.config).not.toHaveProperty('adminPin');
    expect(snapshot.config).not.toHaveProperty('liveUnlockPhrase');
    expect(snapshot.config).not.toHaveProperty('learningRecords');
    expect(snapshot.config).not.toHaveProperty('algorithmSettings');
  });

  it('round-trips settings through local storage', () => {
    const store = memoryStorage();
    saveAutoTradeDisplaySnapshot({ enabled: true, minScore: 81, pnlPerUsdMoveAtReferenceSize: 0.01 }, store);
    const loaded = loadAutoTradeDisplaySnapshot(store);
    expect(loaded.config.enabled).toBe(true);
    expect(loaded.config.minScore).toBe(81);
    expect(loaded.config.pnlPerUsdMoveAtReferenceSize).toBe(0.01);
    expect(store.dump().has(AUTO_TRADE_DISPLAY_CACHE_KEY)).toBe(true);
  });

  it('fails safely for corrupt cache and can clear it', () => {
    const store = memoryStorage({ [AUTO_TRADE_DISPLAY_CACHE_KEY]: '{bad json' });
    expect(loadAutoTradeDisplaySnapshot(store)).toBeNull();
    saveAutoTradeDisplaySnapshot({ executionMode: 'confirm' }, store);
    clearAutoTradeDisplaySnapshot(store);
    expect(loadAutoTradeDisplaySnapshot(store)).toBeNull();
  });
});
