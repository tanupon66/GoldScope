import { describe, expect, it } from 'vitest';
import { evaluateLiveReadiness } from '../src/core/readiness.js';

describe('live readiness gate', () => {
  it('blocks an unproven system', () => {
    const result = evaluateLiveReadiness({});
    expect(result.passed).toBe(false);
    expect(result.blockingReasons).toContain('DEMO_TRADES');
  });

  it('passes only when all engineering checks pass', () => {
    const result = evaluateLiveReadiness({
      calibrationPassed: true, closedDemoTrades: 120, forwardTestDays: 35, criticalExecutionErrors: 0,
      duplicateOrders: 0, unresolvedOrderIntents: 0, outOfSampleExpectancy: 0.08, maximumDrawdownPercent: 8,
      killSwitchTestPassed: true, reconciliationTestPassed: true, configFrozen: true
    });
    expect(result.passed).toBe(true);
  });
});
