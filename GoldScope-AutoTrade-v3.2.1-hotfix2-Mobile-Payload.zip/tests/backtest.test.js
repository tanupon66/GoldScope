import { expect, it } from 'vitest';
import { generateMockCandles } from '../src/mock/generator.js';
import { monteCarloTradeOrder, runBacktest, stressTestTradeResults } from '../src/core/backtest.js';

it('runs walk-forward backtest and returns metrics', () => {
  const result = runBacktest(generateMockCandles('15min', 420), '15min', { minScore: 55 });
  expect(result.summary.trades).toBeGreaterThanOrEqual(0);
  expect(result.summary.curve).toHaveLength(result.summary.trades);
  expect(Number.isFinite(result.summary.netR)).toBe(true);
});

it('uses the current adaptive model during backtest without learning from backtest outcomes', () => {
  const stats = { eligible:true, adjustment:5, winRate:60, expectancyR:0.3, confidence:80, samples:40, label:'test' };
  const groups = {};
  for (const key of ['trend-pullback','momentum-continuation','breakout-retest','range-mean-reversion']) {
    groups[`strategy-tf:${key}|15min`] = { key:`strategy-tf:${key}|15min`, ...stats };
  }
  const model = { enabled:true, eligibleTrades:160, overall:{confidence:80,expectancyR:0.3}, groups, fingerprint:'gs-test' };
  const result = runBacktest(generateMockCandles('15min', 600), '15min', { minScore:45, adaptiveLearning:true, accountSize:1000, positionSizingMode:'risk', riskPercent:1, maxLot:1, profile:'balanced', maxExpectedBarsToTp2:5, maxTargetAtr:5 }, model);
  expect(result.adaptive.enabled).toBe(true);
  expect(result.adaptive.fingerprint).toBe('gs-test');
  expect(result.summary.trades).toBeGreaterThan(0);
  expect(result.adaptive.adjustedTrades).toBe(result.summary.trades);
  expect(result.trades.some(trade => trade.adaptiveAdjustment > 0)).toBe(true);
});


it('reports deterministic Monte Carlo and cost stress results', () => {
  const trades = [{ resultR: 1 }, { resultR: -1 }, { resultR: 2 }, { resultR: -0.5 }];
  expect(monteCarloTradeOrder(trades, { iterations: 100, seed: 7 })).toEqual(monteCarloTradeOrder(trades, { iterations: 100, seed: 7 }));
  const stress = stressTestTradeResults(trades, { spreadMultiplier: 2, slippageR: 0.1, delayedEntryR: 0.1 });
  expect(stress.summary.netR).toBeLessThan(1.5);
});
