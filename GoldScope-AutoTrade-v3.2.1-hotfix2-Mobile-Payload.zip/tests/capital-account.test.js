import { afterEach, describe, expect, it, vi } from 'vitest';
import { CapitalClient } from '../worker/capital.js';

afterEach(() => vi.unstubAllGlobals());

function response(body, { status = 200, headers = {} } = {}) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', ...headers } });
}

describe('Capital account and history adapter', () => {
  it('switches to the configured account before returning summary', async () => {
    const calls = [];
    vi.stubGlobal('fetch', vi.fn(async (url, init = {}) => {
      calls.push({ url: String(url), method: init.method || 'GET', body: init.body });
      if ((init.method || 'GET') === 'PUT') return response({ accountId: 'B' }, { headers: { CST: 'c2', 'X-SECURITY-TOKEN': 's2' } });
      return response({ accounts: [
        { accountId: 'A', status: 'ENABLED', currency: 'USD', balance: { balance: 100, available: 90 } },
        { accountId: 'B', status: 'ENABLED', currency: 'USD', balance: { balance: 200, available: 180 } }
      ] });
    }));
    const client = new CapitalClient({ CAPITAL_API_KEY: 'test-api-key' }, 'demo', { cst: 'c', securityToken: 's', createdAt: Date.now(), account: { accountId: 'A' } });
    const account = await client.accountSummary('B');
    expect(account.accountId).toBe('B');
    expect(calls.some(call => call.method === 'PUT' && call.url.endsWith('/api/v1/session'))).toBe(true);
    expect(client.exportSession().cst).toBe('c2');
  });

  it('requests exact broker history without retrying an order POST', async () => {
    vi.stubGlobal('fetch', vi.fn(async url => response({ transactions: [{ reference: 'D1', amount: 1.25, currency: 'USD' }] })));
    const client = new CapitalClient({ CAPITAL_API_KEY: 'test-api-key' }, 'demo', { cst: 'c', securityToken: 's', createdAt: Date.now(), account: { accountId: 'A' } });
    const history = await client.transactionHistory({ lastPeriod: 60, type: 'TRADE' });
    expect(history.transactions[0].reference).toBe('D1');
  });
});
