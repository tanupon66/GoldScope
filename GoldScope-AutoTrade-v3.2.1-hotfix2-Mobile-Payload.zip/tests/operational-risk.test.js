import { describe, expect, it } from 'vitest';
import { checkRiskGuards, defaultAutoTradeState, normalizeAutoTradeConfig, recordClosedTrade, utcWeekKey } from '../src/core/autotrade.js';

describe('operational circuit breakers', () => {
  const config = normalizeAutoTradeConfig({ enabled: true, cooldownMinutes: 0, maxWeeklyLossUsd: 4, maxDrawdownPercent: 20, maxMarginUsagePercent: 35, maxReconciliationMismatch: 1 });
  it('blocks after weekly loss limit', () => {
    const state = { ...defaultAutoTradeState(), weekly: { week: utcWeekKey(), trades: 3, realizedPnlUsd: -4 } };
    expect(checkRiskGuards({ config, state }).reasons.join(' ')).toContain('สัปดาห์');
  });
  it('blocks drawdown, margin and reconciliation mismatch independently', () => {
    const state = { ...defaultAutoTradeState(), currentDrawdownPercent: 25, marginUsagePercent: 40, reconciliationMismatch: 2 };
    const reasons = checkRiskGuards({ config, state }).reasons.join(' ');
    expect(reasons).toContain('Drawdown');
    expect(reasons).toContain('Margin');
    expect(reasons).toContain('Broker');
  });
  it('updates weekly P/L when a verified trade closes', () => {
    const state = recordClosedTrade(defaultAutoTradeState(), { id: 't1', pnlUsd: -1.5, closedAt: Date.now(), directionLabel: 'BUY' });
    expect(state.weekly.realizedPnlUsd).toBe(-1.5);
    expect(state.weekly.trades).toBe(1);
  });
});
