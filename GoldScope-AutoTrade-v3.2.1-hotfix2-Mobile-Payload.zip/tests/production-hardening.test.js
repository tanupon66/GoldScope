import { describe, expect, it } from 'vitest';
import { readFile, readdir } from 'node:fs/promises';
import worker from '../worker/index.js';

describe('production hardening', () => {
  it('requires authentication before proxying Twelve Data market quota', async () => {
    const response = await worker.fetch(new Request('https://example.com/api/market?symbol=XAU%2FUSD&interval=5min'), {});
    const payload = await response.json();
    expect(response.status).toBe(401);
    expect(payload.code).toMatch(/SESSION|UNAUTHORIZED/);
  });

  it('ships anti-framing and CSP headers for static assets', async () => {
    const headers = await readFile(new URL('../public/_headers', import.meta.url), 'utf8');
    expect(headers).toContain('Content-Security-Policy:');
    expect(headers).toContain("frame-ancestors 'none'");
    expect(headers).toContain('X-Frame-Options: DENY');
  });

  it('uses the current service-worker cache generation', async () => {
    const sw = await readFile(new URL('../public/sw.js', import.meta.url), 'utf8');
    expect(sw).toContain('goldscope-autotrade-shell-v321');
    expect(sw).not.toContain('shell-v300');
  });

  it('does not emit production source maps', async () => {
    const config = await readFile(new URL('../vite.config.js', import.meta.url), 'utf8');
    expect(config).toContain('sourcemap: false');
    const distUrl = new URL('../dist/assets/', import.meta.url);
    try {
      const files = await readdir(distUrl);
      expect(files.some(file => file.endsWith('.map'))).toBe(false);
    } catch {
      // dist is created by the build step; the configuration assertion is authoritative during unit tests.
    }
  });
});
