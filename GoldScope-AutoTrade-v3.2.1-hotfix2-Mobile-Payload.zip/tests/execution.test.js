import { describe, expect, it } from 'vitest';
import { executionCosts, effectiveRiskReward, executionAwareTargetDistance } from '../src/core/execution.js';

it('converts broker points using configured digits', () => {
  const two = executionCosts({ brokerDigits: 2, spreadPoints: 200, slippagePoints: 0, manualEntryBufferPoints: 0 });
  const three = executionCosts({ brokerDigits: 3, spreadPoints: 200, slippagePoints: 0, manualEntryBufferPoints: 0 });
  expect(two.spreadUsd).toBeCloseTo(2, 8);
  expect(three.spreadUsd).toBeCloseTo(0.2, 8);
});

it('builds gross target that preserves net R:R after costs', () => {
  const distance = executionAwareTargetDistance(5, 1.8, 0.8);
  expect(effectiveRiskReward(5, distance, 0.8)).toBeCloseTo(1.8, 8);
});
