import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import {
  bootstrapCloudflareResources,
  DEFAULT_QUEUE_NAMES
} from '../scripts/mobile-cloudflare-bootstrap.mjs';
import { createCloudflareSecrets } from '../scripts/mobile-prepare-secrets.mjs';

function response(payload, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { 'content-type': 'application/json' }
  });
}

describe('mobile one-click deployment bootstrap', () => {
  it('creates missing D1 and queues, then writes a deployment-only config', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'goldscope-mobile-'));
    const configPath = join(directory, 'wrangler.jsonc');
    const outputPath = join(directory, '.wrangler.generated.jsonc');
    await writeFile(configPath, JSON.stringify({
      name: 'goldscope-autotrade',
      vars: { APP_VERSION: '3.2.0' },
      durable_objects: { bindings: [
        { name: 'AUTO_TRADE_STATE', class_name: 'AutoTradeState' },
        { name: 'AUTH_STATE', class_name: 'AuthState' }
      ] },
      migrations: [
        { tag: 'v1', new_sqlite_classes: ['AutoTradeState'] },
        { tag: 'v2', new_sqlite_classes: ['AuthState'] }
      ],
      d1_databases: [{ binding: 'DB', database_name: 'goldscope-autotrade', database_id: 'placeholder' }],
      queues: { producers: [], consumers: [] }
    }));

    const createdQueues = [];
    const fetchImpl = async (url, init = {}) => {
      const method = init.method || 'GET';
      if (url.includes('/d1/database') && method === 'GET') {
        return response({ success: true, result: [], result_info: { total_pages: 1 } });
      }
      if (url.endsWith('/d1/database') && method === 'POST') {
        return response({ success: true, result: { uuid: '11111111-2222-3333-4444-555555555555' } });
      }
      if (url.includes('/queues?') && method === 'GET') {
        return response({
          success: true,
          result: [{ queue_name: DEFAULT_QUEUE_NAMES[0] }],
          result_info: { total_pages: 1 }
        });
      }
      if (url.endsWith('/queues') && method === 'POST') {
        const body = JSON.parse(init.body);
        createdQueues.push(body.queue_name);
        return response({ success: true, result: { queue_name: body.queue_name } });
      }
      throw new Error(`Unexpected request: ${method} ${url}`);
    };

    const result = await bootstrapCloudflareResources({
      fetchImpl,
      accountId: 'account123',
      token: 'token123',
      configPath,
      outputPath,
      workerName: 'goldscope-mobile',
      databaseName: 'goldscope-autotrade',
      databaseLocation: 'apac',
      newsApiBaseUrl: 'https://news.example.test',
      economicCalendarApiBaseUrl: 'https://calendar.example.test'
    });

    expect(result.database.created).toBe(true);
    expect(createdQueues).toHaveLength(DEFAULT_QUEUE_NAMES.length - 1);
    const generated = JSON.parse(await readFile(outputPath, 'utf8'));
    expect(generated.name).toBe('goldscope-mobile');
    expect(generated.vars.APP_VERSION).toBe('3.2.1');
    expect(generated.vars.NEWS_API_BASE_URL).toBe('https://news.example.test');
    expect(generated.d1_databases[0].database_id).toBe('11111111-2222-3333-4444-555555555555');
    expect(generated.durable_objects.bindings).toEqual([
      { name: 'AUTO_TRADE_STATE', class_name: 'AutoTradeState' },
      { name: 'AUTH_STATE', class_name: 'AuthState' }
    ]);
    expect(generated.migrations.at(-1)).toEqual({ tag: 'v2', new_sqlite_classes: ['AuthState'] });
  });

  it('reuses existing resources without issuing create requests', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'goldscope-mobile-reuse-'));
    const configPath = join(directory, 'wrangler.jsonc');
    const outputPath = join(directory, '.wrangler.generated.jsonc');
    await writeFile(configPath, JSON.stringify({
      d1_databases: [{ binding: 'DB', database_name: 'goldscope-autotrade', database_id: 'placeholder' }]
    }));

    let postCount = 0;
    const fetchImpl = async (url, init = {}) => {
      const method = init.method || 'GET';
      if (method === 'POST') postCount += 1;
      if (url.includes('/d1/database')) {
        return response({
          success: true,
          result: [{ name: 'goldscope-autotrade', uuid: 'existing-db-id' }],
          result_info: { total_pages: 1 }
        });
      }
      if (url.includes('/queues')) {
        return response({
          success: true,
          result: DEFAULT_QUEUE_NAMES.map(queue_name => ({ queue_name })),
          result_info: { total_pages: 1 }
        });
      }
      throw new Error(`Unexpected request: ${method} ${url}`);
    };

    const result = await bootstrapCloudflareResources({
      fetchImpl,
      accountId: 'account123',
      token: 'token123',
      configPath,
      outputPath
    });

    expect(result.database).toEqual({ id: 'existing-db-id', created: false });
    expect(postCount).toBe(0);
  });
});

describe('mobile first-install secrets', () => {
  it('hashes the admin password, generates a session secret and keeps plaintext out of the payload', () => {
    const payload = createCloudflareSecrets({
      GOLDSCOPE_ADMIN_PASSWORD: 'StrongPassword123!',
      CAPITAL_API_KEY: 'test-capital-key',
      CAPITAL_IDENTIFIER: 'test-identifier',
      CAPITAL_API_PASSWORD: 'test-api-password',
      TWELVE_DATA_API_KEY: 'test-twelve-key'
    });

    expect(payload.ADMIN_CREDENTIAL_HASH).toMatch(/^pbkdf2-sha256\$310000\$/);
    expect(payload.ADMIN_CREDENTIAL_HASH).not.toContain('StrongPassword123!');
    expect(payload.SESSION_SIGNING_SECRET.length).toBeGreaterThan(50);
    expect(payload.CAPITAL_API_KEY).toBe('test-capital-key');
    expect(payload.TWELVE_DATA_API_KEY).toBe('test-twelve-key');
  });

  it('rejects incomplete first-install secrets', () => {
    expect(() => createCloudflareSecrets({ GOLDSCOPE_ADMIN_PASSWORD: 'StrongPassword123!' }))
      .toThrow(/CAPITAL_API_KEY/);
  });
});
