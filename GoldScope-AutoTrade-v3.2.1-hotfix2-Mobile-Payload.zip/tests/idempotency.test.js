import { describe, expect, it } from 'vitest';
import { createIdempotencyKey, createOrderIntent, transitionOrderIntent, canTransitionOrderIntent } from '../src/core/idempotency.js';

const base = {
  broker: 'capital', environment: 'demo', accountId: 'A1', symbol: 'GOLD', strategyVersion: '3.0.0',
  modelVersion: 'champion-1', timeframe: '5min', closedCandleTime: 1710000000, direction: 'BUY', signalId: 'sig-1'
};

describe('order idempotency', () => {
  it('creates a deterministic key and changes when a material field changes', () => {
    expect(createIdempotencyKey(base)).toBe(createIdempotencyKey({ ...base }));
    expect(createIdempotencyKey(base)).not.toBe(createIdempotencyKey({ ...base, direction: 'SELL' }));
  });

  it('enforces valid state transitions', () => {
    let intent = createOrderIntent({ idempotencyKey: createIdempotencyKey(base), signal: { id: 'sig-1' }, accountKey: 'demo:A1', now: 1 });
    intent = transitionOrderIntent(intent, 'RISK_APPROVED', {}, 2);
    intent = transitionOrderIntent(intent, 'SUBMITTING', {}, 3);
    intent = transitionOrderIntent(intent, 'UNKNOWN', { reason: 'timeout' }, 4);
    expect(intent.state).toBe('UNKNOWN');
    expect(canTransitionOrderIntent('UNKNOWN', 'OPEN')).toBe(true);
    expect(() => transitionOrderIntent(intent, 'CREATED')).toThrow(/INVALID_ORDER_INTENT_TRANSITION/);
  });
});
