import { describe, expect, it } from 'vitest';
import { createForwardPosition, evaluateForwardPosition, summarizeForwardPositions } from '../src/core/forwardTest.js';

describe('forward test shadow execution', () => {
  const signal = { id: 'sig-1', currentPrice: 2300, candleTime: 100, epic: 'GOLD' };
  const plan = { direction: 1, directionLabel: 'BUY', stopLoss: 2298, tp2: 2304, exitAtTarget: 'tp2', valuePerPriceUnit: 1, timeframe: '1min' };

  it('includes spread and slippage in simulated fill', () => {
    const pos = createForwardPosition({ signal, plan, spread: 0.4, slippageUsd: 0.1, now: 101000 });
    expect(pos.simulatedFill).toBe(2300.3);
    expect(pos.initialRiskUsd).toBeCloseTo(2.3);
  });

  it('uses conservative stop-first handling when stop and target touch same candle', () => {
    const pos = createForwardPosition({ signal, plan, spread: 0, slippageUsd: 0, now: 101000 });
    const result = evaluateForwardPosition(pos, [{ time: 102, high: 2305, low: 2297 }], 102000);
    expect(result.closed).toBe(true);
    expect(result.position.outcome).toBe('SL');
    expect(result.position.pnlUsd).toBeLessThan(0);
  });

  it('summarizes only completed signals in expectancy', () => {
    const open = createForwardPosition({ signal, plan, now: 101000 });
    const closed = { ...open, id: 'forward-2', status: 'COMPLETED', pnl: 4, resultR: 2 };
    const summary = summarizeForwardPositions({ [open.id]: open, [closed.id]: closed }, 201000);
    expect(summary.signals).toBe(2);
    expect(summary.closed).toBe(1);
    expect(summary.expectancyR).toBe(2);
  });
});
