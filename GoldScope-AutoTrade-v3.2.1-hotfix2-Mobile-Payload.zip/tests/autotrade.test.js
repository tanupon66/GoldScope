import { describe, expect, it } from 'vitest';
import {
  normalizeAutoTradeConfig, defaultAutoTradeState, checkRiskGuards,
  createPaperPosition, evaluatePaperPosition, recordClosedTrade, evaluateEntryWindow
} from '../src/core/autotrade.js';
import { extractCapitalDealId } from '../worker/capital.js';

describe('auto trade safeguards', () => {
  it('defaults to disabled paper mode', () => {
    const config = normalizeAutoTradeConfig({});
    expect(config.enabled).toBe(false);
    expect(config.executionMode).toBe('paper');
    expect(config.maxOpenPositions).toBe(1);
  });

  it('blocks live mode until explicitly unlocked', () => {
    const config = normalizeAutoTradeConfig({ enabled: true, executionMode: 'live', brokerEnvironment: 'live' });
    const result = checkRiskGuards({ config, state: defaultAutoTradeState(), openPositions: 0, spreadUsd: 0.2 });
    expect(result.allowed).toBe(false);
    expect(result.reasons.join(' ')).toContain('LIVE');
  });


  it('requires LIVE unlock for Confirm mode on a real account', () => {
    const config = normalizeAutoTradeConfig({ enabled: true, executionMode: 'confirm', brokerEnvironment: 'live' });
    const result = checkRiskGuards({ config, state: defaultAutoTradeState(), openPositions: 0, spreadUsd: 0.2 });
    expect(result.allowed).toBe(false);
    expect(result.reasons.join(' ')).toContain('LIVE');
  });

  it('preserves explicit zero values for cooldown and entry tolerance', () => {
    const config = normalizeAutoTradeConfig({ cooldownMinutes: 0, entryToleranceUsd: 0 });
    expect(config.cooldownMinutes).toBe(0);
    expect(config.entryToleranceUsd).toBe(0);
  });

  it('checks entry window with tolerance', () => {
    expect(evaluateEntryWindow({ entryLow: 2300, entryHigh: 2300.2 }, 2300.3, 0.1).eligible).toBe(true);
  });


  it('extracts the opened broker deal id from confirmation', () => {
    const dealId = extractCapitalDealId({
      dealId: 'order-parent',
      affectedDeals: [{ dealId:'position-1', status:'OPENED' }]
    });
    expect(dealId).toBe('position-1');
  });

  it('closes paper position conservatively at stop when both levels touch', () => {
    const position = createPaperPosition({ id:'p1', direction:1, stopLoss:99, tp2:102, exitAtTarget:'tp2', valuePerPriceUnit:1 }, 100, 0.01, 1);
    const result = evaluatePaperPosition(position, { high:103, low:98 }, 2);
    expect(result.closed).toBe(true);
    expect(result.position.exitReason).toBe('STOP_LOSS');
    const state = recordClosedTrade(defaultAutoTradeState(), result.position, 2);
    expect(state.daily.trades).toBe(1);
    expect(state.daily.consecutiveLosses).toBe(1);
  });
});

import { activateAccountLedger } from '../src/core/autotrade.js';
import { settingsForEngine } from '../worker/engine.js';

describe('v2.0.2 integrated auto trade', () => {
  it('allows automatic Broker orders on Demo without LIVE unlock', () => {
    const config = normalizeAutoTradeConfig({ enabled: true, executionMode: 'auto', brokerEnvironment: 'demo' });
    const result = checkRiskGuards({ config, state: defaultAutoTradeState(), openPositions: 0, spreadUsd: 0.2 });
    expect(result.allowed).toBe(true);
  });

  it('migrates the old live execution label to auto', () => {
    const config = normalizeAutoTradeConfig({ executionMode: 'live', brokerEnvironment: 'demo' });
    expect(config.executionMode).toBe('auto');
  });

  it('uses per-order loss cap instead of daily loss cap for plan sizing', () => {
    const settings = settingsForEngine({
      maxLossPerTradeUsd: 1.25,
      maxDailyLossUsd: 8,
      riskPercentPerTrade: 6,
      orderSize: 0.01,
      pnlReferenceSize: 0.01,
      pnlPerUsdMoveAtReferenceSize: 0.01,
      algorithmSettings: { contractSize: 100, brokerDigits: 2 }
    }, 20, { spreadUsd: 0.3, minStopDistance: { value: 20, unit: 'POINTS' }, mid: 2300 }, 0.01);
    expect(settings.maxLossUsd).toBe(1.25);
    expect(settings.riskPercent).toBe(6);
    expect(settings.pnlPerUsdMoveAtReferenceSize).toBe(0.01);
    expect(settings.minStopPoints).toBeGreaterThanOrEqual(20);
  });

  it('keeps the configured P/L per $1 move in Auto Trade config', () => {
    const config = normalizeAutoTradeConfig({
      orderSize: 0.01,
      pnlReferenceSize: 0.01,
      pnlPerUsdMoveAtReferenceSize: 0.01
    });
    expect(config.pnlReferenceSize).toBe(0.01);
    expect(config.pnlPerUsdMoveAtReferenceSize).toBe(0.01);
  });

  it('keeps Demo and Live daily ledgers separate', () => {
    let state = activateAccountLedger(defaultAutoTradeState(1), 'demo', { accountId: 'D1', balance: 10000 }, 1);
    state.daily.realizedPnlUsd = -25;
    state.accountLedgers[state.activeAccountKey] = { ...state.daily };
    state = activateAccountLedger(state, 'live', { accountId: 'L1', balance: 20 }, 1);
    expect(state.activeAccountKey).toBe('capital:live:L1');
    expect(state.daily.realizedPnlUsd).toBe(0);
    expect(state.daily.startBalance).toBe(20);
    expect(state.accountLedgers['capital:demo:D1'].realizedPnlUsd).toBe(-25);
  });
});
