import { expect, it } from 'vitest';
import { generateMockCandles } from '../src/mock/generator.js';
import { analyzeTimeframe } from '../src/core/market.js';
import { buildPlan, DEFAULT_SETTINGS } from '../src/core/risk.js';

function candidate(a, overrides = {}) {
  return {
    strategy:'Test', strategyKey:'test', timeframe:'15min', timeframeLabel:'M15', direction:1,
    score:82, atr:a.snapshot.atr, createdFromTime:a.candles.at(-1).time,
    entryLow:a.snapshot.close-0.2, entryHigh:a.snapshot.close+0.2,
    invalidationHint:a.snapshot.close-a.snapshot.atr,
    expiryTime:a.candles.at(-1).time+3600, evidence:[], warnings:[], counterTrend:false,
    trigger:'test', ...overrides
  };
}

const fundedSettings = {
  ...DEFAULT_SETTINGS,
  accountSize: 1000,
  positionSizingMode: 'risk',
  riskPercent: 1,
  maxLot: 1,
  profile: 'balanced',
  maxExpectedBarsToTp2: 5,
  maxTargetAtr: 5
};

it('builds BUY plan with stop below and dynamic targets above', () => {
  const a = analyzeTimeframe(generateMockCandles('15min', 500), '15min');
  const p = buildPlan(candidate(a), a, fundedSettings);
  expect(p).not.toBeNull();
  expect(p.stopLoss).toBeLessThan(p.entry);
  expect(p.tp1).toBeGreaterThan(p.entry);
  expect(p.tp3).toBeGreaterThan(p.tp2);
  expect(p.riskReward).toBeGreaterThanOrEqual(fundedSettings.minRiskReward);
  expect(p.estimatedLossUsd).toBeLessThanOrEqual(p.riskBudget + 0.01);
});

it('rejects candidates with invalid score instead of rendering Score null', () => {
  const a = analyzeTimeframe(generateMockCandles('15min', 500), '15min');
  expect(buildPlan(candidate(a, { score: NaN }), a, fundedSettings)).toBeNull();
});

it('rejects a fixed 0.01-lot plan when its SL exceeds the $20 account loss cap', () => {
  const a = analyzeTimeframe(generateMockCandles('15min', 500), '15min');
  const p = buildPlan(candidate(a), a, {
    ...DEFAULT_SETTINGS,
    accountSize: 20,
    fixedLot: 0.01,
    positionSizingMode: 'fixed',
    riskPercent: 5,
    contractSize: 100
  });
  expect(p).toBeNull();
});

it('calculates fixed-lot P/L using contract size and leverage only for margin', () => {
  const a = analyzeTimeframe(generateMockCandles('15min', 500), '15min');
  const p = buildPlan(candidate(a, { invalidationHint: a.snapshot.close - a.snapshot.atr * 0.7 }), a, {
    ...DEFAULT_SETTINGS,
    accountSize: 100,
    fixedLot: 0.01,
    maxLot: 0.01,
    positionSizingMode: 'fixed',
    riskPercent: 20,
    pnlPerUsdMoveAtReferenceSize: 0,
    contractSize: 100,
    leverage: 500,
    maxMarginUsagePercent: 100,
    profile: 'scalp',
    maxExpectedBarsToTp2: 5,
    maxTargetAtr: 5
  });
  expect(p).not.toBeNull();
  expect(p.valuePerPriceUnit).toBe(1);
  expect(p.estimatedMarginUsd).toBeGreaterThan(0);
});

it('supports a broker-specific P/L value for a $1 gold move', () => {
  const a = analyzeTimeframe(generateMockCandles('15min', 500), '15min');
  const p = buildPlan(candidate(a, { invalidationHint: a.snapshot.close - a.snapshot.atr * 0.7 }), a, {
    ...DEFAULT_SETTINGS,
    accountSize: 100,
    fixedLot: 0.01,
    maxLot: 0.01,
    positionSizingMode: 'fixed',
    riskPercent: 20,
    pnlReferenceSize: 0.01,
    pnlPerUsdMoveAtReferenceSize: 0.01,
    contractSize: 100,
    leverage: 500,
    maxMarginUsagePercent: 100,
    profile: 'scalp',
    maxExpectedBarsToTp2: 5,
    maxTargetAtr: 5
  });
  expect(p).not.toBeNull();
  expect(p.valuePerPriceUnit).toBe(0.01);
  expect(p.estimatedMarginUsd).toBeGreaterThan(0);
});

it('rejects extreme spread for a small fixed-lot account instead of widening SL', () => {
  const a = analyzeTimeframe(generateMockCandles('15min', 500), '15min');
  const p = buildPlan(candidate(a, { strategy:'Wide spread', strategyKey:'wide-spread' }), a, {
    ...DEFAULT_SETTINGS,
    brokerDigits:2,
    spreadPoints:200,
    slippagePoints:20,
    manualEntryBufferPoints:20
  });
  expect(p).toBeNull();
});
