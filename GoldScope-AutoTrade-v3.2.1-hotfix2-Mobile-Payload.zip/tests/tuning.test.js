import { describe, expect, it } from 'vitest';
import {
  buildAdaptiveModel, createTuningProfile, validateTuningProfile,
  mergeLearningRecords
} from '../src/core/learning.js';

const settings = {
  adaptiveLearning:true, learningMinSamples:20, learningMaxAdjustment:8,
  learningLookback:400, learningUseDemo:false, learningResetAt:0,
  profile:'balanced', minScore:68, minRiskReward:1.6, brokerDigits:2,
  spreadPoints:200, slippagePoints:20, manualEntryBufferPoints:30,
  maxExecutionCostPercent:22, minExpectedBarsToTp2:1.5, minStopPoints:0,
  backtestMaxHoldBars:24
};

function records() {
  const now = Date.now();
  return Array.from({length:30}, (_, index) => ({
    id:`t-${index}`, strategyKey:'trend-pullback', strategy:'Trend pullback',
    timeframe:'15min', regime:'Trend', direction:1, dataMode:'live',
    status:index < 20 ? 'COMPLETED' : 'STOPPED', resultR:index < 20 ? 1.8 : -1,
    endedAt:now-index*1000
  }));
}

describe('tuning profile', () => {
  it('exports only minimal learning records and current tuning settings', () => {
    const source = records();
    const model = buildAdaptiveModel(source, settings, 'live');
    const profile = createTuningProfile(source, settings, 'live', model, '2.0.0');
    expect(profile.schema).toBe('goldscope-tuning-profile');
    expect(profile.records).toHaveLength(30);
    expect(profile.algorithmSettings.spreadPoints).toBe(200);
    expect(profile.learningSettings.learningMaxAdjustment).toBe(8);
    expect(profile.records[0]).not.toHaveProperty('entry');
    expect(profile.records[0]).not.toHaveProperty('stopLoss');
    expect(profile).not.toHaveProperty('plans');
    expect(profile).not.toHaveProperty('backtests');
  });

  it('validates and rebuilds the same adaptive model from an exported profile', () => {
    const source = records();
    const original = buildAdaptiveModel(source, settings, 'live');
    const imported = validateTuningProfile(createTuningProfile(source, settings, 'live', original, '2.0.0'));
    const restoredSettings = {...settings, ...imported.algorithmSettings, ...imported.learningSettings};
    const restored = buildAdaptiveModel(imported.records, restoredSettings, 'live');
    expect(restored.eligibleTrades).toBe(original.eligibleTrades);
    expect(restored.fingerprint).toBe(original.fingerprint);
    expect(restored.overall.expectancyR).toBe(original.overall.expectancyR);
  });

  it('deduplicates imported tuning records and newly collected results', () => {
    const base = records();
    const merged = mergeLearningRecords(base, [base[0], {...base[0], learningId:'new-id', endedAt:base[0].endedAt+1}]);
    expect(merged).toHaveLength(31);
  });

  it('rejects unrelated JSON files', () => {
    expect(() => validateTuningProfile({hello:'world'})).toThrow(/Tuning Profile/);
  });
});
