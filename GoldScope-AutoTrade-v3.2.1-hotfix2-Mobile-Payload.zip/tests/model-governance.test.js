import { describe, expect, it } from 'vitest';
import { createModelRegistry, evaluateModelPromotion, promoteChallenger, rollbackChampion } from '../src/core/modelGovernance.js';

const good = {
  version: 'm2', shadowDays: 28, featureSchemaCompatible: true, raisesRiskLimit: false,
  metrics: {
    sampleSize: 160, outOfSampleExpectancy: 0.12, maximumDrawdownPercent: 9,
    periodExpectancies: [0.1, 0.08, 0.04, -0.01], recentDegradationPercent: 10,
    transactionCostsIncluded: true, dataLeakageDetected: false
  }
};

describe('model governance', () => {
  it('blocks a challenger with leakage or too few shadow days', () => {
    const result = evaluateModelPromotion({ ...good, shadowDays: 2, metrics: { ...good.metrics, dataLeakageDetected: true } });
    expect(result.passed).toBe(false);
    expect(result.blockingReasons).toContain('NO_DATA_LEAKAGE');
    expect(result.blockingReasons).toContain('SHADOW_MODE');
  });

  it('promotes and can rollback a validated challenger', () => {
    const evaluation = evaluateModelPromotion(good);
    expect(evaluation.passed).toBe(true);
    const promoted = promoteChallenger(createModelRegistry({ version: 'm1' }, good), evaluation, 1000);
    expect(promoted.champion.version).toBe('m2');
    const rolled = rollbackChampion(promoted, 'm1', 2000);
    expect(rolled.champion.version).toBe('m1');
  });
});
