import { afterEach, describe, expect, it, vi } from 'vitest';
import { healthCheck } from '../src/core/data.js';

afterEach(() => {
  vi.restoreAllMocks();
});

describe('fresh API requests', () => {
  it('bypasses the browser HTTP cache for market API calls', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { 'content-type': 'application/json' }
    }));

    await healthCheck();
    const [url, options] = fetchMock.mock.calls[0];
    expect(String(url)).toContain('/api/health');
    expect(String(url)).toContain('_gs=');
    expect(options.cache).toBe('no-store');
    expect(options.headers['cache-control']).toBe('no-cache');
  });
});
