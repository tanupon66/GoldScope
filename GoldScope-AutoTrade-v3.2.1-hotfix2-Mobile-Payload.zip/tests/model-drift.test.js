import { describe, expect, it } from 'vitest';
import { evaluateAdaptiveDrift, regimeJensenShannon } from '../src/core/modelDrift.js';

function rows(values, start = 1, regimes = ['trend', 'range']) {
  return values.map((resultR, index) => ({
    id: `${start + index}`, resultR, status: resultR < 0 ? 'STOPPED' : 'COMPLETED',
    endedAt: (start + index) * 1000, regime: regimes[index % regimes.length]
  }));
}

describe('adaptive model drift monitor', () => {
  it('keeps adaptive learning active for stable recent performance', () => {
    const baseline = rows(Array.from({ length: 50 }, (_, i) => i % 2 ? -0.5 : 0.8), 1);
    const recent = rows(Array.from({ length: 20 }, (_, i) => i % 2 ? -0.45 : 0.75), 100);
    const result = evaluateAdaptiveDrift([...baseline, ...recent], { recentWindow: 20, baselineWindow: 50 });
    expect(result.status).toBe('STABLE');
    expect(result.pauseAdaptive).toBe(false);
  });

  it('pauses adaptive adjustment after severe out-of-sample degradation', () => {
    const baseline = rows(Array.from({ length: 50 }, (_, i) => i % 3 ? 0.8 : -0.4), 1, ['trend']);
    const recent = rows(Array.from({ length: 20 }, () => -1), 100, ['news-shock']);
    const result = evaluateAdaptiveDrift([...baseline, ...recent], { recentWindow: 20, baselineWindow: 50 });
    expect(result.status).toBe('DRIFT');
    expect(result.pauseAdaptive).toBe(true);
    expect(result.reasons).toContain('RECENT_EXPECTANCY_NEGATIVE');
  });

  it('returns bounded regime divergence', () => {
    expect(regimeJensenShannon({ trend: 1 }, { range: 1 })).toBe(1);
  });
});
