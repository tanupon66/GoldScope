import { describe, expect, it } from 'vitest';
import { inspectCandleQuality, closedCandlesOnly } from '../src/core/dataQuality.js';

function candles(count = 100, start = 1_700_000_000, step = 300) {
  return Array.from({ length: count }, (_, index) => ({
    time: start + index * step, open: 2000 + index, high: 2001 + index, low: 1999 + index, close: 2000.5 + index
  }));
}

describe('market data quality', () => {
  it('accepts continuous fresh closed candles', () => {
    const rows = candles();
    const nowMs = (rows.at(-1).time + 330) * 1000;
    const result = inspectCandleQuality(rows, '5min', { nowMs, staleAfterSeconds: 700 });
    expect(result.ok).toBe(true);
    expect(result.score).toBeGreaterThanOrEqual(90);
  });

  it('blocks duplicate and stale candles', () => {
    const rows = candles();
    rows.push({ ...rows.at(-1) });
    const result = inspectCandleQuality(rows, '5min', { nowMs: (rows.at(-1).time + 5000) * 1000 });
    expect(result.ok).toBe(false);
    expect(result.blockingReasons).toContain('DUPLICATE_CANDLE');
    expect(result.blockingReasons).toContain('STALE_CANDLE');
  });

  it('removes a still-forming candle', () => {
    const rows = candles(3);
    const nowMs = (rows.at(-1).time + 100) * 1000;
    expect(closedCandlesOnly(rows, '5min', nowMs)).toHaveLength(2);
  });
});
