# Backtest Methodology — v3.2

## Simulation

- ใช้ข้อมูลถึง decision index เท่านั้น; entry ที่ next bar.
- Adaptive model frozen ตลอด run และไม่เรียนจากผล run เดียวกัน.
- รวม spread, slippage, manual-entry buffer และ execution cost settings.
- ใช้ risk-plan builder เดียวกับ analysis path.
- SL/TP แตะในแท่งเดียวกัน → conservative stop (`SL_AMBIGUOUS`).
- Trades ไม่ซ้อนกันใน engine ปัจจุบัน.

## Metrics

Total trades, win rate, average win/loss, expectancy, Net R/P&L, profit factor, maximum drawdown/duration, Sharpe-like, Sortino-like, recovery factor, consecutive sequences, exposure/holding time, cost-to-gross-profit และ breakdown ตาม strategy/timeframe/regime/UTC hour/month.

## Robustness

- Walk-forward split และ out-of-sample metrics
- Deterministic Monte Carlo ด้วย fixed seed
- Spread/slippage/delayed-entry stress scenarios
- Conservative same-bar handling
- Frozen adaptive model/no future data tests

## Forward Test complement

Shadow Forward Test ใช้ signal/quote จริงหลัง Deploy และเก็บ intended entry, simulated fill, spread, slippage, news/model/config version และผลต่างจาก Demo execution ที่สามารถนำมาเทียบภายหลัง. Forward Test ไม่แทน Broker Demo execution test.

## Limitations

ยังเป็น candle-based ไม่ใช่ tick/order-book replay; partial fills, financing, historical variable-spread stream, exact rejection frequency และ historical point-in-time news ยังไม่สมบูรณ์. ผลไม่ใช่หลักฐานรับประกันกำไร.
