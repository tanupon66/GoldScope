# คู่มือผู้ใช้ GoldScope AutoTrade v3.2

## ขอบเขต

GoldScope เป็นระบบวิเคราะห์/ทดสอบ automation สำหรับ XAU/USD ไม่รับประกันกำไร. Cloudflare ทำงานต่อเมื่อปิด PWA เฉพาะบัญชีที่เชื่อมและเปิดใช้งานใน D1 แล้ว.

## เริ่มต้น

## Setup Wizard บนหน้า Auto Trade

หน้า Auto Trade แบ่งการตั้งค่าเป็น 4 ขั้น โดยค่าทั้งหมดอยู่ในฟอร์มเดียวและไม่หายเมื่อสลับขั้น:

1. **พื้นฐาน** — Login, เลือก Paper/Confirm/Auto, Demo/Live, Account ID, Epic, timeframe และคะแนนขั้นต่ำ.
2. **ความเสี่ยง** — ขนาดคำสั่ง, P/L calibration, spread, risk/order, daily/weekly loss, drawdown, margin และ cooldown.
3. **Forward Test** — เปิด Shadow test, ตั้ง slippage และดู signals/closed/expectancy/days.
4. **ขั้นสูง** — Model Drift, Live unlock, scan/reconcile/pause และบันทึกค่าทั้งหมด.

เริ่มจากขั้นพื้นฐานและกด **ทดสอบ Broker** ก่อนปรับ Risk. การกดถัดไปไม่ได้เปิด Auto จนกว่าจะบันทึกและ `enabled` ถูกเลือก.

1. เปิดแท็บ Auto Trade และ Login.
2. เลือก `Demo API` และกรอก Capital account ID ที่ต้องการใช้.
3. กด `ทดสอบ Broker`; ตรวจว่าระบบสลับไปบัญชีนั้นจริง.
4. ตรวจ Calibration, minimum size, spread และมูลค่า P/L ต่อการขยับราคา.
5. เริ่มจาก Paper + Forward Test.

## โหมด

- **Paper** — จำลองภายใน GoldScope ไม่ส่ง Broker.
- **Forward Test** — ใช้ signal/ราคาจริง สร้าง Shadow fill แยกต่างหาก ไม่ส่ง Broker เพิ่ม.
- **Confirm Demo** — ผู้ใช้ยืนยันก่อนหมดอายุ; Queue ตรวจราคาและ Risk Gate ใหม่ก่อนส่ง.
- **Demo Auto** — Cloudflare ส่ง Demo order อัตโนมัติหลังผ่าน guards.
- **Live** — ปิดเป็นค่าเริ่มต้นและต้องผ่าน Readiness + unlock ชั่วคราว.

## สิ่งที่ควรดูบน Home/Auto

- Broker environment และ account ID
- Market/quote freshness และ spread
- Auto status, pending execution และ unresolved intent
- Daily/weekly P/L, drawdown และ margin usage
- Forward Test days/trades/expectancy
- Reconciliation mismatch
- Queue/DLQ, provider health และ last successful scan
- News blackout และ Kill Switch

## NO_TRADE / ORDER_BLOCKED

เป็นผลลัพธ์ที่ถูกต้องเมื่อ market ปิด, quote เก่า, data quality ต่ำ, spread/latency สูง, ข่าวแรง, entry zone หมดอายุ, risk เกิน, minimum size เกินงบ, มี position/pending order, loss/drawdown/margin limit, account/environment เปลี่ยน หรือระบบถูกหยุด. อย่าลด guard เพียงเพื่อให้มีออเดอร์.

## Kill Switch

Kill Switch จะ:

- ปิด Auto และ Live unlock
- เปลี่ยนกลับ Paper/Demo
- ยกเลิก Intent ที่ยังไม่ส่ง Broker
- ล้าง pending signals/executions
- หยุดเปิดออเดอร์ใหม่

Kill Switch **ไม่ปิด position ที่ Broker อัตโนมัติ**. ให้ตรวจ Capital.com โดยตรงและจัดการ position ตามแผนฉุกเฉิน.

## Reconciliation

เมื่อเห็น `UNKNOWN` หรือ `RECONCILIATION_REQUIRED` ห้ามกดส่งออเดอร์เดิมซ้ำ. ใช้ปุ่มตรวจ Broker/Reconcile และตรวจ deal/reference ใน Capital.com. ระบบจะบันทึก P/L เฉพาะเมื่อ match ประวัติ Broker ได้.

## Dead Letter Queue

หน้า DLQ แสดงงานที่เกิน retry limit. อ่าน event/account/error ก่อนกด Retry. สำหรับ order execution การ retry จะยังผ่าน idempotency + pre-submit guards; หาก Broker outcome ยังไม่ชัด ให้ reconcile ก่อน ไม่ควร retry แบบเดาสุ่ม.

## Notifications

- Browser notification: ต้องเปิด PWA และอนุญาตสิทธิ์.
- Telegram/Webhook: ตั้ง Secrets ฝั่ง Cloudflare แล้วระบบ Queue จะส่ง event สำคัญพร้อม deduplication.
- ห้ามใส่ token/URL ลับใน frontend.

## Offline/PWA update

Offline เปิด app shell และข้อมูล cache ได้ แต่ไม่ส่งคำสั่ง/แก้ Cloud config และข้อมูลต้องถือว่า stale. เมื่อมี update ให้ทำหลังไม่มีขั้นตอนยืนยัน/ออเดอร์ค้าง และตรวจสถานะ Broker หลัง reload.
