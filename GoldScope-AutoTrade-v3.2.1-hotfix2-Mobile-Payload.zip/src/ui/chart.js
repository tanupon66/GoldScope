import { createChart, CandlestickSeries, LineSeries, HistogramSeries, ColorType } from 'lightweight-charts';

export class MarketChart {
  constructor(container) {
    this.container = container;
    this.chart = createChart(container, {
      autoSize: true,
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#8f98a6',
        fontFamily: 'Inter, ui-sans-serif, system-ui, sans-serif'
      },
      grid: {
        vertLines: { color: 'rgba(255,255,255,.035)' },
        horzLines: { color: 'rgba(255,255,255,.035)' }
      },
      rightPriceScale: { borderColor: 'rgba(255,255,255,.08)' },
      timeScale: { borderColor: 'rgba(255,255,255,.08)', timeVisible: true, secondsVisible: false },
      crosshair: {
        vertLine: { color: 'rgba(232,184,63,.45)', labelBackgroundColor: '#be8d19' },
        horzLine: { color: 'rgba(232,184,63,.45)', labelBackgroundColor: '#be8d19' }
      },
      localization: { priceFormatter: value => Number(value).toFixed(2) }
    });
    this.candles = this.chart.addSeries(CandlestickSeries, {
      upColor: '#29c893', downColor: '#f05f6b', borderVisible: false,
      wickUpColor: '#29c893', wickDownColor: '#f05f6b', priceLineVisible: true
    });
    this.ema20 = this.chart.addSeries(LineSeries, { color: '#e7b83f', lineWidth: 2, priceLineVisible: false, lastValueVisible: false });
    this.ema50 = this.chart.addSeries(LineSeries, { color: '#6f8cff', lineWidth: 2, priceLineVisible: false, lastValueVisible: false });
    this.volume = this.chart.addSeries(HistogramSeries, {
      priceFormat: { type: 'volume' }, priceScaleId: '', lastValueVisible: false, priceLineVisible: false
    }, 1);
    this.chart.panes()[1]?.setHeight(90);
    this.priceLines = [];
  }

  setData(analysis, plan = null) {
    const candles = analysis.candles.map(c => ({ time: c.time, open: c.open, high: c.high, low: c.low, close: c.close }));
    this.candles.setData(candles);
    const mapLine = values => values.map((v, i) => Number.isFinite(v) ? ({ time: analysis.candles[i].time, value: v }) : null).filter(Boolean);
    this.ema20.setData(mapLine(analysis.series.ema20));
    this.ema50.setData(mapLine(analysis.series.ema50));
    this.volume.setData(analysis.candles.map(c => ({
      time: c.time,
      value: c.volume || 0,
      color: c.close >= c.open ? 'rgba(41,200,147,.32)' : 'rgba(240,95,107,.32)'
    })));
    this.clearPlanLines();
    if (plan) this.showPlan(plan);
    this.chart.timeScale().fitContent();
  }

  clearPlanLines() {
    for (const line of this.priceLines) this.candles.removePriceLine(line);
    this.priceLines = [];
  }

  showPlan(plan) {
    const lines = [
      [plan.entry, '#e7b83f', `ENTRY ${plan.entry.toFixed(2)}`],
      [plan.stopLoss, '#f05f6b', `SL ${plan.stopLoss.toFixed(2)}`],
      [plan.tp1, '#57c6ff', `TP1 ${plan.tp1.toFixed(2)}`],
      [plan.tp2, '#29c893', `TP2 ${plan.tp2.toFixed(2)}`],
      [plan.tp3, '#9e7bff', `TP3 ${plan.tp3.toFixed(2)}`]
    ];
    this.priceLines = lines.map(([price, color, title]) => this.candles.createPriceLine({
      price, color, lineWidth: 1, lineStyle: 2, axisLabelVisible: true, title
    }));
  }

  destroy() { this.chart.remove(); }
}
