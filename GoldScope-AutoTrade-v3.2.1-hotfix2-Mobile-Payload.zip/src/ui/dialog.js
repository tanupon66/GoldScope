function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, ch => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' })[ch]);
}

export function confirmDialog({
  title = 'ยืนยันการทำรายการ',
  message = '',
  confirmLabel = 'ยืนยัน',
  cancelLabel = 'ยกเลิก',
  danger = false,
  requireText = '',
  detail = ''
} = {}) {
  if (typeof document === 'undefined') return Promise.resolve(false);
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.className = 'dialog-overlay';
    overlay.setAttribute('role', 'presentation');
    const required = String(requireText || '');
    overlay.innerHTML = `<section class="app-dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title">
      <div class="dialog-icon ${danger ? 'danger' : ''}" aria-hidden="true">${danger ? '!' : '✓'}</div>
      <div class="dialog-body">
        <h2 id="dialog-title">${escapeHtml(title)}</h2>
        <p>${escapeHtml(message).replace(/\n/g, '<br>')}</p>
        ${detail ? `<div class="dialog-detail">${escapeHtml(detail).replace(/\n/g, '<br>')}</div>` : ''}
        ${required ? `<label class="dialog-confirm-field">พิมพ์ <strong>${escapeHtml(required)}</strong> เพื่อยืนยัน<input name="confirmationText" autocomplete="off" spellcheck="false"></label>` : ''}
      </div>
      <div class="dialog-actions">
        <button type="button" class="ghost-button" data-dialog-cancel>${escapeHtml(cancelLabel)}</button>
        <button type="button" class="${danger ? 'danger-button' : 'primary-button'}" data-dialog-confirm ${required ? 'disabled' : ''}>${escapeHtml(confirmLabel)}</button>
      </div>
    </section>`;

    const close = value => {
      document.removeEventListener('keydown', onKeydown);
      overlay.remove();
      resolve(value);
    };
    const onKeydown = event => {
      if (event.key === 'Escape') close(false);
      if (event.key === 'Enter' && !overlay.querySelector('[data-dialog-confirm]')?.disabled) close(true);
    };
    overlay.addEventListener('click', event => {
      if (event.target === overlay || event.target.closest('[data-dialog-cancel]')) close(false);
      if (event.target.closest('[data-dialog-confirm]')) close(true);
    });
    const input = overlay.querySelector('[name="confirmationText"]');
    const confirm = overlay.querySelector('[data-dialog-confirm]');
    input?.addEventListener('input', () => {
      confirm.disabled = input.value.trim() !== required;
    });
    document.addEventListener('keydown', onKeydown);
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('visible'));
    (input || overlay.querySelector('[data-dialog-cancel]'))?.focus();
  });
}
