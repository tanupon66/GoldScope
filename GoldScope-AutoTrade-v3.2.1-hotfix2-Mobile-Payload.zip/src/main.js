import './styles.css';
import { GoldScopeApp } from './ui/app.js';
import { confirmDialog } from './ui/dialog.js';

const app = new GoldScopeApp(document.getElementById('app'));
app.init();

function offerUpdate(registration) {
  if (!registration.waiting) return;
  window.dispatchEvent(new CustomEvent('goldscope:update-available'));
  const activate = () => registration.waiting?.postMessage({ type: 'SKIP_WAITING' });
  if (window.__goldscopeCriticalAction) {
    window.addEventListener('goldscope:critical-action-complete', activate, { once: true });
    return;
  }
  confirmDialog({
    title: 'มีเวอร์ชันใหม่พร้อมใช้งาน',
    message: 'โหลด GoldScope รุ่นใหม่ตอนนี้หรือไม่? ระบบจะรอหากกำลังยืนยันคำสั่งสำคัญอยู่',
    confirmLabel: 'อัปเดตตอนนี้'
  }).then(ok => { if (ok) activate(); });
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js', { updateViaCache: 'none' });
      if (registration.waiting) offerUpdate(registration);
      registration.addEventListener('updatefound', () => {
        const worker = registration.installing;
        worker?.addEventListener('statechange', () => {
          if (worker.state === 'installed' && navigator.serviceWorker.controller) offerUpdate(registration);
        });
      });
      registration.update().catch(() => {});
      let reloading = false;
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (reloading || window.__goldscopeCriticalAction) return;
        reloading = true;
        location.reload();
      });
    } catch (error) {
      console.error('Service worker registration failed', error);
    }
  });
}
