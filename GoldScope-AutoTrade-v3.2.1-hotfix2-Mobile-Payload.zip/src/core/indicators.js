const finite = (v) => Number.isFinite(v);
const safe = (v, fallback = null) => finite(v) ? v : fallback;

export function sma(values, period) {
  const out = Array(values.length).fill(null);
  if (period <= 0) return out;
  let sum = 0;
  let valid = 0;
  for (let i = 0; i < values.length; i++) {
    const v = values[i];
    if (finite(v)) { sum += v; valid++; }
    if (i >= period) {
      const old = values[i - period];
      if (finite(old)) { sum -= old; valid--; }
    }
    if (i >= period - 1 && valid === period) out[i] = sum / period;
  }
  return out;
}

export function ema(values, period) {
  const out = Array(values.length).fill(null);
  if (!values.length || period <= 0) return out;
  const k = 2 / (period + 1);
  let seed = [];
  let prev = null;
  for (let i = 0; i < values.length; i++) {
    const v = values[i];
    if (!finite(v)) continue;
    if (prev === null) {
      seed.push(v);
      if (seed.length === period) {
        prev = seed.reduce((a, b) => a + b, 0) / period;
        out[i] = prev;
      }
    } else {
      prev = v * k + prev * (1 - k);
      out[i] = prev;
    }
  }
  return out;
}

export function rma(values, period) {
  const out = Array(values.length).fill(null);
  let sum = 0;
  let count = 0;
  let prev = null;
  for (let i = 0; i < values.length; i++) {
    const v = values[i];
    if (!finite(v)) continue;
    if (prev === null) {
      sum += v; count++;
      if (count === period) {
        prev = sum / period;
        out[i] = prev;
      }
    } else {
      prev = (prev * (period - 1) + v) / period;
      out[i] = prev;
    }
  }
  return out;
}

export function trueRange(candles) {
  return candles.map((c, i) => {
    if (i === 0) return c.high - c.low;
    const pc = candles[i - 1].close;
    return Math.max(c.high - c.low, Math.abs(c.high - pc), Math.abs(c.low - pc));
  });
}

export function atr(candles, period = 14) {
  return rma(trueRange(candles), period);
}

export function rsi(values, period = 14) {
  const gains = Array(values.length).fill(null);
  const losses = Array(values.length).fill(null);
  for (let i = 1; i < values.length; i++) {
    const d = values[i] - values[i - 1];
    gains[i] = Math.max(0, d);
    losses[i] = Math.max(0, -d);
  }
  const ag = rma(gains, period);
  const al = rma(losses, period);
  return values.map((_, i) => {
    if (!finite(ag[i]) || !finite(al[i])) return null;
    if (al[i] === 0) return 100;
    const rs = ag[i] / al[i];
    return 100 - 100 / (1 + rs);
  });
}

export function macd(values, fast = 12, slow = 26, signalPeriod = 9) {
  const fastEma = ema(values, fast);
  const slowEma = ema(values, slow);
  const line = values.map((_, i) => finite(fastEma[i]) && finite(slowEma[i]) ? fastEma[i] - slowEma[i] : null);
  const signal = ema(line, signalPeriod);
  const histogram = line.map((v, i) => finite(v) && finite(signal[i]) ? v - signal[i] : null);
  return { line, signal, histogram };
}

export function standardDeviation(values, period = 20) {
  const mean = sma(values, period);
  return values.map((_, i) => {
    if (i < period - 1 || !finite(mean[i])) return null;
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) sum += (values[j] - mean[i]) ** 2;
    return Math.sqrt(sum / period);
  });
}

export function bollinger(values, period = 20, mult = 2) {
  const middle = sma(values, period);
  const sd = standardDeviation(values, period);
  return {
    middle,
    upper: middle.map((m, i) => finite(m) && finite(sd[i]) ? m + mult * sd[i] : null),
    lower: middle.map((m, i) => finite(m) && finite(sd[i]) ? m - mult * sd[i] : null),
    width: middle.map((m, i) => finite(m) && m !== 0 && finite(sd[i]) ? (2 * mult * sd[i]) / m : null)
  };
}

export function stochastic(candles, kPeriod = 14, dPeriod = 3) {
  const k = Array(candles.length).fill(null);
  for (let i = kPeriod - 1; i < candles.length; i++) {
    const slice = candles.slice(i - kPeriod + 1, i + 1);
    const high = Math.max(...slice.map(c => c.high));
    const low = Math.min(...slice.map(c => c.low));
    k[i] = high === low ? 50 : ((candles[i].close - low) / (high - low)) * 100;
  }
  return { k, d: sma(k, dPeriod) };
}

export function adx(candles, period = 14) {
  const tr = trueRange(candles);
  const plusDM = Array(candles.length).fill(0);
  const minusDM = Array(candles.length).fill(0);
  for (let i = 1; i < candles.length; i++) {
    const up = candles[i].high - candles[i - 1].high;
    const down = candles[i - 1].low - candles[i].low;
    plusDM[i] = up > down && up > 0 ? up : 0;
    minusDM[i] = down > up && down > 0 ? down : 0;
  }
  const trRma = rma(tr, period);
  const pRma = rma(plusDM, period);
  const mRma = rma(minusDM, period);
  const plusDI = candles.map((_, i) => finite(trRma[i]) && trRma[i] !== 0 ? 100 * pRma[i] / trRma[i] : null);
  const minusDI = candles.map((_, i) => finite(trRma[i]) && trRma[i] !== 0 ? 100 * mRma[i] / trRma[i] : null);
  const dx = candles.map((_, i) => {
    if (!finite(plusDI[i]) || !finite(minusDI[i])) return null;
    const sum = plusDI[i] + minusDI[i];
    return sum === 0 ? 0 : 100 * Math.abs(plusDI[i] - minusDI[i]) / sum;
  });
  return { adx: rma(dx, period), plusDI, minusDI };
}

export function cci(candles, period = 20) {
  const typical = candles.map(c => (c.high + c.low + c.close) / 3);
  const mean = sma(typical, period);
  return candles.map((_, i) => {
    if (i < period - 1 || !finite(mean[i])) return null;
    let md = 0;
    for (let j = i - period + 1; j <= i; j++) md += Math.abs(typical[j] - mean[i]);
    md /= period;
    return md === 0 ? 0 : (typical[i] - mean[i]) / (0.015 * md);
  });
}

export function roc(values, period = 12) {
  return values.map((v, i) => i >= period && values[i - period] !== 0 ? ((v - values[i - period]) / values[i - period]) * 100 : null);
}

export function williamsR(candles, period = 14) {
  return candles.map((c, i) => {
    if (i < period - 1) return null;
    const slice = candles.slice(i - period + 1, i + 1);
    const high = Math.max(...slice.map(x => x.high));
    const low = Math.min(...slice.map(x => x.low));
    return high === low ? -50 : ((high - c.close) / (high - low)) * -100;
  });
}

export function donchian(candles, period = 20) {
  const upper = Array(candles.length).fill(null);
  const lower = Array(candles.length).fill(null);
  const middle = Array(candles.length).fill(null);
  for (let i = period - 1; i < candles.length; i++) {
    const slice = candles.slice(i - period + 1, i + 1);
    upper[i] = Math.max(...slice.map(c => c.high));
    lower[i] = Math.min(...slice.map(c => c.low));
    middle[i] = (upper[i] + lower[i]) / 2;
  }
  return { upper, lower, middle };
}

export function vwap(candles, resetEvery = 0) {
  let pv = 0;
  let vol = 0;
  return candles.map((c, i) => {
    if (resetEvery > 0 && i % resetEvery === 0) { pv = 0; vol = 0; }
    const volume = c.volume > 0 ? c.volume : 1;
    pv += ((c.high + c.low + c.close) / 3) * volume;
    vol += volume;
    return pv / vol;
  });
}

export function obv(candles) {
  const out = Array(candles.length).fill(0);
  for (let i = 1; i < candles.length; i++) {
    const volume = candles[i].volume || 1;
    out[i] = out[i - 1] + (candles[i].close > candles[i - 1].close ? volume : candles[i].close < candles[i - 1].close ? -volume : 0);
  }
  return out;
}

export function supertrend(candles, period = 10, multiplier = 3) {
  const atrValues = atr(candles, period);
  const upper = Array(candles.length).fill(null);
  const lower = Array(candles.length).fill(null);
  const value = Array(candles.length).fill(null);
  const direction = Array(candles.length).fill(0);
  for (let i = 0; i < candles.length; i++) {
    if (!finite(atrValues[i])) continue;
    const hl2 = (candles[i].high + candles[i].low) / 2;
    const basicUpper = hl2 + multiplier * atrValues[i];
    const basicLower = hl2 - multiplier * atrValues[i];
    if (i === 0 || !finite(upper[i - 1])) {
      upper[i] = basicUpper; lower[i] = basicLower;
    } else {
      upper[i] = basicUpper < upper[i - 1] || candles[i - 1].close > upper[i - 1] ? basicUpper : upper[i - 1];
      lower[i] = basicLower > lower[i - 1] || candles[i - 1].close < lower[i - 1] ? basicLower : lower[i - 1];
    }
    if (i === 0 || direction[i - 1] === 0) direction[i] = candles[i].close >= lower[i] ? 1 : -1;
    else if (direction[i - 1] === 1) direction[i] = candles[i].close < lower[i] ? -1 : 1;
    else direction[i] = candles[i].close > upper[i] ? 1 : -1;
    value[i] = direction[i] === 1 ? lower[i] : upper[i];
  }
  return { value, direction, upper, lower };
}

export function ichimoku(candles, conversion = 9, base = 26, spanBPeriod = 52) {
  const midpoint = (i, period) => {
    if (i < period - 1) return null;
    const slice = candles.slice(i - period + 1, i + 1);
    return (Math.max(...slice.map(c => c.high)) + Math.min(...slice.map(c => c.low))) / 2;
  };
  const conversionLine = candles.map((_, i) => midpoint(i, conversion));
  const baseLine = candles.map((_, i) => midpoint(i, base));
  const spanA = candles.map((_, i) => finite(conversionLine[i]) && finite(baseLine[i]) ? (conversionLine[i] + baseLine[i]) / 2 : null);
  const spanB = candles.map((_, i) => midpoint(i, spanBPeriod));
  return { conversion: conversionLine, base: baseLine, spanA, spanB };
}

export function efficiencyRatio(values, period = 10) {
  return values.map((v, i) => {
    if (i < period) return null;
    const change = Math.abs(v - values[i - period]);
    let volatility = 0;
    for (let j = i - period + 1; j <= i; j++) volatility += Math.abs(values[j] - values[j - 1]);
    return volatility === 0 ? 0 : change / volatility;
  });
}

export function linearRegression(values, period = 20) {
  const slope = Array(values.length).fill(null);
  const r2 = Array(values.length).fill(null);
  const xMean = (period - 1) / 2;
  let xVar = 0;
  for (let x = 0; x < period; x++) xVar += (x - xMean) ** 2;
  for (let i = period - 1; i < values.length; i++) {
    const slice = values.slice(i - period + 1, i + 1);
    const yMean = slice.reduce((a, b) => a + b, 0) / period;
    let cov = 0, yVar = 0;
    for (let x = 0; x < period; x++) {
      cov += (x - xMean) * (slice[x] - yMean);
      yVar += (slice[x] - yMean) ** 2;
    }
    slope[i] = xVar === 0 ? 0 : cov / xVar;
    const corr = xVar === 0 || yVar === 0 ? 0 : cov / Math.sqrt(xVar * yVar);
    r2[i] = corr ** 2;
  }
  return { slope, r2 };
}

export function percentileRank(values, lookback = 100) {
  return values.map((v, i) => {
    if (!finite(v)) return null;
    const start = Math.max(0, i - lookback + 1);
    const sample = values.slice(start, i + 1).filter(finite);
    if (sample.length < 10) return null;
    return sample.filter(x => x <= v).length / sample.length;
  });
}

export function zScore(values, period = 20) {
  const mean = sma(values, period);
  const sd = standardDeviation(values, period);
  return values.map((v, i) => finite(mean[i]) && finite(sd[i]) && sd[i] !== 0 ? (v - mean[i]) / sd[i] : null);
}

export function latest(series, fallback = null) {
  for (let i = series.length - 1; i >= 0; i--) if (finite(series[i])) return series[i];
  return fallback;
}

export function previous(series, offset = 1, fallback = null) {
  let count = 0;
  for (let i = series.length - 1; i >= 0; i--) {
    if (finite(series[i])) {
      if (count === offset) return series[i];
      count++;
    }
  }
  return fallback;
}

export { safe };
