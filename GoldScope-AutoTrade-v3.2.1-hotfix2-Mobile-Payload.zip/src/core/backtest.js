import { analyzeTimeframe, timeframeSeconds } from './market.js';
import { DEFAULT_SETTINGS, buildPlan } from './risk.js';
import { executionCosts, sideAdjustedCandle } from './execution.js';
import { applyAdaptiveLearning, adaptiveModelFingerprint } from './learning.js';

const finite = Number.isFinite;
const round = (v, d = 2) => Number(Number(v).toFixed(d));

function strategyIdentity(a, direction) {
  const s = a.snapshot;
  if (a.flags.ranging) return { strategy: 'Range mean reversion', strategyKey: 'range-mean-reversion' };

  const atr = Math.max(0.0001, Number(s.atr || 0));
  const nearUpper = finite(s.donchianUpper) && Math.abs(s.close - s.donchianUpper) / atr <= 0.22;
  const nearLower = finite(s.donchianLower) && Math.abs(s.close - s.donchianLower) / atr <= 0.22;
  if ((direction === 1 && nearUpper) || (direction === -1 && nearLower)) {
    return { strategy: 'Breakout retest', strategyKey: 'breakout-retest' };
  }

  const emaDistance = finite(s.ema20) ? Math.abs(s.close - s.ema20) / atr : 99;
  if (emaDistance <= 0.75) return { strategy: 'Trend pullback', strategyKey: 'trend-pullback' };
  return { strategy: 'Momentum continuation', strategyKey: 'momentum-continuation' };
}

function decideSetup(a, settings, adaptiveModel = null) {
  const s = a.snapshot;
  let direction = a.direction;
  let score = 45 + a.directionStrength * 0.35;
  if (!direction || !finite(s.atr)) return null;
  const pressureAlign = direction * Number(s.pressureNet || 0) / 100;

  if (a.flags.ranging) {
    if (s.priceZ < -1.15 && s.rsi < 42 && (s.buyPressure >= 48 || s.pressureShift > 12)) {
      direction = 1;
      score = 66 + Math.abs(s.priceZ) * 5 + Math.max(-5, s.pressureShift / 15);
    } else if (s.priceZ > 1.15 && s.rsi > 58 && (s.sellPressure >= 48 || s.pressureShift < -12)) {
      direction = -1;
      score = 66 + Math.abs(s.priceZ) * 5 + Math.max(-5, -s.pressureShift / 15);
    } else return null;
  } else {
    if (s.adx >= 23) score += 8;
    if (direction === 1 && s.macdHistogram > 0 && s.roc > 0) score += 7;
    if (direction === -1 && s.macdHistogram < 0 && s.roc < 0) score += 7;
    if (s.supertrendDirection === direction) score += 5;
    score += pressureAlign * 10;
    if (s.pressureConfidence >= 25 && pressureAlign < 0.05) return null;
    if (a.flags.highVol) score -= 5;
  }

  if (!finite(score)) return null;
  const identity = strategyIdentity(a, direction);
  const baseCandidate = {
    ...identity,
    timeframe: a.timeframe,
    timeframeLabel: a.label,
    regime: a.regime,
    direction,
    score: Math.round(score),
    evidence: [],
    warnings: []
  };
  const tuned = applyAdaptiveLearning([baseCandidate], adaptiveModel, settings)[0];
  if (!finite(Number(tuned.score)) || Number(tuned.score) < Number(settings.minScore)) return null;
  return {
    direction,
    score: Number(tuned.score),
    baseScore: Number(tuned.baseScore ?? baseCandidate.score),
    adaptiveAdjustment: Number(tuned.adaptiveAdjustment || 0),
    learnedWinRate: tuned.learnedWinRate,
    learnedExpectancyR: tuned.learnedExpectancyR,
    learningSamples: Number(tuned.learningSamples || 0),
    learningConfidence: Number(tuned.learningConfidence || 0),
    label: identity.strategy,
    strategyKey: identity.strategyKey
  };
}

function candidateForBacktest(candles, index, setup, analysis) {
  const next = candles[index + 1];
  const entry = Number(next?.open);
  if (!next || !finite(entry)) return null;
  const structure = setup.direction === 1 ? analysis.structure.lastLow : analysis.structure.lastHigh;
  return {
    strategy: setup.label,
    strategyKey: setup.strategyKey,
    timeframe: analysis.timeframe,
    timeframeLabel: analysis.label,
    regime: analysis.regime,
    direction: setup.direction,
    score: setup.score,
    baseScore: setup.baseScore,
    adaptiveAdjustment: setup.adaptiveAdjustment,
    learnedWinRate: setup.learnedWinRate,
    learnedExpectancyR: setup.learnedExpectancyR,
    learningSamples: setup.learningSamples,
    learningConfidence: setup.learningConfidence,
    atr: analysis.snapshot.atr,
    createdFromTime: analysis.candles.at(-1).time,
    entryLow: entry,
    entryHigh: entry,
    invalidationHint: structure,
    expiryTime: analysis.candles.at(-1).time + timeframeSeconds(analysis.timeframe) * 3,
    evidence: [],
    warnings: [],
    counterTrend: false,
    trigger: 'Backtest next-bar open'
  };
}

function simulateTrade(candles, index, setup, analysis, settings) {
  const next = candles[index + 1];
  const candidate = candidateForBacktest(candles, index, setup, analysis);
  if (!next || !candidate) return null;

  // Use the exact same risk/TP/position-sizing engine as live plan generation.
  const plan = buildPlan(candidate, analysis, settings);
  if (!plan) return null;

  const costs = executionCosts(settings);
  const chartEntry = plan.entry;
  const stop = plan.stopLoss;
  const completionTarget = ['tp1', 'tp2', 'tp3'].includes(plan.exitAtTarget) ? plan.exitAtTarget : 'tp2';
  const target = plan[completionTarget];
  const targetR = Number(plan[`${completionTarget}R`] || plan.riskReward || 0);
  const effectiveRisk = Number(plan.effectiveRiskDistance || Math.abs(chartEntry - stop) + costs.totalUsd);
  const maxHold = Math.max(1, Number(settings.backtestMaxHoldBars || 12));
  let exitIndex = Math.min(candles.length - 1, index + maxHold);
  let resultR = 0;
  let outcome = 'TIME';
  let exitPrice = candles[exitIndex].close;

  for (let j = index + 1; j <= Math.min(candles.length - 1, index + maxHold); j++) {
    const raw = candles[j];
    const exitCandle = sideAdjustedCandle(raw, setup.direction, costs.spreadUsd, 'exit');
    const hitStop = setup.direction === 1 ? exitCandle.low <= stop : exitCandle.high >= stop;
    const hitTarget = setup.direction === 1 ? exitCandle.high >= target : exitCandle.low <= target;
    if (hitStop && hitTarget) {
      resultR = -1; outcome = 'SL_AMBIGUOUS'; exitPrice = stop; exitIndex = j; break;
    }
    if (hitStop) {
      resultR = -1; outcome = 'SL'; exitPrice = stop; exitIndex = j; break;
    }
    if (hitTarget) {
      resultR = targetR; outcome = completionTarget.toUpperCase(); exitPrice = target; exitIndex = j; break;
    }
    if (j === Math.min(candles.length - 1, index + maxHold)) {
      const adjustedClose = exitCandle.close;
      const grossMove = setup.direction * (adjustedClose - chartEntry);
      resultR = (grossMove - costs.slippageUsd - costs.manualBufferUsd) / Math.max(0.0001, effectiveRisk);
      outcome = 'TIME'; exitPrice = adjustedClose; exitIndex = j;
    }
  }

  return {
    setup: setup.label,
    strategyKey: setup.strategyKey,
    timeframe: analysis.timeframe,
    regime: analysis.regime,
    direction: setup.direction === 1 ? 'BUY' : 'SELL',
    score: setup.score,
    baseScore: setup.baseScore,
    adaptiveAdjustment: round(setup.adaptiveAdjustment, 2),
    learnedWinRate: setup.learnedWinRate,
    learnedExpectancyR: setup.learnedExpectancyR,
    learningSamples: setup.learningSamples,
    learningConfidence: setup.learningConfidence,
    entryTime: next.time,
    exitTime: candles[exitIndex].time,
    entry: round(chartEntry),
    stop: round(stop),
    target: round(target),
    targetName: completionTarget.toUpperCase(),
    exit: round(exitPrice),
    lot: plan.lot,
    estimatedLossUsd: plan.estimatedLossUsd,
    estimatedMarginUsd: plan.estimatedMarginUsd,
    spreadPoints: costs.spreadPoints,
    executionCostPrice: round(costs.totalUsd, 5),
    executionCostUsd: round(costs.totalUsd * Number(plan.valuePerPriceUnit || 0), 4),
    grossPnlUsd: round(resultR * Number(plan.estimatedLossUsd || 0) + costs.totalUsd * Number(plan.valuePerPriceUnit || 0), 4),
    pnlUsd: round(resultR * Number(plan.estimatedLossUsd || 0), 4),
    resultR: round(resultR, 3),
    holdingSeconds: Math.max(0, Number(candles[exitIndex].time || 0) - Number(next.time || 0)),
    outcome,
    exitIndex
  };
}

function aggregateBy(trades, keyFn) {
  const groups = {};
  for (const trade of trades) {
    const key = String(keyFn(trade) || 'unknown');
    const bucket = groups[key] || { trades: 0, wins: 0, netR: 0, pnlUsd: 0 };
    bucket.trades += 1;
    bucket.wins += Number(trade.resultR) > 0 ? 1 : 0;
    bucket.netR += Number(trade.resultR || 0);
    bucket.pnlUsd += Number(trade.pnlUsd || 0);
    groups[key] = bucket;
  }
  return Object.fromEntries(Object.entries(groups).map(([key, value]) => [key, {
    ...value,
    winRate: value.trades ? round(value.wins / value.trades * 100, 1) : 0,
    netR: round(value.netR, 3),
    pnlUsd: round(value.pnlUsd, 2)
  }]));
}

function sequenceStats(trades) {
  let maxWins = 0; let maxLosses = 0; let wins = 0; let losses = 0;
  for (const trade of trades) {
    if (Number(trade.resultR) > 0) { wins += 1; losses = 0; maxWins = Math.max(maxWins, wins); }
    else if (Number(trade.resultR) < 0) { losses += 1; wins = 0; maxLosses = Math.max(maxLosses, losses); }
    else { wins = 0; losses = 0; }
  }
  return { consecutiveWins: maxWins, consecutiveLosses: maxLosses };
}

function metrics(trades) {
  const returns = trades.map(t => Number(t.resultR || 0));
  const wins = trades.filter(t => t.resultR > 0);
  const losses = trades.filter(t => t.resultR < 0);
  const grossProfit = wins.reduce((sum, trade) => sum + Number(trade.resultR || 0), 0);
  const grossLoss = Math.abs(losses.reduce((sum, trade) => sum + Number(trade.resultR || 0), 0));
  const totalCostsUsd = trades.reduce((sum, trade) => sum + Number(trade.executionCostUsd || 0), 0);
  const grossProfitUsd = trades.reduce((sum, trade) => sum + Math.max(0, Number(trade.grossPnlUsd || 0)), 0);
  const netPnlUsd = trades.reduce((sum, trade) => sum + Number(trade.pnlUsd || 0), 0);
  const mean = returns.length ? returns.reduce((a, b) => a + b, 0) / returns.length : 0;
  const variance = returns.length > 1 ? returns.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (returns.length - 1) : 0;
  const downside = returns.filter(value => value < 0);
  const downsideDeviation = downside.length ? Math.sqrt(downside.reduce((sum, value) => sum + value ** 2, 0) / downside.length) : 0;
  let equity = 0;
  let peak = 0;
  let maxDrawdown = 0;
  let drawdownStart = null;
  let longestDrawdownTrades = 0;
  const curve = trades.map((trade, index) => {
    equity += Number(trade.resultR || 0);
    if (equity >= peak) { peak = equity; drawdownStart = null; }
    else if (drawdownStart === null) drawdownStart = index;
    if (drawdownStart !== null) longestDrawdownTrades = Math.max(longestDrawdownTrades, index - drawdownStart + 1);
    maxDrawdown = Math.max(maxDrawdown, peak - equity);
    return { trade: index + 1, equity: round(equity, 3) };
  });
  const holding = trades.map(trade => Number(trade.holdingSeconds || 0)).filter(Number.isFinite);
  const sequence = sequenceStats(trades);
  return {
    trades: trades.length,
    wins: wins.length,
    losses: losses.length,
    winRate: trades.length ? round(wins.length / trades.length * 100, 1) : 0,
    averageWinR: wins.length ? round(grossProfit / wins.length, 3) : 0,
    averageLossR: losses.length ? round(-grossLoss / losses.length, 3) : 0,
    profitFactor: grossLoss ? round(grossProfit / grossLoss, 2) : grossProfit > 0 ? 99 : 0,
    expectancyR: trades.length ? round(equity / trades.length, 3) : 0,
    netR: round(equity, 2),
    netPnlUsd: round(netPnlUsd, 2),
    totalExecutionCostsUsd: round(totalCostsUsd, 2),
    costToGrossProfitRatio: grossProfitUsd > 0 ? round(totalCostsUsd / grossProfitUsd, 3) : null,
    maxDrawdownR: round(maxDrawdown, 2),
    averageDrawdownDurationTrades: trades.length ? round(longestDrawdownTrades / Math.max(1, trades.length), 3) : 0,
    maximumDrawdownDurationTrades: longestDrawdownTrades,
    sharpeLike: variance > 0 ? round(mean / Math.sqrt(variance) * Math.sqrt(returns.length), 3) : 0,
    sortinoLike: downsideDeviation > 0 ? round(mean / downsideDeviation * Math.sqrt(returns.length), 3) : 0,
    recoveryFactor: maxDrawdown > 0 ? round(equity / maxDrawdown, 3) : equity > 0 ? 99 : 0,
    ...sequence,
    averageHoldingSeconds: holding.length ? Math.round(holding.reduce((a, b) => a + b, 0) / holding.length) : 0,
    performanceByStrategy: aggregateBy(trades, trade => trade.strategyKey),
    performanceByTimeframe: aggregateBy(trades, trade => trade.timeframe),
    performanceByRegime: aggregateBy(trades, trade => trade.regime),
    performanceByHourUtc: aggregateBy(trades, trade => new Date(Number(trade.entryTime || 0) * 1000).getUTCHours()),
    monthlyStability: aggregateBy(trades, trade => new Date(Number(trade.exitTime || 0) * 1000).toISOString().slice(0, 7)),
    curve
  };
}

function seededRandom(seedInput = 123456789) {
  let seed = Number(seedInput) >>> 0;
  return () => {
    seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5;
    return (seed >>> 0) / 4294967296;
  };
}

export function monteCarloTradeOrder(trades = [], { iterations = 500, seed = 42 } = {}) {
  const values = trades.map(trade => Number(trade.resultR || 0));
  if (!values.length) return { iterations: 0, medianNetR: 0, p05NetR: 0, p95NetR: 0, medianMaxDrawdownR: 0 };
  const random = seededRandom(seed);
  const results = [];
  for (let run = 0; run < Math.max(1, Math.min(5000, Number(iterations || 500))); run += 1) {
    const shuffled = [...values];
    for (let index = shuffled.length - 1; index > 0; index -= 1) {
      const swap = Math.floor(random() * (index + 1));
      [shuffled[index], shuffled[swap]] = [shuffled[swap], shuffled[index]];
    }
    let equity = 0; let peak = 0; let maxDrawdown = 0;
    for (const value of shuffled) { equity += value; peak = Math.max(peak, equity); maxDrawdown = Math.max(maxDrawdown, peak - equity); }
    results.push({ netR: equity, maxDrawdownR: maxDrawdown });
  }
  const quantile = (key, q) => results.map(row => row[key]).sort((a, b) => a - b)[Math.min(results.length - 1, Math.floor((results.length - 1) * q))];
  return {
    iterations: results.length,
    seed,
    medianNetR: round(quantile('netR', 0.5), 3),
    p05NetR: round(quantile('netR', 0.05), 3),
    p95NetR: round(quantile('netR', 0.95), 3),
    medianMaxDrawdownR: round(quantile('maxDrawdownR', 0.5), 3),
    p95MaxDrawdownR: round(quantile('maxDrawdownR', 0.95), 3)
  };
}

export function stressTestTradeResults(trades = [], { spreadMultiplier = 1.5, slippageR = 0.05, delayedEntryR = 0.05 } = {}) {
  const additionalCostR = Math.max(0, Number(spreadMultiplier || 1) - 1) * 0.05 + Math.max(0, Number(slippageR || 0)) + Math.max(0, Number(delayedEntryR || 0));
  const stressed = trades.map(trade => ({ ...trade, resultR: round(Number(trade.resultR || 0) - additionalCostR, 4) }));
  return { assumptions: { spreadMultiplier, slippageR, delayedEntryR, additionalCostR: round(additionalCostR, 4) }, summary: metrics(stressed) };
}

export function runBacktest(candles, timeframe = '15min', settingsInput = {}, adaptiveModel = null) {
  const settings = { ...DEFAULT_SETTINGS, ...settingsInput };
  const trades = [];
  const warmup = Math.min(220, Math.max(80, Math.floor(candles.length * 0.35)));
  let i = warmup;
  while (i < candles.length - 2) {
    const history = candles.slice(0, i + 1);
    let analysis;
    try { analysis = analyzeTimeframe(history, timeframe); }
    catch { i++; continue; }
    const setup = decideSetup(analysis, settings, adaptiveModel);
    if (!setup) { i++; continue; }
    const trade = simulateTrade(candles, i, setup, analysis, settings);
    if (!trade) { i++; continue; }
    trades.push(trade);
    i = Math.max(i + 1, trade.exitIndex + 1);
  }
  const summary = metrics(trades);
  const sourceSpanSeconds = candles.length > 1 ? Math.max(1, Number(candles.at(-1).time) - Number(candles[0].time)) : 1;
  summary.exposureTimePercent = round(trades.reduce((sum, trade) => sum + Number(trade.holdingSeconds || 0), 0) / sourceSpanSeconds * 100, 2);
  const monteCarlo = monteCarloTradeOrder(trades, { iterations: 500, seed: 42 });
  const stressTests = {
    moderate: stressTestTradeResults(trades, { spreadMultiplier: 1.5, slippageR: 0.05, delayedEntryR: 0.05 }),
    severe: stressTestTradeResults(trades, { spreadMultiplier: 2, slippageR: 0.1, delayedEntryR: 0.1 })
  };
  const costs = executionCosts(settings);
  const adaptiveEnabled = Boolean(settings.adaptiveLearning && adaptiveModel?.enabled);
  const adjustedTrades = trades.filter(t => Math.abs(Number(t.adaptiveAdjustment || 0)) >= 0.05).length;
  return {
    id: `bt-${Date.now()}`,
    generatedAt: new Date().toISOString(),
    timeframe,
    timeframeSeconds: timeframeSeconds(timeframe),
    candles: candles.length,
    note: adaptiveEnabled
      ? 'Walk-forward ใช้ Adaptive Learning ปัจจุบันแบบแช่แข็ง และใช้ Risk/TP engine เดียวกับแผนจริง'
      : 'Walk-forward ใช้ Base Algorithm และ Risk/TP engine เดียวกับแผนจริง',
    adaptive: {
      enabled: adaptiveEnabled,
      fingerprint: adaptiveEnabled ? (adaptiveModel.fingerprint || adaptiveModelFingerprint(adaptiveModel, settings)) : null,
      eligibleTrades: adaptiveModel?.eligibleTrades || 0,
      confidence: adaptiveModel?.overall?.confidence || 0,
      expectancyR: adaptiveModel?.overall?.expectancyR || 0,
      adjustedTrades
    },
    settings: {
      profile: settings.profile,
      minScore: settings.minScore,
      positionSizingMode: settings.positionSizingMode,
      fixedLot: settings.fixedLot,
      accountSize: settings.accountSize,
      riskPercent: settings.riskPercent,
      targetRiskReward: settings.targetRiskReward,
      exitAtTarget: settings.exitAtTarget,
      brokerDigits: settings.brokerDigits,
      spreadPoints: costs.spreadPoints,
      slippagePoints: costs.slippagePoints,
      executionCostUsd: round(costs.totalUsd, 3),
      maxHoldBars: settings.backtestMaxHoldBars
    },
    methodology: { nextBarEntry: true, conservativeSameBarSlTp: true, adaptiveModelFrozen: true, transactionCostsIncluded: true, futureDataUsed: false },
    monteCarlo,
    stressTests,
    summary,
    trades
  };
}
