const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const finite = Number.isFinite;

export function pointSizeFromSettings(settings = {}) {
  const explicit = Number(settings.pointSize);
  if (finite(explicit) && explicit > 0) return explicit;
  const digits = clamp(Math.round(Number(settings.brokerDigits ?? 2)), 0, 6);
  return 10 ** -digits;
}

export function executionCosts(settings = {}) {
  const pointSize = pointSizeFromSettings(settings);
  const spreadPoints = Math.max(0, Number(settings.spreadPoints ?? 0));
  const slippagePoints = Math.max(0, Number(settings.slippagePoints ?? 0));
  const manualEntryBufferPoints = Math.max(0, Number(settings.manualEntryBufferPoints ?? 0));

  // Backward compatibility for settings saved by v1.1.x.
  const legacySpread = Math.max(0, Number(settings.spread ?? 0));
  const legacySlippage = Math.max(0, Number(settings.slippage ?? 0));
  const spreadUsd = spreadPoints > 0 ? spreadPoints * pointSize : legacySpread;
  const slippageUsd = slippagePoints > 0 ? slippagePoints * pointSize : legacySlippage;
  const manualBufferUsd = manualEntryBufferPoints * pointSize;
  const totalUsd = spreadUsd + slippageUsd + manualBufferUsd;

  return {
    pointSize,
    brokerDigits: Math.max(0, Math.round(-Math.log10(pointSize))),
    spreadPoints,
    slippagePoints,
    manualEntryBufferPoints,
    spreadUsd,
    slippageUsd,
    manualBufferUsd,
    totalUsd
  };
}

export function executionAwareTargetDistance(stopDistance, desiredNetR, totalCost) {
  const stop = Math.max(0, Number(stopDistance || 0));
  const r = Math.max(0, Number(desiredNetR || 0));
  const cost = Math.max(0, Number(totalCost || 0));
  // Net reward = gross target - cost; effective risk = stop + cost.
  return r * (stop + cost) + cost;
}

export function effectiveRiskReward(stopDistance, grossTargetDistance, totalCost) {
  const stop = Math.max(0, Number(stopDistance || 0));
  const target = Math.max(0, Number(grossTargetDistance || 0));
  const cost = Math.max(0, Number(totalCost || 0));
  const effectiveRisk = stop + cost;
  if (!effectiveRisk) return 0;
  return (target - cost) / effectiveRisk;
}

export function priceToPoints(distance, settings = {}) {
  const pointSize = pointSizeFromSettings(settings);
  return pointSize > 0 ? Math.round(Number(distance || 0) / pointSize) : 0;
}

export function sideAdjustedCandle(candle, direction, spreadUsd, phase = 'exit') {
  const spread = Math.max(0, Number(spreadUsd || 0));
  // Most retail XAU charts/candles are bid-based. BUY opens at ask, while BUY exits
  // are triggered by bid. SELL opens at bid, while SELL exits are triggered by ask.
  if (phase === 'entry' && direction === 1) {
    return { ...candle, open: candle.open + spread, high: candle.high + spread, low: candle.low + spread, close: candle.close + spread };
  }
  if (phase === 'exit' && direction === -1) {
    return { ...candle, open: candle.open + spread, high: candle.high + spread, low: candle.low + spread, close: candle.close + spread };
  }
  return candle;
}
