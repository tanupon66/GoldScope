const TF_SECONDS = Object.freeze({ '1min': 60, '5min': 300, '15min': 900, '1h': 3600, '4h': 14400 });
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

export function timeframeSeconds(timeframe) {
  return TF_SECONDS[timeframe] || 300;
}

export function closedCandlesOnly(candles = [], timeframe = '5min', nowMs = Date.now()) {
  const closeBefore = Math.floor(nowMs / 1000) - timeframeSeconds(timeframe);
  return candles.filter(row => Number(row?.time) <= closeBefore);
}

export function inspectCandleQuality(candles = [], timeframe = '5min', options = {}) {
  const nowMs = Number(options.nowMs || Date.now());
  const expected = timeframeSeconds(timeframe);
  const staleAfter = Number(options.staleAfterSeconds || Math.max(expected * 2.5, 180));
  const rows = (Array.isArray(candles) ? candles : []).filter(row =>
    Number.isFinite(Number(row?.time)) && ['open', 'high', 'low', 'close'].every(key => Number.isFinite(Number(row?.[key])))
  );
  let duplicateCount = 0;
  let outOfOrderCount = 0;
  let gapCount = 0;
  const seen = new Set();
  for (let index = 0; index < rows.length; index += 1) {
    const time = Number(rows[index].time);
    if (seen.has(time)) duplicateCount += 1;
    seen.add(time);
    if (index && time < Number(rows[index - 1].time)) outOfOrderCount += 1;
  }
  const uniqueSorted = [...new Map(rows.map(row => [Number(row.time), row])).values()].sort((a, b) => Number(a.time) - Number(b.time));
  for (let index = 1; index < uniqueSorted.length; index += 1) {
    const delta = Number(uniqueSorted[index].time) - Number(uniqueSorted[index - 1].time);
    if (delta > expected * 1.8) gapCount += Math.max(1, Math.round(delta / expected) - 1);
  }
  const latest = uniqueSorted.at(-1);
  const ageSeconds = latest ? Math.max(0, Math.floor(nowMs / 1000 - Number(latest.time))) : Infinity;
  const freshness = latest ? clamp(100 - Math.max(0, ageSeconds - expected) / Math.max(expected, 1) * 35, 0, 100) : 0;
  const completeness = clamp(100 - gapCount * 8, 0, 100);
  const ordering = clamp(100 - outOfOrderCount * 30 - duplicateCount * 12, 0, 100);
  const continuity = clamp(100 - gapCount * 10, 0, 100);
  const score = Math.round(freshness * 0.4 + completeness * 0.2 + ordering * 0.2 + continuity * 0.2);
  const blockingReasons = [];
  if (uniqueSorted.length < Number(options.minimumCandles || 80)) blockingReasons.push('INSUFFICIENT_CANDLES');
  if (ageSeconds > staleAfter) blockingReasons.push('STALE_CANDLE');
  if (outOfOrderCount > 0) blockingReasons.push('OUT_OF_ORDER_CANDLE');
  if (duplicateCount > Number(options.maxDuplicates || 0)) blockingReasons.push('DUPLICATE_CANDLE');
  if (score < Number(options.minimumScore || 70)) blockingReasons.push('LOW_DATA_QUALITY');
  return {
    ok: blockingReasons.length === 0,
    score,
    freshness: Math.round(freshness),
    completeness: Math.round(completeness),
    ordering: Math.round(ordering),
    continuity: Math.round(continuity),
    ageSeconds,
    duplicateCount,
    outOfOrderCount,
    gapCount,
    blockingReasons,
    candles: uniqueSorted
  };
}

export function spreadQuality(spreadUsd, maximumSpreadUsd) {
  const spread = Math.max(0, Number(spreadUsd || 0));
  const maximum = Math.max(0.000001, Number(maximumSpreadUsd || 0.8));
  return Math.round(clamp(100 - spread / maximum * 70, 0, 100));
}
