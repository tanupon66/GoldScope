export const DEFAULT_READINESS_THRESHOLDS = Object.freeze({
  minimumClosedDemoTrades: 100,
  minimumForwardTestDays: 28,
  maximumCriticalExecutionErrors: 0,
  maximumDuplicateOrders: 0,
  maximumUnresolvedOrderIntents: 0,
  maximumDrawdownPercent: 20
});

export function evaluateLiveReadiness(input = {}, thresholdsInput = {}) {
  const thresholds = { ...DEFAULT_READINESS_THRESHOLDS, ...(thresholdsInput || {}) };
  const checks = [
    ['BROKER_CALIBRATION', Boolean(input.calibrationPassed), 'Broker calibration ยังไม่ผ่าน'],
    ['DEMO_TRADES', Number(input.closedDemoTrades || 0) >= thresholds.minimumClosedDemoTrades, `Demo trades ต้องไม่น้อยกว่า ${thresholds.minimumClosedDemoTrades}`],
    ['FORWARD_DAYS', Number(input.forwardTestDays || 0) >= thresholds.minimumForwardTestDays, `Forward test ต้องไม่น้อยกว่า ${thresholds.minimumForwardTestDays} วัน`],
    ['CRITICAL_ERRORS', Number(input.criticalExecutionErrors || 0) <= thresholds.maximumCriticalExecutionErrors, 'ยังมี critical execution error'],
    ['DUPLICATE_ORDERS', Number(input.duplicateOrders || 0) <= thresholds.maximumDuplicateOrders, 'พบ duplicate order'],
    ['UNRESOLVED_INTENTS', Number(input.unresolvedOrderIntents || 0) <= thresholds.maximumUnresolvedOrderIntents, 'ยังมี order intent ที่ไม่ทราบผล'],
    ['EXPECTANCY', Number(input.outOfSampleExpectancy || 0) > 0, 'Out-of-sample expectancy หลังต้นทุนยังไม่เป็นบวก'],
    ['DRAWDOWN', Number(input.maximumDrawdownPercent ?? Infinity) <= thresholds.maximumDrawdownPercent, `Drawdown เกิน ${thresholds.maximumDrawdownPercent}%`],
    ['KILL_SWITCH_TEST', Boolean(input.killSwitchTestPassed), 'Kill switch test ยังไม่ผ่าน'],
    ['RECONCILIATION_TEST', Boolean(input.reconciliationTestPassed), 'Reconciliation test ยังไม่ผ่าน'],
    ['CONFIG_FROZEN', Boolean(input.configFrozen), 'Config/model ยังไม่ถูก freeze']
  ].map(([code, passed, message]) => ({ code, passed, message: passed ? null : message }));
  return {
    passed: checks.every(check => check.passed),
    checks,
    blockingReasons: checks.filter(check => !check.passed).map(check => check.code),
    thresholds
  };
}
