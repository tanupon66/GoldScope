export function refreshIntervalMs(settings = {}) {
  const seconds = Math.max(30, Number(settings.refreshSeconds || 60));
  return seconds * 1000;
}

export function staleThresholdMs(settings = {}) {
  // Give the timer a small grace period, then treat data as stale.
  return Math.max(45_000, refreshIntervalMs(settings) * 1.2);
}

export function isDataStale(lastUpdated, settings = {}, now = Date.now()) {
  const last = Number(lastUpdated || 0);
  if (!last) return true;
  return now - last >= staleThresholdMs(settings);
}

export function secondsUntilRefresh(nextRefreshAt, now = Date.now()) {
  const next = Number(nextRefreshAt || 0);
  if (!next) return 0;
  return Math.max(0, Math.ceil((next - now) / 1000));
}

export function dataAgeSeconds(lastUpdated, now = Date.now()) {
  const last = Number(lastUpdated || 0);
  if (!last) return null;
  return Math.max(0, Math.floor((now - last) / 1000));
}
