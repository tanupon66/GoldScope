import { combineMarketBias, timeframeSeconds } from './market.js';

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const finite = Number.isFinite;
const round = (v, d = 2) => Number(v.toFixed(d));

function baseCandidate(strategy, analysis, direction, score, fields = {}) {
  const s = analysis.snapshot;
  return {
    strategy,
    strategyKey: strategy.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    timeframe: analysis.timeframe,
    timeframeLabel: analysis.label,
    direction,
    score: finite(Number(score)) ? clamp(Math.round(Number(score)), 0, 100) : NaN,
    atr: s.atr,
    createdFromTime: analysis.candles.at(-1).time,
    currentPrice: s.close,
    regime: analysis.regime,
    evidence: [],
    warnings: [],
    counterTrend: false,
    ...fields
  };
}

function multiTfAlignment(direction, analysis, analyses) {
  const weights = { '1min': 0.5, '5min': 1, '15min': 1.4, '1h': 1.8, '4h': 2.2 };
  let aligned = 0;
  let total = 0;
  for (const a of Object.values(analyses)) {
    if (a.timeframe === analysis.timeframe) continue;
    const w = weights[a.timeframe] || 1;
    total += w;
    if (a.direction === direction) aligned += w;
    else if (a.direction === -direction) aligned -= w * 0.8;
  }
  return total ? aligned / total : 0;
}



function pressureAlignment(direction, snapshot) {
  if (!finite(snapshot.pressureNet)) return 0;
  return clamp(direction * snapshot.pressureNet / 100, -1, 1);
}

function pressureEvidence(candidate, direction, snapshot) {
  const aligned = pressureAlignment(direction, snapshot);
  const side = direction === 1 ? 'ซื้อ' : 'ขาย';
  const value = direction === 1 ? snapshot.buyPressure : snapshot.sellPressure;
  if (aligned >= 0.12) candidate.evidence.push(`แรง${side}ประมาณ ${round(value, 1)}% สนับสนุนทิศทาง`);
  if (aligned <= -0.18) candidate.warnings.push(`แรงฝั่งตรงข้ามเด่น (${round(direction === 1 ? snapshot.sellPressure : snapshot.buyPressure, 1)}%)`);
  if (!snapshot.pressureVolumeAvailable) candidate.warnings.push('แรงซื้อ/ขายเป็น proxy จาก OHLC เพราะแหล่งข้อมูลไม่มี volume ที่เชื่อถือได้');
  return aligned;
}

function trendPullback(analysis, analyses) {
  const s = analysis.snapshot;
  if (!analysis.flags.trending || !finite(s.ema20) || !finite(s.ema50) || !finite(s.atr)) return null;
  const direction = analysis.direction;
  if (!direction) return null;
  const alignment = multiTfAlignment(direction, analysis, analyses);
  const targetEma = Math.abs(s.close - s.ema20) < Math.abs(s.close - s.ema50) ? s.ema20 : s.ema50;
  const distanceAtr = Math.abs(s.close - targetEma) / s.atr;
  if (distanceAtr > 2.2) return null;
  const width = s.atr * 0.16;
  const entryLow = targetEma - width;
  const entryHigh = targetEma + width;
  const pressure = pressureAlignment(direction, s);
  let score = 61 + Math.min(14, s.adx / 4) + alignment * 13 + Math.min(8, s.efficiency * 15) + pressure * 7;
  if (direction === 1 && s.rsi > 76 || direction === -1 && s.rsi < 24) score -= 9;
  const c = baseCandidate('Trend pullback', analysis, direction, score, {
    entryLow, entryHigh,
    trigger: 'รอราคาแตะโซน EMA และแท่งยืนยันกลับตามแนวโน้ม',
    invalidationHint: direction === 1 ? analysis.structure.lastLow : analysis.structure.lastHigh,
    expiryBars: 10
  });
  c.evidence.push(`ADX ${round(s.adx, 1)} ยืนยันแรงแนวโน้ม`, `EMA20/50 เรียงตัวตามทิศ`, `สอดคล้องหลายกรอบเวลา ${Math.round(alignment * 100)}%`);
  pressureEvidence(c, direction, s);
  if (distanceAtr > 1.2) c.warnings.push('ราคายังห่างโซนเข้า ควรรอ ไม่ไล่ราคา');
  return c;
}

function momentumContinuation(analysis, analyses) {
  const s = analysis.snapshot;
  const direction = analysis.direction;
  if (!direction || s.adx < 20 || Math.abs(s.macdHistogram) < s.atr * 0.01) return null;
  const alignment = multiTfAlignment(direction, analysis, analyses);
  const pressure = pressureAlignment(direction, s);
  const momentumOk = direction === 1
    ? s.macdHistogram > 0 && s.roc > 0 && s.rsi >= 52
    : s.macdHistogram < 0 && s.roc < 0 && s.rsi <= 48;
  if (!momentumOk || (s.pressureConfidence >= 25 && pressure < 0.08)) return null;
  const entry = direction === 1 ? Math.max(s.close, s.ema20) : Math.min(s.close, s.ema20);
  const width = s.atr * 0.12;
  let score = 58 + s.adx * 0.45 + alignment * 12 + Math.min(8, Math.abs(s.roc) * 2) + pressure * 10;
  if (analysis.flags.highVol) score -= 5;
  const c = baseCandidate('Momentum continuation', analysis, direction, score, {
    entryLow: entry - width,
    entryHigh: entry + width,
    trigger: 'รอแท่งปิดยืนยันโมเมนตัมและไม่เกิดแท่งสวนขนาดใหญ่',
    invalidationHint: direction === 1 ? s.ema50 : s.ema50,
    expiryBars: 6
  });
  c.evidence.push('MACD, ROC และ RSI ไปทิศเดียวกัน', `ADX ${round(s.adx, 1)}`, `แรงหลายกรอบเวลา ${Math.round(alignment * 100)}%`);
  pressureEvidence(c, direction, s);
  if (analysis.flags.highVol) c.warnings.push('ความผันผวนสูง มีโอกาส slippage และไส้เทียนกว้าง');
  return c;
}

function breakoutRetest(analysis, analyses) {
  const s = analysis.snapshot;
  if (!finite(s.donchianUpper) || !finite(s.donchianLower) || !finite(s.atr)) return null;
  const prev = analysis.candles.at(-2);
  let direction = 0;
  let level = null;
  if (s.close >= s.donchianUpper - s.atr * 0.12 && prev.close < s.donchianUpper) { direction = 1; level = s.donchianUpper; }
  if (s.close <= s.donchianLower + s.atr * 0.12 && prev.close > s.donchianLower) { direction = -1; level = s.donchianLower; }
  if (!direction) return null;
  const alignment = multiTfAlignment(direction, analysis, analyses);
  const pressure = pressureAlignment(direction, s);
  if (s.pressureConfidence >= 25 && pressure < 0.12 && direction * s.pressureShift < 8) return null;
  const width = s.atr * 0.14;
  let score = 62 + Math.min(12, s.adx * 0.35) + alignment * 12 + pressure * 9 + clamp(direction * s.pressureShift / 18, -4, 4);
  if (analysis.flags.lowVol) score += 4;
  if (analysis.flags.highVol) score -= 6;
  const c = baseCandidate('Breakout retest', analysis, direction, score, {
    entryLow: level - width,
    entryHigh: level + width,
    trigger: 'รอเบรกจริงแล้วกลับมาทดสอบระดับเดิมโดยไม่ปิดกลับเข้ากรอบ',
    invalidationHint: direction === 1 ? level - s.atr * 0.9 : level + s.atr * 0.9,
    expiryBars: 8
  });
  c.evidence.push('ราคาอยู่ใกล้ขอบ Donchian 20', 'มีโอกาสเกิด breakout + retest', `การยืนยันหลายกรอบเวลา ${Math.round(alignment * 100)}%`);
  pressureEvidence(c, direction, s);
  c.warnings.push('Breakout ปลอมเกิดบ่อย ต้องรอแท่งปิดและ retest');
  return c;
}

function rangeMeanReversion(analysis, analyses) {
  const s = analysis.snapshot;
  if (!analysis.flags.ranging || !finite(s.bbLower) || !finite(s.bbUpper) || !finite(s.priceZ)) return [];
  const out = [];
  const nearLower = (s.close - s.bbLower) / s.atr < 0.45;
  const nearUpper = (s.bbUpper - s.close) / s.atr < 0.45;
  if (nearLower && s.rsi < 43 && s.priceZ < -0.8 && (s.buyPressure >= 48 || s.pressureShift > 12)) {
    const alignment = multiTfAlignment(1, analysis, analyses);
    const c = baseCandidate('Range mean reversion', analysis, 1, 64 + Math.abs(s.priceZ) * 6 + Math.max(-7, alignment * 7), {
      entryLow: s.bbLower - s.atr * 0.08,
      entryHigh: s.bbLower + s.atr * 0.2,
      trigger: 'รอแท่งกลับตัวบริเวณขอบล่าง Bollinger/แนวรับ',
      invalidationHint: analysis.levels.supports[0]?.price,
      expiryBars: 6
    });
    c.evidence.push(`Z-score ${round(s.priceZ, 2)} อยู่ต่ำกว่าค่าเฉลี่ย`, `RSI ${round(s.rsi, 1)}`, 'ตลาดถูกจัดเป็นกรอบ');
    pressureEvidence(c, 1, s);
    c.counterTrend = analyses['1h']?.direction === -1;
    out.push(c);
  }
  if (nearUpper && s.rsi > 57 && s.priceZ > 0.8 && (s.sellPressure >= 48 || s.pressureShift < -12)) {
    const alignment = multiTfAlignment(-1, analysis, analyses);
    const c = baseCandidate('Range mean reversion', analysis, -1, 64 + Math.abs(s.priceZ) * 6 + Math.max(-7, alignment * 7), {
      entryLow: s.bbUpper - s.atr * 0.2,
      entryHigh: s.bbUpper + s.atr * 0.08,
      trigger: 'รอแท่งกลับตัวบริเวณขอบบน Bollinger/แนวต้าน',
      invalidationHint: analysis.levels.resistances[0]?.price,
      expiryBars: 6
    });
    c.evidence.push(`Z-score ${round(s.priceZ, 2)} อยู่สูงกว่าค่าเฉลี่ย`, `RSI ${round(s.rsi, 1)}`, 'ตลาดถูกจัดเป็นกรอบ');
    pressureEvidence(c, -1, s);
    c.counterTrend = analyses['1h']?.direction === 1;
    out.push(c);
  }
  return out;
}

function liquiditySweep(analysis, analyses) {
  const s = analysis.snapshot;
  const c = analysis.candles.at(-1);
  const p = analysis.candles.at(-2);
  const lastHigh = analysis.swings.highs.at(-1)?.price;
  const lastLow = analysis.swings.lows.at(-1)?.price;
  let direction = 0;
  let level;
  if (finite(lastLow) && c.low < lastLow && c.close > lastLow && c.close > c.open) { direction = 1; level = lastLow; }
  if (finite(lastHigh) && c.high > lastHigh && c.close < lastHigh && c.close < c.open) { direction = -1; level = lastHigh; }
  if (!direction) return null;
  const wickRatio = direction === 1 ? (Math.min(c.open, c.close) - c.low) / Math.max(0.01, Math.abs(c.close - c.open)) : (c.high - Math.max(c.open, c.close)) / Math.max(0.01, Math.abs(c.close - c.open));
  const alignment = multiTfAlignment(direction, analysis, analyses);
  const pressure = pressureAlignment(direction, s);
  const reversalShift = clamp(direction * s.pressureShift / 15, -5, 6);
  let score = 66 + Math.min(10, wickRatio * 2.5) + Math.max(-8, alignment * 8) + pressure * 5 + reversalShift;
  if (Math.abs(c.close - p.close) > s.atr * 1.8) score -= 7;
  const width = s.atr * 0.13;
  const entry = direction === 1 ? Math.max(level, c.close - s.atr * 0.35) : Math.min(level, c.close + s.atr * 0.35);
  const cand = baseCandidate('Liquidity sweep reversal', analysis, direction, score, {
    entryLow: entry - width,
    entryHigh: entry + width,
    trigger: 'รอแท่ง sweep ปิดกลับในโครงสร้างและแท่งถัดไปไม่ทำจุดสุดโต่งใหม่',
    invalidationHint: direction === 1 ? c.low : c.high,
    expiryBars: 4
  });
  cand.evidence.push('ราคาแทงผ่าน swing แล้วปิดกลับ', `อัตราไส้เทียนต่อ body ${round(wickRatio, 1)}x`, `ระดับ sweep ${round(level)}`);
  pressureEvidence(cand, direction, s);
  cand.warnings.push('เป็นรูปแบบกลับตัว ต้องลดขนาดความเสี่ยงเมื่อสวน H1/H4');
  cand.counterTrend = analyses['1h']?.direction === -direction || analyses['4h']?.direction === -direction;
  return cand;
}

function supportResistanceRejection(analysis, analyses) {
  const s = analysis.snapshot;
  const patterns = analysis.patterns.filter(p => p.direction !== 0);
  if (!patterns.length || !finite(s.atr)) return null;
  const strongest = patterns.sort((a, b) => b.weight - a.weight)[0];
  const direction = strongest.direction;
  const levels = direction === 1 ? analysis.levels.supports : analysis.levels.resistances;
  const level = levels.find(l => Math.abs(l.price - s.close) <= s.atr * 0.8);
  if (!level) return null;
  const alignment = multiTfAlignment(direction, analysis, analyses);
  const pressure = pressureAlignment(direction, s);
  let score = 60 + strongest.weight + level.strength * 0.14 + alignment * 10 + pressure * 7;
  const width = s.atr * 0.16;
  const c = baseCandidate('S/R rejection', analysis, direction, score, {
    entryLow: s.close - width,
    entryHigh: s.close + width,
    trigger: `รอการยืนยัน ${strongest.name} บริเวณระดับสำคัญ`,
    invalidationHint: direction === 1 ? level.price - s.atr * 0.75 : level.price + s.atr * 0.75,
    expiryBars: 5
  });
  c.evidence.push(strongest.name, `ระดับถูกแตะ ${level.touches} ครั้ง`, `ความแข็งแรงระดับ ${Math.round(level.strength)}/100`);
  pressureEvidence(c, direction, s);
  c.counterTrend = analyses['1h']?.direction === -direction;
  return c;
}

function fairValueGapRetest(analysis, analyses) {
  const s = analysis.snapshot;
  if (!analysis.fvgs.length || !finite(s.atr)) return null;
  const gaps = analysis.fvgs.slice().reverse();
  const gap = gaps.find(g => Math.abs(((g.low + g.high) / 2) - s.close) <= s.atr * 2.2);
  if (!gap) return null;
  const direction = gap.type === 'bullish' ? 1 : -1;
  const alignment = multiTfAlignment(direction, analysis, analyses);
  const pressure = pressureAlignment(direction, s);
  let score = 57 + alignment * 12 + pressure * 6 + Math.min(10, (analysis.candles.length - gap.index < 20 ? 8 : 3));
  const width = Math.max((gap.high - gap.low) * 0.2, s.atr * 0.08);
  const c = baseCandidate('FVG retest', analysis, direction, score, {
    entryLow: gap.low - width,
    entryHigh: gap.high + width,
    trigger: 'รอราคากลับเข้า FVG แล้วเกิดแรงปฏิเสธตามทิศเดิม',
    invalidationHint: direction === 1 ? gap.low - s.atr * 0.7 : gap.high + s.atr * 0.7,
    expiryBars: 12
  });
  c.evidence.push(`พบ ${gap.type === 'bullish' ? 'Bullish' : 'Bearish'} FVG ที่ยังไม่เต็ม`, `ช่วง ${round(gap.low)}–${round(gap.high)}`, `alignment ${Math.round(alignment * 100)}%`);
  pressureEvidence(c, direction, s);
  c.warnings.push('FVG เป็นเพียงโซนความไม่สมดุล ไม่ใช่การรับประกันว่าจะกลับตัว');
  return c;
}

function ichimokuContinuation(analysis, analyses) {
  const s = analysis.snapshot;
  if (![s.ichimokuTop, s.ichimokuBottom, s.ichimokuBase, s.ichimokuConversion].every(finite)) return null;
  let direction = 0;
  if (s.close > s.ichimokuTop && s.ichimokuConversion > s.ichimokuBase) direction = 1;
  if (s.close < s.ichimokuBottom && s.ichimokuConversion < s.ichimokuBase) direction = -1;
  if (!direction) return null;
  const alignment = multiTfAlignment(direction, analysis, analyses);
  const pressure = pressureAlignment(direction, s);
  let score = 59 + alignment * 13 + pressure * 7 + Math.min(10, s.adx * 0.3);
  const base = s.ichimokuBase;
  const width = s.atr * 0.15;
  const c = baseCandidate('Ichimoku continuation', analysis, direction, score, {
    entryLow: base - width,
    entryHigh: base + width,
    trigger: 'รอ pullback สู่ Kijun/ขอบเมฆแล้วปิดกลับตามแนวโน้ม',
    invalidationHint: direction === 1 ? s.ichimokuBottom : s.ichimokuTop,
    expiryBars: 10
  });
  c.evidence.push('ราคาอยู่นอกเมฆ', 'Tenkan/Kijun เรียงตามทิศ', `alignment ${Math.round(alignment * 100)}%`);
  pressureEvidence(c, direction, s);
  return c;
}

function addGlobalAdjustments(candidate, analysis, analyses, bias) {
  if (!candidate || !finite(Number(candidate.score))) return null;
  const s = analysis.snapshot;
  if (analysis.stale) {
    candidate.score -= 18;
    candidate.warnings.push('ข้อมูลกรอบเวลานี้เก่า โปรดตรวจราคาจริงก่อนใช้');
  }
  if (bias.direction && bias.direction !== candidate.direction) {
    candidate.score -= 8;
    candidate.counterTrend = true;
    candidate.warnings.push('ทิศทางสวน bias รวมของหลายกรอบเวลา');
  } else if (bias.direction === candidate.direction) candidate.score += 4;
  if (bias.conflict >= 40) {
    candidate.score -= 5;
    candidate.warnings.push(`กรอบเวลาขัดแย้งกัน ${bias.conflict}%`);
  }
  const pAlign = pressureAlignment(candidate.direction, s);
  if (s.pressureConfidence >= 25 && pAlign <= -0.28) {
    candidate.score -= 10;
    candidate.warnings.push('แรงซื้อ/ขายสวนแผนอย่างชัดเจน ระบบลดคะแนนเพื่อหลีกเลี่ยงการเข้าฝืนแรงตลาด');
  } else if (s.pressureConfidence >= 25 && pAlign >= 0.28) candidate.score += 4;
  if (analysis.flags.highVol) candidate.warnings.push('ATR อยู่ในช่วงสูง ควรลด lot และเผื่อ slippage');
  if (s.rsi > 80 || s.rsi < 20) candidate.warnings.push('RSI อยู่ในเขตสุดโต่ง มีโอกาสย่อแรง');
  candidate.score = clamp(Math.round(candidate.score), 0, 100);
  const rawEntryLow = candidate.entryLow;
  const rawEntryHigh = candidate.entryHigh;
  candidate.entryLow = Math.min(rawEntryLow, rawEntryHigh);
  candidate.entryHigh = Math.max(rawEntryLow, rawEntryHigh);
  candidate.expiryTime = candidate.createdFromTime + timeframeSeconds(candidate.timeframe) * candidate.expiryBars;
  return candidate;
}

export function generateCandidates(analyses) {
  const bias = combineMarketBias(analyses);
  const candidates = [];
  const eligible = ['5min', '15min', '1h'];
  for (const tf of eligible) {
    const a = analyses[tf];
    if (!a) continue;
    const generated = [
      trendPullback(a, analyses),
      momentumContinuation(a, analyses),
      breakoutRetest(a, analyses),
      liquiditySweep(a, analyses),
      supportResistanceRejection(a, analyses),
      fairValueGapRetest(a, analyses),
      ichimokuContinuation(a, analyses),
      ...rangeMeanReversion(a, analyses)
    ];
    for (const item of generated) {
      const adjusted = addGlobalAdjustments(item, a, analyses, bias);
      if (adjusted && [adjusted.entryLow, adjusted.entryHigh, adjusted.atr, adjusted.score].every(finite)) candidates.push(adjusted);
    }
  }
  return { candidates, bias };
}
