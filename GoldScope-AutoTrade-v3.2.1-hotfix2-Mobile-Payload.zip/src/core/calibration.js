const relativeError = (actual, expected) => Math.abs(actual - expected) / Math.max(Math.abs(expected), 1e-9);

export function expectedPnlPerUsdMove({ size, referenceSize, pnlPerUsdMoveAtReferenceSize }) {
  const actualSize = Number(size);
  const refSize = Number(referenceSize);
  const refPnl = Number(pnlPerUsdMoveAtReferenceSize);
  if (!(actualSize > 0 && refSize > 0 && refPnl > 0)) return null;
  return refPnl * actualSize / refSize;
}

export function evaluateBrokerCalibration(input = {}) {
  const expected = expectedPnlPerUsdMove(input);
  const observed = Number(input.observedPnlPerUsdMove);
  const metadataComplete = ['minimumSize', 'sizeStep', 'currency', 'tickSize'].every(key => input[key] !== undefined && input[key] !== null && input[key] !== '');
  const tolerance = Math.max(0.01, Number(input.tolerancePercent || 20) / 100);
  const error = expected && Number.isFinite(observed) ? relativeError(observed, expected) : Infinity;
  const reasons = [];
  if (!metadataComplete) reasons.push('BROKER_METADATA_INCOMPLETE');
  if (!(expected > 0)) reasons.push('EXPECTED_PNL_INVALID');
  if (!(observed > 0)) reasons.push('OBSERVED_PNL_REQUIRED');
  if (Number.isFinite(error) && error > tolerance) reasons.push('PNL_CONVERSION_MISMATCH');
  return {
    passed: reasons.length === 0,
    code: reasons.length ? 'BROKER_CALIBRATION_REQUIRED' : 'BROKER_CALIBRATION_OK',
    expectedPnlPerUsdMove: expected,
    observedPnlPerUsdMove: Number.isFinite(observed) ? observed : null,
    relativeError: Number.isFinite(error) ? error : null,
    reasons
  };
}
