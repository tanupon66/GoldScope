export const ORDER_INTENT_STATES = Object.freeze([
  'CREATED', 'RISK_APPROVED', 'QUEUED', 'SUBMITTING', 'SUBMITTED',
  'BROKER_ACCEPTED', 'BROKER_REJECTED', 'OPEN', 'PARTIALLY_FILLED',
  'CLOSING', 'CLOSED', 'FAILED', 'UNKNOWN', 'RECONCILIATION_REQUIRED'
]);

const TRANSITIONS = Object.freeze({
  CREATED: ['RISK_APPROVED', 'FAILED'],
  RISK_APPROVED: ['QUEUED', 'SUBMITTING', 'FAILED'],
  QUEUED: ['SUBMITTING', 'FAILED'],
  SUBMITTING: ['SUBMITTED', 'BROKER_ACCEPTED', 'BROKER_REJECTED', 'UNKNOWN', 'FAILED'],
  SUBMITTED: ['BROKER_ACCEPTED', 'BROKER_REJECTED', 'UNKNOWN', 'RECONCILIATION_REQUIRED'],
  BROKER_ACCEPTED: ['OPEN', 'PARTIALLY_FILLED', 'CLOSED', 'RECONCILIATION_REQUIRED'],
  OPEN: ['PARTIALLY_FILLED', 'CLOSING', 'CLOSED', 'RECONCILIATION_REQUIRED'],
  PARTIALLY_FILLED: ['OPEN', 'CLOSING', 'CLOSED', 'RECONCILIATION_REQUIRED'],
  CLOSING: ['CLOSED', 'UNKNOWN', 'RECONCILIATION_REQUIRED'],
  UNKNOWN: ['BROKER_ACCEPTED', 'BROKER_REJECTED', 'OPEN', 'CLOSED', 'RECONCILIATION_REQUIRED'],
  RECONCILIATION_REQUIRED: ['BROKER_ACCEPTED', 'BROKER_REJECTED', 'OPEN', 'CLOSED', 'FAILED'],
  BROKER_REJECTED: [], CLOSED: [], FAILED: []
});

const REQUIRED_KEY_FIELDS = [
  'broker', 'environment', 'accountId', 'symbol', 'strategyVersion',
  'modelVersion', 'timeframe', 'closedCandleTime', 'direction', 'signalId'
];

function normalizePart(value) {
  return String(value ?? '').trim().toLowerCase().replaceAll('|', '_');
}

// Deterministic FNV-1a 64-bit; no secret properties are required for an idempotency key.
function fnv1a64(text) {
  let hash = 0xcbf29ce484222325n;
  for (let index = 0; index < text.length; index += 1) {
    hash ^= BigInt(text.charCodeAt(index));
    hash = BigInt.asUintN(64, hash * 0x100000001b3n);
  }
  return hash.toString(16).padStart(16, '0');
}

export function createIdempotencyKey(input = {}) {
  const missing = REQUIRED_KEY_FIELDS.filter(field => normalizePart(input[field]) === '');
  if (missing.length) throw new Error(`IDEMPOTENCY_FIELDS_MISSING:${missing.join(',')}`);
  const canonical = REQUIRED_KEY_FIELDS.map(field => `${field}=${normalizePart(input[field])}`).join('|');
  return `gsi_${fnv1a64(canonical)}`;
}

export function canTransitionOrderIntent(from, to) {
  if (!ORDER_INTENT_STATES.includes(from) || !ORDER_INTENT_STATES.includes(to)) return false;
  if (from === to) return true;
  return Boolean(TRANSITIONS[from]?.includes(to));
}

export function transitionOrderIntent(intent, nextState, patch = {}, now = Date.now()) {
  if (!intent || !intent.idempotencyKey) throw new Error('ORDER_INTENT_REQUIRED');
  const current = intent.state || 'CREATED';
  if (!canTransitionOrderIntent(current, nextState)) {
    throw new Error(`INVALID_ORDER_INTENT_TRANSITION:${current}->${nextState}`);
  }
  const history = Array.isArray(intent.history) ? intent.history : [];
  return {
    ...intent,
    ...patch,
    state: nextState,
    updatedAt: now,
    history: [...history, { from: current, to: nextState, at: now, reason: patch.reason || null }].slice(-40)
  };
}

export function createOrderIntent({ idempotencyKey, signal, accountKey, requestId, now = Date.now() } = {}) {
  if (!idempotencyKey) throw new Error('IDEMPOTENCY_KEY_REQUIRED');
  return {
    id: `oi-${idempotencyKey}`,
    idempotencyKey,
    accountKey: String(accountKey || ''),
    signalId: signal?.id || null,
    state: 'CREATED',
    requestId: requestId || null,
    createdAt: now,
    updatedAt: now,
    dealReference: null,
    dealId: null,
    lastError: null,
    history: [{ from: null, to: 'CREATED', at: now, reason: 'intent-created' }]
  };
}

export function isTerminalOrderIntent(intent) {
  return ['BROKER_REJECTED', 'CLOSED', 'FAILED'].includes(intent?.state);
}

export function isRetryBlockedOrderIntent(intent) {
  return Boolean(intent && !isTerminalOrderIntent(intent));
}
