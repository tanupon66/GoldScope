const ACCOUNT_KEY_STORAGE = 'goldscope.accountKey.v3';
let csrfToken = '';
let sessionExpiresAt = 0;

function storageGet(key) {
  try { return localStorage.getItem(key) || ''; } catch { return ''; }
}
function storageSet(key, value) {
  try { if (value) localStorage.setItem(key, value); else localStorage.removeItem(key); } catch {}
}

export function getActiveAccountKey() {
  return storageGet(ACCOUNT_KEY_STORAGE) || 'capital:demo:setup';
}

export function setActiveAccountKey(accountKey) {
  const clean = String(accountKey || '').trim();
  if (!/^capital:(demo|live):[A-Za-z0-9._:-]+$/.test(clean)) throw new Error('accountKey ไม่ถูกต้อง');
  storageSet(ACCOUNT_KEY_STORAGE, clean);
  return clean;
}

async function parseResponse(response) {
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok === false) {
    const error = new Error(payload.message || payload.code || `HTTP ${response.status}`);
    error.code = payload.code || `HTTP_${response.status}`;
    error.requestId = payload.requestId || response.headers.get('x-request-id') || null;
    error.retryable = payload.retryable === true;
    error.status = response.status;
    error.details = payload;
    throw error;
  }
  return payload;
}

export async function authenticatedFetch(url, { method = 'GET', body, headers = {}, accountKey = getActiveAccountKey() } = {}) {
  const upper = String(method).toUpperCase();
  const requestHeaders = { accept: 'application/json', 'x-account-key': accountKey, ...headers };
  if (!['GET', 'HEAD', 'OPTIONS'].includes(upper)) {
    if (!csrfToken) await getAuthSession();
    requestHeaders['x-csrf-token'] = csrfToken;
    if (body !== undefined && !requestHeaders['content-type']) requestHeaders['content-type'] = 'application/json';
  }
  const response = await fetch(url, {
    method: upper,
    cache: 'no-store',
    credentials: 'same-origin',
    headers: requestHeaders,
    body: body === undefined ? undefined : requestHeaders['content-type'] === 'application/json' && typeof body !== 'string' ? JSON.stringify(body) : body
  });
  return parseResponse(response);
}

export async function getAuthSession() {
  const payload = await parseResponse(await fetch('/api/auth/session', { cache: 'no-store', credentials: 'same-origin' }));
  csrfToken = String(payload.csrfToken || '');
  sessionExpiresAt = Number(payload.expiresAt || 0);
  return { ...payload, accountKey: getActiveAccountKey() };
}

export async function login(password) {
  const payload = await parseResponse(await fetch('/api/auth/login', {
    method: 'POST', cache: 'no-store', credentials: 'same-origin',
    headers: { 'content-type': 'application/json' }, body: JSON.stringify({ password: String(password || '') })
  }));
  csrfToken = String(payload.csrfToken || '');
  sessionExpiresAt = Number(payload.expiresAt || 0);
  return { ...payload, accountKey: getActiveAccountKey() };
}

export async function logout() {
  try {
    const payload = await authenticatedFetch('/api/auth/logout', { method: 'POST', body: {} });
    return payload;
  } finally {
    csrfToken = '';
    sessionExpiresAt = 0;
  }
}

export function authSnapshot() {
  return { authenticated: Boolean(csrfToken && sessionExpiresAt > Date.now()), expiresAt: sessionExpiresAt, accountKey: getActiveAccountKey() };
}

export async function getAutoTradeStatus() {
  return authenticatedFetch('/api/autotrade/status');
}

export async function autoTradeAction(path, { method = 'POST', body = {}, accountKey } = {}) {
  return authenticatedFetch(`/api/autotrade/${path}`, { method, body, accountKey });
}

export async function saveAutoTradeConfig(config) {
  return autoTradeAction('config', { method: 'PUT', body: { config } });
}


export async function getSystemHealth() {
  return authenticatedFetch('/api/system/health');
}

export async function getDeadLetters(status = 'OPEN') {
  return authenticatedFetch(`/api/system/dead-letters?status=${encodeURIComponent(status)}`);
}

export async function retryDeadLetter(id) {
  return authenticatedFetch('/api/system/dead-letters/retry', { method: 'POST', body: { id } });
}

export async function dismissDeadLetter(id) {
  return authenticatedFetch('/api/system/dead-letters/dismiss', { method: 'POST', body: { id } });
}

export async function getNotificationEvents(limit = 50) {
  return authenticatedFetch(`/api/system/notifications?limit=${Math.max(1, Math.min(200, Number(limit || 50)))}`);
}

export async function getForwardTestStatus() {
  return authenticatedFetch('/api/forward-test/status');
}

export async function reconcileAutoTrade() {
  return authenticatedFetch('/api/autotrade/reconcile', { method: 'POST', body: {} });
}
