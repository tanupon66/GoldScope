const finite = value => Number.isFinite(Number(value));

export const DEFAULT_PROMOTION_RULES = Object.freeze({
  minimumSampleSize: 100,
  maximumDrawdownPercent: 20,
  minimumStablePeriods: 3,
  maximumRecentDegradationPercent: 30,
  minimumShadowDays: 14
});

export function evaluateModelPromotion(candidate = {}, rulesInput = {}) {
  const rules = { ...DEFAULT_PROMOTION_RULES, ...(rulesInput || {}) };
  const metrics = candidate.metrics || candidate;
  const stablePeriods = Array.isArray(metrics.periodExpectancies)
    ? metrics.periodExpectancies.filter(value => finite(value) && Number(value) > 0).length
    : Number(metrics.stablePeriods || 0);
  const checks = [
    ['MINIMUM_SAMPLE_SIZE', Number(metrics.sampleSize || 0) >= rules.minimumSampleSize, `ต้องมีตัวอย่างอย่างน้อย ${rules.minimumSampleSize}`],
    ['POSITIVE_OOS_EXPECTANCY', finite(metrics.outOfSampleExpectancy) && Number(metrics.outOfSampleExpectancy) > 0, 'Out-of-sample expectancy หลังต้นทุนต้องเป็นบวก'],
    ['ACCEPTABLE_DRAWDOWN', finite(metrics.maximumDrawdownPercent) && Number(metrics.maximumDrawdownPercent) <= rules.maximumDrawdownPercent, `Drawdown ต้องไม่เกิน ${rules.maximumDrawdownPercent}%`],
    ['STABLE_PERIODS', stablePeriods >= rules.minimumStablePeriods, `ต้องเป็นบวกอย่างน้อย ${rules.minimumStablePeriods} ช่วง`],
    ['RECENT_DEGRADATION', finite(metrics.recentDegradationPercent) && Number(metrics.recentDegradationPercent) <= rules.maximumRecentDegradationPercent, 'ผลช่วงล่าสุดเสื่อมลงเกินเกณฑ์'],
    ['TRANSACTION_COSTS_INCLUDED', metrics.transactionCostsIncluded === true, 'ยังไม่ได้รวมต้นทุนการส่งคำสั่ง'],
    ['NO_DATA_LEAKAGE', metrics.dataLeakageDetected === false, 'ตรวจพบหรือยังไม่ยืนยันว่าไม่มี data leakage'],
    ['SHADOW_MODE', Number(candidate.shadowDays || metrics.shadowDays || 0) >= rules.minimumShadowDays, `Challenger ต้องอยู่ Shadow Mode อย่างน้อย ${rules.minimumShadowDays} วัน`],
    ['SCHEMA_COMPATIBLE', candidate.featureSchemaCompatible !== false, 'Feature schema ไม่เข้ากัน'],
    ['RISK_LIMIT_UNCHANGED', candidate.raisesRiskLimit !== true, 'โมเดลห้ามเพิ่มเพดานความเสี่ยงเอง']
  ].map(([code, passed, message]) => ({ code, passed: Boolean(passed), message: passed ? null : message }));
  return {
    passed: checks.every(check => check.passed),
    checks,
    blockingReasons: checks.filter(check => !check.passed).map(check => check.code),
    evaluatedAt: Date.now(),
    rules
  };
}

export function createModelRegistry(champion = null, challenger = null) {
  return {
    champion: champion ? { ...champion, role: 'CHAMPION', status: 'ACTIVE' } : null,
    challenger: challenger ? { ...challenger, role: 'CHALLENGER', status: 'SHADOW' } : null,
    history: [],
    updatedAt: Date.now()
  };
}

export function promoteChallenger(registryInput, evaluation, now = Date.now()) {
  const registry = { ...createModelRegistry(), ...(registryInput || {}) };
  if (!registry.challenger) throw new Error('CHALLENGER_REQUIRED');
  if (evaluation?.passed !== true) throw new Error(`MODEL_PROMOTION_BLOCKED:${(evaluation?.blockingReasons || []).join(',')}`);
  const previous = registry.champion ? { ...registry.champion, role: 'ARCHIVED', status: 'ROLLED_BACK_AVAILABLE', archivedAt: now } : null;
  return {
    champion: { ...registry.challenger, role: 'CHAMPION', status: 'ACTIVE', promotedAt: now },
    challenger: null,
    history: [...(registry.history || []), ...(previous ? [previous] : [])].slice(-20),
    updatedAt: now
  };
}

export function rollbackChampion(registryInput, targetVersion, now = Date.now()) {
  const registry = { ...createModelRegistry(), ...(registryInput || {}) };
  const index = (registry.history || []).findIndex(model => model.version === targetVersion || model.id === targetVersion);
  if (index < 0) throw new Error('ROLLBACK_MODEL_NOT_FOUND');
  const target = registry.history[index];
  const history = [...registry.history];
  history.splice(index, 1);
  if (registry.champion) history.push({ ...registry.champion, role: 'ARCHIVED', status: 'ROLLED_BACK_AVAILABLE', archivedAt: now });
  return {
    champion: { ...target, role: 'CHAMPION', status: 'ACTIVE', rolledBackAt: now },
    challenger: registry.challenger || null,
    history: history.slice(-20),
    updatedAt: now
  };
}
