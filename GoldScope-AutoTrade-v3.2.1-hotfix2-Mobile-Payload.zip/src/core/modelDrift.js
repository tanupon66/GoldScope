const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const round = (value, digits = 4) => Number(Number(value || 0).toFixed(digits));

function finalRows(records = []) {
  return (Array.isArray(records) ? records : [])
    .filter(row => ['COMPLETED', 'STOPPED'].includes(String(row?.status || '').toUpperCase()) && Number.isFinite(Number(row?.resultR)))
    .map(row => ({ ...row, resultR: Number(row.resultR), endedAt: Number(row.endedAt || row.closedAt || 0), regime: String(row.regime || 'unknown').toLowerCase() }))
    .filter(row => row.endedAt > 0)
    .sort((a, b) => b.endedAt - a.endedAt);
}

function stats(rows = []) {
  const count = rows.length;
  const expectancyR = count ? rows.reduce((sum, row) => sum + row.resultR, 0) / count : 0;
  const wins = rows.filter(row => row.resultR > 0).length;
  return { count, expectancyR: round(expectancyR), winRate: count ? round(wins / count * 100, 2) : 0 };
}

function distribution(rows = []) {
  const counts = new Map();
  for (const row of rows) counts.set(row.regime, (counts.get(row.regime) || 0) + 1);
  const total = Math.max(1, rows.length);
  return Object.fromEntries([...counts.entries()].map(([key, value]) => [key, value / total]));
}

function kl(a, m, keys) {
  let sum = 0;
  for (const key of keys) {
    const p = Number(a[key] || 0);
    const q = Number(m[key] || 0);
    if (p > 0 && q > 0) sum += p * Math.log2(p / q);
  }
  return sum;
}

export function regimeJensenShannon(a = {}, b = {}) {
  const keys = [...new Set([...Object.keys(a), ...Object.keys(b)])];
  if (!keys.length) return 0;
  const middle = Object.fromEntries(keys.map(key => [key, (Number(a[key] || 0) + Number(b[key] || 0)) / 2]));
  return round(clamp((kl(a, middle, keys) + kl(b, middle, keys)) / 2, 0, 1));
}

export function evaluateAdaptiveDrift(records = [], options = {}) {
  const recentWindow = Math.max(5, Math.trunc(Number(options.recentWindow || 20)));
  const baselineWindow = Math.max(20, Math.trunc(Number(options.baselineWindow || 100)));
  const minimumRecent = Math.max(5, Math.trunc(Number(options.minimumRecent || Math.min(10, recentWindow))));
  const minimumBaseline = Math.max(20, Math.trunc(Number(options.minimumBaseline || Math.min(40, baselineWindow))));
  const maximumExpectancyDropR = Math.max(0.05, Number(options.maximumExpectancyDropR || 0.3));
  const maximumWinRateDropPercent = Math.max(5, Number(options.maximumWinRateDropPercent || 18));
  const maximumRegimeDivergence = clamp(Number(options.maximumRegimeDivergence || 0.25), 0.05, 1);
  const rows = finalRows(records);
  const recent = rows.slice(0, recentWindow);
  const baseline = rows.slice(recentWindow, recentWindow + baselineWindow);
  const recentStats = stats(recent);
  const baselineStats = stats(baseline);
  if (recent.length < minimumRecent || baseline.length < minimumBaseline) {
    return {
      status: 'INSUFFICIENT_DATA', pauseAdaptive: false, sampleSize: rows.length,
      recent: recentStats, baseline: baselineStats, expectancyDropR: 0, winRateDropPercent: 0,
      regimeDivergence: 0, reasons: [`ต้องมี recent ≥ ${minimumRecent} และ baseline ≥ ${minimumBaseline}`],
      evaluatedAt: Date.now(), windows: { recentWindow, baselineWindow }
    };
  }
  const expectancyDropR = round(baselineStats.expectancyR - recentStats.expectancyR);
  const winRateDropPercent = round(baselineStats.winRate - recentStats.winRate, 2);
  const regimeDivergence = regimeJensenShannon(distribution(recent), distribution(baseline));
  const reasons = [];
  if (expectancyDropR > maximumExpectancyDropR) reasons.push('RECENT_EXPECTANCY_DEGRADED');
  if (winRateDropPercent > maximumWinRateDropPercent) reasons.push('RECENT_WIN_RATE_DEGRADED');
  if (regimeDivergence > maximumRegimeDivergence) reasons.push('REGIME_DISTRIBUTION_SHIFT');
  if (recentStats.expectancyR < 0) reasons.push('RECENT_EXPECTANCY_NEGATIVE');
  const severePerformance = recentStats.expectancyR < 0 && expectancyDropR > maximumExpectancyDropR;
  const status = severePerformance || reasons.length >= 3 ? 'DRIFT' : reasons.length ? 'WATCH' : 'STABLE';
  return {
    status,
    pauseAdaptive: status === 'DRIFT',
    sampleSize: rows.length,
    recent: recentStats,
    baseline: baselineStats,
    expectancyDropR,
    winRateDropPercent,
    regimeDivergence,
    reasons,
    evaluatedAt: Date.now(),
    windows: { recentWindow, baselineWindow },
    thresholds: { maximumExpectancyDropR, maximumWinRateDropPercent, maximumRegimeDivergence }
  };
}
