import {
  ema, rsi, macd, atr, bollinger, stochastic, adx, cci, roc, williamsR,
  donchian, vwap, obv, supertrend, ichimoku, efficiencyRatio, linearRegression,
  percentileRank, zScore, latest, previous
} from './indicators.js';

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const finite = Number.isFinite;

export const TIMEFRAME_LABELS = {
  '1min': 'M1',
  '5min': 'M5',
  '15min': 'M15',
  '1h': 'H1',
  '4h': 'H4'
};

export function timeframeSeconds(tf) {
  return ({ '1min': 60, '5min': 300, '15min': 900, '1h': 3600, '4h': 14400 })[tf] || 300;
}

export function findSwings(candles, left = 3, right = 3) {
  const highs = [];
  const lows = [];
  for (let i = left; i < candles.length - right; i++) {
    let isHigh = true;
    let isLow = true;
    for (let j = i - left; j <= i + right; j++) {
      if (j === i) continue;
      if (candles[j].high >= candles[i].high) isHigh = false;
      if (candles[j].low <= candles[i].low) isLow = false;
    }
    if (isHigh) highs.push({ index: i, time: candles[i].time, price: candles[i].high });
    if (isLow) lows.push({ index: i, time: candles[i].time, price: candles[i].low });
  }
  return { highs, lows };
}

function clusterLevels(points, tolerance) {
  const clusters = [];
  for (const p of points.sort((a, b) => a.price - b.price)) {
    const found = clusters.find(c => Math.abs(c.price - p.price) <= tolerance);
    if (found) {
      found.points.push(p);
      found.price = found.points.reduce((s, x) => s + x.price, 0) / found.points.length;
      found.touches = found.points.length;
      found.lastIndex = Math.max(found.lastIndex, p.index);
    } else {
      clusters.push({ price: p.price, points: [p], touches: 1, lastIndex: p.index });
    }
  }
  return clusters;
}

export function detectLevels(candles, atrValue, lookback = 180) {
  const start = Math.max(0, candles.length - lookback);
  const slice = candles.slice(start);
  const swings = findSwings(slice, 3, 3);
  const mapPoint = p => ({ ...p, index: p.index + start });
  const tolerance = Math.max((atrValue || candles.at(-1).close * 0.001) * 0.35, candles.at(-1).close * 0.0002);
  const clusters = clusterLevels([...swings.highs.map(mapPoint), ...swings.lows.map(mapPoint)], tolerance)
    .filter(c => c.touches >= 2)
    .map(c => ({
      price: c.price,
      touches: c.touches,
      recency: 1 - Math.min(1, (candles.length - 1 - c.lastIndex) / lookback),
      strength: clamp(c.touches * 12 + c.recency * 35, 0, 100)
    }))
    .sort((a, b) => b.strength - a.strength);
  const price = candles.at(-1).close;
  const supports = clusters.filter(l => l.price < price).sort((a, b) => b.price - a.price);
  const resistances = clusters.filter(l => l.price > price).sort((a, b) => a.price - b.price);
  return { supports, resistances, all: clusters, tolerance };
}

export function detectFairValueGaps(candles, lookback = 120) {
  const gaps = [];
  const start = Math.max(2, candles.length - lookback);
  for (let i = start; i < candles.length; i++) {
    const a = candles[i - 2];
    const c = candles[i];
    if (c.low > a.high) {
      gaps.push({ type: 'bullish', low: a.high, high: c.low, index: i, filled: false });
    }
    if (c.high < a.low) {
      gaps.push({ type: 'bearish', low: c.high, high: a.low, index: i, filled: false });
    }
  }
  for (const gap of gaps) {
    for (let j = gap.index + 1; j < candles.length; j++) {
      if (candles[j].low <= gap.high && candles[j].high >= gap.low) {
        const fullyFilled = gap.type === 'bullish' ? candles[j].low <= gap.low : candles[j].high >= gap.high;
        if (fullyFilled) { gap.filled = true; gap.filledIndex = j; break; }
      }
    }
  }
  return gaps.filter(g => !g.filled).slice(-8);
}

export function candlePatterns(candles) {
  if (candles.length < 3) return [];
  const c = candles.at(-1);
  const p = candles.at(-2);
  const body = Math.abs(c.close - c.open);
  const range = Math.max(c.high - c.low, Number.EPSILON);
  const upperWick = c.high - Math.max(c.open, c.close);
  const lowerWick = Math.min(c.open, c.close) - c.low;
  const patterns = [];
  if (body / range < 0.12) patterns.push({ name: 'Doji', direction: 0, weight: 2 });
  if (lowerWick > body * 2.2 && upperWick < body * 0.8 && c.close > c.open) patterns.push({ name: 'Bullish pin bar', direction: 1, weight: 6 });
  if (upperWick > body * 2.2 && lowerWick < body * 0.8 && c.close < c.open) patterns.push({ name: 'Bearish pin bar', direction: -1, weight: 6 });
  if (c.close > c.open && p.close < p.open && c.open <= p.close && c.close >= p.open) patterns.push({ name: 'Bullish engulfing', direction: 1, weight: 7 });
  if (c.close < c.open && p.close > p.open && c.open >= p.close && c.close <= p.open) patterns.push({ name: 'Bearish engulfing', direction: -1, weight: 7 });
  if (c.high < p.high && c.low > p.low) patterns.push({ name: 'Inside bar', direction: 0, weight: 3 });
  return patterns;
}



export function analyzeOrderPressure(candles, atrValue, lookback = 24) {
  const rows = candles.slice(-Math.max(8, lookback));
  if (!rows.length) {
    return { buy: 50, sell: 50, net: 0, direction: 0, strength: 0, confidence: 0, shift: 0, volumeAvailable: false, absorption: 'none' };
  }

  const volumes = rows.map(c => Math.max(0, Number(c.volume || 0)));
  const volumeAvailable = volumes.some(v => v > 0);
  const avgVolume = volumeAvailable ? volumes.reduce((a, b) => a + b, 0) / Math.max(1, volumes.filter(v => v > 0).length) : 0;
  const atrBase = Math.max(Number(atrValue || 0), rows.at(-1).close * 0.0002, Number.EPSILON);

  let weightedNet = 0;
  let weightedAbs = 0;
  let totalWeight = 0;
  const signed = [];

  rows.forEach((c, index) => {
    const range = Math.max(c.high - c.low, atrBase * 0.02, Number.EPSILON);
    const body = (c.close - c.open) / range;
    const closeLocation = ((c.close - c.low) - (c.high - c.close)) / range;
    const expansion = clamp(range / atrBase, 0.45, 2.4);
    const volumeWeight = volumeAvailable && c.volume > 0 ? clamp(c.volume / Math.max(avgVolume, 1), 0.55, 2.2) : clamp(expansion, 0.65, 1.55);
    const recency = Math.pow(0.94, rows.length - 1 - index);
    const impulse = clamp(body * 0.58 + closeLocation * 0.42, -1, 1);
    const weight = recency * volumeWeight * (0.65 + expansion * 0.35);
    weightedNet += impulse * weight;
    weightedAbs += Math.abs(impulse) * weight;
    totalWeight += weight;
    signed.push(impulse);
  });

  const netRaw = totalWeight ? weightedNet / totalWeight : 0;
  const conviction = totalWeight ? weightedAbs / totalWeight : 0;
  const net = clamp(netRaw * 100, -100, 100);
  const buy = clamp(50 + net / 2, 0, 100);
  const sell = 100 - buy;
  const recent = signed.slice(-6).reduce((a, b) => a + b, 0) / Math.max(1, signed.slice(-6).length);
  const priorSlice = signed.slice(-12, -6);
  const prior = priorSlice.length ? priorSlice.reduce((a, b) => a + b, 0) / priorSlice.length : 0;
  const shift = clamp((recent - prior) * 100, -100, 100);
  const direction = Math.abs(net) < 8 ? 0 : net > 0 ? 1 : -1;
  const strength = Math.round(Math.abs(net));
  const sampleConfidence = clamp(rows.length / lookback, 0, 1);
  const confidence = Math.round(clamp((0.35 + conviction * 0.65) * sampleConfidence * (volumeAvailable ? 1 : 0.82), 0, 1) * 100);

  const last = rows.at(-1);
  const lastRange = Math.max(last.high - last.low, Number.EPSILON);
  const upperWick = last.high - Math.max(last.open, last.close);
  const lowerWick = Math.min(last.open, last.close) - last.low;
  let absorption = 'none';
  if (upperWick / lastRange > 0.55 && last.close < last.open) absorption = 'sell';
  if (lowerWick / lastRange > 0.55 && last.close > last.open) absorption = 'buy';

  return {
    buy: Number(buy.toFixed(1)),
    sell: Number(sell.toFixed(1)),
    net: Number(net.toFixed(1)),
    direction,
    strength,
    confidence,
    shift: Number(shift.toFixed(1)),
    volumeAvailable,
    absorption
  };
}

function structureState(candles, swings) {
  const highs = swings.highs.slice(-3);
  const lows = swings.lows.slice(-3);
  const close = candles.at(-1).close;
  let direction = 0;
  let label = 'ไม่ชัดเจน';
  if (highs.length >= 2 && lows.length >= 2) {
    const hh = highs.at(-1).price > highs.at(-2).price;
    const hl = lows.at(-1).price > lows.at(-2).price;
    const lh = highs.at(-1).price < highs.at(-2).price;
    const ll = lows.at(-1).price < lows.at(-2).price;
    if (hh && hl) { direction = 1; label = 'Higher high / Higher low'; }
    if (lh && ll) { direction = -1; label = 'Lower high / Lower low'; }
  }
  const lastHigh = highs.at(-1)?.price ?? null;
  const lastLow = lows.at(-1)?.price ?? null;
  let breakType = null;
  if (finite(lastHigh) && close > lastHigh) breakType = direction < 0 ? 'CHOCH ขาขึ้น' : 'BOS ขาขึ้น';
  if (finite(lastLow) && close < lastLow) breakType = direction > 0 ? 'CHOCH ขาลง' : 'BOS ขาลง';
  return { direction, label, lastHigh, lastLow, breakType };
}

function scoreDirection(snapshot) {
  let bull = 0;
  let bear = 0;
  const add = (condition, up, down = up) => { if (condition === true) bull += up; if (condition === false) bear += down; };
  add(snapshot.close > snapshot.ema20, 7);
  add(snapshot.ema20 > snapshot.ema50, 8);
  add(snapshot.ema50 > snapshot.ema200, 8);
  add(snapshot.supertrendDirection > 0, 7);
  add(snapshot.close > snapshot.ichimokuTop, 7);
  add(snapshot.macdHistogram > 0, 6);
  add(snapshot.macdLine > snapshot.macdSignal, 5);
  if (snapshot.rsi > 55) bull += 5; else if (snapshot.rsi < 45) bear += 5;
  if (snapshot.cci > 50) bull += 4; else if (snapshot.cci < -50) bear += 4;
  if (snapshot.roc > 0) bull += 4; else if (snapshot.roc < 0) bear += 4;
  if (snapshot.plusDI > snapshot.minusDI) bull += 5; else bear += 5;
  if (snapshot.structureDirection > 0) bull += 8; else if (snapshot.structureDirection < 0) bear += 8;
  if (snapshot.regressionSlope > 0) bull += 5; else bear += 5;
  if (snapshot.pressureDirection > 0) bull += Math.min(10, snapshot.pressureStrength * 0.12);
  else if (snapshot.pressureDirection < 0) bear += Math.min(10, snapshot.pressureStrength * 0.12);
  if (snapshot.pressureShift > 22) bull += 3; else if (snapshot.pressureShift < -22) bear += 3;
  return { bull, bear, net: bull - bear, direction: bull === bear ? 0 : bull > bear ? 1 : -1 };
}

export function analyzeTimeframe(candles, timeframe) {
  if (!Array.isArray(candles) || candles.length < 80) throw new Error(`ข้อมูล ${timeframe} ไม่เพียงพอ`);
  const closes = candles.map(c => c.close);
  const ema20 = ema(closes, 20);
  const ema50 = ema(closes, 50);
  const ema200 = ema(closes, 200);
  const rsi14 = rsi(closes, 14);
  const macdData = macd(closes);
  const atr14 = atr(candles, 14);
  const bb = bollinger(closes, 20, 2);
  const stoch = stochastic(candles);
  const adxData = adx(candles);
  const cci20 = cci(candles);
  const roc12 = roc(closes);
  const willR = williamsR(candles);
  const don = donchian(candles, 20);
  const vwapValues = vwap(candles);
  const obvValues = obv(candles);
  const st = supertrend(candles, 10, 3);
  const ichi = ichimoku(candles);
  const er = efficiencyRatio(closes, 10);
  const lr = linearRegression(closes, 30);
  const atrPct = percentileRank(atr14, 120);
  const bbPct = percentileRank(bb.width, 120);
  const priceZ = zScore(closes, 20);
  const swings = findSwings(candles, 3, 3);
  const structure = structureState(candles, swings);
  const pressure = analyzeOrderPressure(candles, latest(atr14));
  const last = candles.at(-1);
  const i = candles.length - 1;
  const cloudA = ichi.spanA[i];
  const cloudB = ichi.spanB[i];
  const snapshot = {
    close: last.close,
    open: last.open,
    high: last.high,
    low: last.low,
    ema20: latest(ema20), ema50: latest(ema50), ema200: latest(ema200),
    rsi: latest(rsi14),
    macdLine: latest(macdData.line), macdSignal: latest(macdData.signal), macdHistogram: latest(macdData.histogram),
    previousMacdHistogram: previous(macdData.histogram),
    atr: latest(atr14), atrPercentile: latest(atrPct, 0.5),
    bbUpper: latest(bb.upper), bbMiddle: latest(bb.middle), bbLower: latest(bb.lower), bbWidth: latest(bb.width), bbWidthPercentile: latest(bbPct, 0.5),
    stochasticK: latest(stoch.k), stochasticD: latest(stoch.d),
    adx: latest(adxData.adx), plusDI: latest(adxData.plusDI), minusDI: latest(adxData.minusDI),
    cci: latest(cci20), roc: latest(roc12), williamsR: latest(willR),
    donchianUpper: latest(don.upper), donchianLower: latest(don.lower), donchianMiddle: latest(don.middle),
    vwap: latest(vwapValues), obv: latest(obvValues), previousObv: previous(obvValues),
    supertrend: latest(st.value), supertrendDirection: latest(st.direction, 0),
    ichimokuConversion: latest(ichi.conversion), ichimokuBase: latest(ichi.base),
    ichimokuTop: Math.max(cloudA ?? -Infinity, cloudB ?? -Infinity),
    ichimokuBottom: Math.min(cloudA ?? Infinity, cloudB ?? Infinity),
    efficiency: latest(er), regressionSlope: latest(lr.slope), regressionR2: latest(lr.r2),
    priceZ: latest(priceZ), structureDirection: structure.direction,
    buyPressure: pressure.buy, sellPressure: pressure.sell, pressureNet: pressure.net,
    pressureDirection: pressure.direction, pressureStrength: pressure.strength,
    pressureConfidence: pressure.confidence, pressureShift: pressure.shift,
    pressureVolumeAvailable: pressure.volumeAvailable, pressureAbsorption: pressure.absorption
  };
  const directionScore = scoreDirection(snapshot);
  const trending = snapshot.adx >= 23 && snapshot.efficiency >= 0.28 && snapshot.regressionR2 >= 0.35;
  const ranging = snapshot.adx < 20 && snapshot.efficiency < 0.28;
  const highVol = snapshot.atrPercentile >= 0.78 || snapshot.bbWidthPercentile >= 0.8;
  const lowVol = snapshot.atrPercentile <= 0.25 && snapshot.bbWidthPercentile <= 0.3;
  let regime = 'สมดุล';
  if (trending) regime = directionScore.direction > 0 ? 'แนวโน้มขาขึ้น' : 'แนวโน้มขาลง';
  else if (ranging) regime = 'แกว่งในกรอบ';
  if (highVol) regime += ' / ผันผวนสูง';
  if (lowVol) regime += ' / บีบตัว';
  const levels = detectLevels(candles, snapshot.atr);
  const fvgs = detectFairValueGaps(candles);
  const patterns = candlePatterns(candles);
  const dataAgeSeconds = Math.max(0, Math.floor(Date.now() / 1000 - last.time));
  return {
    timeframe,
    label: TIMEFRAME_LABELS[timeframe] || timeframe,
    candles,
    series: { ema20, ema50, ema200, rsi14, macd: macdData, atr14, bb, stoch, adx: adxData, supertrend: st, vwap: vwapValues },
    snapshot,
    directionScore,
    direction: directionScore.direction,
    directionStrength: clamp(Math.abs(directionScore.net) / 0.7, 0, 100),
    regime,
    flags: { trending, ranging, highVol, lowVol },
    structure,
    swings,
    levels,
    fvgs,
    patterns,
    pressure,
    dataAgeSeconds,
    stale: dataAgeSeconds > timeframeSeconds(timeframe) * 3
  };
}

export function combineMarketBias(analyses) {
  const weights = { '1min': 0.6, '5min': 1.1, '15min': 1.6, '1h': 2.2, '4h': 2.7 };
  let weighted = 0;
  let total = 0;
  let conflict = 0;
  const dirs = [];
  for (const a of Object.values(analyses)) {
    const w = weights[a.timeframe] || 1;
    weighted += a.direction * a.directionStrength * w;
    total += 100 * w;
    dirs.push(a.direction);
  }
  const nonZero = dirs.filter(Boolean);
  if (nonZero.length) {
    const up = nonZero.filter(d => d > 0).length;
    const down = nonZero.filter(d => d < 0).length;
    conflict = Math.min(up, down) / nonZero.length;
  }
  const normalized = total ? weighted / total : 0;
  return {
    direction: Math.abs(normalized) < 0.12 ? 0 : normalized > 0 ? 1 : -1,
    strength: Math.round(Math.abs(normalized) * 100),
    conflict: Math.round(conflict * 100),
    label: Math.abs(normalized) < 0.12 ? 'เป็นกลาง' : normalized > 0 ? 'เอนเอียงขาขึ้น' : 'เอนเอียงขาลง'
  };
}
