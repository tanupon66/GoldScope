import {
  executionCosts, executionAwareTargetDistance, effectiveRiskReward, priceToPoints
} from './execution.js';

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const finite = Number.isFinite;
const round = (v, d = 2) => Number(Number(v).toFixed(d));

export const DEFAULT_SETTINGS = {
  settingsVersion: 4,
  profile: 'scalp',
  maxPlans: 3,
  minScore: 70,
  minRiskReward: 1.05,

  // Small-account defaults. Leverage affects required margin, not P/L per $1 move.
  accountSize: 20,
  positionSizingMode: 'fixed',
  fixedLot: 0.01,
  riskPercent: 5,
  maxLossUsd: 0,
  pnlReferenceSize: 0.01,
  pnlPerUsdMoveAtReferenceSize: 0.01,
  contractSize: 100,
  leverage: 500,
  maxMarginUsagePercent: 55,
  lotStep: 0.01,
  maxLot: 0.01,

  // Dynamic short-term targets. Values are R multiples / ATR limits, not fixed dollars.
  targetRiskReward: 1.15,
  maxTargetRiskReward: 1.8,
  minTargetAtr: 0.35,
  maxTargetAtr: 1.8,
  exitAtTarget: 'tp2',
  minExpectedBarsToTp2: 0.3,
  maxExpectedBarsToTp2: 2.2,

  // Broker execution model. At 2 digits, 30 points = $0.30 in XAU price.
  brokerDigits: 2,
  spreadPoints: 30,
  slippagePoints: 10,
  manualEntryBufferPoints: 10,
  maxExecutionCostPercent: 45,
  minStopPoints: 0,
  minStopAtrMultiplier: 0.9,

  // Legacy v1.1.x fallbacks.
  spread: 0,
  slippage: 0,

  notifications: false,
  refreshSeconds: 60,
  backtestMaxHoldBars: 12,
  adaptiveLearning: true,
  learningMinSamples: 8,
  learningMaxAdjustment: 7,
  learningLookback: 800,
  learningUseDemo: true,
  learningDataPolicy: 'weighted-all',
  learningDemoWeight: 0.35,
  learningMixedWeight: 0.55,
  learningIncludeBreakeven: true,
  learningResetAt: 0
};

const PROFILE = {
  scalp: {
    atrStop: 0.72, rr1: 0.62, rr3Bonus: 0.42,
    scoreBonus: 0, riskFactor: 1, maxStructureAtr: 1.65
  },
  conservative: {
    atrStop: 1.2, rr1: 0.75, rr3Bonus: 0.5,
    scoreBonus: 0, riskFactor: 0.72, maxStructureAtr: 2.2
  },
  balanced: {
    atrStop: 1.45, rr1: 0.8, rr3Bonus: 0.65,
    scoreBonus: 1, riskFactor: 0.9, maxStructureAtr: 2.8
  },
  opportunity: {
    atrStop: 1.2, rr1: 0.85, rr3Bonus: 0.85,
    scoreBonus: 1, riskFactor: 1, maxStructureAtr: 3.2
  }
};

const TF_STOP_MULTIPLIER = { '1min': 0.85, '5min': 0.95, '15min': 1, '1h': 1.08, '4h': 1.15 };
const TF_MIN_TARGET_ATR = { '1min': 0.28, '5min': 0.35, '15min': 0.45, '1h': 0.7, '4h': 0.9 };

function nearestTarget(levels, direction, entry) {
  const list = direction === 1 ? levels.resistances : levels.supports;
  return list.find(level => direction === 1 ? level.price > entry : level.price < entry)?.price ?? null;
}

function normalizeEntryZone(candidate, analysis, costs) {
  const atrValue = Math.max(0, Number(candidate.atr || analysis.snapshot.atr || 0));
  const rawLow = Math.min(Number(candidate.entryLow), Number(candidate.entryHigh));
  const rawHigh = Math.max(Number(candidate.entryLow), Number(candidate.entryHigh));
  if (![rawLow, rawHigh].every(finite)) return null;
  const mid = (rawLow + rawHigh) / 2;
  const rawWidth = rawHigh - rawLow;
  const minimumWidth = Math.max(atrValue * 0.06, costs.spreadUsd * 0.45 + costs.manualBufferUsd);
  const width = Math.max(rawWidth, minimumWidth);
  return { low: mid - width / 2, high: mid + width / 2, mid, width };
}

function chooseStop(candidate, analysis, settings, costs, entryZone) {
  const p = PROFILE[settings.profile] || PROFILE.scalp;
  const entry = entryZone.mid;
  const atrValue = Math.max(0.0001, Number(candidate.atr || analysis.snapshot.atr));
  const tfMultiplier = TF_STOP_MULTIPLIER[candidate.timeframe] || 1;
  const atrDistance = atrValue * p.atrStop * tfMultiplier;

  let structureStop = Number(candidate.invalidationHint);
  if (!finite(structureStop)) {
    structureStop = candidate.direction === 1
      ? Number(analysis.structure.lastLow ?? analysis.levels.supports[0]?.price)
      : Number(analysis.structure.lastHigh ?? analysis.levels.resistances[0]?.price);
  }

  let structureDistance = 0;
  if (finite(structureStop)) {
    const validSide = candidate.direction === 1 ? structureStop < entry : structureStop > entry;
    if (validSide) structureDistance = Math.abs(entry - structureStop) + Math.max(costs.manualBufferUsd, atrValue * 0.04);
  }

  // A very distant invalidation belongs to a longer-term setup. Reject it in scalp mode
  // rather than silently creating a very wide stop that a small account cannot absorb.
  const maxStructureDistance = atrValue * p.maxStructureAtr;
  if (settings.profile === 'scalp' && structureDistance > maxStructureDistance) {
    return { rejected: true, reason: 'structure-too-wide', structureDistance, maxStructureDistance };
  }

  const maxCostRatio = clamp(Number(settings.maxExecutionCostPercent || 45) / 100, 0.08, 0.65);
  const costDistance = costs.totalUsd / maxCostRatio;
  const pointFloor = Math.max(0, Number(settings.minStopPoints || 0)) * costs.pointSize;
  const atrFloor = atrValue * clamp(Number(settings.minStopAtrMultiplier ?? 0.9), 0, 5);
  const stopDistance = Math.max(atrDistance, atrFloor, structureDistance, costDistance, pointFloor);
  const stop = entry - candidate.direction * stopDistance;

  return {
    entry,
    stop,
    stopDistance,
    effectiveRiskDistance: stopDistance + costs.totalUsd,
    atrDistance,
    atrFloor,
    structureDistance,
    costDistance,
    maxCostRatio,
    rejected: false
  };
}

function configuredRiskBudget(settings, riskFactor = 1) {
  const account = Math.max(0, Number(settings.accountSize || 0));
  const percentBudget = account * Math.max(0, Number(settings.riskPercent || 0)) / 100;
  const hardUsd = Math.max(0, Number(settings.maxLossUsd || 0));
  const base = hardUsd > 0 ? Math.min(percentBudget || hardUsd, hardUsd) : percentBudget;
  return Math.max(0, base * riskFactor);
}

export function valuePerPriceUnitForSize(sizeInput, settingsInput = {}) {
  const settings = { ...DEFAULT_SETTINGS, ...(settingsInput || {}) };
  const size = Math.max(0, Number(sizeInput || 0));
  const contractSize = Math.max(0.0001, Number(settings.contractSize || 100));
  const referenceSize = Math.max(0.0001, Number(settings.pnlReferenceSize || settings.fixedLot || 0.01));
  const configuredAtReference = Number(settings.pnlPerUsdMoveAtReferenceSize);
  const valuePerSizeUnit = Number.isFinite(configuredAtReference) && configuredAtReference > 0
    ? configuredAtReference / referenceSize
    : contractSize;
  return size * valuePerSizeUnit;
}

function positionSizing(effectiveRiskDistance, entry, settings, riskFactor) {
  const contractSize = Math.max(0.0001, Number(settings.contractSize || 100));
  const step = Math.max(0.001, Number(settings.lotStep || 0.01));
  const maxLot = Math.max(step, Number(settings.maxLot || step));
  const riskBudget = configuredRiskBudget(settings, riskFactor);
  const mode = settings.positionSizingMode === 'risk' ? 'risk' : 'fixed';
  const referenceSize = Math.max(0.0001, Number(settings.pnlReferenceSize || settings.fixedLot || step));
  const configuredAtReference = Number(settings.pnlPerUsdMoveAtReferenceSize);
  const valuePerSizeUnit = Number.isFinite(configuredAtReference) && configuredAtReference > 0
    ? configuredAtReference / referenceSize
    : contractSize;

  let rawLot;
  let lot;
  if (mode === 'fixed') {
    rawLot = Math.max(step, Number(settings.fixedLot || step));
    lot = Math.floor(rawLot / step + 1e-9) * step;
    lot = clamp(round(lot, 3), step, maxLot);
  } else {
    rawLot = riskBudget / Math.max(0.0001, effectiveRiskDistance * valuePerSizeUnit);
    lot = Math.floor(rawLot / step + 1e-9) * step;
    lot = clamp(round(lot, 3), 0, maxLot);
    if (lot < step) return { accepted: false, reason: 'lot-below-minimum', rawLot, lot: 0, riskBudget };
  }

  const valuePerPriceUnit = lot * valuePerSizeUnit;
  const estimatedLossUsd = effectiveRiskDistance * valuePerPriceUnit;
  if (!finite(estimatedLossUsd) || estimatedLossUsd > riskBudget + 0.005) {
    return {
      accepted: false,
      reason: 'risk-budget-exceeded',
      rawLot,
      lot,
      riskBudget,
      estimatedLossUsd,
      valuePerPriceUnit
    };
  }

  const leverage = Math.max(1, Number(settings.leverage || 1));
  const estimatedMarginUsd = Math.abs(entry) * contractSize * lot / leverage;
  const marginLimit = Math.max(0, Number(settings.accountSize || 0)) * clamp(Number(settings.maxMarginUsagePercent || 55) / 100, 0.05, 1);
  if (estimatedMarginUsd > marginLimit + 0.005) {
    return {
      accepted: false,
      reason: 'margin-limit-exceeded',
      rawLot,
      lot,
      riskBudget,
      estimatedLossUsd,
      estimatedMarginUsd,
      marginLimit,
      valuePerPriceUnit
    };
  }

  return {
    accepted: true,
    mode,
    riskBudget: round(riskBudget),
    rawLot,
    lot,
    valuePerPriceUnit: round(valuePerPriceUnit, 4),
    estimatedLossUsd: round(estimatedLossUsd),
    estimatedMarginUsd: round(estimatedMarginUsd),
    marginLimit: round(marginLimit)
  };
}

function riskLevel(candidate, analysis, executionCostPercent, expectedBarsToTp2, lossPercent) {
  let points = 0;
  if (candidate.counterTrend) points += 3;
  if (analysis.flags.highVol) points += 3;
  if (analysis.stale) points += 5;
  if (candidate.score < 74) points += 2;
  if (executionCostPercent > 35) points += 4;
  else if (executionCostPercent > 22) points += 2;
  if (lossPercent > 10) points += 5;
  else if (lossPercent > 5) points += 2;
  const pressureAgainst = candidate.direction * Number(analysis.snapshot.pressureNet || 0) < -20;
  if (pressureAgainst) points += 3;
  if (expectedBarsToTp2 > 2.2) points += 2;
  if ((candidate.warnings || []).length >= 3) points += 2;
  if (points >= 9) return 'สูง';
  if (points >= 4) return 'ปานกลาง';
  return 'ต่ำ';
}

function targetModel(candidate, analysis, settings, costs, entry, stopDistance, atrValue) {
  const profile = PROFILE[settings.profile] || PROFILE.scalp;
  const minR = Math.max(0.5, Number(settings.minRiskReward || 1.05));
  const maxR = Math.max(minR, Number(settings.maxTargetRiskReward || 1.8));
  const scoreAdjustment = clamp((Number(candidate.score) - 72) / 65, -0.08, 0.18);
  const trendAdjustment = candidate.counterTrend ? -0.08 : analysis.flags.trending ? 0.08 : 0;
  const volatilityAdjustment = analysis.flags.highVol ? -0.06 : 0;
  const primaryR = clamp(Number(settings.targetRiskReward || 1.15) + scoreAdjustment + trendAdjustment + volatilityAdjustment, minR, maxR);

  const minAtr = Math.max(
    Number(settings.minTargetAtr || 0.35),
    TF_MIN_TARGET_ATR[candidate.timeframe] || 0.35
  );
  const maxAtr = Math.max(minAtr, Number(settings.maxTargetAtr || 1.8));

  let d2 = Math.max(
    executionAwareTargetDistance(stopDistance, primaryR, costs.totalUsd),
    atrValue * minAtr
  );

  const nearbyTarget = nearestTarget(analysis.levels, candidate.direction, entry);
  if (finite(nearbyTarget)) {
    const obstacleDistance = Math.abs(nearbyTarget - entry);
    const obstacleNetR = effectiveRiskReward(stopDistance, obstacleDistance, costs.totalUsd);
    const isBreakout = candidate.strategyKey === 'breakout-retest' || candidate.strategyKey === 'momentum-continuation';
    if (!isBreakout && obstacleNetR < minR * 0.92) return { rejected: true, reason: 'nearby-obstacle' };
    if (obstacleNetR >= minR && obstacleDistance < d2) d2 = obstacleDistance;
  }

  const expectedBarsToTp2 = d2 / atrValue;
  const minBars = Math.max(0.05, Number(settings.minExpectedBarsToTp2 || 0.3));
  const maxBars = Math.max(minBars, Number(settings.maxExpectedBarsToTp2 || 2.2));
  if (expectedBarsToTp2 < minBars || expectedBarsToTp2 > maxBars || d2 > atrValue * maxAtr) {
    return { rejected: true, reason: 'target-not-short-term', expectedBarsToTp2, d2 };
  }

  const tp1R = clamp(Math.min(profile.rr1, primaryR * 0.68), 0.45, primaryR);
  const tp3R = clamp(Math.max(primaryR + profile.rr3Bonus, primaryR * 1.25), primaryR, maxR);
  const d1 = Math.min(d2, executionAwareTargetDistance(stopDistance, tp1R, costs.totalUsd));
  const runnerRaw = executionAwareTargetDistance(stopDistance, tp3R, costs.totalUsd);
  const d3 = Math.max(d2 + atrValue * 0.15, Math.min(runnerRaw, atrValue * maxAtr * 1.25));

  return {
    rejected: false,
    d1,
    d2,
    d3,
    primaryR: effectiveRiskReward(stopDistance, d2, costs.totalUsd),
    expectedBarsToTp2
  };
}

export function buildPlan(candidate, analysis, settingsInput = {}) {
  const settings = { ...DEFAULT_SETTINGS, ...settingsInput };
  if (!candidate || !analysis || !finite(Number(candidate.score)) || !finite(Number(candidate.atr))) return null;
  const profile = PROFILE[settings.profile] || PROFILE.scalp;
  const costs = executionCosts(settings);
  const entryZone = normalizeEntryZone(candidate, analysis, costs);
  if (!entryZone) return null;

  const stopModel = chooseStop(candidate, analysis, settings, costs, entryZone);
  if (stopModel.rejected) return null;
  const { entry, stop, stopDistance, effectiveRiskDistance } = stopModel;
  if (![entry, stop, stopDistance, effectiveRiskDistance].every(finite) || stopDistance <= 0) return null;

  const executionCostPercent = costs.totalUsd / Math.max(effectiveRiskDistance, 0.0001) * 100;
  if (executionCostPercent > Number(settings.maxExecutionCostPercent || 45) + 0.01) return null;

  const riskFactor = profile.riskFactor * (candidate.counterTrend ? 0.72 : 1);
  const sizing = positionSizing(effectiveRiskDistance, entry, settings, riskFactor);
  if (!sizing.accepted) return null;

  const direction = candidate.direction;
  const sign = direction === 1 ? 1 : -1;
  const atrValue = Math.max(0.0001, Number(candidate.atr));
  const targets = targetModel(candidate, analysis, settings, costs, entry, stopDistance, atrValue);
  if (targets.rejected) return null;

  const { d1, d2, d3, expectedBarsToTp2 } = targets;
  const tp1 = entry + sign * d1;
  const tp2 = entry + sign * d2;
  const tp3 = entry + sign * d3;
  const rr = effectiveRiskReward(stopDistance, d2, costs.totalUsd);
  if (!finite(rr) || rr < Number(settings.minRiskReward || 1.05)) return null;

  const pressureAlignment = direction * Number(analysis.snapshot.pressureNet || 0) / 100;
  const executionPenalty = executionCostPercent > 38 ? 5 : executionCostPercent > 25 ? 2 : 0;
  const rawScore = Number(candidate.score) + profile.scoreBonus - (candidate.counterTrend ? 3 : 0) - executionPenalty;
  if (!finite(rawScore)) return null;
  const score = clamp(Math.round(rawScore), 0, 100);

  const accountSize = Math.max(0.01, Number(settings.accountSize || 0.01));
  const lossPercent = sizing.estimatedLossUsd / accountSize * 100;
  const netProfit = distance => Math.max(0, distance - costs.totalUsd) * sizing.valuePerPriceUnit;
  const warnings = [...new Set(candidate.warnings || [])];
  if (executionCostPercent > 32) warnings.push(`ต้นทุนเข้าออร์เดอร์กินระยะเสี่ยงประมาณ ${round(executionCostPercent, 1)}%`);
  if (costs.spreadPoints >= 150) warnings.push(`Spread สูง (${Math.round(costs.spreadPoints)} points) แผนระยะสั้นอาจถูกตัดทิ้งจำนวนมาก`);
  if (lossPercent > 5) warnings.push(`หากโดน SL คาดว่าจะเสียประมาณ ${round(lossPercent, 1)}% ของพอร์ต ซึ่งถือว่าสูง`);
  if (pressureAlignment < -0.2) warnings.push('แรงซื้อ/ขายล่าสุดสวนทิศทางแผน');
  if (settings.positionSizingMode === 'fixed') warnings.push('ใช้ lot คงที่ ระบบจะไม่ออกแผนเมื่อ SL เกินงบขาดทุนที่ตั้งไว้');

  const exitAtTarget = ['tp1', 'tp2', 'tp3'].includes(settings.exitAtTarget) ? settings.exitAtTarget : 'tp2';
  const idSeed = `${candidate.strategyKey}-${candidate.timeframe}-${direction}-${Math.round(entry / costs.pointSize)}-${candidate.createdFromTime}`;
  return {
    id: idSeed,
    algorithmVersion: '2.0.2',
    strategy: candidate.strategy,
    strategyKey: candidate.strategyKey,
    timeframe: candidate.timeframe,
    timeframeLabel: candidate.timeframeLabel,
    direction,
    directionLabel: direction === 1 ? 'BUY' : 'SELL',
    score,
    baseScore: finite(Number(candidate.baseScore)) ? Number(candidate.baseScore) : Number(candidate.score),
    adaptiveAdjustment: finite(Number(candidate.adaptiveAdjustment)) ? Number(candidate.adaptiveAdjustment) : 0,
    learningSamples: finite(Number(candidate.learningSamples)) ? Number(candidate.learningSamples) : 0,
    learningConfidence: finite(Number(candidate.learningConfidence)) ? Number(candidate.learningConfidence) : 0,
    learnedWinRate: candidate.learnedWinRate === null || candidate.learnedWinRate === undefined ? null : finite(Number(candidate.learnedWinRate)) ? Number(candidate.learnedWinRate) : null,
    learnedExpectancyR: candidate.learnedExpectancyR === null || candidate.learnedExpectancyR === undefined ? null : finite(Number(candidate.learnedExpectancyR)) ? Number(candidate.learnedExpectancyR) : null,
    learningSources: candidate.learningSources || [],
    qualityLabel: score >= 84 ? 'สูงมาก' : score >= 76 ? 'สูง' : score >= 70 ? 'พอใช้' : 'ต่ำ',
    status: 'WAITING_ENTRY',
    createdAt: Date.now(),
    sourceCandleTime: candidate.createdFromTime,
    expiresAt: candidate.expiryTime * 1000,
    entryLow: round(entryZone.low),
    entryHigh: round(entryZone.high),
    entry: round(entry),
    stopLoss: round(stop),
    tp1: round(tp1),
    tp2: round(tp2),
    tp3: round(tp3),
    exitAtTarget,
    riskReward: round(rr, 2),
    tp1R: round(effectiveRiskReward(stopDistance, d1, costs.totalUsd), 2),
    tp2R: round(rr, 2),
    tp3R: round(effectiveRiskReward(stopDistance, d3, costs.totalUsd), 2),
    stopDistance: round(stopDistance),
    stopPoints: priceToPoints(stopDistance, settings),
    effectiveRiskDistance: round(effectiveRiskDistance),
    atr: round(atrValue),
    expectedBarsToTp2: round(expectedBarsToTp2, 1),
    executionCostPercent: round(executionCostPercent, 1),
    pointSize: costs.pointSize,
    brokerDigits: costs.brokerDigits,
    spreadPoints: Math.round(costs.spreadPoints),
    spreadUsd: round(costs.spreadUsd, 3),
    slippagePoints: Math.round(costs.slippagePoints),
    slippageUsd: round(costs.slippageUsd, 3),
    manualEntryBufferPoints: Math.round(costs.manualEntryBufferPoints),
    manualBufferUsd: round(costs.manualBufferUsd, 3),
    totalExecutionCostUsd: round(costs.totalUsd, 3),
    buyPressure: Number(analysis.snapshot.buyPressure || 50),
    sellPressure: Number(analysis.snapshot.sellPressure || 50),
    pressureNet: Number(analysis.snapshot.pressureNet || 0),
    pressureConfidence: Number(analysis.snapshot.pressureConfidence || 0),
    riskLevel: riskLevel(candidate, analysis, executionCostPercent, expectedBarsToTp2, lossPercent),
    positionSizingMode: sizing.mode,
    lot: sizing.lot,
    theoreticalLot: sizing.lot,
    riskBudget: sizing.riskBudget,
    estimatedLossUsd: sizing.estimatedLossUsd,
    estimatedLossPercent: round(lossPercent, 1),
    estimatedMarginUsd: sizing.estimatedMarginUsd,
    valuePerPriceUnit: sizing.valuePerPriceUnit,
    pnlReferenceSize: Number(settings.pnlReferenceSize || settings.fixedLot || 0.01),
    pnlPerUsdMoveAtReferenceSize: Number(settings.pnlPerUsdMoveAtReferenceSize || 0),
    estimatedTp1ProfitUsd: round(netProfit(d1)),
    estimatedTp2ProfitUsd: round(netProfit(d2)),
    estimatedTp3ProfitUsd: round(netProfit(d3)),
    leverage: Number(settings.leverage || 1),
    trigger: candidate.trigger,
    evidence: candidate.evidence || [],
    warnings,
    counterTrend: candidate.counterTrend,
    regime: analysis.regime,
    progress: { tp1: false, tp2: false, tp3: false },
    resultR: null,
    endedAt: null,
    outcome: null
  };
}

function overlapRatio(a, b) {
  const left = Math.max(a.entryLow, b.entryLow);
  const right = Math.min(a.entryHigh, b.entryHigh);
  if (right <= left) return 0;
  const union = Math.max(a.entryHigh, b.entryHigh) - Math.min(a.entryLow, b.entryLow);
  return union === 0 ? 1 : (right - left) / union;
}

export function selectPlans(candidates, analyses, settingsInput = {}, existingPlans = []) {
  const settings = { ...DEFAULT_SETTINGS, ...settingsInput };
  const existingIds = new Set(existingPlans.map(p => p.id));
  const plans = [];
  const sorted = candidates
    .filter(candidate => finite(Number(candidate?.score)))
    .slice()
    .sort((a, b) => Number(b.score) - Number(a.score));

  for (const candidate of sorted) {
    const analysis = analyses[candidate.timeframe];
    if (!analysis) continue;
    const plan = buildPlan(candidate, analysis, settings);
    if (!plan || !finite(plan.score) || plan.score < settings.minScore || existingIds.has(plan.id)) continue;
    const duplicate = [...existingPlans, ...plans].some(other =>
      other.direction === plan.direction &&
      (other.timeframe === plan.timeframe || other.strategyKey === plan.strategyKey) &&
      (overlapRatio(other, plan) > 0.35 || Math.abs(other.entry - plan.entry) < Math.max(other.atr, plan.atr) * 0.3)
    );
    if (duplicate) continue;
    const sameDirection = [...existingPlans, ...plans].filter(p => p.direction === plan.direction && !['COMPLETED', 'STOPPED', 'EXPIRED', 'INVALIDATED'].includes(p.status)).length;
    if (sameDirection >= 2) continue;
    plans.push(plan);
    if (plans.length + existingPlans.length >= settings.maxPlans) break;
  }
  return plans;
}
