const KEYS = {
  settings: 'goldscope.settings.v1',
  plans: 'goldscope.plans.v1',
  journal: 'goldscope.journal.v1',
  backtests: 'goldscope.backtests.v1',
  tuning: 'goldscope.tuning.v1'
};

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function write(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* private/embedded contexts may block storage */ }
  return value;
}

export const storage = {
  getSettings: () => read(KEYS.settings, {}),
  saveSettings: value => write(KEYS.settings, value),
  getPlans: () => read(KEYS.plans, []),
  savePlans: value => write(KEYS.plans, value),
  getJournal: () => read(KEYS.journal, []),
  saveJournal: value => write(KEYS.journal, value.slice(0, 1000)),
  addJournal: plans => {
    const current = read(KEYS.journal, []);
    const ids = new Set(current.map(p => `${p.id}-${p.endedAt}`));
    const unique = plans.filter(p => !ids.has(`${p.id}-${p.endedAt}`));
    return write(KEYS.journal, [...unique, ...current].slice(0, 1000));
  },
  getBacktests: () => read(KEYS.backtests, []),
  saveBacktest: result => write(KEYS.backtests, [result, ...read(KEYS.backtests, [])].slice(0, 20)),
  getTuningState: () => read(KEYS.tuning, null),
  saveTuningState: value => write(KEYS.tuning, value),
  clearTuningState: () => localStorage.removeItem(KEYS.tuning),
  clearAll: () => Object.values(KEYS).forEach(key => localStorage.removeItem(key)),
  exportAll: () => ({
    exportedAt: new Date().toISOString(),
    settings: read(KEYS.settings, {}),
    plans: read(KEYS.plans, []),
    journal: read(KEYS.journal, []),
    backtests: read(KEYS.backtests, []),
    tuning: read(KEYS.tuning, null)
  })
};

export function downloadJson(filename, value) {
  const blob = new Blob([JSON.stringify(value, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

export async function readJsonFile(file) {
  if (!file) throw new Error('ไม่ได้เลือกไฟล์');
  if (file.size > 5 * 1024 * 1024) throw new Error('ไฟล์มีขนาดใหญ่เกิน 5 MB');
  const text = await file.text();
  try { return JSON.parse(text); }
  catch { throw new Error('ไฟล์ JSON อ่านไม่ได้หรือรูปแบบเสียหาย'); }
}

export function downloadCsv(filename, rows) {
  if (!rows.length) return;
  const keys = [...new Set(rows.flatMap(Object.keys))];
  const escape = value => `"${String(value ?? '').replaceAll('"', '""')}"`;
  const csv = [keys.map(escape).join(','), ...rows.map(row => keys.map(key => escape(Array.isArray(row[key]) ? row[key].join(' | ') : row[key])).join(','))].join('\n');
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}
