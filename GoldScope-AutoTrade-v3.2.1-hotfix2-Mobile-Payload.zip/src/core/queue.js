export function queueIdempotencyKey(eventType, stateObjectKey, bucket = null) {
  const resolvedBucket = bucket ?? Math.floor(Date.now() / 60_000);
  return `${String(eventType || 'UNKNOWN')}:${String(stateObjectKey || 'unknown')}:${resolvedBucket}`;
}

export function normalizeQueueEnvelope(message = {}, deliveryAttempt = 0) {
  if (!message || typeof message !== 'object') throw new Error('QUEUE_MESSAGE_INVALID');
  const eventType = String(message.eventType || '').trim();
  const stateObjectKey = String(message.stateObjectKey || message.accountKey || '').trim();
  if (!eventType || !stateObjectKey) throw new Error('QUEUE_MESSAGE_FIELDS_REQUIRED');
  return {
    messageId: String(message.messageId || crypto.randomUUID()),
    eventType,
    accountKey: String(message.accountKey || stateObjectKey),
    stateObjectKey,
    createdAt: Number(message.createdAt || Date.now()),
    attempt: Math.max(Number(message.attempt || 0), Number(deliveryAttempt || 0)),
    correlationId: String(message.correlationId || crypto.randomUUID()),
    idempotencyKey: String(message.idempotencyKey || queueIdempotencyKey(eventType, stateObjectKey)),
    payloadVersion: Math.max(1, Number(message.payloadVersion || 1)),
    payload: message.payload && typeof message.payload === 'object' ? message.payload : {}
  };
}

export function retryDelaySeconds(attempt, { base = 30, maximum = 900 } = {}) {
  const value = Math.max(0, Number(attempt || 0));
  return Math.min(maximum, Math.max(base, Math.round(base * (2 ** value))));
}
