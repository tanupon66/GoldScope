const round = (value, digits = 4) => Number(Number(value).toFixed(digits));

export function createForwardPosition({ signal, plan, spread = 0, slippageUsd = 0, now = Date.now(), accountKey = null, configVersion = null } = {}) {
  if (!signal?.id || !plan) throw new Error('FORWARD_SIGNAL_INVALID');
  const direction = Number(plan.direction) === -1 || String(plan.directionLabel).toUpperCase() === 'SELL' ? -1 : 1;
  const intendedEntry = Number(signal.currentPrice ?? plan.entry ?? (Number(plan.entryLow) + Number(plan.entryHigh)) / 2);
  if (!Number.isFinite(intendedEntry)) throw new Error('FORWARD_ENTRY_INVALID');
  const fillPenalty = Math.max(0, Number(spread || 0)) / 2 + Math.max(0, Number(slippageUsd || 0));
  const simulatedFill = intendedEntry + direction * fillPenalty;
  const stopLoss = Number(plan.stopLoss);
  const takeProfit = Number(plan[plan.exitAtTarget] ?? plan.tp2);
  if (![stopLoss, takeProfit].every(Number.isFinite)) throw new Error('FORWARD_LEVEL_INVALID');
  const valuePerPriceUnit = Math.max(0.000001, Number(plan.valuePerPriceUnit || 1));
  const initialRiskUsd = Math.max(0.000001, Math.abs(simulatedFill - stopLoss) * valuePerPriceUnit);
  return {
    id: `forward-${signal.id}`,
    accountKey,
    signalId: signal.id,
    symbol: signal.epic || 'GOLD',
    timeframe: plan.timeframe || '5min',
    direction,
    directionLabel: direction === 1 ? 'BUY' : 'SELL',
    intendedEntry: round(intendedEntry, 5),
    simulatedFill: round(simulatedFill, 5),
    stopLoss,
    takeProfit,
    spread: Number(spread || 0),
    slippageAssumption: Number(slippageUsd || 0),
    valuePerPriceUnit,
    initialRiskUsd,
    openedAt: now,
    signalCandleTime: Number(signal.candleTime || 0),
    strategyVersion: plan.strategyVersion || plan.algorithmVersion || null,
    modelVersion: plan.modelVersion || null,
    configVersion,
    newsContext: signal.newsContext || null,
    status: 'OPEN'
  };
}

export function evaluateForwardPosition(position, candles = [], now = Date.now()) {
  if (!position || position.status !== 'OPEN') return { closed: false, position };
  const eligible = (candles || []).filter(candle => {
    const candleMs = Number(candle.time || 0) * 1000;
    return candleMs > Math.max(Number(position.openedAt || 0), Number(position.signalCandleTime || 0) * 1000)
      && Number.isFinite(Number(candle.high)) && Number.isFinite(Number(candle.low));
  }).sort((a, b) => Number(a.time) - Number(b.time));
  for (const candle of eligible) {
    const isBuy = Number(position.direction) === 1;
    const hitStop = isBuy ? Number(candle.low) <= Number(position.stopLoss) : Number(candle.high) >= Number(position.stopLoss);
    const hitTarget = isBuy ? Number(candle.high) >= Number(position.takeProfit) : Number(candle.low) <= Number(position.takeProfit);
    if (!hitStop && !hitTarget) continue;
    // Conservative rule: if both touched in one candle, stop is assumed first.
    const stopped = hitStop;
    const exitPrice = stopped ? Number(position.stopLoss) : Number(position.takeProfit);
    const pnl = (exitPrice - Number(position.simulatedFill)) * Number(position.direction) * Number(position.valuePerPriceUnit || 1);
    return {
      closed: true,
      position: {
        ...position,
        status: stopped ? 'STOPPED' : 'COMPLETED',
        closedAt: Number(candle.time || 0) * 1000 || now,
        exitPrice: round(exitPrice, 5),
        pnl: round(pnl, 4),
        pnlUsd: round(pnl, 4),
        resultR: round(pnl / Math.max(0.000001, Number(position.initialRiskUsd || 0.000001)), 4),
        outcome: stopped ? 'SL' : 'TP',
        exitCandleTime: Number(candle.time || 0)
      }
    };
  }
  return { closed: false, position };
}

export function summarizeForwardPositions(positions = [], now = Date.now()) {
  const all = Object.values(positions || {});
  const closed = all.filter(item => item.status !== 'OPEN');
  const startedAt = all.length ? Math.min(...all.map(item => Number(item.openedAt || now))) : 0;
  return {
    startedAt,
    days: startedAt ? Math.max(0, (now - startedAt) / 86_400_000) : 0,
    signals: all.length,
    open: all.length - closed.length,
    closed: closed.length,
    pnl: round(closed.reduce((sum, item) => sum + Number(item.pnl || item.pnlUsd || 0), 0), 4),
    expectancyR: closed.length ? round(closed.reduce((sum, item) => sum + Number(item.resultR || 0), 0) / closed.length, 4) : 0,
    wins: closed.filter(item => Number(item.pnl || item.pnlUsd || 0) > 0).length,
    losses: closed.filter(item => Number(item.pnl || item.pnlUsd || 0) < 0).length
  };
}
