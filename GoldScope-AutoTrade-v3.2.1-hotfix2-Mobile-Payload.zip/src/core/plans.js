import { sideAdjustedCandle } from './execution.js';

const TERMINAL = new Set(['COMPLETED', 'STOPPED', 'EXPIRED', 'INVALIDATED', 'CANCELLED']);

export function isTerminal(plan) {
  return TERMINAL.has(plan.status);
}

function touched(candle, low, high) {
  return candle.low <= high && candle.high >= low;
}

function priceHit(direction, candle, price, kind) {
  if (direction === 1) return kind === 'stop' ? candle.low <= price : candle.high >= price;
  return kind === 'stop' ? candle.high >= price : candle.low <= price;
}

export function evaluatePlan(plan, candles, now = Date.now()) {
  if (isTerminal(plan)) return plan;
  const updated = structuredClone(plan);
  const startTime = plan.status === 'ACTIVE' && plan.activatedAt ? Math.floor(plan.activatedAt / 1000) : plan.sourceCandleTime;
  const relevant = candles.filter(c => c.time > startTime);
  if (!relevant.length) return updated;

  const spread = Number(updated.spreadUsd || 0);
  for (const rawCandle of relevant) {
    const entryCandle = sideAdjustedCandle(rawCandle, updated.direction, spread, 'entry');
    const exitCandle = sideAdjustedCandle(rawCandle, updated.direction, spread, 'exit');

    if (updated.status === 'WAITING_ENTRY') {
      const invalidBeforeEntry = priceHit(updated.direction, exitCandle, updated.stopLoss, 'stop');
      if (invalidBeforeEntry && !touched(entryCandle, updated.entryLow, updated.entryHigh)) {
        updated.status = 'INVALIDATED';
        updated.outcome = 'โครงสร้างเสียก่อนเข้า';
        updated.resultR = 0;
        updated.endedAt = rawCandle.time * 1000;
        break;
      }
      if (touched(entryCandle, updated.entryLow, updated.entryHigh)) {
        updated.status = 'ACTIVE';
        updated.activatedAt = rawCandle.time * 1000;
      }
    }

    if (updated.status === 'ACTIVE') {
      const hitStop = priceHit(updated.direction, exitCandle, updated.stopLoss, 'stop');
      const hitTp1 = priceHit(updated.direction, exitCandle, updated.tp1, 'target');
      const hitTp2 = priceHit(updated.direction, exitCandle, updated.tp2, 'target');
      const hitTp3 = priceHit(updated.direction, exitCandle, updated.tp3, 'target');
      if (hitStop && (hitTp1 || hitTp2 || hitTp3)) {
        updated.status = 'STOPPED';
        updated.outcome = 'แท่งเดียวแตะทั้ง TP/SL — ประเมินแบบอนุรักษนิยมว่า SL ก่อน';
        updated.resultR = -1;
        updated.endedAt = rawCandle.time * 1000;
        break;
      }
      if (hitStop) {
        updated.status = 'STOPPED';
        updated.outcome = updated.progress.tp1 ? 'SL หลังผ่าน TP1' : 'แตะ Stop loss';
        updated.resultR = updated.progress.tp2 ? Math.max(0.8, Number(updated.tp2R || 1.1) * 0.6) : updated.progress.tp1 ? 0.1 : -1;
        updated.endedAt = rawCandle.time * 1000;
        break;
      }
      if (hitTp1) updated.progress.tp1 = true;
      if (hitTp2) updated.progress.tp2 = true;
      if (hitTp3) updated.progress.tp3 = true;

      const completionTarget = ['tp1', 'tp2', 'tp3'].includes(updated.exitAtTarget) ? updated.exitAtTarget : 'tp3';
      const completed = completionTarget === 'tp1' ? hitTp1 : completionTarget === 'tp2' ? hitTp2 : hitTp3;
      if (completed) {
        updated.status = 'COMPLETED';
        updated.outcome = `ถึง ${completionTarget.toUpperCase()} (เป้าหมายปิดหลัก)`;
        updated.resultR = Number(updated[`${completionTarget}R`] || 0);
        updated.endedAt = rawCandle.time * 1000;
        break;
      }
    }
  }

  if (!isTerminal(updated) && now >= updated.expiresAt && updated.status === 'WAITING_ENTRY') {
    updated.status = 'EXPIRED';
    updated.outcome = 'หมดเวลาก่อนเข้าโซน';
    updated.resultR = 0;
    updated.endedAt = now;
  }
  return updated;
}

export function evaluatePlans(plans, analyses, now = Date.now()) {
  return plans.map(plan => evaluatePlan(plan, analyses[plan.timeframe]?.candles || [], now));
}

export function statusLabel(status) {
  return ({
    WAITING_ENTRY: 'รอเข้า',
    ACTIVE: 'กำลังติดตาม',
    COMPLETED: 'สำเร็จ',
    STOPPED: 'หยุดขาดทุน',
    EXPIRED: 'หมดอายุ',
    INVALIDATED: 'ยกเลิกโดยตลาด',
    CANCELLED: 'ยกเลิกเอง'
  })[status] || status;
}
