const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

export const NEWS_RISK_MODES = Object.freeze(['OFF', 'INFORMATION_ONLY', 'RISK_FILTER', 'FULL_SIGNAL_ADJUSTMENT']);

export function newsAgeWeight(publishedAt, now = Date.now(), halfLifeMinutes = 180) {
  const published = new Date(publishedAt).getTime();
  if (!Number.isFinite(published)) return 0;
  const ageMinutes = Math.max(0, (now - published) / 60_000);
  return clamp(2 ** (-ageMinutes / Math.max(1, Number(halfLifeMinutes || 180))), 0, 1);
}

export function deduplicateNews(items = []) {
  const groups = new Map();
  for (const item of items || []) {
    const key = String(item?.duplicateGroup || item?.urlHash || `${item?.source || ''}:${item?.title || ''}`).trim().toLowerCase();
    if (!key) continue;
    const previous = groups.get(key);
    if (!previous || new Date(item.publishedAt).getTime() > new Date(previous.publishedAt).getTime()) groups.set(key, item);
  }
  return [...groups.values()];
}

export function evaluateHighImpactBlackout(events = [], config = {}, now = Date.now()) {
  const beforeMs = Math.max(0, Number(config.pauseMinutesBeforeHighImpact ?? 30)) * 60_000;
  const afterMs = Math.max(0, Number(config.pauseMinutesAfterHighImpact ?? 30)) * 60_000;
  const relevant = (events || []).filter(event => {
    const impact = String(event?.impactLevel || '').toUpperCase();
    const currency = String(event?.currency || '').toUpperCase();
    const scheduled = new Date(event?.scheduledAt).getTime();
    if (!Number.isFinite(scheduled) || !['HIGH', '3', 'RED'].includes(impact)) return false;
    if (currency && !['USD', 'XAU', 'ALL'].includes(currency)) return false;
    return now >= scheduled - beforeMs && now <= scheduled + afterMs;
  }).sort((a, b) => new Date(a.scheduledAt) - new Date(b.scheduledAt));
  return {
    blocked: relevant.length > 0,
    events: relevant,
    reason: relevant.length ? `HIGH_IMPACT_EVENT:${relevant[0].eventName || 'UNKNOWN'}` : null
  };
}

export function newsRiskScore(articles = [], now = Date.now()) {
  const unique = deduplicateNews(articles);
  if (!unique.length) return { score: 50, confidence: 0, articles: [] };
  let weighted = 0;
  let totalWeight = 0;
  for (const article of unique) {
    const age = newsAgeWeight(article.publishedAt, now);
    const relevance = clamp(Number(article.relevanceScore ?? 0.5), 0, 1);
    const confidence = clamp(Number(article.sentimentConfidence ?? 0.3), 0, 1);
    const impact = String(article.impactLevel || '').toUpperCase() === 'HIGH' ? 1 : String(article.impactLevel || '').toUpperCase() === 'MEDIUM' ? 0.7 : 0.4;
    const weight = age * relevance * confidence * impact;
    weighted += clamp(Number(article.sentimentScore || 0), -1, 1) * weight;
    totalWeight += weight;
  }
  return {
    score: Math.round(clamp(50 + (totalWeight ? weighted / totalWeight : 0) * 40, 0, 100)),
    confidence: Math.round(clamp(totalWeight / Math.max(1, unique.length) * 100, 0, 100)),
    articles: unique
  };
}
