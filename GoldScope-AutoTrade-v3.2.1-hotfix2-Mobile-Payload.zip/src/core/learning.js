const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const round = (value, digits = 2) => Number(Number(value || 0).toFixed(digits));
const finite = Number.isFinite;

const DEFAULTS = {
  adaptiveLearning: true,
  learningMinSamples: 8,
  learningMaxAdjustment: 7,
  learningLookback: 800,
  learningUseDemo: true,
  learningDataPolicy: 'weighted-all',
  learningDemoWeight: 0.35,
  learningMixedWeight: 0.55,
  learningIncludeBreakeven: true,
  learningResetAt: 0
};

export const TUNING_PROFILE_SCHEMA = 'goldscope-tuning-profile';
export const TUNING_PROFILE_VERSION = 2;

export const LEARNING_SETTING_KEYS = [
  'adaptiveLearning', 'learningMinSamples', 'learningMaxAdjustment',
  'learningLookback', 'learningUseDemo', 'learningDataPolicy',
  'learningDemoWeight', 'learningMixedWeight', 'learningIncludeBreakeven'
];

export const ALGORITHM_SETTING_KEYS = [
  'profile', 'minScore', 'minRiskReward', 'targetRiskReward', 'maxTargetRiskReward',
  'minTargetAtr', 'maxTargetAtr', 'exitAtTarget', 'positionSizingMode', 'accountSize',
  'fixedLot', 'riskPercent', 'maxLossUsd', 'pnlReferenceSize', 'pnlPerUsdMoveAtReferenceSize', 'contractSize', 'leverage',
  'maxMarginUsagePercent', 'lotStep', 'maxLot', 'brokerDigits', 'spreadPoints',
  'slippagePoints', 'manualEntryBufferPoints', 'maxExecutionCostPercent',
  'minExpectedBarsToTp2', 'maxExpectedBarsToTp2', 'minStopPoints', 'minStopAtrMultiplier', 'backtestMaxHoldBars'
];

function normalize(value, fallback = 'unknown') {
  return String(value || fallback).trim().toLowerCase().replace(/\s+/g, '-');
}

function normalizedStatus(status) {
  return ['COMPLETED', 'STOPPED'].includes(status) ? status : 'IGNORED';
}

function learningRecordId(item = {}) {
  if (item.learningId) return String(item.learningId);
  return [
    normalize(item.strategyKey || item.strategy), normalize(item.timeframe),
    normalize(item.regime), Number(item.direction) === -1 ? -1 : 1,
    Number(item.endedAt || 0), Number(item.resultR || 0).toFixed(4),
    normalize(item.dataMode), normalizedStatus(item.status)
  ].join('|');
}

export function learningRecordFromTrade(trade = {}) {
  const resultR = Number(trade.resultR);
  const endedAt = Number(trade.endedAt || 0);
  return {
    learningId: learningRecordId(trade),
    strategyKey: normalize(trade.strategyKey || trade.strategy),
    strategy: String(trade.strategy || trade.strategyKey || 'unknown').slice(0, 120),
    timeframe: normalize(trade.timeframe),
    regime: String(trade.regime || 'unknown').slice(0, 120),
    direction: Number(trade.direction) === -1 ? -1 : 1,
    dataMode: normalize(trade.dataMode),
    status: normalizedStatus(trade.status),
    resultR: finite(resultR) ? round(clamp(resultR, -20, 20), 4) : 0,
    endedAt: finite(endedAt) ? Math.max(0, Math.floor(endedAt)) : 0
  };
}

export function mergeLearningRecords(...collections) {
  const merged = new Map();
  for (const collection of collections) {
    for (const item of Array.isArray(collection) ? collection : []) {
      const record = learningRecordFromTrade(item);
      if (!record.endedAt) continue;
      merged.set(record.learningId, record);
    }
  }
  return [...merged.values()].sort((a, b) => b.endedAt - a.endedAt);
}

function dataWeight(trade, settings, currentMode) {
  const mode = normalize(trade.dataMode);
  if (!settings.learningUseDemo) return mode === 'live' ? 1 : 0;

  const policy = ['weighted-all', 'same-mode', 'live-only'].includes(settings.learningDataPolicy)
    ? settings.learningDataPolicy
    : 'weighted-all';
  if (policy === 'live-only') return mode === 'live' ? 1 : 0;
  if (policy === 'same-mode') return mode === normalize(currentMode) ? 1 : 0;
  if (mode === 'live') return 1;
  if (mode === 'mixed') return clamp(Number(settings.learningMixedWeight || 0.55), 0.05, 1);
  if (mode === 'demo') return clamp(Number(settings.learningDemoWeight || 0.35), 0.05, 1);
  return 0.2;
}

function eligibility(trade, settings, currentMode) {
  if (!trade || !finite(Number(trade.resultR))) return { eligible: false, reason: 'invalid-result', weight: 0 };
  if (!['COMPLETED', 'STOPPED'].includes(trade.status)) return { eligible: false, reason: 'not-final-trade', weight: 0 };
  if (Number(trade.endedAt || 0) <= Number(settings.learningResetAt || 0)) return { eligible: false, reason: 'before-reset', weight: 0 };
  if (Number(trade.resultR) === 0 && !settings.learningIncludeBreakeven) return { eligible: false, reason: 'breakeven-disabled', weight: 0 };
  const weight = dataWeight(trade, settings, currentMode);
  if (weight <= 0) return { eligible: false, reason: 'data-policy', weight: 0 };
  return { eligible: true, reason: 'used', weight };
}

export function learningEligibilityReport(records = [], settingsInput = {}, currentMode = 'live') {
  const settings = { ...DEFAULTS, ...settingsInput };
  const merged = mergeLearningRecords(records);
  const reasons = {};
  const eligible = [];
  for (const trade of merged) {
    const check = eligibility(trade, settings, currentMode);
    reasons[check.reason] = (reasons[check.reason] || 0) + 1;
    if (check.eligible) eligible.push({ ...trade, learningWeight: check.weight });
  }
  const lookback = Math.max(50, Number(settings.learningLookback || DEFAULTS.learningLookback));
  const selected = eligible.slice(0, lookback);
  if (eligible.length > selected.length) reasons['outside-lookback'] = eligible.length - selected.length;
  return {
    total: merged.length,
    eligible: selected,
    eligibleCount: selected.length,
    excludedCount: Math.max(0, merged.length - selected.length),
    reasons
  };
}

export function eligibleLearningRecords(records = [], settingsInput = {}, currentMode = 'live') {
  return learningEligibilityReport(records, settingsInput, currentMode).eligible;
}

function groupKeys(item) {
  const strategy = normalize(item.strategyKey || item.strategy);
  const timeframe = normalize(item.timeframe);
  const regime = normalize(item.regime);
  const direction = Number(item.direction) === -1 ? 'sell' : 'buy';
  return {
    exact: `strategy-tf-regime:${strategy}|${timeframe}|${regime}`,
    strategyTf: `strategy-tf:${strategy}|${timeframe}`,
    strategy: `strategy:${strategy}`,
    timeframe: `timeframe:${timeframe}`,
    regime: `regime:${regime}`,
    direction: `direction:${direction}`
  };
}

function friendlyGroup(key) {
  const [kind, raw = ''] = key.split(':');
  const parts = raw.split('|');
  if (kind === 'strategy-tf-regime') return `${parts[0]} • ${parts[1]} • ${parts[2]}`;
  if (kind === 'strategy-tf') return `${parts[0]} • ${parts[1]}`;
  if (kind === 'strategy') return parts[0];
  if (kind === 'timeframe') return `Timeframe ${parts[0]}`;
  if (kind === 'regime') return `Regime ${parts[0]}`;
  if (kind === 'direction') return parts[0].toUpperCase();
  return raw;
}

function summarize(rows, settings) {
  const minSamples = Math.max(4, Number(settings.learningMinSamples || DEFAULTS.learningMinSamples));
  const priorTrades = Math.max(4, minSamples * 0.5);
  let weightedWins = 0;
  let weightedLosses = 0;
  let weightedR = 0;
  let grossProfit = 0;
  let grossLoss = 0;
  let effectiveSamples = 0;

  rows.forEach((row, index) => {
    const sourceWeight = clamp(Number(row.learningWeight || 1), 0.05, 1);
    const recencyWeight = Math.pow(0.995, index);
    const weight = sourceWeight * recencyWeight;
    const resultR = Number(row.resultR);
    effectiveSamples += weight;
    weightedR += resultR * weight;
    if (resultR > 0) {
      weightedWins += weight;
      grossProfit += resultR * weight;
    } else if (resultR < 0) {
      weightedLosses += weight;
      grossLoss += Math.abs(resultR) * weight;
    }
  });

  const smoothedWinRate = (weightedWins + priorTrades * 0.5) / Math.max(1, weightedWins + weightedLosses + priorTrades) * 100;
  const smoothedExpectancy = weightedR / Math.max(1, effectiveSamples + priorTrades * 0.4);
  const confidence = clamp((effectiveSamples - minSamples * 0.35) / (minSamples * 1.15), 0, 1);
  const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? 9.99 : 0;
  const rawAdjustment = smoothedExpectancy * 7 + (smoothedWinRate - 50) * 0.105;
  const adjustment = clamp(rawAdjustment * confidence, -Number(settings.learningMaxAdjustment || 7), Number(settings.learningMaxAdjustment || 7));

  return {
    samples: rows.length,
    effectiveSamples: round(effectiveSamples, 1),
    wins: rows.filter(row => Number(row.resultR) > 0).length,
    losses: rows.filter(row => Number(row.resultR) < 0).length,
    breakeven: rows.filter(row => Number(row.resultR) === 0).length,
    winRate: round(smoothedWinRate, 1),
    rawWinRate: round(rows.filter(row => Number(row.resultR) > 0).length / Math.max(1, rows.filter(row => Number(row.resultR) !== 0).length) * 100, 1),
    expectancyR: round(smoothedExpectancy, 3),
    rawExpectancyR: round(rows.reduce((sum, row) => sum + Number(row.resultR), 0) / Math.max(1, rows.length), 3),
    profitFactor: round(Math.min(9.99, profitFactor), 2),
    confidence: round(confidence * 100, 1),
    adjustment: round(adjustment, 2),
    eligible: effectiveSamples >= Math.max(2, minSamples * 0.35) && confidence > 0
  };
}

export function buildAdaptiveModel(records = [], settingsInput = {}, currentMode = 'live') {
  const settings = { ...DEFAULTS, ...settingsInput };
  const report = learningEligibilityReport(records, settings, currentMode);
  const sorted = report.eligible;
  const buckets = new Map();
  const add = (key, trade) => {
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(trade);
  };

  for (const trade of sorted) {
    const keys = groupKeys(trade);
    Object.values(keys).forEach(key => add(key, trade));
  }

  const groups = {};
  for (const [key, rows] of buckets) groups[key] = { key, label: friendlyGroup(key), ...summarize(rows, settings) };

  const overall = summarize(sorted, settings);
  const minimum = Math.max(4, Number(settings.learningMinSamples || DEFAULTS.learningMinSamples));
  let status = 'ปิดใช้งาน';
  if (settings.adaptiveLearning) {
    if (!sorted.length) status = 'รอผลลัพธ์ที่ปิดแผนแล้ว';
    else if (!overall.eligible) status = `กำลังสะสม ${overall.effectiveSamples}/${round(minimum * 0.35, 1)} น้ำหนักตัวอย่าง`;
    else status = overall.confidence >= 65 ? 'กำลังปรับเต็มรูปแบบ' : 'กำลังปรับแบบจำกัด';
  }

  const model = {
    enabled: Boolean(settings.adaptiveLearning),
    mode: currentMode,
    status,
    eligibleTrades: sorted.length,
    effectiveTrades: overall.effectiveSamples,
    excludedTrades: report.excludedCount,
    exclusionReasons: report.reasons,
    minimumSamples: minimum,
    lookback: Math.max(50, Number(settings.learningLookback || DEFAULTS.learningLookback)),
    overall,
    groups,
    updatedAt: Date.now()
  };
  model.fingerprint = adaptiveModelFingerprint(model, settings);
  return model;
}

function modelForCandidate(candidate, model, settings) {
  const keys = groupKeys(candidate);
  const weightedGroups = [
    [keys.exact, 0.42],
    [keys.strategyTf, 0.27],
    [keys.strategy, 0.18],
    [keys.timeframe, 0.08],
    [keys.regime, 0.05]
  ];

  let weightedAdjustment = 0;
  let weightedWinRate = 0;
  let weightedExpectancy = 0;
  let weightedConfidence = 0;
  let weightedSamples = 0;
  let totalWeight = 0;
  const sources = [];

  for (const [key, baseWeight] of weightedGroups) {
    const stats = model.groups[key];
    if (!stats?.eligible) continue;
    const reliability = clamp(stats.confidence / 100, 0.05, 1);
    const weight = baseWeight * reliability;
    totalWeight += weight;
    weightedAdjustment += stats.adjustment * weight;
    weightedWinRate += stats.winRate * weight;
    weightedExpectancy += stats.expectancyR * weight;
    weightedConfidence += stats.confidence * weight;
    weightedSamples += stats.effectiveSamples * weight;
    sources.push({ key, label: stats.label, samples: stats.samples, effectiveSamples: stats.effectiveSamples, adjustment: stats.adjustment, confidence: stats.confidence });
  }

  if (!totalWeight) return { adjustment: 0, winRate: null, expectancyR: null, confidence: 0, samples: 0, sources: [] };
  return {
    adjustment: clamp(weightedAdjustment / totalWeight, -Number(settings.learningMaxAdjustment || 7), Number(settings.learningMaxAdjustment || 7)),
    winRate: weightedWinRate / totalWeight,
    expectancyR: weightedExpectancy / totalWeight,
    confidence: weightedConfidence / totalWeight,
    samples: weightedSamples / totalWeight,
    sources
  };
}

export function applyAdaptiveLearning(candidates = [], model, settingsInput = {}) {
  const settings = { ...DEFAULTS, ...settingsInput };
  return candidates.map(candidate => {
    const next = { ...candidate, evidence: [...(candidate.evidence || [])], warnings: [...(candidate.warnings || [])] };
    next.baseScore = Number(candidate.score);
    next.adaptiveAdjustment = 0;
    next.learningSamples = 0;
    next.learningConfidence = 0;
    next.learnedWinRate = null;
    next.learnedExpectancyR = null;
    next.learningSources = [];
    if (!settings.adaptiveLearning || !model?.enabled) return next;

    const learned = modelForCandidate(next, model, settings);
    next.adaptiveAdjustment = round(learned.adjustment, 1);
    next.learningSamples = round(learned.samples, 1);
    next.learningConfidence = round(learned.confidence, 1);
    next.learnedWinRate = learned.winRate === null ? null : round(learned.winRate, 1);
    next.learnedExpectancyR = learned.expectancyR === null ? null : round(learned.expectancyR, 3);
    next.learningSources = learned.sources;
    next.score = clamp(Math.round(next.baseScore + learned.adjustment), 0, 100);

    if (learned.adjustment >= 1) next.evidence.push(`Adaptive Learning เพิ่มคะแนน +${round(learned.adjustment, 1)} จากน้ำหนักข้อมูล ${round(learned.samples, 1)} ตัวอย่าง`);
    else if (learned.adjustment <= -1) next.warnings.push(`Adaptive Learning ลดคะแนน ${round(learned.adjustment, 1)} จากผลรูปแบบใกล้เคียง`);
    else if (learned.samples > 0) next.evidence.push(`Adaptive Learning ปรับเล็กน้อย ความเชื่อมั่น ${round(learned.confidence, 0)}%`);
    return next;
  });
}

export function adaptiveModelFingerprint(model, settingsInput = {}) {
  const settings = { ...DEFAULTS, ...settingsInput };
  const compact = {
    settings: LEARNING_SETTING_KEYS.reduce((out, key) => ({ ...out, [key]: settings[key] }), {}),
    groups: Object.values(model?.groups || {})
      .filter(group => group.eligible)
      .sort((a, b) => a.key.localeCompare(b.key))
      .map(group => [group.key, group.samples, group.effectiveSamples, group.adjustment, group.expectancyR, group.confidence])
  };
  const text = JSON.stringify(compact);
  let hash = 2166136261;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return `gs-${(hash >>> 0).toString(16).padStart(8, '0')}`;
}

function pickSettings(settings, keys) {
  return keys.reduce((out, key) => {
    if (settings[key] !== undefined) out[key] = settings[key];
    return out;
  }, {});
}

export function createTuningProfile(records = [], settingsInput = {}, currentMode = 'live', modelInput = null, appVersion = '2.0.0') {
  const settings = { ...DEFAULTS, ...settingsInput };
  const effectiveRecords = eligibleLearningRecords(records, settings, currentMode);
  const model = modelInput || buildAdaptiveModel(records, settings, currentMode);
  return {
    schema: TUNING_PROFILE_SCHEMA,
    schemaVersion: TUNING_PROFILE_VERSION,
    appVersion,
    exportedAt: new Date().toISOString(),
    sourceMode: currentMode,
    algorithmSettings: pickSettings(settings, ALGORITHM_SETTING_KEYS),
    learningSettings: pickSettings(settings, LEARNING_SETTING_KEYS),
    model: {
      fingerprint: adaptiveModelFingerprint(model, settings),
      eligibleTrades: model.eligibleTrades,
      effectiveTrades: model.effectiveTrades,
      confidence: model.overall?.confidence || 0,
      expectancyR: model.overall?.expectancyR || 0,
      winRate: model.overall?.winRate || 0
    },
    records: effectiveRecords.map(({ learningWeight, ...record }) => learningRecordFromTrade(record))
  };
}

const SETTING_RULES = {
  profile: value => ['scalp', 'conservative', 'balanced', 'opportunity'].includes(value) ? value : undefined,
  minScore: value => clamp(Number(value), 50, 95),
  minRiskReward: value => clamp(Number(value), 0.5, 4),
  targetRiskReward: value => clamp(Number(value), 0.5, 4),
  maxTargetRiskReward: value => clamp(Number(value), 0.5, 5),
  minTargetAtr: value => clamp(Number(value), 0.1, 5),
  maxTargetAtr: value => clamp(Number(value), 0.2, 10),
  exitAtTarget: value => ['tp1', 'tp2', 'tp3'].includes(value) ? value : undefined,
  positionSizingMode: value => ['fixed', 'risk'].includes(value) ? value : undefined,
  accountSize: value => clamp(Number(value), 1, 10000000),
  fixedLot: value => clamp(Number(value), 0.001, 100),
  riskPercent: value => clamp(Number(value), 0.05, 50),
  maxLossUsd: value => clamp(Number(value), 0, 1000000),
  pnlReferenceSize: value => clamp(Number(value), 0.0001, 1000000),
  pnlPerUsdMoveAtReferenceSize: value => clamp(Number(value), 0.000001, 1000000),
  contractSize: value => clamp(Number(value), 0.01, 10000),
  leverage: value => clamp(Number(value), 1, 5000),
  maxMarginUsagePercent: value => clamp(Number(value), 5, 100),
  lotStep: value => clamp(Number(value), 0.001, 100),
  maxLot: value => clamp(Number(value), 0.001, 1000),
  brokerDigits: value => Number(value) === 3 ? 3 : 2,
  spreadPoints: value => clamp(Number(value), 0, 5000),
  slippagePoints: value => clamp(Number(value), 0, 2000),
  manualEntryBufferPoints: value => clamp(Number(value), 0, 2000),
  maxExecutionCostPercent: value => clamp(Number(value), 5, 65),
  minExpectedBarsToTp2: value => clamp(Number(value), 0.05, 10),
  maxExpectedBarsToTp2: value => clamp(Number(value), 0.1, 30),
  minStopPoints: value => clamp(Number(value), 0, 10000),
  minStopAtrMultiplier: value => clamp(Number(value), 0, 5),
  backtestMaxHoldBars: value => clamp(Number(value), 1, 100),
  adaptiveLearning: value => Boolean(value),
  learningMinSamples: value => clamp(Number(value), 4, 200),
  learningMaxAdjustment: value => clamp(Number(value), 1, 15),
  learningLookback: value => clamp(Number(value), 50, 2000),
  learningUseDemo: value => Boolean(value),
  learningDataPolicy: value => ['weighted-all', 'same-mode', 'live-only'].includes(value) ? value : undefined,
  learningDemoWeight: value => clamp(Number(value), 0.05, 1),
  learningMixedWeight: value => clamp(Number(value), 0.05, 1),
  learningIncludeBreakeven: value => Boolean(value)
};

function sanitizeSettings(input, keys) {
  const out = {};
  for (const key of keys) {
    if (!(key in (input || {}))) continue;
    const rule = SETTING_RULES[key];
    if (!rule) continue;
    const value = rule(input[key]);
    if (value !== undefined && (typeof value === 'boolean' || typeof value === 'string' || finite(Number(value)))) out[key] = value;
  }
  return out;
}

export function validateTuningProfile(raw) {
  if (!raw || raw.schema !== TUNING_PROFILE_SCHEMA || ![1, 2].includes(Number(raw.schemaVersion))) {
    throw new Error('ไฟล์นี้ไม่ใช่ GoldScope Tuning Profile ที่รองรับ');
  }
  if (!Array.isArray(raw.records) || raw.records.length > 4000) throw new Error('จำนวนข้อมูลจูนในไฟล์ไม่ถูกต้อง');
  const records = mergeLearningRecords(raw.records).filter(row => ['COMPLETED', 'STOPPED'].includes(row.status));
  if (raw.records.length && !records.length) throw new Error('ไม่พบผลการเทรดที่ปิดแล้วในไฟล์');
  return {
    schema: TUNING_PROFILE_SCHEMA,
    schemaVersion: TUNING_PROFILE_VERSION,
    appVersion: String(raw.appVersion || 'unknown'),
    exportedAt: String(raw.exportedAt || ''),
    sourceMode: normalize(raw.sourceMode),
    algorithmSettings: sanitizeSettings(raw.algorithmSettings, ALGORITHM_SETTING_KEYS),
    learningSettings: sanitizeSettings(raw.learningSettings, LEARNING_SETTING_KEYS),
    model: {
      fingerprint: String(raw.model?.fingerprint || ''),
      eligibleTrades: Math.max(0, Number(raw.model?.eligibleTrades || records.length)),
      effectiveTrades: Math.max(0, Number(raw.model?.effectiveTrades || records.length)),
      confidence: round(raw.model?.confidence || 0, 1),
      expectancyR: round(raw.model?.expectancyR || 0, 4),
      winRate: round(raw.model?.winRate || 0, 1)
    },
    records
  };
}

export function learningLeaderboard(model, limit = 12) {
  if (!model?.groups) return [];
  return Object.values(model.groups)
    .filter(group => group.eligible && group.key.startsWith('strategy-tf:'))
    .sort((a, b) => Math.abs(b.adjustment) - Math.abs(a.adjustment) || b.effectiveSamples - a.effectiveSamples)
    .slice(0, limit);
}
