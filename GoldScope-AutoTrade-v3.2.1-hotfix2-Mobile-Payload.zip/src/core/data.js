import { mockDataset } from '../mock/generator.js';
import { getActiveAccountKey } from './brokerApi.js';

export const TIMEFRAMES = ['1min', '5min', '15min', '1h', '4h'];

function freshUrl(url) {
  const separator = url.includes('?') ? '&' : '?';
  return `${url}${separator}_gs=${Date.now()}`;
}

async function fetchJson(url, timeoutMs = 15000, extraHeaders = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(freshUrl(url), {
      signal: controller.signal,
      cache: 'no-store',
      credentials: 'same-origin',
      headers: {
        accept: 'application/json',
        'cache-control': 'no-cache',
        pragma: 'no-cache',
        ...extraHeaders
      }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.ok === false) throw Object.assign(new Error(data.message || `HTTP ${response.status}`), { code: data.code, status: response.status });
    return data;
  } finally {
    clearTimeout(timer);
  }
}

export async function healthCheck() {
  try {
    return await fetchJson('/api/health', 8000);
  } catch (error) {
    return { ok: false, marketDataConfigured: false, error: error.message };
  }
}

async function loadCapitalBrokerData(outputsize) {
  const payload = await fetchJson(`/api/autotrade/market-data?outputsize=${Math.min(1000, Math.max(100, outputsize))}`, 30000, { 'x-account-key': getActiveAccountKey() });
  const datasets = payload.datasets || {};
  if (Object.keys(datasets).length < 3) throw new Error('ข้อมูล Capital.com ไม่พอ');
  return {
    mode: payload.mode === 'live' ? 'live' : 'demo',
    source: 'capital',
    environment: payload.environment,
    datasets,
    account: payload.account || null,
    market: payload.market || null,
    epic: payload.epic || null,
    errors: payload.errors || []
  };
}

async function loadTwelveData(outputsize) {
  const errors = [];
  const results = await Promise.all(TIMEFRAMES.map(async tf => {
    try {
      const size = tf === '1min' ? Math.min(outputsize, 700) : outputsize;
      const data = await fetchJson(`/api/market?symbol=XAU%2FUSD&interval=${tf}&outputsize=${size}`);
      if (!data.candles?.length) throw new Error('ไม่พบแท่งราคา');
      return [tf, data];
    } catch (error) {
      errors.push({ timeframe: tf, message: error.message, code: error.code });
      return [tf, null];
    }
  }));
  const valid = Object.fromEntries(results.filter(([, value]) => value));
  if (Object.keys(valid).length < 3) throw Object.assign(new Error('Twelve Data ไม่พร้อม'), { errors });
  return { mode: errors.length ? 'mixed' : 'live', source: 'twelvedata', datasets: valid, errors };
}

export async function loadMarketData({ forceDemo = false, outputsize = 900, brokerAuthenticated = false, preferBroker = true } = {}) {
  if (forceDemo) return { mode: 'demo', source: 'mock', datasets: mockDataset(), errors: [] };
  const errors = [];

  if (preferBroker && brokerAuthenticated) {
    try {
      return await loadCapitalBrokerData(outputsize);
    } catch (error) {
      errors.push({ timeframe: 'all', source: 'capital', message: error.message, code: error.code });
    }
  }

  try {
    const market = await loadTwelveData(outputsize);
    return { ...market, errors: [...errors, ...(market.errors || [])] };
  } catch (error) {
    const twelveErrors = error.errors || [{ timeframe: 'all', source: 'twelvedata', message: error.message, code: error.code }];
    return { mode: 'demo', source: 'mock', datasets: mockDataset(), errors: [...errors, ...twelveErrors] };
  }
}

export async function loadSingleTimeframe(timeframe, outputsize = 900) {
  try {
    return await fetchJson(`/api/market?symbol=XAU%2FUSD&interval=${timeframe}&outputsize=${outputsize}`);
  } catch {
    return mockDataset()[timeframe];
  }
}
