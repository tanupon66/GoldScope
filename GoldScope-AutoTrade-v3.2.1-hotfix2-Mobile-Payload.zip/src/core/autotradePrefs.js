import { DEFAULT_AUTO_TRADE_CONFIG, normalizeAutoTradeConfig } from './autotrade.js';

export const AUTO_TRADE_DISPLAY_CACHE_KEY = 'goldscope.autotrade.display.v1';

const DISPLAY_KEYS = [
  'enabled', 'executionMode', 'brokerEnvironment', 'instrumentSearch', 'instrumentEpic', 'timeframe',
  'minScore', 'maxOpenPositions', 'maxTradesPerDay', 'maxLossPerTradeUsd', 'riskPercentPerTrade',
  'maxDailyLossUsd', 'maxConsecutiveLosses', 'cooldownMinutes', 'maxSpreadUsd', 'entryToleranceUsd',
  'orderSize', 'pnlReferenceSize', 'pnlPerUsdMoveAtReferenceSize', 'useBrokerMinimumSize',
  'takeProfitTarget', 'requireFreshCandleSeconds', 'syncAlgorithm'
];

function storageOrNull(storageLike) {
  if (storageLike) return storageLike;
  try { return globalThis.localStorage || null; }
  catch { return null; }
}

export function sanitizeAutoTradeDisplayConfig(input = {}) {
  const normalized = normalizeAutoTradeConfig({ ...DEFAULT_AUTO_TRADE_CONFIG, ...(input || {}) });
  return Object.fromEntries(DISPLAY_KEYS.map(key => [key, normalized[key]]));
}

export function createAutoTradeDisplaySnapshot(config = {}, savedAt = Date.now()) {
  return {
    schema: 1,
    savedAt: Number(savedAt) || Date.now(),
    config: sanitizeAutoTradeDisplayConfig(config)
  };
}

export function loadAutoTradeDisplaySnapshot(storageLike = null) {
  const target = storageOrNull(storageLike);
  if (!target) return null;
  try {
    const raw = target.getItem(AUTO_TRADE_DISPLAY_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || !parsed.config) return null;
    return createAutoTradeDisplaySnapshot(parsed.config, parsed.savedAt);
  } catch {
    return null;
  }
}

export function saveAutoTradeDisplaySnapshot(config = {}, storageLike = null) {
  const snapshot = createAutoTradeDisplaySnapshot(config);
  const target = storageOrNull(storageLike);
  try { target?.setItem(AUTO_TRADE_DISPLAY_CACHE_KEY, JSON.stringify(snapshot)); }
  catch { /* Storage may be unavailable in private/embedded contexts. */ }
  return snapshot;
}

export function clearAutoTradeDisplaySnapshot(storageLike = null) {
  const target = storageOrNull(storageLike);
  try { target?.removeItem(AUTO_TRADE_DISPLAY_CACHE_KEY); }
  catch { /* Ignore storage errors. */ }
}
