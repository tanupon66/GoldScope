function mulberry32(seed) {
  return function() {
    let t = seed += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

const TF_SECONDS = { '1min': 60, '5min': 300, '15min': 900, '1h': 3600, '4h': 14400 };

export function generateMockCandles(timeframe = '5min', count = 800, seed = 424242) {
  const random = mulberry32(seed + TF_SECONDS[timeframe]);
  const interval = TF_SECONDS[timeframe] || 300;
  const end = Math.floor(Date.now() / 1000 / interval) * interval;
  let price = 2320 + random() * 80;
  let trend = (random() - 0.45) * 0.08;
  let volatility = 0.75;
  const candles = [];
  for (let i = count - 1; i >= 0; i--) {
    if ((count - i) % 90 === 0) trend = (random() - 0.5) * 0.22;
    if ((count - i) % 55 === 0) volatility = 0.35 + random() * 1.4;
    const open = price;
    const cycle = Math.sin((count - i) / 23) * 0.12;
    const shock = (random() + random() + random() - 1.5) * volatility;
    const close = Math.max(100, open + trend + cycle + shock);
    const wick = (0.15 + random() * 0.8) * volatility;
    const high = Math.max(open, close) + wick * random();
    const low = Math.min(open, close) - wick * random();
    const volume = Math.round(80 + random() * 920 + Math.abs(close - open) * 300);
    candles.push({
      time: end - i * interval,
      datetime: new Date((end - i * interval) * 1000).toISOString(),
      open: Number(open.toFixed(2)),
      high: Number(high.toFixed(2)),
      low: Number(low.toFixed(2)),
      close: Number(close.toFixed(2)),
      volume
    });
    price = close;
  }
  return candles;
}

export function mockDataset() {
  return Object.fromEntries(Object.keys(TF_SECONDS).map((tf, i) => [tf, {
    ok: true,
    source: 'demo',
    symbol: 'XAU/USD (SIMULATED)',
    interval: tf,
    candles: generateMockCandles(tf, tf === '1min' ? 600 : 900, 424242 + i * 17),
    receivedAt: new Date().toISOString()
  }]));
}
