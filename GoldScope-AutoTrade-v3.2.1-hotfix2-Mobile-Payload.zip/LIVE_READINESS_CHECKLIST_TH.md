# Live Readiness Checklist — GoldScope v3.2

> สถานะ Source ที่ส่งมอบ: **ยังไม่พร้อม Live Auto** จนกว่าจะสร้างหลักฐานจาก Cloudflare และ Capital.com account จริง. Code gate ตั้งใจบล็อก Live.

## Infrastructure

- [ ] Remote D1 migrations 0001/0002 ผ่าน.
- [ ] Queue consumers ทั้ง 7 ตัวทำงานและ Dead Letter = 0.
- [ ] Cron last scan/last success สม่ำเสมอ.
- [ ] Broker/market/news provider health ไม่มี critical error.
- [ ] Notification/Kill Switch alert ทดสอบแล้ว.

## Broker execution

- [ ] Account ID, environment และ Epic ตรงบัญชีที่ตั้งใจใช้.
- [ ] Calibration ผ่านจาก Demo result ที่ตรวจสอบได้.
- [ ] Accepted, rejected, 401, 429, 5xx และ timeout-after-submit drills ผ่าน.
- [ ] Duplicate Cron/Queue ไม่สร้าง duplicate order.
- [ ] Reconciliation match deal/reference และ verified P/L ได้.
- [ ] Unknown/unresolved order intents = 0.
- [ ] Reconciliation mismatch = 0.
- [ ] Minimum size/step/stop/tick/P&L conversion ถูกยืนยัน.

## Performance evidence

- [ ] Demo trades ปิดแล้วอย่างน้อย 100 รายการ.
- [ ] Shadow Forward Test อย่างน้อย 28 วัน.
- [ ] Out-of-sample expectancy หลังต้นทุน > 0.
- [ ] Drawdown ไม่เกินเกณฑ์.
- [ ] ผลเสถียรหลายช่วง/regime ไม่ได้มาจากเดือนเดียว.
- [ ] Cost/spread/slippage/delay stress ยังยอมรับได้.
- [ ] Model Drift ไม่อยู่ `DRIFT`; Adaptive pause/rollback ถูกทดสอบ.
- [ ] Config/model version ถูก freeze และ export backup แล้ว.

## Risk operations

- [ ] Daily/weekly loss, drawdown, margin, consecutive-loss และ max-trade guards ทดสอบ.
- [ ] News blackout ทดสอบโดยยัง reconcile/จัดการ position ได้.
- [ ] Kill Switch ยกเลิก queued intent และไม่ส่ง Broker POST.
- [ ] ผู้ใช้มีแผนตรวจ/ปิด position ที่ Capital.com โดยตรง.
- [ ] ไม่มี critical execution error หรือ open DLQ.

## User confirmation

- [ ] ยอมรับความเสี่ยง CFD/leverage และไม่มีการรับประกันกำไร.
- [ ] ยืนยัน account, symbol, size, P/L conversion และ maximum loss.
- [ ] ตรวจ spread/financing/commission จาก statement จริง.
- [ ] อ่าน Known Limitations และมี rollback plan.

## Unlock flow

เลือก Live → Broker test → Calibration → Readiness report → พิมพ์ `LIVE` → unlock อายุสั้น. Logout, deploy, environment/account/risk config เปลี่ยน หรือ session หมดอายุ ต้องยกเลิก unlock.
