import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright-core';

const root = fileURLToPath(new URL('../dist/', import.meta.url));
const projectRoot = fileURLToPath(new URL('../', import.meta.url));
const artifactDir = resolve(process.env.GOLDSCOPE_E2E_ARTIFACT_DIR || join(projectRoot, 'artifacts', 'e2e'));
await mkdir(artifactDir, { recursive: true });
const artifactPath = (name) => join(artifactDir, name);
const assets = await readdir(join(root, 'assets'));
const jsFile = assets.find(x => x.endsWith('.js'));
const cssFile = assets.find(x => x.endsWith('.css'));
const js = await readFile(join(root, 'assets', jsFile), 'utf8');
const css = await readFile(join(root, 'assets', cssFile), 'utf8');
const html = `<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><style>${css}</style></head><body><div id="app"></div><script type="module">${js}</script></body></html>`;

const browser = await chromium.launch({ executablePath:'/usr/bin/chromium', headless:true, args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--disable-background-networking'] });
const errors=[];
try {
  const page = await browser.newPage({ viewport:{width:1440,height:1000} });
  page.on('console', msg => {
    if (msg.type()==='error' && !/service worker|Failed to parse URL|about:blank|fetch/i.test(msg.text())) errors.push(`console: ${msg.text()}`);
  });
  page.on('pageerror', err => {
    if (!/Failed to parse URL|fetch|service worker/i.test(err.message)) errors.push(`pageerror: ${err.message}`);
  });
  await page.setContent(html, { waitUntil:'load', timeout:30000 });
  await page.waitForSelector('.loading-overlay', { state:'detached', timeout:30000 });
  await page.waitForSelector('.plan-card, .empty-state', { timeout:15000 });
  if ((await page.locator('body').innerText()).includes('Score null')) throw new Error('Invalid Score null rendered');
  await page.waitForSelector('#syncStatus');
  const syncText = await page.locator('#syncStatus').textContent();
  if (!/ล่าสุด|กำลังโหลด|รอบถัดไป/.test(syncText || '')) throw new Error(`Auto-sync status missing: ${syncText}`);
  const title = await page.locator('.page-title').textContent();
  const metrics = await page.locator('.metric-card').count();
  if (title?.trim() !== 'ภาพรวมตลาด' || metrics < 4) throw new Error(`Dashboard smoke failed title=${title} metrics=${metrics}`);
  await page.screenshot({ path:artifactPath('goldscope-desktop.png'), fullPage:true });
  await page.locator('.sidebar [data-page="analysis"]').click();
  await page.waitForSelector('.analysis-section');
  await page.locator('.sidebar [data-page="autotrade"]').click();
  await page.waitForSelector('#autoTradeForm');
  await page.waitForSelector('#brokerTest');
  await page.waitForSelector('[data-auto-panel="basic"].active');
  await page.click('[data-auto-step="risk"]');
  await page.waitForSelector('[data-auto-panel="risk"].active');
  await page.click('[data-auto-step="basic"]');
  await page.waitForSelector('#autoKill');
  await page.screenshot({ path:artifactPath('goldscope-autotrade-desktop.png'), fullPage:true });
  await page.locator('.sidebar [data-page="backtest"]').click();
  await page.waitForSelector('#runBacktest');
  await page.click('#runBacktest');
  await page.waitForSelector('.loading-overlay', { state:'detached', timeout:30000 });
  await page.waitForSelector('.equity-chart, .empty-state', { timeout:30000 });
  await page.locator('.sidebar [data-page="journal"]').click();
  await page.waitForSelector('text=Adaptive Learning model');
  await page.locator('.sidebar [data-page="settings"]').click();
  await page.waitForSelector('#adaptiveLearning');
  await page.waitForSelector('#spreadPoints');
  await page.waitForSelector('#brokerDigits');
  await page.waitForSelector('#exportTuning');
  await page.waitForSelector('#importTuning');
  const adaptiveChecked = await page.locator('#adaptiveLearning').isChecked();
  if (!adaptiveChecked) throw new Error('Adaptive learning should be enabled by default');

  const tuningPath = artifactPath('goldscope-e2e-tuning.json');
  const now = Date.now();
  const records = Array.from({length:24}, (_, i) => ({
    learningId:`e2e-${i}`, strategyKey:'trend-pullback', strategy:'Trend pullback',
    timeframe:'15min', regime:'Trend', direction:1, dataMode:'live',
    status:i < 16 ? 'COMPLETED' : 'STOPPED', resultR:i < 16 ? 1.8 : -1, endedAt:now-i*1000
  }));
  await writeFile(tuningPath, JSON.stringify({
    schema:'goldscope-tuning-profile', schemaVersion:2, appVersion:'3.2.1',
    exportedAt:new Date().toISOString(), sourceMode:'live',
    algorithmSettings:{profile:'balanced',minScore:68,spreadPoints:200,brokerDigits:2},
    learningSettings:{adaptiveLearning:true,learningMinSamples:8,learningMaxAdjustment:7,learningLookback:800,learningUseDemo:true,learningDataPolicy:'weighted-all',learningDemoWeight:0.35,learningMixedWeight:0.55,learningIncludeBreakeven:true},
    model:{fingerprint:'gs-e2e',eligibleTrades:24,confidence:46,expectancyR:0.2,winRate:56}, records
  }));
  await page.locator('#tuningFile').setInputFiles(tuningPath);
  await page.waitForSelector('.app-dialog');
  await page.click('[data-dialog-confirm]');
  await page.waitForSelector('text=ฐานนำเข้า 24 ผล', { timeout:30000 });

  const mobile = await browser.newPage({ viewport:{width:412,height:915}, isMobile:true });
  mobile.on('pageerror', err => { if (!/Failed to parse URL|fetch|service worker/i.test(err.message)) errors.push(`mobile pageerror: ${err.message}`); });
  await mobile.setContent(html, { waitUntil:'load', timeout:30000 });
  await mobile.waitForSelector('.loading-overlay', { state:'detached', timeout:30000 });
  await mobile.screenshot({ path:artifactPath('goldscope-mobile.png'), fullPage:true });
  await mobile.locator('.bottom-nav [data-page="autotrade"]').click();
  await mobile.waitForSelector('#autoTradeForm');
  await mobile.waitForSelector('.setup-steps');
  await mobile.screenshot({ path:artifactPath('goldscope-autotrade-mobile.png'), fullPage:true });
  const bottomDisplay = await mobile.locator('.bottom-nav').evaluate(el => getComputedStyle(el).display);
  if (bottomDisplay === 'none') throw new Error('Mobile bottom nav hidden');

  if (errors.length) throw new Error(errors.join('\n'));
  console.log(`E2E smoke passed: dashboard, Auto Trade UI, tuned backtest, tuning import, responsive mobile. Artifacts: ${artifactDir}`);
} finally {
  await browser.close();
}
