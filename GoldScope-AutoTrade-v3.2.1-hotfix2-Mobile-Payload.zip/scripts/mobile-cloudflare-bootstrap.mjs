import { readFile, writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

export const DEFAULT_QUEUE_NAMES = Object.freeze([
  'goldscope-market-ingestion',
  'goldscope-news-ingestion',
  'goldscope-signal-analysis',
  'goldscope-order-execution',
  'goldscope-broker-reconciliation',
  'goldscope-notification-delivery',
  'goldscope-dead-letter'
]);

const API_BASE = 'https://api.cloudflare.com/client/v4';
const VALID_RESOURCE_NAME = /^[a-z0-9][a-z0-9-]{0,62}$/;
const VALID_D1_LOCATIONS = new Set(['wnam', 'enam', 'weur', 'eeur', 'apac', 'oc']);

function required(value, name) {
  const normalized = String(value || '').trim();
  if (!normalized) throw new Error(`${name} is required`);
  return normalized;
}

function validateResourceName(value, label) {
  if (!VALID_RESOURCE_NAME.test(value)) {
    throw new Error(`${label} must contain only lowercase letters, numbers and hyphens (1-63 characters)`);
  }
}

async function cloudflareRequest({ fetchImpl, token, path, method = 'GET', body }) {
  const response = await fetchImpl(`${API_BASE}${path}`, {
    method,
    headers: {
      authorization: `Bearer ${token}`,
      'content-type': 'application/json'
    },
    body: body === undefined ? undefined : JSON.stringify(body)
  });

  const text = await response.text();
  let payload;
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    throw new Error(`Cloudflare returned a non-JSON response (${response.status})`);
  }

  if (!response.ok || payload.success === false) {
    const details = (payload.errors || [])
      .map(item => `${item.code || 'CF_ERROR'}: ${item.message || 'Unknown Cloudflare error'}`)
      .join('; ');
    throw new Error(details || `Cloudflare API request failed (${response.status})`);
  }
  return payload;
}

async function listAll({ fetchImpl, token, path }) {
  const items = [];
  let page = 1;
  while (page <= 20) {
    const separator = path.includes('?') ? '&' : '?';
    const payload = await cloudflareRequest({
      fetchImpl,
      token,
      path: `${path}${separator}page=${page}&per_page=100`
    });
    const result = Array.isArray(payload.result) ? payload.result : [];
    items.push(...result);
    const totalPages = Number(payload.result_info?.total_pages || 1);
    if (page >= totalPages || result.length === 0) break;
    page += 1;
  }
  return items;
}

export async function ensureD1Database({
  fetchImpl = fetch,
  accountId,
  token,
  databaseName,
  location = 'apac'
}) {
  validateResourceName(databaseName, 'D1 database name');
  if (!VALID_D1_LOCATIONS.has(location)) throw new Error(`Unsupported D1 location: ${location}`);

  const databases = await listAll({
    fetchImpl,
    token,
    path: `/accounts/${accountId}/d1/database`
  });
  const existing = databases.find(item => item?.name === databaseName);
  if (existing?.uuid) return { id: existing.uuid, created: false };

  const payload = await cloudflareRequest({
    fetchImpl,
    token,
    path: `/accounts/${accountId}/d1/database`,
    method: 'POST',
    body: {
      name: databaseName,
      primary_location_hint: location,
      read_replication: { mode: 'disabled' }
    }
  });
  const id = payload.result?.uuid;
  if (!id) throw new Error('Cloudflare created the D1 database but did not return its UUID');
  return { id, created: true };
}

export async function ensureQueues({
  fetchImpl = fetch,
  accountId,
  token,
  queueNames = DEFAULT_QUEUE_NAMES
}) {
  const existing = await listAll({
    fetchImpl,
    token,
    path: `/accounts/${accountId}/queues`
  });
  const existingNames = new Set(existing.map(item => item?.queue_name || item?.name).filter(Boolean));
  const result = [];

  for (const queueName of queueNames) {
    validateResourceName(queueName, 'Queue name');
    if (existingNames.has(queueName)) {
      result.push({ name: queueName, created: false });
      continue;
    }
    await cloudflareRequest({
      fetchImpl,
      token,
      path: `/accounts/${accountId}/queues`,
      method: 'POST',
      body: { queue_name: queueName }
    });
    result.push({ name: queueName, created: true });
  }
  return result;
}

export async function createGeneratedWranglerConfig({
  configPath,
  outputPath,
  workerName,
  databaseName,
  databaseId,
  appVersion = '3.2.1',
  newsApiBaseUrl = '',
  economicCalendarApiBaseUrl = ''
}) {
  validateResourceName(workerName, 'Worker name');
  const raw = await readFile(configPath, 'utf8');
  const config = JSON.parse(raw);
  config.name = workerName;
  config.vars = {
    ...(config.vars || {}),
    APP_VERSION: appVersion,
    NEWS_API_BASE_URL: String(newsApiBaseUrl || '').trim(),
    ECONOMIC_CALENDAR_API_BASE_URL: String(economicCalendarApiBaseUrl || '').trim()
  };
  if (!Array.isArray(config.d1_databases) || !config.d1_databases.length) {
    throw new Error('wrangler.jsonc does not contain a D1 binding');
  }
  config.d1_databases[0] = {
    ...config.d1_databases[0],
    binding: 'DB',
    database_name: databaseName,
    database_id: databaseId,
    migrations_dir: config.d1_databases[0].migrations_dir || 'migrations'
  };
  await writeFile(outputPath, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600 });
  return config;
}

export async function bootstrapCloudflareResources({
  fetchImpl = fetch,
  accountId,
  token,
  configPath = 'wrangler.jsonc',
  outputPath = '.wrangler.mobile.generated.jsonc',
  workerName = 'goldscope-autotrade',
  databaseName = 'goldscope-autotrade',
  databaseLocation = 'apac',
  appVersion = '3.2.1',
  newsApiBaseUrl = '',
  economicCalendarApiBaseUrl = ''
}) {
  accountId = required(accountId, 'CLOUDFLARE_ACCOUNT_ID');
  token = required(token, 'CLOUDFLARE_API_TOKEN');
  validateResourceName(workerName, 'Worker name');
  validateResourceName(databaseName, 'D1 database name');

  const database = await ensureD1Database({
    fetchImpl,
    accountId,
    token,
    databaseName,
    location: databaseLocation
  });
  const queues = await ensureQueues({ fetchImpl, accountId, token });
  await createGeneratedWranglerConfig({
    configPath,
    outputPath,
    workerName,
    databaseName,
    databaseId: database.id,
    appVersion,
    newsApiBaseUrl,
    economicCalendarApiBaseUrl
  });
  return { database, queues, outputPath, workerName, databaseName };
}

function readArg(name, fallback = '') {
  const prefix = `--${name}=`;
  const item = process.argv.slice(2).find(value => value.startsWith(prefix));
  return item ? item.slice(prefix.length) : fallback;
}

async function main() {
  const result = await bootstrapCloudflareResources({
    accountId: process.env.CLOUDFLARE_ACCOUNT_ID,
    token: process.env.CLOUDFLARE_API_TOKEN,
    configPath: readArg('config', 'wrangler.jsonc'),
    outputPath: readArg('out', '.wrangler.mobile.generated.jsonc'),
    workerName: readArg('worker-name', process.env.GOLDSCOPE_WORKER_NAME || 'goldscope-autotrade'),
    databaseName: readArg('database-name', process.env.GOLDSCOPE_DATABASE_NAME || 'goldscope-autotrade'),
    databaseLocation: readArg('database-location', process.env.GOLDSCOPE_D1_LOCATION || 'apac'),
    appVersion: readArg('app-version', '3.2.1'),
    newsApiBaseUrl: process.env.NEWS_API_BASE_URL || '',
    economicCalendarApiBaseUrl: process.env.ECONOMIC_CALENDAR_API_BASE_URL || ''
  });

  const createdQueues = result.queues.filter(item => item.created).map(item => item.name);
  console.log(`D1 ${result.database.created ? 'created' : 'reused'}: ${result.databaseName}`);
  console.log(`Queues ready: ${result.queues.length} (${createdQueues.length} created)`);
  console.log(`Generated deployment config: ${result.outputPath}`);
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch(error => {
    console.error(`Mobile bootstrap failed: ${error.message}`);
    process.exit(1);
  });
}
