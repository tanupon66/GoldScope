import crypto from 'node:crypto';
import { writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

export function hashAdminPassword(password, { salt = crypto.randomBytes(24), iterations = 310000 } = {}) {
  if (typeof password !== 'string' || password.length < 10) {
    throw new Error('GOLDSCOPE_ADMIN_PASSWORD must be at least 10 characters');
  }
  const hash = crypto.pbkdf2Sync(password, salt, iterations, 32, 'sha256');
  return `pbkdf2-sha256$${iterations}$${salt.toString('base64url')}$${hash.toString('base64url')}`;
}

function requireSecret(env, name) {
  const value = String(env[name] || '').trim();
  if (!value) throw new Error(`Missing required GitHub Actions secret: ${name}`);
  return value;
}

export function createCloudflareSecrets(env = process.env) {
  const adminPassword = requireSecret(env, 'GOLDSCOPE_ADMIN_PASSWORD');
  const payload = {
    ADMIN_CREDENTIAL_HASH: hashAdminPassword(adminPassword),
    SESSION_SIGNING_SECRET: crypto.randomBytes(48).toString('base64url'),
    CAPITAL_API_KEY: requireSecret(env, 'CAPITAL_API_KEY'),
    CAPITAL_IDENTIFIER: requireSecret(env, 'CAPITAL_IDENTIFIER'),
    CAPITAL_API_PASSWORD: requireSecret(env, 'CAPITAL_API_PASSWORD')
  };

  const optional = [
    'TWELVE_DATA_API_KEY',
    'NEWS_API_KEY',
    'ECONOMIC_CALENDAR_API_KEY',
    'TELEGRAM_BOT_TOKEN',
    'TELEGRAM_CHAT_ID',
    'NOTIFICATION_WEBHOOK_URL',
    'NOTIFICATION_SECRET'
  ];
  for (const name of optional) {
    const value = String(env[name] || '').trim();
    if (value) payload[name] = value;
  }
  return payload;
}

export async function writeCloudflareSecretsFile(outputPath, env = process.env) {
  const payload = createCloudflareSecrets(env);
  await writeFile(outputPath, `${JSON.stringify(payload)}\n`, { mode: 0o600 });
  return Object.keys(payload);
}

async function main() {
  const outputPath = process.argv[2] || '.mobile-secrets.json';
  const names = await writeCloudflareSecretsFile(outputPath);
  console.log(`Prepared ${names.length} Cloudflare secrets: ${names.join(', ')}`);
  console.log('Secret values were not printed. The temporary file must be deleted after deployment.');
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch(error => {
    console.error(`Secret preparation failed: ${error.message}`);
    process.exit(1);
  });
}
