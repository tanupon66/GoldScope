import crypto from 'node:crypto';

const password = process.argv[2];
if (!password || password.length < 10) {
  console.error('Usage: node scripts/generate-admin-hash.mjs "a strong password of at least 10 characters"');
  process.exit(1);
}
const iterations = 310000;
const salt = crypto.randomBytes(24);
const hash = crypto.pbkdf2Sync(password, salt, iterations, 32, 'sha256');
const b64url = value => value.toString('base64url');
console.log(`pbkdf2-sha256$${iterations}$${b64url(salt)}$${b64url(hash)}`);
