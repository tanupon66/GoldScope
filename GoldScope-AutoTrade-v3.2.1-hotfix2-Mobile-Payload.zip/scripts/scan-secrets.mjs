import { readdir, readFile, stat } from 'node:fs/promises';
import { extname, join, relative } from 'node:path';

const root = new URL('../', import.meta.url).pathname;
const ignoredDirectories = new Set(['.git', '.wrangler', 'node_modules', 'dist']);
const ignoredFiles = new Set(['package-lock.json']);
const readableExtensions = new Set(['.js', '.mjs', '.json', '.jsonc', '.html', '.css', '.sh', '.bat', '.txt', '.md', '.sql', '.example']);
const findings = [];

const credentialNames = [
  'CAPITAL_API_KEY', 'CAPITAL_IDENTIFIER', 'CAPITAL_API_PASSWORD',
  'SESSION_SIGNING_SECRET', 'ADMIN_CREDENTIAL_HASH', 'TWELVE_DATA_API_KEY',
  'NEWS_API_KEY', 'ECONOMIC_CALENDAR_API_KEY', 'NOTIFICATION_SECRET'
];
const directAssignment = new RegExp(`(?:${credentialNames.join('|')})\\s*[:=]\\s*["']([^"'\\r\\n]+)["']`, 'gi');
const envAssignment = new RegExp(`^(?:${credentialNames.join('|')})=(.+)$`, 'gmi');
const bearerLiteral = /authorization\s*[:=]\s*["']bearer\s+([A-Za-z0-9._~+\/-]{16,})["']/gi;
const privateKey = /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g;

async function walk(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (entry.isDirectory() && ignoredDirectories.has(entry.name)) continue;
    const path = join(directory, entry.name);
    if (entry.isDirectory()) await walk(path);
    else await inspect(path);
  }
}

async function inspect(path) {
  const name = relative(root, path);
  if (ignoredFiles.has(name)) return;
  if (name === '.dev.vars.example') return; // deliberately empty template
  const extension = extname(path);
  if (!readableExtensions.has(extension) && !entryIsEnv(name)) return;
  if ((await stat(path)).size > 2_000_000) return;
  let text;
  try { text = await readFile(path, 'utf8'); } catch { return; }
  for (const [label, pattern] of [['credential literal', directAssignment], ['environment credential', envAssignment], ['Bearer literal', bearerLiteral], ['private key', privateKey]]) {
    pattern.lastIndex = 0;
    let match;
    while ((match = pattern.exec(text))) {
      const value = String(match[1] || match[0]).trim();
      if (!value || /^<.*>$/.test(value) || /^(your|replace|example|changeme|test|placeholder)/i.test(value)) continue;
      const line = text.slice(0, match.index).split('\n').length;
      findings.push(`${name}:${line} ${label}`);
    }
  }
}

function entryIsEnv(name) {
  return /(^|\/)\.?(?:dev\.vars|env)(?:\.|$)/.test(name);
}

await walk(root);
if (findings.length) {
  console.error('Potential secrets detected:\n' + findings.join('\n'));
  process.exit(1);
}
console.log('Secret scan passed: no committed credential literals or private keys detected.');
