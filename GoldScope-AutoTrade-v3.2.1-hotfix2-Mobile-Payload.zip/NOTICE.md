# Third-party notices

GoldScope AutoTrade uses Lightweight Charts by TradingView, distributed under the Apache License 2.0. The application displays the required “Charts by TradingView” attribution in its interface.

GoldScope AutoTrade is an independent application and is not affiliated with, endorsed by, or sponsored by TradingView, Capital.com, Cloudflare, Twelve Data, or any broker/market-data provider.

Broker names and APIs remain subject to their respective terms, eligibility, regional restrictions, instrument specifications, and rate limits.
