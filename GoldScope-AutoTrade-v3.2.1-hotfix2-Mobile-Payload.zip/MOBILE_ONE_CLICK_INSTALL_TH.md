# ติดตั้ง GoldScope AutoTrade v3.2.1 จากโทรศัพท์ด้วย GitHub Actions

วิธีนี้ไม่ต้องใช้ Codespaces, Terminal, Node.js หรือคอมพิวเตอร์ ผู้ใช้ต้องกดและกรอกข้อมูลผ่านหน้า GitHub/Cloudflare ด้วยตนเองเท่านั้น และห้ามส่งรหัสผ่าน, API token, OTP หรือ Broker credentials ให้บุคคลอื่น

## ไฟล์ที่ใช้

อัปโหลดไฟล์ต่อไปนี้เข้า GitHub repository แบบ Private:

1. `GoldScope-AutoTrade-v3.2.1-Mobile-Payload.zip` ที่ root ของ repository
2. Workflow `GoldScope-Mobile-One-Click-Deploy.yml` โดยสร้างเป็น path:
   `.github/workflows/mobile-one-click-deploy.yml`

Workflow รองรับทั้ง repository ที่มี source แตกไว้แล้วและ repository ที่มีเพียง Mobile Payload ZIP

## 1. สร้าง Cloudflare API Token

ใน Cloudflare Dashboard สร้าง Custom API Token จำกัดเฉพาะ Account ที่ใช้ และให้สิทธิ์:

- Workers Scripts: Edit
- D1: Edit
- Queues: Edit

ไม่ต้องให้ Zone permissions หากยังไม่ใช้ Custom Domain

เก็บ `Cloudflare Account ID` และ Token ไว้ชั่วคราว ห้ามบันทึกในไฟล์ Source

## 2. สร้าง GitHub repository

1. เปิด GitHub จาก Chrome หรือ Safari
2. สร้าง repository ใหม่
3. ตั้ง Visibility เป็น **Private**
4. เปิด repository แล้วเลือก **Add file → Upload files**
5. อัปโหลด `GoldScope-AutoTrade-v3.2.1-Mobile-Payload.zip`
6. Commit เข้า branch `main`

## 3. เพิ่ม Workflow ด้วยโทรศัพท์

1. ใน repository กด **Add file → Create new file**
2. ช่องชื่อไฟล์พิมพ์:

```text
.github/workflows/mobile-one-click-deploy.yml
```

3. เปิดไฟล์ `GoldScope-Mobile-One-Click-Deploy.yml` ที่ได้รับมากับแพ็กเกจ
4. เลือกข้อความทั้งหมดและ Copy
5. Paste ลงในช่องแก้ไขของ GitHub
6. กด **Commit changes** เข้า `main`

หลัง commit จะเห็นแท็บ **Actions** และ workflow ชื่อ `GoldScope Mobile One-Click Deploy`

## 4. เพิ่ม GitHub Actions Secrets

ไปที่:

```text
Repository → Settings → Secrets and variables → Actions → Secrets
```

กด **New repository secret** และเพิ่มค่าต่อไปนี้ทีละรายการ

### Cloudflare — จำเป็นทุกครั้ง

```text
CLOUDFLARE_ACCOUNT_ID
CLOUDFLARE_API_TOKEN
```

### GoldScope และ Capital.com — จำเป็นตอน first_install

```text
GOLDSCOPE_ADMIN_PASSWORD
CAPITAL_API_KEY
CAPITAL_IDENTIFIER
CAPITAL_API_PASSWORD
```

`GOLDSCOPE_ADMIN_PASSWORD` คือรหัสที่ใช้ Login หน้า GoldScope ต้องยาวอย่างน้อย 10 ตัว และต้องไม่ใช้รหัสเดียวกับ Cloudflare, GitHub หรือ Capital.com

### Optional Secrets

เพิ่มเมื่อมี Provider จริงเท่านั้น:

```text
TWELVE_DATA_API_KEY
NEWS_API_KEY
ECONOMIC_CALENDAR_API_KEY
TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID
NOTIFICATION_WEBHOOK_URL
NOTIFICATION_SECRET
```

ห้ามใส่ Secret ใน Repository Variables เพราะ Variables ไม่ได้ใช้สำหรับเก็บข้อมูลลับ

## 5. Optional Repository Variables

ไปที่:

```text
Settings → Secrets and variables → Actions → Variables
```

เพิ่มเมื่อมี provider URL จริง:

```text
NEWS_API_BASE_URL
ECONOMIC_CALENDAR_API_BASE_URL
```

API Key ต้องอยู่ใน Secrets ไม่ใส่ใน URL

## 6. กดติดตั้งครั้งแรก

1. เปิดแท็บ **Actions**
2. เลือก `GoldScope Mobile One-Click Deploy`
3. กด **Run workflow**
4. ตั้งค่า:

```text
deployment_mode: first_install
confirmation: INSTALL_DEMO
worker_name: goldscope-autotrade
database_location: apac
run_e2e: เปิด
```

5. กดปุ่มสีเขียว **Run workflow**

Workflow จะทำงานตามลำดับ:

1. ตรวจ Secrets ที่จำเป็น
2. แตก Mobile Payload
3. `npm ci`
4. Secret scan, unit/integration tests และ production build
5. E2E desktop/mobile
6. ค้นหา D1 ชื่อ `goldscope-autotrade`; ถ้าไม่มีก็สร้างใน `apac`
7. ค้นหา Queues ทั้ง 7; สร้างเฉพาะรายการที่ยังไม่มี
8. สร้าง Wrangler config ชั่วคราวโดยใส่ D1 UUID จริง
9. Apply D1 migrations
10. Dry-run แบบ strict
11. Hash รหัสผู้ดูแลและสร้าง session signing secret แบบสุ่ม
12. Deploy Worker พร้อม Secrets โดยไม่พิมพ์ค่า Secret ลง log
13. ลบไฟล์ config/secret ชั่วคราวจาก runner

การกด `first_install` ซ้ำจะเปลี่ยน admin hash และ session signing secret ทำให้ session เดิมถูก logout ควรใช้เฉพาะติดตั้งครั้งแรกหรือเมื่อต้องการหมุน Core Secrets

## 7. ดูผล Deploy

กด workflow run ล่าสุด:

- เครื่องหมายเขียว = สำเร็จ
- เครื่องหมายแดง = กด step ที่ล้มเหลวเพื่อดูข้อความ

เมื่อสำเร็จ เปิดส่วน **Summary** จะมีลิงก์ไปหน้า Worker บน Cloudflare และใน step Deploy จะมี `workers.dev` URL

ตรวจ:

```text
https://<worker-subdomain>.workers.dev/api/health
```

จากนั้นเปิด URL หลักและ Login ด้วยค่าที่ตั้งใน `GOLDSCOPE_ADMIN_PASSWORD`

## 8. ลบ Broker Secrets จาก GitHub หลังติดตั้ง

เมื่อ first_install สำเร็จแล้ว Cloudflare จะเก็บ Secrets ไว้เอง สามารถลบ GitHub Secrets เหล่านี้เพื่อลดพื้นที่เสี่ยงได้:

```text
GOLDSCOPE_ADMIN_PASSWORD
CAPITAL_API_KEY
CAPITAL_IDENTIFIER
CAPITAL_API_PASSWORD
TWELVE_DATA_API_KEY
NEWS_API_KEY
ECONOMIC_CALENDAR_API_KEY
TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID
NOTIFICATION_WEBHOOK_URL
NOTIFICATION_SECRET
```

ควรเก็บไว้เฉพาะ:

```text
CLOUDFLARE_ACCOUNT_ID
CLOUDFLARE_API_TOKEN
```

สำหรับ Safe Update ในอนาคต หากต้องการหมุน Broker Secret ให้ตั้งผ่าน Cloudflare Dashboard หรือเพิ่มกลับใน GitHub แล้วใช้ first_install ด้วยความเข้าใจว่าจะ logout session เดิม

## 9. อัปเดตเวอร์ชันถัดไป

1. ลบ Payload ZIP รุ่นเก่าใน repository
2. อัปโหลด Payload ZIP รุ่นใหม่ชื่อรูปแบบ `GoldScope-AutoTrade-v*-Mobile-Payload.zip`
3. เปิด Actions → workflow เดิม
4. Run workflow ด้วย:

```text
deployment_mode: safe_update
confirmation: UPDATE_DEMO
worker_name: ใช้ชื่อเดิม
database_location: ใช้ตำแหน่งเดิม
run_e2e: เปิด
```

Safe Update จะ:

- ใช้ D1/Queues เดิม
- Apply migration ที่ยังไม่เคยรัน
- Build/Test ใหม่
- Deploy source ใหม่
- ไม่สร้างหรือเปลี่ยน Cloudflare Secrets

## 10. ติดตั้งเป็น PWA บนโทรศัพท์

### Android

1. เปิด workers.dev URL ใน Chrome
2. Login และตรวจหน้า Home
3. เมนูสามจุด → **ติดตั้งแอป** หรือ **เพิ่มลงในหน้าจอหลัก**
4. เปิดจากไอคอน GoldScope

### iPhone

1. เปิด workers.dev URL ใน Safari
2. กด Share
3. เลือก **เพิ่มไปยังหน้าจอโฮม**
4. เปิด **Open as Web App** ถ้ามี
5. กดเพิ่ม

## 11. เริ่มใช้งานอย่างปลอดภัย

เริ่มตามลำดับ:

```text
Paper → Forward Test → Confirm Demo → Demo Auto
```

อย่าเปิด Live Auto จน Readiness Gate ผ่านจากข้อมูล Demo จริง, Broker calibration, reconciliation, Forward Test และ out-of-sample metrics

## 12. แก้ปัญหาที่พบบ่อย

### Actions ไม่มีปุ่ม Run workflow

- Workflow ต้องอยู่ใน `.github/workflows/`
- ต้อง commit ลง default branch โดยทั่วไปคือ `main`
- เปิด Actions สำหรับ repository ก่อน

### ขึ้น Missing GitHub Secret

กลับไป Settings → Secrets and variables → Actions และตรวจชื่อให้ตรงทุกตัว ชื่อ Secret แยกตัวพิมพ์เล็ก/ใหญ่

### Cloudflare 403 หรือ permission denied

สร้าง Token ใหม่โดยมี Workers Scripts Edit, D1 Edit และ Queues Edit และจำกัด Account ให้ถูกบัญชี

### D1 หรือ Queue มีอยู่แล้ว

Workflow เป็น idempotent และจะ reuse ทรัพยากรชื่อเดิม ไม่ต้องลบ

### first_install ผ่านแต่ Login ไม่ได้

ตรวจว่าจำค่า `GOLDSCOPE_ADMIN_PASSWORD` ถูกต้อง หากต้องตั้งใหม่ ให้เพิ่ม Secret ใหม่แล้วรัน first_install อีกครั้ง ซึ่งจะ logout session เดิม

### safe_update ล้มเหลวเพราะ Worker ยังไม่มี Secret

ใช้ `first_install` ก่อนอย่างน้อยหนึ่งครั้ง

### Payload ZIP ไม่พบ

ชื่อไฟล์ต้องตรงรูปแบบ:

```text
GoldScope-AutoTrade-v*-Mobile-Payload.zip
```

และอยู่ภายใน repository ไม่ลึกเกิน 3 โฟลเดอร์
