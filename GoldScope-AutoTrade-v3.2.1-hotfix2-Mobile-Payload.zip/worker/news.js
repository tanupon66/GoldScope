import { deduplicateNews, evaluateHighImpactBlackout, newsRiskScore } from '../src/core/news.js';

async function fetchJson(url, headers = {}, timeoutMs = 8000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort('timeout'), timeoutMs);
  try {
    const response = await fetch(url, { headers, signal: controller.signal, cf: { cacheEverything: false } });
    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload) throw new Error(`PROVIDER_HTTP_${response.status}`);
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

function normalizeArticle(item = {}, provider = 'custom') {
  const title = String(item.title || item.headline || '').trim();
  if (!title) return null;
  return {
    id: String(item.id || item.uuid || crypto.randomUUID()), provider, title,
    summary: String(item.summary || item.description || '').slice(0, 1200),
    source: String(item.source?.name || item.source || provider),
    publishedAt: item.publishedAt || item.published_at || item.datetime || null,
    receivedAt: new Date().toISOString(),
    symbols: Array.isArray(item.symbols) ? item.symbols : ['XAU/USD'],
    topics: Array.isArray(item.topics) ? item.topics : [],
    language: item.language || 'en',
    relevanceScore: Number(item.relevanceScore ?? item.relevance ?? 0.5),
    sentimentScore: Number(item.sentimentScore ?? item.sentiment ?? 0),
    sentimentConfidence: Number(item.sentimentConfidence ?? item.confidence ?? 0.3),
    impactLevel: String(item.impactLevel || item.impact || 'LOW').toUpperCase(),
    duplicateGroup: String(item.duplicateGroup || item.urlHash || title.toLowerCase().replace(/\W+/g, '-').slice(0, 120)),
    urlHash: item.urlHash || null
  };
}

function normalizeEvent(item = {}, provider = 'custom') {
  const eventName = String(item.eventName || item.name || item.event || '').trim();
  const scheduledAt = item.scheduledAt || item.date || item.datetime || null;
  if (!eventName || !scheduledAt) return null;
  return {
    id: String(item.id || crypto.randomUUID()), provider,
    country: item.country || null, currency: String(item.currency || 'USD').toUpperCase(), eventName,
    scheduledAt, impactLevel: String(item.impactLevel || item.impact || 'LOW').toUpperCase(),
    forecast: item.forecast ?? null, previous: item.previous ?? null, actual: item.actual ?? null,
    revision: item.revision ?? null, status: item.status || 'SCHEDULED'
  };
}

export async function loadNewsContext(env, config = {}, now = Date.now()) {
  const articles = [];
  const events = [];
  const errors = [];
  if (env.NEWS_API_BASE_URL && env.NEWS_API_KEY) {
    try {
      const url = new URL(env.NEWS_API_BASE_URL);
      url.searchParams.set('symbols', 'XAUUSD');
      const payload = await fetchJson(url, { authorization: `Bearer ${env.NEWS_API_KEY}` });
      for (const item of payload.articles || payload.data || []) {
        const normalized = normalizeArticle(item, payload.provider || 'custom-news');
        if (normalized) articles.push(normalized);
      }
    } catch (error) { errors.push({ provider: 'news', code: String(error?.message || error) }); }
  }
  if (env.ECONOMIC_CALENDAR_API_BASE_URL && env.ECONOMIC_CALENDAR_API_KEY) {
    try {
      const url = new URL(env.ECONOMIC_CALENDAR_API_BASE_URL);
      url.searchParams.set('currency', 'USD');
      const payload = await fetchJson(url, { authorization: `Bearer ${env.ECONOMIC_CALENDAR_API_KEY}` });
      for (const item of payload.events || payload.data || []) {
        const normalized = normalizeEvent(item, payload.provider || 'custom-calendar');
        if (normalized) events.push(normalized);
      }
    } catch (error) { errors.push({ provider: 'calendar', code: String(error?.message || error) }); }
  }
  const uniqueArticles = deduplicateNews(articles);
  return {
    mode: config.newsRiskMode || 'RISK_FILTER',
    configured: Boolean((env.NEWS_API_BASE_URL && env.NEWS_API_KEY) || (env.ECONOMIC_CALENDAR_API_BASE_URL && env.ECONOMIC_CALENDAR_API_KEY)),
    articles: uniqueArticles,
    events,
    sentiment: newsRiskScore(uniqueArticles, now),
    blackout: evaluateHighImpactBlackout(events, config, now),
    receivedAt: new Date(now).toISOString(),
    errors
  };
}
