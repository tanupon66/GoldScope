function safeText(value, limit = 3000) {
  return String(value ?? '').replace(/(password|token|secret|api[-_ ]?key)\s*[:=]\s*\S+/gi, '$1=[REDACTED]').slice(0, limit);
}

export function notificationEnvelope(eventType, payload = {}, accountKey = null, correlationId = null) {
  return {
    id: crypto.randomUUID(),
    eventType: String(eventType || 'SYSTEM_EVENT'),
    accountKey: accountKey || payload.accountKey || null,
    correlationId: correlationId || crypto.randomUUID(),
    createdAt: Date.now(),
    payload
  };
}

function notificationText(message = {}) {
  const p = message.payload || {};
  const details = Object.entries(p)
    .filter(([key, value]) => value !== null && value !== undefined && !/token|secret|password/i.test(key))
    .slice(0, 10)
    .map(([key, value]) => `${key}: ${typeof value === 'object' ? JSON.stringify(value) : value}`)
    .join('\n');
  return safeText(`GoldScope AutoTrade\n${message.eventType}\n${message.accountKey || ''}${details ? `\n${details}` : ''}`);
}

async function sendTelegram(env, message) {
  if (!env.TELEGRAM_BOT_TOKEN || !env.TELEGRAM_CHAT_ID) return { channel: 'telegram', skipped: true };
  const response = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ chat_id: env.TELEGRAM_CHAT_ID, text: notificationText(message), disable_web_page_preview: true })
  });
  if (!response.ok) throw Object.assign(new Error(`Telegram notification failed (${response.status})`), { code: 'TELEGRAM_FAILED' });
  return { channel: 'telegram', sent: true };
}

async function sendWebhook(env, message) {
  if (!env.NOTIFICATION_WEBHOOK_URL) return { channel: 'webhook', skipped: true };
  const body = JSON.stringify({ ...message, text: notificationText(message) });
  const headers = { 'content-type': 'application/json' };
  if (env.NOTIFICATION_SECRET) headers.authorization = `Bearer ${env.NOTIFICATION_SECRET}`;
  const response = await fetch(env.NOTIFICATION_WEBHOOK_URL, { method: 'POST', headers, body });
  if (!response.ok) throw Object.assign(new Error(`Webhook notification failed (${response.status})`), { code: 'WEBHOOK_FAILED' });
  return { channel: 'webhook', sent: true };
}

export async function deliverNotification(env, message) {
  const results = [];
  const errors = [];
  for (const sender of [sendTelegram, sendWebhook]) {
    try { results.push(await sender(env, message)); }
    catch (error) { errors.push({ code: error?.code || 'NOTIFICATION_FAILED', message: safeText(error?.message || error, 500) }); }
  }
  const sent = results.some(result => result.sent);
  if (!sent && errors.length) throw Object.assign(new Error(errors.map(item => item.message).join('; ')), { code: 'NOTIFICATION_DELIVERY_FAILED', details: errors });
  return { sent, results, errors };
}
