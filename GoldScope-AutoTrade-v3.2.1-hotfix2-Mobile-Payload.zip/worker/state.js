import {
  DEFAULT_AUTO_TRADE_CONFIG, normalizeAutoTradeConfig, defaultAutoTradeState,
  appendAutoTradeLog, emptyDailyState
} from '../src/core/autotrade.js';
import { evaluateBrokerCalibration } from '../src/core/calibration.js';
import { transitionOrderIntent } from '../src/core/idempotency.js';
import { runAutoTradeCycle, loadBrokerMarketData, executeQueuedOrder } from './engine.js';
import {
  persistOrderIntent, saveConfigVersion, upsertAccount, persistStrategySignal,
  persistForwardSignal, closeForwardSignal, persistJournalTrade, persistReconciliationEvent
} from './db.js';

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }
  });
}

async function readBody(request) {
  return request.json().catch(() => ({}));
}

function internalQueueMessage(eventType, stateObjectKey, accountKey, payload = {}, correlationId = null) {
  const now = Date.now();
  return {
    messageId: crypto.randomUUID(), eventType, stateObjectKey, accountKey: accountKey || stateObjectKey,
    createdAt: now, attempt: 0, correlationId: correlationId || crypto.randomUUID(),
    idempotencyKey: `${eventType}:${stateObjectKey}:${payload.idempotencyKey || Math.floor(now / 60000)}`,
    payloadVersion: 1, payload
  };
}

function publicState(stateInput = {}) {
  const state = { ...stateInput };
  delete state.brokerSession;
  delete state.executionLock;
  if (state.liveUnlock) {
    state.liveUnlock = {
      active: state.liveUnlock.active === true,
      accountKey: state.liveUnlock.accountKey || null,
      expiresAt: Number(state.liveUnlock.expiresAt || 0),
      createdAt: Number(state.liveUnlock.createdAt || 0)
    };
  }
  state.pendingExecutions = Object.fromEntries(Object.entries(state.pendingExecutions || {}).slice(-20).map(([key, item]) => [key, {
    idempotencyKey: item.idempotencyKey,
    signalId: item.signal?.id || null,
    epic: item.epic || null,
    direction: item.plan?.directionLabel || null,
    orderSize: item.orderSize || null,
    createdAt: item.createdAt || null
  }]));
  state.orderIntents = Object.fromEntries(Object.entries(state.orderIntents || {}).slice(-50).map(([key, intent]) => [key, {
    id: intent.id,
    idempotencyKey: intent.idempotencyKey,
    signalId: intent.signalId,
    state: intent.state,
    dealReference: intent.dealReference || null,
    dealId: intent.dealId || null,
    createdAt: intent.createdAt,
    updatedAt: intent.updatedAt,
    lastError: intent.lastError || null
  }]));
  return state;
}

export class AutoTradeState {
  constructor(ctx, env) {
    this.ctx = ctx;
    this.env = env;
  }

  async getConfig() {
    const [stored, learningRecords] = await Promise.all([
      this.ctx.storage.get('config'),
      this.ctx.storage.get('learningRecords')
    ]);
    return normalizeAutoTradeConfig({ ...(stored || DEFAULT_AUTO_TRADE_CONFIG), learningRecords: learningRecords ?? stored?.learningRecords ?? [] });
  }

  async getState() {
    const [stored, cloudJournal, logs] = await Promise.all([
      this.ctx.storage.get('state'),
      this.ctx.storage.get('cloudJournal'),
      this.ctx.storage.get('logs')
    ]);
    const core = stored || {};
    return {
      ...defaultAutoTradeState(),
      ...core,
      cloudJournal: cloudJournal ?? core.cloudJournal ?? [],
      logs: logs ?? core.logs ?? []
    };
  }

  async save(config, state) {
    const normalized = normalizeAutoTradeConfig(config);
    // Authentication and live unlock are server-side state, never persisted as a reusable phrase.
    normalized.liveTradingUnlocked = false;
    normalized.liveUnlockPhrase = '';
    const { learningRecords, ...configCore } = normalized;
    const { cloudJournal = [], logs = [], ...stateCore } = state || defaultAutoTradeState();
    await this.ctx.storage.put({
      config: configCore,
      learningRecords,
      state: stateCore,
      cloudJournal,
      logs
    });
  }

  async status() {
    const [config, state] = await Promise.all([this.getConfig(), this.getState()]);
    return { ok: true, config, state: publicState(state) };
  }

  async acquireExecutionLock(requestId, ttlMs = 90_000) {
    const now = Date.now();
    const operation = async storage => {
      const current = await storage.get('executionLock');
      if (current && Number(current.expiresAt || 0) > now) return { acquired: false, lock: current };
      const lock = { id: crypto.randomUUID(), requestId: requestId || null, acquiredAt: now, expiresAt: now + ttlMs };
      await storage.put('executionLock', lock);
      return { acquired: true, lock };
    };
    return this.ctx.storage.transaction ? this.ctx.storage.transaction(operation) : operation(this.ctx.storage);
  }

  async releaseExecutionLock(lock) {
    const current = await this.ctx.storage.get('executionLock');
    if (!current || current.id === lock?.id) await this.ctx.storage.delete('executionLock');
  }

  authStub() {
    if (!this.env.AUTH_STATE) return null;
    const id = this.env.AUTH_STATE.idFromName('admin');
    return this.env.AUTH_STATE.get(id);
  }

  async isSessionRevoked(sessionId) {
    if (!sessionId) return true;
    const stub = this.authStub();
    if (!stub) return false;
    const response = await stub.fetch(`https://auth.internal/is-revoked?sid=${encodeURIComponent(sessionId)}`);
    const payload = await response.json().catch(() => ({}));
    return payload.revoked === true;
  }

  async run(trigger = 'manual', confirmedPlanId = null, requestId = null, stateObjectKey = 'capital:demo:setup') {
    const acquired = await this.acquireExecutionLock(requestId);
    if (!acquired.acquired) {
      const [config, state] = await Promise.all([this.getConfig(), this.getState()]);
      return {
        config,
        state: publicState({ ...state, status: 'LOCKED', lastDecision: 'มีวงจร Auto Trade อื่นกำลังทำงาน จึงไม่เริ่มซ้ำ' }),
        replayed: true
      };
    }
    try {
      const [config, state] = await Promise.all([this.getConfig(), this.getState()]);
      const services = this.services(requestId, stateObjectKey);

      const result = await runAutoTradeCycle({ env: this.env, config, state, trigger, confirmedPlanId, services });
      await this.save(result.config, result.state);
      if (result.state?.brokerAccount?.accountId) {
        await upsertAccount(this.env, {
          accountKey: result.state.activeAccountKey,
          broker: 'capital',
          environment: result.config.brokerEnvironment,
          accountId: result.state.brokerAccount.accountId,
          symbol: result.state.resolvedEpic || 'GOLD',
          active: result.config.enabled,
          stateObjectKey
        });
      }
      return { ...result, state: publicState(result.state) };
    } finally {
      await this.releaseExecutionLock(acquired.lock);
    }
  }

  services(requestId, stateObjectKey) {
    return {
      requestId,
      checkpoint: async (nextConfig, nextState) => this.save(nextConfig, nextState),
      persistIntent: intent => persistOrderIntent(this.env, intent),
      persistSignal: signal => persistStrategySignal(this.env, signal),
      persistForward: row => persistForwardSignal(this.env, row),
      closeForward: row => closeForwardSignal(this.env, row),
      persistJournal: trade => persistJournalTrade(this.env, trade),
      persistReconciliation: event => persistReconciliationEvent(this.env, event),
      isSessionRevoked: sessionId => this.isSessionRevoked(sessionId),
      enqueueOrder: async payload => {
        const message = internalQueueMessage('EXECUTE_ORDER', stateObjectKey, payload.accountKey, payload, requestId);
        if (this.env.ORDER_EXECUTION_QUEUE) await this.env.ORDER_EXECUTION_QUEUE.send(message);
        else throw Object.assign(new Error('ORDER_EXECUTION_QUEUE_NOT_CONFIGURED'), { code: 'ORDER_QUEUE_MISSING' });
      },
      notify: async (eventType, payload = {}) => {
        if (!this.env.NOTIFICATION_DELIVERY_QUEUE) return false;
        await this.env.NOTIFICATION_DELIVERY_QUEUE.send(internalQueueMessage('DELIVER_NOTIFICATION', stateObjectKey, payload.accountKey, { eventType, ...payload }, requestId));
        return true;
      }
    };
  }

  async executeOrder(idempotencyKey, requestId, stateObjectKey) {
    const acquired = await this.acquireExecutionLock(requestId, 120_000);
    if (!acquired.acquired) return { config: await this.getConfig(), state: publicState({ ...(await this.getState()), status: 'LOCKED' }), replayed: true };
    try {
      const [config, state] = await Promise.all([this.getConfig(), this.getState()]);
      const result = await executeQueuedOrder({ env: this.env, config, state, idempotencyKey, services: this.services(requestId, stateObjectKey) });
      await this.save(result.config, result.state);
      return { ...result, state: publicState(result.state) };
    } finally {
      await this.releaseExecutionLock(acquired.lock);
    }
  }

  async marketData(outputsize = 900) {
    const config = await this.getConfig();
    return loadBrokerMarketData({ env: this.env, config, outputsize });
  }

  async fetch(request) {
    const url = new URL(request.url);
    const requestId = request.headers.get('x-request-id') || crypto.randomUUID();
    const stateObjectKey = request.headers.get('x-state-object-key') || 'capital:demo:setup';
    if (request.method === 'GET' && url.pathname === '/status') return json(await this.status());

    if (request.method === 'GET' && url.pathname === '/market-data') {
      try {
        const outputsize = Math.min(1000, Math.max(100, Number(url.searchParams.get('outputsize') || 900)));
        return json(await this.marketData(outputsize));
      } catch (error) {
        return json({ ok: false, code: error?.code || 'BROKER_MARKET_FAILED', message: String(error?.message || error), requestId }, 502);
      }
    }

    if (request.method === 'PUT' && url.pathname === '/config') {
      const body = await readBody(request);
      const current = await this.getConfig();
      const next = normalizeAutoTradeConfig({ ...current, ...(body.config || body), liveTradingUnlocked: false, liveUnlockPhrase: '', updatedAt: Date.now() });
      let state = await this.getState();
      const environmentChanged = current.brokerEnvironment !== next.brokerEnvironment || (current.accountId && current.accountId !== next.accountId);
      const riskChanged = [
        'executionMode','timeframe','minScore','orderSize','pnlReferenceSize','pnlPerUsdMoveAtReferenceSize','takeProfitTarget',
        'maxLossPerTradeUsd','riskPercentPerTrade','maxSpreadUsd','entryToleranceUsd','minimumDataQualityScore','newsRiskMode'
      ].some(key => JSON.stringify(current[key]) !== JSON.stringify(next[key]))
        || JSON.stringify(current.algorithmSettings || {}) !== JSON.stringify(next.algorithmSettings || {});
      const leftPaperMode = current.executionMode === 'paper' && next.executionMode !== 'paper';
      if (environmentChanged) {
        state = {
          ...state,
          status: 'IDLE', brokerAccount: null, activeAccountKey: null, resolvedEpic: null, market: null,
          pendingSignal: null, lastSignal: null, paperPosition: null, lastBrokerOrder: null,
          liveUnlock: null, brokerSession: null, daily: emptyDailyState(),
          lastDecision: `สลับไปบัญชี ${next.brokerEnvironment.toUpperCase()} และแยก state ออกจากบัญชีเดิมแล้ว`
        };
        state = appendAutoTradeLog(state, 'warn', `สลับ Broker environment/account; ยกเลิก session และ Live unlock เดิม`);
      } else if (riskChanged) {
        state = { ...state, pendingSignal: null, lastSignal: null, liveUnlock: null, configFrozen: false, paperPosition: leftPaperMode ? null : state.paperPosition, lastDecision: 'ล้างสัญญาณและ Live unlock หลังเปลี่ยนค่าความเสี่ยง/Algorithm' };
        state = appendAutoTradeLog(state, 'info', 'ล้างสัญญาณรอและ Live unlock เพื่อให้สร้างใหม่ด้วย config ล่าสุด');
      } else if (leftPaperMode && state.paperPosition) {
        state = { ...state, paperPosition: null, pendingSignal: null, lastDecision: 'ยกเลิก Paper position เมื่อเปลี่ยนเป็นโหมดส่ง Broker' };
        state = appendAutoTradeLog(state, 'warn', 'ล้าง Paper position เดิมเมื่อเปลี่ยนโหมดส่งคำสั่ง');
      }
      state = appendAutoTradeLog(state, 'info', `อัปเดตการตั้งค่า: ${next.executionMode}/${next.brokerEnvironment}`);
      await this.save(next, state);
      const accountKey = state.activeAccountKey || `capital:${next.brokerEnvironment}:${next.accountId || 'setup'}`;
      // Ensure the D1 parent row exists before inserting a versioned configuration.
      await upsertAccount(this.env, {
        accountKey,
        broker: 'capital',
        environment: next.brokerEnvironment,
        accountId: state.brokerAccount?.accountId || next.accountId || 'setup',
        symbol: state.resolvedEpic || next.instrumentEpic || 'GOLD',
        active: Boolean(next.enabled && (state.brokerAccount?.accountId || next.accountId)),
        stateObjectKey
      });
      const configVersion = await saveConfigVersion(this.env, { accountKey, config: next, actor: request.headers.get('x-session-id') || 'admin' });
      if (configVersion) {
        state.configVersion = configVersion;
        await this.save(next, state);
      }
      return json({ ok: true, config: next, state: publicState(state), requestId });
    }

    if (request.method === 'POST' && url.pathname === '/import-legacy') {
      const body = await readBody(request);
      const legacy = body.legacy || {};
      if (!legacy.config || !legacy.state) return json({ ok: false, code: 'LEGACY_PAYLOAD_INVALID', message: 'ข้อมูลสำรอง v2 ไม่ครบ', requestId }, 400);
      const config = normalizeAutoTradeConfig({
        ...DEFAULT_AUTO_TRADE_CONFIG,
        ...legacy.config,
        enabled: false,
        liveTradingUnlocked: false,
        liveUnlockPhrase: '',
        updatedAt: Date.now()
      });
      const legacyLedgers = Object.fromEntries(Object.entries(legacy.state.accountLedgers || {}).map(([key, value]) => [
        /^capital:/.test(key) ? key : `capital:${key}`,
        value
      ]));
      const legacyActiveKey = legacy.state.activeAccountKey
        ? (/^capital:/.test(legacy.state.activeAccountKey) ? legacy.state.activeAccountKey : `capital:${legacy.state.activeAccountKey}`)
        : null;
      const importedState = {
        ...defaultAutoTradeState(),
        ...legacy.state,
        accountLedgers: legacyLedgers,
        activeAccountKey: legacyActiveKey,
        status: 'PAUSED',
        pendingSignal: null,
        liveUnlock: null,
        brokerSession: null,
        executionLock: null,
        systemVersion: '3.2.1',
        migration: {
          from: '2.0.3',
          sourceKey: body.sourceKey || 'primary',
          importedAt: Date.now(),
          note: 'ระบบปิด Auto หลัง migration เพื่อให้ตรวจ config และ Broker calibration ใหม่'
        },
        lastDecision: 'นำเข้าข้อมูล v2 แล้ว ระบบยังปิดอยู่จนกว่าจะตรวจสอบและเปิดใหม่'
      };
      importedState.logs = Array.isArray(legacy.state.logs) ? legacy.state.logs : [];
      importedState.cloudJournal = Array.isArray(legacy.state.cloudJournal) ? legacy.state.cloudJournal : [];
      await this.save(config, importedState);
      return json({ ok: true, config, state: publicState(importedState), migration: importedState.migration, requestId });
    }

    if (request.method === 'POST' && url.pathname === '/live-unlock') {
      const body = await readBody(request);
      const config = await this.getConfig();
      let state = await this.getState();
      if (config.brokerEnvironment !== 'live' || !['confirm', 'auto'].includes(config.executionMode)) {
        return json({ ok: false, code: 'LIVE_MODE_NOT_SELECTED', message: 'เลือกบัญชี Live และ Confirm/Auto ก่อน', requestId }, 409);
      }
      if (String(body.phrase || '') !== 'LIVE') return json({ ok: false, code: 'LIVE_CONFIRMATION_INVALID', message: 'ต้องพิมพ์ LIVE ตรงตัว', requestId }, 400);
      if (state.liveReadiness?.passed !== true) return json({ ok: false, code: 'LIVE_READINESS_FAILED', message: 'Live Readiness Gate ยังไม่ผ่าน', readiness: state.liveReadiness, requestId }, 409);
      const sessionId = request.headers.get('x-session-id');
      const sessionExp = Number(request.headers.get('x-session-exp') || 0) * 1000;
      if (!sessionId || sessionExp <= Date.now()) return json({ ok: false, code: 'SESSION_REQUIRED', message: 'Session ไม่พร้อมสำหรับปลดล็อก Live', requestId }, 401);
      const requestedMinutes = Math.max(1, Math.min(60, Number(body.expiresMinutes || 15)));
      state.liveUnlock = {
        active: true,
        sessionId,
        accountKey: state.activeAccountKey,
        createdAt: Date.now(),
        expiresAt: Math.min(sessionExp, Date.now() + requestedMinutes * 60_000),
        deploymentVersion: this.env.APP_VERSION || '3.2.1'
      };
      state = appendAutoTradeLog(state, 'warn', `ปลดล็อก Live ชั่วคราวถึง ${new Date(state.liveUnlock.expiresAt).toISOString()}`);
      await this.save(config, state);
      return json({ ok: true, config, state: publicState(state), requestId });
    }

    if (request.method === 'POST' && url.pathname === '/calibration') {
      const body = await readBody(request);
      const config = await this.getConfig();
      let state = await this.getState();
      const report = evaluateBrokerCalibration({
        size: body.size || config.orderSize,
        referenceSize: config.pnlReferenceSize,
        pnlPerUsdMoveAtReferenceSize: config.pnlPerUsdMoveAtReferenceSize,
        observedPnlPerUsdMove: body.observedPnlPerUsdMove,
        minimumSize: body.minimumSize ?? state.market?.minDealSize,
        sizeStep: body.sizeStep ?? state.market?.sizeStep ?? state.market?.minDealSize,
        currency: body.currency ?? state.brokerAccount?.currency,
        tickSize: body.tickSize ?? state.market?.tickSize,
        tolerancePercent: body.tolerancePercent || 20
      });
      state.calibration = { ...report, checkedAt: Date.now() };
      await this.save(config, state);
      return json({ ok: report.passed, calibration: report, config, state: publicState(state), requestId }, report.passed ? 200 : 409);
    }

    if (request.method === 'POST' && url.pathname === '/run') {
      const body = await readBody(request);
      const result = await this.run(body.trigger || 'manual', body.confirmedPlanId || null, requestId, stateObjectKey);
      return json({ ok: true, ...result, requestId });
    }

    if (request.method === 'POST' && url.pathname === '/confirm') {
      const body = await readBody(request);
      const result = await this.run('confirm', body.signalId || body.confirmedPlanId || null, requestId, stateObjectKey);
      return json({ ok: true, ...result, requestId });
    }

    if (request.method === 'POST' && url.pathname === '/execute-order') {
      const body = await readBody(request);
      if (!body.idempotencyKey) return json({ ok: false, code: 'IDEMPOTENCY_KEY_REQUIRED', message: 'ไม่พบ idempotencyKey', requestId }, 400);
      const result = await this.executeOrder(body.idempotencyKey, requestId, stateObjectKey);
      return json({ ok: true, ...result, requestId });
    }

    if (request.method === 'GET' && url.pathname === '/forward-test/status') {
      const state = await this.getState();
      return json({ ok: true, forwardTest: state.forwardTest || {}, positions: Object.values(state.forwardPositions || {}).slice(-100), requestId });
    }

    if (request.method === 'POST' && url.pathname === '/pause') {
      const body = await readBody(request);
      const config = normalizeAutoTradeConfig({ ...(await this.getConfig()), enabled: false, pauseReason: body.reason || 'ผู้ใช้หยุดระบบ', updatedAt: Date.now() });
      let state = await this.getState();
      state = appendAutoTradeLog(state, 'warn', `หยุด Auto Trade: ${config.pauseReason}`);
      state = { ...state, status: 'PAUSED', lastDecision: config.pauseReason, liveUnlock: null };
      await this.save(config, state);
      return json({ ok: true, config, state: publicState(state), requestId });
    }

    if (request.method === 'POST' && url.pathname === '/kill') {
      const config = normalizeAutoTradeConfig({
        ...(await this.getConfig()), enabled: false, executionMode: 'paper', brokerEnvironment: 'demo',
        liveTradingUnlocked: false, liveUnlockPhrase: '', pauseReason: 'Kill switch ถูกกด', updatedAt: Date.now()
      });
      let state = await this.getState();
      const now = Date.now();
      const intents = { ...(state.orderIntents || {}) };
      const cancelledKeys = [];
      for (const [key, current] of Object.entries(intents)) {
        if (!['CREATED', 'RISK_APPROVED', 'QUEUED'].includes(current?.state)) continue;
        const cancelled = transitionOrderIntent(current, 'FAILED', {
          reason: 'KILL_SWITCH_BEFORE_SUBMIT',
          lastError: { code: 'KILL_SWITCH_BEFORE_SUBMIT', message: 'Kill Switch ยกเลิกออเดอร์ก่อนส่ง Broker' }
        }, now);
        intents[key] = cancelled;
        cancelledKeys.push(key);
        await persistOrderIntent(this.env, cancelled);
      }
      state = appendAutoTradeLog(state, 'error', 'KILL SWITCH: หยุดส่งคำสั่งใหม่ ล้างสัญญาณ และล็อกบัญชีจริง', { cancelledQueuedIntents: cancelledKeys.length });
      state = {
        ...state, status: 'KILLED', pendingSignal: null, pendingExecutions: {}, orderIntents: intents,
        paperPosition: null, liveUnlock: null, brokerSession: null,
        lastDecision: `หยุดฉุกเฉินแล้ว ยกเลิกออเดอร์ที่ยังไม่ส่ง ${cancelledKeys.length} รายการ (ไม่ปิดสถานะที่ Broker อัตโนมัติ)`,
        safetyTests: { ...(state.safetyTests || {}), killSwitch: true, killSwitchTestedAt: now }
      };
      await this.save(config, state);
      return json({ ok: true, config, state: publicState(state), requestId });
    }

    if (request.method === 'POST' && url.pathname === '/reset') {
      const body = await readBody(request);
      const previous = await this.getState();
      const config = body.keepConfig ? await this.getConfig() : normalizeAutoTradeConfig(DEFAULT_AUTO_TRADE_CONFIG);
      let state = defaultAutoTradeState();
      if (body.keepJournal !== false) {
        state.cloudJournal = previous.cloudJournal || [];
        state.accountLedgers = previous.accountLedgers || {};
      }
      state = appendAutoTradeLog(state, 'info', 'รีเซ็ตสถานะ Auto Trade แล้ว');
      await this.save(config, state);
      return json({ ok: true, config, state: publicState(state), requestId });
    }

    return json({ ok: false, code: 'NOT_FOUND', message: 'Internal Auto Trade route not found', requestId }, 404);
  }
}
