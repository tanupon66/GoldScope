function safeJson(value) {
  try { return JSON.stringify(value ?? null); } catch { return JSON.stringify({ serializationError: true }); }
}

function safeParse(value, fallback = null) {
  if (value === null || value === undefined || value === '') return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}

export function dbConfigured(env) {
  return Boolean(env?.DB?.prepare);
}

export async function auditLog(env, entry = {}) {
  if (!dbConfigured(env)) return false;
  await env.DB.prepare(`INSERT INTO audit_logs (id, actor, action, account_key, request_id, ip_hash, payload_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).bind(
    entry.id || crypto.randomUUID(), entry.actor || 'admin', entry.action || 'UNKNOWN', entry.accountKey || null,
    entry.requestId || null, entry.ipHash || null, safeJson(entry.payload || null), Number(entry.createdAt || Date.now())
  ).run();
  return true;
}

export async function systemEvent(env, entry = {}) {
  if (!dbConfigured(env)) return false;
  await env.DB.prepare(`INSERT INTO system_events
    (id, level, event, request_id, correlation_id, account_key, duration_ms, payload_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
    entry.id || crypto.randomUUID(), entry.level || 'INFO', entry.event || 'UNKNOWN', entry.requestId || null,
    entry.correlationId || null, entry.accountKey || null, Number.isFinite(Number(entry.durationMs)) ? Number(entry.durationMs) : null,
    safeJson(entry.payload || null), Number(entry.createdAt || Date.now())
  ).run();
  return true;
}

export async function upsertAccount(env, account = {}) {
  if (!dbConfigured(env) || !account.accountKey || !account.accountId) return false;
  const now = Date.now();
  await env.DB.prepare(`INSERT INTO accounts
    (account_key, broker, environment, account_id, symbol, active, created_at, updated_at, state_object_key, last_seen_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(account_key) DO UPDATE SET environment=excluded.environment, account_id=excluded.account_id,
      symbol=excluded.symbol, active=excluded.active, updated_at=excluded.updated_at,
      state_object_key=COALESCE(excluded.state_object_key, accounts.state_object_key), last_seen_at=excluded.last_seen_at`).bind(
    account.accountKey, account.broker || 'capital', account.environment || 'demo', account.accountId,
    account.symbol || 'GOLD', account.active === false ? 0 : 1, now, now, account.stateObjectKey || null, now
  ).run();
  return true;
}

export async function listActiveAccounts(env) {
  if (!dbConfigured(env)) return [];
  const result = await env.DB.prepare(`SELECT account_key, broker, environment, account_id, symbol,
    COALESCE(state_object_key, account_key) AS state_object_key, last_seen_at, last_scan_at, last_success_at, last_error_code
    FROM accounts WHERE active = 1 ORDER BY updated_at DESC`).all();
  return result.results || [];
}

export async function listAutomationTargets(env) {
  const accounts = await listActiveAccounts(env);
  const seen = new Set();
  return accounts.filter(row => {
    const key = row.state_object_key || row.account_key;
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).map(row => ({ ...row, stateObjectKey: row.state_object_key || row.account_key }));
}

export async function markAccountScan(env, { accountKey, ok, errorCode = null, scannedAt = Date.now() } = {}) {
  if (!dbConfigured(env) || !accountKey) return false;
  await env.DB.prepare(`UPDATE accounts SET last_scan_at = ?, last_success_at = CASE WHEN ? = 1 THEN ? ELSE last_success_at END,
    last_error_code = ?, updated_at = ? WHERE account_key = ? OR state_object_key = ?`).bind(
    scannedAt, ok ? 1 : 0, scannedAt, ok ? null : errorCode, scannedAt, accountKey, accountKey
  ).run();
  return true;
}

export async function saveConfigVersion(env, { accountKey, config, actor = 'admin' } = {}) {
  if (!dbConfigured(env) || !accountKey) return null;
  const current = await env.DB.prepare('SELECT COALESCE(MAX(version), 0) AS version FROM config_versions WHERE account_key = ?').bind(accountKey).first();
  const version = Number(current?.version || 0) + 1;
  await env.DB.batch([
    env.DB.prepare('UPDATE config_versions SET active = 0 WHERE account_key = ?').bind(accountKey),
    env.DB.prepare(`INSERT INTO config_versions (id, account_key, version, config_json, active, created_at, created_by)
      VALUES (?, ?, ?, ?, 1, ?, ?)`).bind(crypto.randomUUID(), accountKey, version, safeJson(config), Date.now(), actor)
  ]);
  return version;
}

export async function persistOrderIntent(env, intent) {
  if (!dbConfigured(env) || !intent?.idempotencyKey) return false;
  await env.DB.prepare(`INSERT INTO order_intents
    (id, idempotency_key, account_key, signal_id, state, broker_deal_reference, broker_deal_id, request_json, response_json, last_error_json, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(idempotency_key) DO UPDATE SET state=excluded.state, broker_deal_reference=excluded.broker_deal_reference,
      broker_deal_id=excluded.broker_deal_id, response_json=excluded.response_json, last_error_json=excluded.last_error_json,
      updated_at=excluded.updated_at`).bind(
    intent.id, intent.idempotencyKey, intent.accountKey, intent.signalId, intent.state,
    intent.dealReference || null, intent.dealId || null, safeJson(intent.request || null), safeJson(intent.response || null),
    safeJson(intent.lastError || null), intent.createdAt, intent.updatedAt
  ).run();
  return true;
}

export async function persistStrategySignal(env, signal = {}) {
  if (!dbConfigured(env) || !signal.id || !signal.accountKey) return false;
  await env.DB.prepare(`INSERT OR IGNORE INTO strategy_signals
    (id, account_key, symbol, timeframe, closed_candle_time, direction, decision, base_score, final_score, confidence,
      expected_r, strategy_version, model_version, config_version, explanation_json, news_context_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
    signal.id, signal.accountKey, signal.symbol || 'GOLD', signal.timeframe || '5min', Number(signal.closedCandleTime || 0),
    signal.direction || 'WAIT', signal.decision || 'WAIT', Number(signal.baseScore || 0), Number(signal.finalScore || signal.score || 0),
    Number(signal.confidence || 0), Number(signal.expectedR || 0), signal.strategyVersion || null, signal.modelVersion || null,
    Number.isFinite(Number(signal.configVersion)) ? Number(signal.configVersion) : null, safeJson(signal.explanation || null),
    safeJson(signal.newsContext || null), Number(signal.createdAt || Date.now())
  ).run();
  return true;
}

export async function persistMarketSnapshot(env, snapshot = {}) {
  if (!dbConfigured(env)) return false;
  await env.DB.prepare(`INSERT INTO market_snapshots
    (id, account_key, provider, symbol, bid, ask, spread, market_status, source_time, received_at, quality_score, payload_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
    snapshot.id || crypto.randomUUID(), snapshot.accountKey || null, snapshot.provider || 'capital', snapshot.symbol || 'GOLD',
    Number.isFinite(Number(snapshot.bid)) ? Number(snapshot.bid) : null, Number.isFinite(Number(snapshot.ask)) ? Number(snapshot.ask) : null,
    Number.isFinite(Number(snapshot.spread)) ? Number(snapshot.spread) : null, snapshot.marketStatus || null,
    Number.isFinite(Number(snapshot.sourceTime)) ? Number(snapshot.sourceTime) : null, Number(snapshot.receivedAt || Date.now()),
    Number.isFinite(Number(snapshot.qualityScore)) ? Number(snapshot.qualityScore) : null, safeJson(snapshot.payload || null)
  ).run();
  return true;
}

export async function persistMarketCandles(env, { provider = 'capital', environment = 'demo', symbol = 'GOLD', timeframe = '5min', candles = [], qualityScore = null } = {}) {
  if (!dbConfigured(env) || !Array.isArray(candles) || !candles.length) return 0;
  const rows = candles.slice(-1000).map(candle => env.DB.prepare(`INSERT OR IGNORE INTO market_candles
    (provider, environment, symbol, timeframe, candle_time, open, high, low, close, bid_close, ask_close, volume, received_at, quality_score)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
    provider, environment, symbol, timeframe, Number(candle.time || 0), Number(candle.open), Number(candle.high), Number(candle.low),
    Number(candle.close), Number.isFinite(Number(candle.bidClose)) ? Number(candle.bidClose) : null,
    Number.isFinite(Number(candle.askClose)) ? Number(candle.askClose) : null, Number(candle.volume || 0), Date.now(),
    Number.isFinite(Number(qualityScore)) ? Number(qualityScore) : null
  ));
  const results = await env.DB.batch(rows);
  return results.reduce((sum, row) => sum + Number(row?.meta?.changes || 0), 0);
}

export async function persistNewsContext(env, context = {}) {
  if (!dbConfigured(env)) return false;
  const articleStatements = (context.articles || []).slice(0, 100).map(item => env.DB.prepare(`INSERT OR REPLACE INTO news_articles
    (id, provider, title, summary, source, published_at, received_at, symbols_json, topics_json, language,
      relevance_score, sentiment_score, sentiment_confidence, impact_level, duplicate_group, url_hash)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
    item.id || crypto.randomUUID(), item.provider || 'unknown', item.title || '(ไม่มีชื่อ)', item.summary || null, item.source || null,
    new Date(item.publishedAt || Date.now()).getTime(), Number(item.receivedAt || Date.now()), safeJson(item.symbols || []),
    safeJson(item.topics || []), item.language || null, Number(item.relevanceScore || 0), Number(item.sentimentScore || 0),
    Number(item.sentimentConfidence || 0), item.impactLevel || null, item.duplicateGroup || null, item.urlHash || null
  ));
  const eventStatements = (context.events || []).slice(0, 100).map(item => env.DB.prepare(`INSERT OR REPLACE INTO economic_events
    (id, provider, country, currency, event_name, scheduled_at, impact_level, forecast, previous, actual, revision, status, received_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
    item.id || crypto.randomUUID(), item.provider || 'unknown', item.country || null, item.currency || null,
    item.eventName || '(ไม่มีชื่อ)', new Date(item.scheduledAt || Date.now()).getTime(), item.impactLevel || null,
    item.forecast ?? null, item.previous ?? null, item.actual ?? null, item.revision ?? null, item.status || null, Number(item.receivedAt || Date.now())
  ));
  const statements = [...articleStatements, ...eventStatements];
  if (statements.length) await env.DB.batch(statements);
  return true;
}

export async function persistForwardSignal(env, row = {}) {
  if (!dbConfigured(env) || !row.id || !row.accountKey || !row.signalId) return false;
  await env.DB.prepare(`INSERT INTO forward_test_signals
    (id, account_key, signal_id, symbol, timeframe, direction, intended_entry, simulated_fill, stop_loss, take_profit,
      spread, slippage_assumption, opened_at, status, strategy_version, model_version, config_version, news_context_json, payload_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(account_key, signal_id) DO NOTHING`).bind(
    row.id, row.accountKey, row.signalId, row.symbol || 'GOLD', row.timeframe || '5min', row.direction || 'BUY',
    Number(row.intendedEntry), Number(row.simulatedFill), Number(row.stopLoss), Number(row.takeProfit), Number(row.spread || 0),
    Number(row.slippageAssumption || 0), Number(row.openedAt || Date.now()), row.status || 'OPEN', row.strategyVersion || null,
    row.modelVersion || null, Number.isFinite(Number(row.configVersion)) ? Number(row.configVersion) : null,
    safeJson(row.newsContext || null), safeJson(row.payload || null)
  ).run();
  return true;
}

export async function closeForwardSignal(env, row = {}) {
  if (!dbConfigured(env) || !row.id) return false;
  await env.DB.prepare(`UPDATE forward_test_signals SET status = ?, closed_at = ?, exit_price = ?, pnl = ?, result_r = ?, outcome = ?, payload_json = ?
    WHERE id = ?`).bind(
    row.status || 'CLOSED', Number(row.closedAt || Date.now()), Number(row.exitPrice), Number(row.pnl || 0), Number(row.resultR || 0),
    row.outcome || null, safeJson(row.payload || null), row.id
  ).run();
  return true;
}

export async function forwardTestSummary(env, accountKey) {
  if (!dbConfigured(env) || !accountKey) return { signals: 0, closed: 0, open: 0, expectancyR: 0, pnl: 0, days: 0 };
  const row = await env.DB.prepare(`SELECT COUNT(*) AS signals,
    SUM(CASE WHEN status = 'OPEN' THEN 1 ELSE 0 END) AS open,
    SUM(CASE WHEN status <> 'OPEN' THEN 1 ELSE 0 END) AS closed,
    COALESCE(AVG(CASE WHEN status <> 'OPEN' THEN result_r END), 0) AS expectancy_r,
    COALESCE(SUM(CASE WHEN status <> 'OPEN' THEN pnl ELSE 0 END), 0) AS pnl,
    MIN(opened_at) AS started_at, MAX(COALESCE(closed_at, opened_at)) AS last_at
    FROM forward_test_signals WHERE account_key = ?`).bind(accountKey).first();
  const startedAt = Number(row?.started_at || 0);
  return {
    signals: Number(row?.signals || 0), open: Number(row?.open || 0), closed: Number(row?.closed || 0),
    expectancyR: Number(row?.expectancy_r || 0), pnl: Number(row?.pnl || 0), startedAt,
    days: startedAt ? Math.max(0, (Date.now() - startedAt) / 86_400_000) : 0,
    lastAt: Number(row?.last_at || 0)
  };
}

export async function persistJournalTrade(env, trade = {}) {
  if (!dbConfigured(env) || !trade.id || !trade.accountKey) return false;
  await env.DB.prepare(`INSERT OR REPLACE INTO trade_journal
    (id, account_key, signal_id, order_intent_id, strategy_id, strategy_version, model_version, timeframe, regime,
      opened_at, closed_at, pnl, result_r, costs, outcome, data_mode, payload_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
    trade.id, trade.accountKey, trade.signalId || null, trade.orderIntentId || null, trade.strategyId || trade.strategyKey || null,
    trade.strategyVersion || null, trade.modelVersion || null, trade.timeframe || null, trade.regime || null,
    Number(trade.openedAt || 0) || null, Number(trade.closedAt || trade.endedAt || 0) || null, Number(trade.pnlUsd ?? trade.pnl ?? 0),
    Number(trade.resultR || 0), Number(trade.costs || 0), trade.outcome || null, trade.dataMode || null, safeJson(trade)
  ).run();
  return true;
}

export async function persistReconciliationEvent(env, event = {}) {
  if (!dbConfigured(env) || !event.accountKey) return false;
  await env.DB.prepare(`INSERT INTO reconciliation_events
    (id, account_key, order_intent_id, broker_deal_id, broker_deal_reference, result, verified_pnl, currency, source, payload_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
    event.id || crypto.randomUUID(), event.accountKey, event.orderIntentId || null, event.dealId || null, event.dealReference || null,
    event.result || 'UNKNOWN', Number.isFinite(Number(event.verifiedPnl)) ? Number(event.verifiedPnl) : null,
    event.currency || null, event.source || null, safeJson(event.payload || null), Number(event.createdAt || Date.now())
  ).run();
  return true;
}

export async function claimQueueMessage(env, message, { leaseMs = 120_000 } = {}) {
  if (!dbConfigured(env)) return { claimed: true, replay: false };
  const now = Date.now();
  const attempt = Math.max(0, Number(message.attempt || 0));
  const inserted = await env.DB.prepare(`INSERT OR IGNORE INTO queue_receipts
    (message_id, event_type, account_key, idempotency_key, status, attempt, received_at, last_attempt_at, retry_count, correlation_id)
    VALUES (?, ?, ?, ?, 'PROCESSING', ?, ?, ?, ?, ?)`).bind(
    message.messageId, message.eventType, message.accountKey || null, message.idempotencyKey || null,
    attempt, now, now, attempt, message.correlationId || null
  ).run();
  if (Number(inserted.meta?.changes || 0) > 0) return { claimed: true, replay: false };

  const existing = await env.DB.prepare(`SELECT message_id, status, attempt, last_attempt_at FROM queue_receipts
    WHERE message_id = ? OR (event_type = ? AND idempotency_key = ?) ORDER BY received_at ASC LIMIT 1`).bind(
    message.messageId, message.eventType, message.idempotencyKey || null
  ).first();
  if (!existing) return { claimed: false, replay: false };
  if (existing.status === 'COMPLETED' || existing.status === 'DEAD_LETTERED') return { claimed: false, replay: true, status: existing.status };
  const stale = now - Number(existing.last_attempt_at || 0) > leaseMs;
  const newerAttempt = attempt > Number(existing.attempt || 0);
  if (!stale && !newerAttempt && existing.status === 'PROCESSING') return { claimed: false, replay: true, status: existing.status };
  const updated = await env.DB.prepare(`UPDATE queue_receipts SET status = 'PROCESSING', attempt = ?, retry_count = ?,
    last_attempt_at = ?, completed_at = NULL, error_json = NULL, correlation_id = ?
    WHERE message_id = ? AND status NOT IN ('COMPLETED', 'DEAD_LETTERED')`).bind(
    attempt, Math.max(attempt, Number(existing.attempt || 0)), now, message.correlationId || null, existing.message_id
  ).run();
  return { claimed: Number(updated.meta?.changes || 0) > 0, replay: true, status: existing.status };
}

export async function completeQueueMessage(env, messageId, status = 'COMPLETED', error = null) {
  if (!dbConfigured(env)) return false;
  await env.DB.prepare('UPDATE queue_receipts SET status = ?, completed_at = ?, error_json = ? WHERE message_id = ?').bind(
    status, Date.now(), safeJson(error), messageId
  ).run();
  return true;
}

export async function recordDeadLetter(env, message = {}, error = null) {
  if (!dbConfigured(env)) return null;
  const id = crypto.randomUUID();
  await env.DB.prepare(`INSERT INTO dead_letter_messages
    (id, original_message_id, event_type, account_key, state_object_key, idempotency_key, correlation_id, attempts,
      payload_json, error_json, status, received_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN', ?)`).bind(
    id, message.messageId || null, message.eventType || 'UNKNOWN', message.accountKey || null,
    message.stateObjectKey || message.accountKey || null, message.idempotencyKey || null, message.correlationId || null,
    Number(message.attempt || 0), safeJson(message), safeJson(error), Date.now()
  ).run();
  return id;
}

export async function listDeadLetters(env, { status = 'OPEN', limit = 50 } = {}) {
  if (!dbConfigured(env)) return [];
  const result = await env.DB.prepare(`SELECT * FROM dead_letter_messages WHERE status = ? ORDER BY received_at DESC LIMIT ?`).bind(
    status, Math.max(1, Math.min(200, Number(limit || 50)))
  ).all();
  return (result.results || []).map(row => ({
    ...row,
    payload: safeParse(row.payload_json, {}),
    error: safeParse(row.error_json, null)
  }));
}

export async function getDeadLetter(env, id) {
  if (!dbConfigured(env) || !id) return null;
  const row = await env.DB.prepare('SELECT * FROM dead_letter_messages WHERE id = ?').bind(id).first();
  return row ? { ...row, payload: safeParse(row.payload_json, {}), error: safeParse(row.error_json, null) } : null;
}

export async function markDeadLetter(env, id, status) {
  if (!dbConfigured(env) || !id || !['RETRIED', 'DISMISSED'].includes(status)) return false;
  const now = Date.now();
  await env.DB.prepare(`UPDATE dead_letter_messages SET status = ?, retried_at = CASE WHEN ? = 'RETRIED' THEN ? ELSE retried_at END,
    dismissed_at = CASE WHEN ? = 'DISMISSED' THEN ? ELSE dismissed_at END WHERE id = ?`).bind(status, status, now, status, now, id).run();
  return true;
}

export async function createNotificationEvent(env, event = {}) {
  if (!dbConfigured(env)) return { created: true, id: event.id || crypto.randomUUID() };
  const id = event.id || crypto.randomUUID();
  const result = await env.DB.prepare(`INSERT OR IGNORE INTO notification_events
    (id, account_key, channel, event_type, dedupe_key, status, payload_json, created_at)
    VALUES (?, ?, ?, ?, ?, 'QUEUED', ?, ?)`).bind(
    id, event.accountKey || null, event.channel || 'telegram', event.eventType || 'SYSTEM',
    event.dedupeKey || null, safeJson(event.payload || null), Number(event.createdAt || Date.now())
  ).run();
  return { created: Number(result.meta?.changes || 0) > 0, id };
}

export async function completeNotificationEvent(env, id, status, payload = null) {
  if (!dbConfigured(env) || !id) return false;
  await env.DB.prepare(`UPDATE notification_events SET status = ?, payload_json = COALESCE(?, payload_json), sent_at = ? WHERE id = ?`).bind(
    status, payload === null ? null : safeJson(payload), ['SENT', 'SKIPPED'].includes(status) ? Date.now() : null, id
  ).run();
  return true;
}

export async function listNotificationEvents(env, accountKey, limit = 50) {
  if (!dbConfigured(env)) return [];
  const result = await env.DB.prepare(`SELECT id, account_key, channel, event_type, dedupe_key, status, payload_json, created_at, sent_at
    FROM notification_events WHERE (? IS NULL OR account_key = ?) ORDER BY created_at DESC LIMIT ?`).bind(
    accountKey || null, accountKey || null, Math.max(1, Math.min(200, Number(limit || 50)))
  ).all();
  return (result.results || []).map(row => ({ ...row, payload: safeParse(row.payload_json, null) }));
}

export async function recordProviderHealth(env, health = {}) {
  if (!dbConfigured(env) || !health.component) return false;
  await env.DB.prepare(`INSERT INTO provider_health (component, status, latency_ms, error_code, message, metadata_json, checked_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(component) DO UPDATE SET status=excluded.status, latency_ms=excluded.latency_ms,
      error_code=excluded.error_code, message=excluded.message, metadata_json=excluded.metadata_json, checked_at=excluded.checked_at`).bind(
    health.component, health.status || 'UNKNOWN', Number.isFinite(Number(health.latencyMs)) ? Number(health.latencyMs) : null,
    health.errorCode || null, health.message || null, safeJson(health.metadata || null), Number(health.checkedAt || Date.now())
  ).run();
  return true;
}

export async function operationalHealth(env) {
  if (!dbConfigured(env)) return { configured: false, providers: [], queues: {}, deadLetters: 0 };
  const [providers, queueRows, deadLetter, recentEvents] = await Promise.all([
    env.DB.prepare('SELECT * FROM provider_health ORDER BY component').all(),
    env.DB.prepare('SELECT event_type, status, COUNT(*) AS count, MAX(last_attempt_at) AS last_attempt_at FROM queue_receipts GROUP BY event_type, status').all(),
    env.DB.prepare("SELECT COUNT(*) AS count FROM dead_letter_messages WHERE status = 'OPEN'").first(),
    env.DB.prepare('SELECT level, event, account_key, payload_json, created_at FROM system_events ORDER BY created_at DESC LIMIT 20').all()
  ]);
  const queues = {};
  for (const row of queueRows.results || []) {
    queues[row.event_type] ||= {};
    queues[row.event_type][row.status] = Number(row.count || 0);
    queues[row.event_type].lastAttemptAt = Math.max(Number(queues[row.event_type].lastAttemptAt || 0), Number(row.last_attempt_at || 0));
  }
  return {
    configured: true,
    providers: (providers.results || []).map(row => ({ ...row, metadata: safeParse(row.metadata_json, null) })),
    queues,
    deadLetters: Number(deadLetter?.count || 0),
    recentEvents: (recentEvents.results || []).map(row => ({ ...row, payload: safeParse(row.payload_json, null) }))
  };
}
