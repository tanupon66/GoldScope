# รายการ Secrets และ Variables — v3.2

## ต้องมี

```text
ADMIN_CREDENTIAL_HASH     PBKDF2 hash จาก npm run auth:hash
SESSION_SIGNING_SECRET    random secret อย่างน้อย 32 bytes
CAPITAL_API_KEY
CAPITAL_IDENTIFIER
CAPITAL_API_PASSWORD      API custom password
```

## Optional market/news

```text
TWELVE_DATA_API_KEY
NEWS_API_KEY
ECONOMIC_CALENDAR_API_KEY
```

## Optional notifications

```text
TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID
NOTIFICATION_WEBHOOK_URL
NOTIFICATION_SECRET       Bearer secret สำหรับ webhook
```

## Non-secret variables

```text
APP_VERSION=3.2.1
SESSION_TTL_SECONDS=900
NEWS_API_BASE_URL
ECONOMIC_CALENDAR_API_BASE_URL
```

ห้ามใส่ค่าจริงใน frontend, GitHub, `dist`, localStorage, screenshot, ZIP เอกสาร หรือ log. เปลี่ยน Secret ทันทีหากเคยเผยแพร่.
