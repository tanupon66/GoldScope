# คู่มือ Deploy GoldScope AutoTrade v3.2 บน Cloudflare

## 1. เตรียมเครื่อง

ใช้ Node.js 20–22 และ npm 10 ขึ้นไป:

```bash
npm ci
npm run check
npm run test:e2e
```

## 2. Login และสร้าง D1

```bash
npx wrangler login
npx wrangler d1 create goldscope-autotrade
```

นำ `database_id` ที่ Cloudflare คืนมาแทน placeholder ใน `wrangler.jsonc`.

## 3. สร้าง Queues

```bash
npx wrangler queues create goldscope-market-ingestion
npx wrangler queues create goldscope-news-ingestion
npx wrangler queues create goldscope-signal-analysis
npx wrangler queues create goldscope-order-execution
npx wrangler queues create goldscope-broker-reconciliation
npx wrangler queues create goldscope-notification-delivery
npx wrangler queues create goldscope-dead-letter
```

Consumer, retry count และ dead-letter routing ถูกประกาศไว้ใน `wrangler.jsonc` แล้ว.

## 4. Apply migrations

```bash
npx wrangler d1 migrations apply goldscope-autotrade --remote
```

ต้องเห็นทั้ง `0001_initial.sql` และ `0002_operational_readiness.sql` สำเร็จ.

## 5. ตั้ง Secrets

สร้าง admin hash:

```bash
npm run auth:hash -- "รหัสผ่านผู้ดูแลที่ยาวและไม่ซ้ำ"
npx wrangler secret put ADMIN_CREDENTIAL_HASH
npx wrangler secret put SESSION_SIGNING_SECRET
npx wrangler secret put CAPITAL_API_KEY
npx wrangler secret put CAPITAL_IDENTIFIER
npx wrangler secret put CAPITAL_API_PASSWORD
```

Optional data/notification providers:

```bash
npx wrangler secret put TWELVE_DATA_API_KEY
npx wrangler secret put NEWS_API_KEY
npx wrangler secret put ECONOMIC_CALENDAR_API_KEY
npx wrangler secret put TELEGRAM_BOT_TOKEN
npx wrangler secret put TELEGRAM_CHAT_ID
npx wrangler secret put NOTIFICATION_WEBHOOK_URL
npx wrangler secret put NOTIFICATION_SECRET
```

`NEWS_API_BASE_URL` และ `ECONOMIC_CALENDAR_API_BASE_URL` เป็น non-secret vars แต่ต้องตรงกับ adapter/provider ที่มีสิทธิ์ใช้งาน.

## 6. Dry-run และ Deploy

```bash
npm run check
npx wrangler deploy --dry-run
npx wrangler deploy
```

ตรวจ `/api/health` และหน้า Cloud Health หลัง Deploy. หาก D1/Queue/Broker ขึ้น `NOT_CONFIGURED` อย่าเปิด Auto.

## 7. Production smoke test ที่ต้องทำ

1. Login แล้ว logout/login ใหม่เพื่อตรวจ session.
2. เลือก **Capital Demo**, ระบุ account ID และกด Broker Test.
3. ตรวจ Epic, minimum size, balance, spread และ calibration.
4. เปิด Paper + Forward Test อย่างน้อยหนึ่งรอบ.
5. เปิด Confirm Demo และส่งออเดอร์ขนาดต่ำสุดหนึ่งรายการ.
6. ตรวจ dealReference, confirmation, open position และ close-history reconciliation.
7. ทดสอบ Kill Switch ขณะไม่มี position และขณะมี queued signal.
8. ตรวจหน้า DLQ และ notification channel.
9. ค่อยเปิด Demo Auto เมื่อไม่มี unresolved intent/reconciliation mismatch.

## 8. ย้ายข้อมูล v2.0.3

หลัง login เรียก `POST /api/system/migrate-v2` โดยส่ง `x-account-key` เป็นบัญชีปลายทางและ CSRF token. เรียก `{}` เพื่อ preview แล้ว `{"confirm":"MIGRATE_V2"}` เพื่อย้ายจริง. ระบบจะปิด Auto, ล้าง Live unlock และบังคับ calibration/readiness ใหม่.

## 9. Rollback

เก็บ Source/Build รุ่นก่อนและ export config/journal ก่อน Deploy. หากพบ execution anomaly ให้กด Kill Switch, ตรวจ Broker โดยตรง, rollback Worker deployment และห้าม retry unknown order จน reconcile เสร็จ.
