@echo off
setlocal
where node >nul 2>&1 || (
  echo [ERROR] Node.js 20-22 is required.
  pause
  exit /b 1
)
call npm ci
if errorlevel 1 goto :failed
call npm run check
if errorlevel 1 goto :failed
call npm run test:e2e
if errorlevel 1 goto :failed
call npx wrangler deploy --dry-run
if errorlevel 1 goto :failed
echo.
echo Preflight passed. Follow CLOUDFLARE_DEPLOY_TH.md to create D1/Queues,
echo apply migrations, set ADMIN_CREDENTIAL_HASH, SESSION_SIGNING_SECRET and Broker secrets,
echo then run: npx wrangler deploy
echo This script intentionally does not deploy before resources and secrets exist.
pause
exit /b 0
:failed
echo.
echo Preflight failed. Review the error above.
pause
exit /b 1
