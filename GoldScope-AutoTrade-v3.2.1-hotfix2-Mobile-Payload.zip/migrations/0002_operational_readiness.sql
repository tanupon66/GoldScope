PRAGMA foreign_keys = ON;

ALTER TABLE accounts ADD COLUMN state_object_key TEXT;
ALTER TABLE accounts ADD COLUMN last_seen_at INTEGER;
ALTER TABLE accounts ADD COLUMN last_scan_at INTEGER;
ALTER TABLE accounts ADD COLUMN last_success_at INTEGER;
ALTER TABLE accounts ADD COLUMN last_error_code TEXT;

CREATE INDEX IF NOT EXISTS idx_accounts_state_object ON accounts(state_object_key, active);
CREATE UNIQUE INDEX IF NOT EXISTS idx_queue_idempotency
  ON queue_receipts(event_type, idempotency_key)
  WHERE idempotency_key IS NOT NULL;

ALTER TABLE queue_receipts ADD COLUMN last_attempt_at INTEGER;
ALTER TABLE queue_receipts ADD COLUMN retry_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE queue_receipts ADD COLUMN correlation_id TEXT;

CREATE TABLE IF NOT EXISTS dead_letter_messages (
  id TEXT PRIMARY KEY,
  original_message_id TEXT,
  event_type TEXT NOT NULL,
  account_key TEXT,
  state_object_key TEXT,
  idempotency_key TEXT,
  correlation_id TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  payload_json TEXT NOT NULL,
  error_json TEXT,
  status TEXT NOT NULL DEFAULT 'OPEN',
  received_at INTEGER NOT NULL,
  retried_at INTEGER,
  dismissed_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_dead_letters_status_time ON dead_letter_messages(status, received_at DESC);

CREATE TABLE IF NOT EXISTS forward_test_signals (
  id TEXT PRIMARY KEY,
  account_key TEXT NOT NULL,
  signal_id TEXT NOT NULL,
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  direction TEXT NOT NULL,
  intended_entry REAL NOT NULL,
  simulated_fill REAL NOT NULL,
  stop_loss REAL NOT NULL,
  take_profit REAL NOT NULL,
  spread REAL NOT NULL DEFAULT 0,
  slippage_assumption REAL NOT NULL DEFAULT 0,
  opened_at INTEGER NOT NULL,
  closed_at INTEGER,
  exit_price REAL,
  pnl REAL,
  result_r REAL,
  outcome TEXT,
  status TEXT NOT NULL,
  strategy_version TEXT,
  model_version TEXT,
  config_version INTEGER,
  news_context_json TEXT,
  payload_json TEXT,
  UNIQUE(account_key, signal_id)
);
CREATE INDEX IF NOT EXISTS idx_forward_account_status ON forward_test_signals(account_key, status, opened_at DESC);

CREATE TABLE IF NOT EXISTS provider_health (
  component TEXT PRIMARY KEY,
  status TEXT NOT NULL,
  latency_ms INTEGER,
  error_code TEXT,
  message TEXT,
  metadata_json TEXT,
  checked_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS notification_preferences (
  account_key TEXT PRIMARY KEY,
  telegram_enabled INTEGER NOT NULL DEFAULT 0,
  webhook_enabled INTEGER NOT NULL DEFAULT 0,
  browser_enabled INTEGER NOT NULL DEFAULT 1,
  event_types_json TEXT,
  cooldown_seconds INTEGER NOT NULL DEFAULT 300,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS model_governance_events (
  id TEXT PRIMARY KEY,
  account_key TEXT NOT NULL,
  action TEXT NOT NULL,
  model_version TEXT,
  previous_model_version TEXT,
  evaluation_json TEXT,
  actor TEXT,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_model_governance_account_time ON model_governance_events(account_key, created_at DESC);

CREATE TABLE IF NOT EXISTS reconciliation_events (
  id TEXT PRIMARY KEY,
  account_key TEXT NOT NULL,
  order_intent_id TEXT,
  broker_deal_id TEXT,
  broker_deal_reference TEXT,
  result TEXT NOT NULL,
  verified_pnl REAL,
  currency TEXT,
  source TEXT,
  payload_json TEXT,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_reconcile_account_time ON reconciliation_events(account_key, created_at DESC);
