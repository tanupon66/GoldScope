PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS accounts (
  account_key TEXT PRIMARY KEY,
  broker TEXT NOT NULL,
  environment TEXT NOT NULL,
  account_id TEXT NOT NULL,
  symbol TEXT NOT NULL DEFAULT 'GOLD',
  active INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  UNIQUE(broker, environment, account_id)
);

CREATE TABLE IF NOT EXISTS config_versions (
  id TEXT PRIMARY KEY,
  account_key TEXT NOT NULL,
  version INTEGER NOT NULL,
  config_json TEXT NOT NULL,
  config_hash TEXT,
  active INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  created_by TEXT,
  FOREIGN KEY(account_key) REFERENCES accounts(account_key)
);
CREATE INDEX IF NOT EXISTS idx_config_account_active ON config_versions(account_key, active, version DESC);

CREATE TABLE IF NOT EXISTS market_candles (
  provider TEXT NOT NULL,
  environment TEXT NOT NULL,
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  candle_time INTEGER NOT NULL,
  open REAL NOT NULL, high REAL NOT NULL, low REAL NOT NULL, close REAL NOT NULL,
  bid_close REAL, ask_close REAL, volume REAL,
  received_at INTEGER NOT NULL,
  quality_score INTEGER,
  PRIMARY KEY(provider, environment, symbol, timeframe, candle_time)
);
CREATE INDEX IF NOT EXISTS idx_market_candles_lookup ON market_candles(symbol, timeframe, candle_time DESC);

CREATE TABLE IF NOT EXISTS market_snapshots (
  id TEXT PRIMARY KEY, account_key TEXT, provider TEXT NOT NULL, symbol TEXT NOT NULL,
  bid REAL, ask REAL, spread REAL, market_status TEXT, source_time INTEGER,
  received_at INTEGER NOT NULL, quality_score INTEGER, payload_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_market_snapshots_account_time ON market_snapshots(account_key, received_at DESC);

CREATE TABLE IF NOT EXISTS news_articles (
  id TEXT PRIMARY KEY, provider TEXT NOT NULL, title TEXT NOT NULL, summary TEXT, source TEXT,
  published_at INTEGER NOT NULL, received_at INTEGER NOT NULL, symbols_json TEXT, topics_json TEXT,
  language TEXT, relevance_score REAL, sentiment_score REAL, sentiment_confidence REAL,
  impact_level TEXT, duplicate_group TEXT, url_hash TEXT
);
CREATE INDEX IF NOT EXISTS idx_news_published ON news_articles(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_news_duplicate ON news_articles(duplicate_group);

CREATE TABLE IF NOT EXISTS economic_events (
  id TEXT PRIMARY KEY, provider TEXT NOT NULL, country TEXT, currency TEXT, event_name TEXT NOT NULL,
  scheduled_at INTEGER NOT NULL, impact_level TEXT, forecast TEXT, previous TEXT, actual TEXT,
  revision TEXT, status TEXT, received_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_schedule ON economic_events(scheduled_at);

CREATE TABLE IF NOT EXISTS feature_snapshots (
  id TEXT PRIMARY KEY, account_key TEXT NOT NULL, symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
  closed_candle_time INTEGER NOT NULL, schema_version TEXT NOT NULL, features_json TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_features_account_time ON feature_snapshots(account_key, closed_candle_time DESC);

CREATE TABLE IF NOT EXISTS strategy_signals (
  id TEXT PRIMARY KEY, account_key TEXT NOT NULL, symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
  closed_candle_time INTEGER NOT NULL, direction TEXT NOT NULL, decision TEXT NOT NULL,
  base_score REAL, final_score REAL, confidence REAL, expected_r REAL,
  strategy_version TEXT, model_version TEXT, config_version INTEGER,
  explanation_json TEXT, news_context_json TEXT, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_signals_account_time ON strategy_signals(account_key, created_at DESC);

CREATE TABLE IF NOT EXISTS order_intents (
  id TEXT PRIMARY KEY,
  idempotency_key TEXT NOT NULL UNIQUE,
  account_key TEXT NOT NULL,
  signal_id TEXT,
  state TEXT NOT NULL,
  broker_deal_reference TEXT,
  broker_deal_id TEXT,
  request_json TEXT,
  response_json TEXT,
  last_error_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_order_intents_account_state ON order_intents(account_key, state, updated_at DESC);

CREATE TABLE IF NOT EXISTS broker_orders (
  id TEXT PRIMARY KEY, order_intent_id TEXT NOT NULL, account_key TEXT NOT NULL,
  broker TEXT NOT NULL, environment TEXT NOT NULL, symbol TEXT NOT NULL, direction TEXT NOT NULL,
  size REAL NOT NULL, submitted_at INTEGER, broker_deal_reference TEXT, broker_deal_id TEXT,
  status TEXT, payload_json TEXT, FOREIGN KEY(order_intent_id) REFERENCES order_intents(id)
);
CREATE INDEX IF NOT EXISTS idx_broker_orders_account ON broker_orders(account_key, submitted_at DESC);

CREATE TABLE IF NOT EXISTS broker_confirmations (
  id TEXT PRIMARY KEY, order_intent_id TEXT NOT NULL, broker_deal_reference TEXT,
  broker_deal_id TEXT, status TEXT, reason TEXT, payload_json TEXT, received_at INTEGER NOT NULL,
  FOREIGN KEY(order_intent_id) REFERENCES order_intents(id)
);

CREATE TABLE IF NOT EXISTS positions (
  id TEXT PRIMARY KEY, account_key TEXT NOT NULL, broker_deal_id TEXT, symbol TEXT NOT NULL,
  direction TEXT NOT NULL, size REAL NOT NULL, entry REAL, stop_loss REAL, take_profit REAL,
  status TEXT NOT NULL, opened_at INTEGER, closed_at INTEGER, pnl REAL, payload_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_positions_account_status ON positions(account_key, status);

CREATE TABLE IF NOT EXISTS trade_journal (
  id TEXT PRIMARY KEY, account_key TEXT NOT NULL, signal_id TEXT, order_intent_id TEXT,
  strategy_id TEXT, strategy_version TEXT, model_version TEXT, timeframe TEXT, regime TEXT,
  opened_at INTEGER, closed_at INTEGER, pnl REAL, result_r REAL, costs REAL,
  outcome TEXT, data_mode TEXT, payload_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_journal_account_close ON trade_journal(account_key, closed_at DESC);

CREATE TABLE IF NOT EXISTS equity_snapshots (
  id TEXT PRIMARY KEY, account_key TEXT NOT NULL, balance REAL, equity REAL, available REAL,
  drawdown REAL, captured_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_equity_account_time ON equity_snapshots(account_key, captured_at DESC);

CREATE TABLE IF NOT EXISTS risk_events (
  id TEXT PRIMARY KEY, account_key TEXT, code TEXT NOT NULL, severity TEXT NOT NULL,
  message TEXT, payload_json TEXT, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_risk_account_time ON risk_events(account_key, created_at DESC);

CREATE TABLE IF NOT EXISTS system_events (
  id TEXT PRIMARY KEY, level TEXT NOT NULL, event TEXT NOT NULL, request_id TEXT,
  correlation_id TEXT, account_key TEXT, duration_ms INTEGER, payload_json TEXT, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_system_events_time ON system_events(created_at DESC);

CREATE TABLE IF NOT EXISTS model_versions (
  id TEXT PRIMARY KEY, account_key TEXT NOT NULL, role TEXT NOT NULL, status TEXT NOT NULL,
  feature_schema_version TEXT NOT NULL, strategy_version TEXT NOT NULL, training_range_json TEXT,
  config_json TEXT, created_at INTEGER NOT NULL, promoted_at INTEGER, rolled_back_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_models_account_role ON model_versions(account_key, role, status);

CREATE TABLE IF NOT EXISTS model_metrics (
  id TEXT PRIMARY KEY, model_version_id TEXT NOT NULL, split TEXT NOT NULL, metrics_json TEXT NOT NULL,
  sample_size REAL, period_start INTEGER, period_end INTEGER, created_at INTEGER NOT NULL,
  FOREIGN KEY(model_version_id) REFERENCES model_versions(id)
);

CREATE TABLE IF NOT EXISTS backtest_runs (
  id TEXT PRIMARY KEY, account_key TEXT, model_version TEXT, strategy_version TEXT,
  data_start INTEGER, data_end INTEGER, settings_json TEXT, metrics_json TEXT,
  leakage_check INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL, created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS forward_test_runs (
  id TEXT PRIMARY KEY, account_key TEXT NOT NULL, status TEXT NOT NULL, started_at INTEGER NOT NULL,
  ended_at INTEGER, settings_json TEXT, metrics_json TEXT, created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS notification_events (
  id TEXT PRIMARY KEY, account_key TEXT, channel TEXT NOT NULL, event_type TEXT NOT NULL,
  dedupe_key TEXT, status TEXT NOT NULL, payload_json TEXT, created_at INTEGER NOT NULL, sent_at INTEGER
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_notification_dedupe ON notification_events(channel, dedupe_key);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY, actor TEXT NOT NULL, action TEXT NOT NULL, account_key TEXT,
  request_id TEXT, ip_hash TEXT, payload_json TEXT, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_logs(created_at DESC);

CREATE TABLE IF NOT EXISTS queue_receipts (
  message_id TEXT PRIMARY KEY, event_type TEXT NOT NULL, account_key TEXT,
  idempotency_key TEXT, status TEXT NOT NULL, attempt INTEGER NOT NULL,
  received_at INTEGER NOT NULL, completed_at INTEGER, error_json TEXT
);
