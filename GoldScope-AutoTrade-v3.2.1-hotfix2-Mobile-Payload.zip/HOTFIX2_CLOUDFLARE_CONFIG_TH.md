# Hotfix 2: Cloudflare remote configuration conflict

แก้ Workflow ที่ใช้ `--strict` แล้วหยุดเมื่อ Worker เดิมบน Dashboard ยังไม่มี Durable Object binding `AUTH_STATE`.

Hotfix นี้:

- ตรวจว่า config ชั่วคราวมี `AUTO_TRADE_STATE` และ `AUTH_STATE`
- ตรวจ migrations ของ `AutoTradeState` และ `AuthState`
- ไม่ใช้ `--strict` ใน CI สำหรับการเปลี่ยน config ที่ตั้งใจไว้
- ยังคงใช้ `--keep-vars` เพื่อรักษา Variables/Secrets ฝั่ง Cloudflare
- อัปเดต GitHub Actions ให้ใช้ Node 24 runtime

หลังแทน Workflow ให้รัน `first_install / INSTALL_DEMO` ใหม่ เพราะรอบที่ล้มยังไม่ได้ Deploy Worker.
