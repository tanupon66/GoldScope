# GoldScope AutoTrade v3.2 Architecture

## เป้าหมาย

PWA เป็น Control Panel เท่านั้น งานสแกนตลาด, Forward Test, reconciliation และ Broker execution อยู่บน Cloudflare Worker/Queues/Durable Objects จึงทำงานต่อได้เมื่อปิด PWA ตราบใดที่บัญชีถูกเปิดใช้งานใน D1.

## Components

```text
PWA
  ├─ secure session + CSRF
  ├─ Dashboard / Auto / Forward / Health / DLQ
  └─ /api/*
       │
Cloudflare Worker Router
  ├─ AuthState Durable Object
  ├─ D1: config, trace, journal, health, DLQ
  ├─ Cron every minute
  └─ Queue producers/consumers
       ├─ market-ingestion
       ├─ news-ingestion
       ├─ signal-analysis
       ├─ order-execution
       ├─ broker-reconciliation
       ├─ notification-delivery
       └─ dead-letter
             │
Account-scoped AutoTradeState Durable Object
  capital:<demo|live>:<accountId>
  ├─ active config + server-side Broker session metadata
  ├─ execution lock + pending execution
  ├─ risk counters/circuit breakers
  ├─ order intents + reconciliation state
  ├─ Forward Test positions
  └─ account ledger/model summary
             │
Capital.com environment matching the selected account
```

## Account and Cron mapping

เมื่อ Broker test/config save สำเร็จ ระบบบันทึก `account_key` และ `state_object_key` ใน D1. Cron อ่านเฉพาะ active accounts แล้ว enqueue งานไป Durable Object เดิมที่ UI ใช้. หากไม่มี active account Cron จะบันทึก `CRON_SKIPPED_NO_ACTIVE_ACCOUNTS` และไม่สร้างงานให้ setup state.

Demo และ Live ไม่แชร์ session, ledger, model summary, pending intent, cooldown หรือ live unlock.

## Market/news flow

1. `market-ingestion` ดึง quote/candles จาก Broker environment เดียวกับบัญชีและเก็บ snapshot/candles ใน D1.
2. `news-ingestion` ดึง provider ที่ตั้งค่าไว้, normalize, deduplicate, decay และสร้าง blackout context.
3. `signal-analysis` ใช้ closed candles, data-quality score, regime, strategy ensemble, adaptive score และ deterministic Risk Gate.
4. Mock/Twelve Data อาจใช้สำหรับ UI/analysis fallback ที่ติดป้ายชัดเจน แต่ไม่เข้า Broker execution path.

## Order flow

```text
ANALYZE_SIGNAL
  → create signal + deterministic idempotency key
  → CREATED → RISK_APPROVED → QUEUED
  → persist/checkpoint
  → enqueue EXECUTE_ORDER

EXECUTE_ORDER consumer
  → acquire account execution lock
  → verify system still enabled / not killed
  → verify environment, account and symbol unchanged
  → refresh Broker account, quote, positions and working orders
  → verify market/quote freshness/entry window
  → rerun spread, latency, loss, drawdown, margin and duplicate guards
  → recalculate latest-price risk
  → SUBMITTING
  → exactly one Broker POST
  → checkpoint dealReference/confirmation
  → OPEN / BROKER_REJECTED / UNKNOWN
```

Timeout หรือ network ambiguity หลัง POST จะไม่ retry POST. Intent เปลี่ยนเป็น `UNKNOWN/RECONCILIATION_REQUIRED` แล้ว `broker-reconciliation` ตรวจ Broker state/history ก่อนตัดสินใจต่อ.

## Reconciliation and verified P/L

ระบบ match position/activity/transaction ด้วย deal ID/reference. จะนำ P/L เข้า journal/learning ต่อเมื่อพบค่าที่ตรวจสอบได้พร้อม currency/source. หากไม่ match ระบบคงสถานะ reconciliation และเพิ่ม mismatch guard; ไม่ใช้ balance delta เป็น P/L.

## Forward Test

สัญญาณที่ผ่านเงื่อนไขสามารถเปิด Shadow Forward position แยกจาก Broker order. Fill จำลองรวมครึ่ง spread + slippage assumption, ประเมินจากแท่งถัดจาก signal และใช้กฎ conservative เมื่อ SL/TP ถูกแตะในแท่งเดียวกัน. ผลเก็บใน D1 และไม่ถูกนับเป็น Demo/Live execution.

## Queue idempotency and DLQ

ทุก message มี message/correlation/idempotency keys. D1 receipt ป้องกัน duplicate processing และอนุญาต retry เฉพาะ attempt ใหม่หรือ lease หมด. งานที่เกิน retry limit เข้า dead-letter queue และปรากฏใน UI เพื่อ retry/dismiss. Order execution ยังคง idempotent แม้ผู้ใช้ retry DLQ.

## Authentication and secrets

Admin credential ถูก verify ด้วย PBKDF2 hash. Session เป็น signed short-lived HttpOnly/Secure/SameSite cookie; state-changing request ต้องมี session-bound CSRF token. Broker/provider credentials อยู่ใน Cloudflare Secrets เท่านั้นและไม่ถูกส่ง frontend/log/cache.
