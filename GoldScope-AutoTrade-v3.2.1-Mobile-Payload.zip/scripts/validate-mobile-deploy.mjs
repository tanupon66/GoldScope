import { readFile } from 'node:fs/promises';

const workflow = await readFile('.github/workflows/mobile-one-click-deploy.yml', 'utf8');
const requiredWorkflowMarkers = [
  'workflow_dispatch:',
  'first_install',
  'safe_update',
  'CLOUDFLARE_ACCOUNT_ID',
  'CLOUDFLARE_API_TOKEN',
  'mobile-cloudflare-bootstrap.mjs',
  'mobile-prepare-secrets.mjs',
  'd1 migrations apply',
  '--secrets-file .mobile-secrets.json',
  'ลบไฟล์ชั่วคราวที่มี Secrets'
];
for (const marker of requiredWorkflowMarkers) {
  if (!workflow.includes(marker)) throw new Error(`Mobile workflow is missing: ${marker}`);
}
if (workflow.includes('pull_request_target')) throw new Error('Unsafe pull_request_target trigger is not allowed');
if (!workflow.includes('permissions:\n  contents: read')) throw new Error('Workflow permissions must be read-only');

const packageJson = JSON.parse(await readFile('package.json', 'utf8'));
if (packageJson.version !== '3.2.1') throw new Error('package.json version must be 3.2.1');
const wrangler = JSON.parse(await readFile('wrangler.jsonc', 'utf8'));
if (wrangler.vars?.APP_VERSION !== '3.2.1') throw new Error('Wrangler APP_VERSION must be 3.2.1');

console.log('Mobile one-click deployment files passed static validation.');
