# Delivery Manifest — GoldScope AutoTrade v3.2.0

## Packages

- `GoldScope-AutoTrade-v3.2.0-Source.zip` — source, Worker, PWA, tests, migrations, current build and documentation.
- `GoldScope-AutoTrade-v3.2.0-Build.zip` — static PWA build only; ไม่รวม Worker/D1/DO/Queues.
- `GoldScope-AutoTrade-v3.2.0-Patch.zip` — changed files สำหรับ Source v3.1.0.
- `GoldScope-AutoTrade-v3.2.0.patch` — unified text patch จาก v3.1.0.
- `GoldScope-AutoTrade-v3.2.0-Documentation.zip` — Markdown manuals + current desktop/mobile screenshots.
- `GoldScope-AutoTrade-v3.2.0-Delivery.zip` — รวมชุดส่งมอบทั้งหมด.
- `GoldScope-AutoTrade-v3.2.0-SHA256SUMS.txt` — checksums.
- `GoldScope-AutoTrade-v3.2.0-FINAL_VALIDATION.txt` — validation summary.

## Upgrade scope

Service Worker/cache, CSP/static headers, source-map policy, protected market API, unified confirmation dialog, Auto Trade 4-step Setup Wizard, current documentation screenshots and Wrangler provider URL vars.
