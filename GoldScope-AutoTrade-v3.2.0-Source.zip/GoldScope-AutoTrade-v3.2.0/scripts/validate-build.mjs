import { access, readFile, readdir } from 'node:fs/promises';

const required = ['dist/index.html','dist/manifest.webmanifest','dist/sw.js','dist/_headers','dist/icons/icon-192.png'];
for (const file of required) await access(new URL(`../${file}`, import.meta.url));
const html = await readFile(new URL('../dist/index.html', import.meta.url), 'utf8');
if (!html.includes('GoldScope AutoTrade')) throw new Error('Build title missing');
const headers = await readFile(new URL('../dist/_headers', import.meta.url), 'utf8');
if (!headers.includes('Content-Security-Policy:') || !headers.includes('X-Frame-Options: DENY')) throw new Error('Static security headers missing');
const sw = await readFile(new URL('../dist/sw.js', import.meta.url), 'utf8');
if (!sw.includes('goldscope-autotrade-shell-v320')) throw new Error('Service worker cache version is stale');
const assets = await readdir(new URL('../dist/assets/', import.meta.url));
if (assets.some(file => file.endsWith('.map'))) throw new Error('Production source map must not be emitted');
console.log(`Build validation passed (${required.length} required files, CSP present, no source maps).`);
