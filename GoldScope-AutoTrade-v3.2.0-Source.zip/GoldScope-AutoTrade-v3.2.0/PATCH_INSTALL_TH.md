# วิธีติดตั้งแพตช์ GoldScope AutoTrade v3.2.0

แพตช์นี้ใช้กับ **Source v3.1.0** เท่านั้น. ผู้ที่อยู่ v2.0.3 หรือ v3.0.0 ควรใช้ Source v3.2.0 เต็มเพื่อให้ migrations, tests และเอกสารตรงกัน.

1. สำรอง config, journal และ Source เดิม.
2. จาก root ของ v3.1.0 ใช้ `patch -p1 < GoldScope-AutoTrade-v3.2.0.patch` หรือคัดลอกไฟล์จาก Patch ZIP ทับตามโครงสร้าง.
3. รัน `npm ci && npm run check && npm run test:e2e`.
4. ตรวจ `wrangler.jsonc` ว่า D1 ID และ Queue names เป็นของบัญชีคุณ.
5. Deploy ด้วย `npx wrangler deploy --dry-run` ก่อน `npx wrangler deploy`.

แพตช์ไม่ใส่ Secret จริงและไม่แก้ D1 database ID ของผู้ใช้.
