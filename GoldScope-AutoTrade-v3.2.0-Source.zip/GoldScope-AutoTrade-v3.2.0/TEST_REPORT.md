# Test Report — GoldScope AutoTrade v3.2.0

Date: 2026-06-27  
Environment: Linux container, Node.js 22.16.0, npm 10.9.2, Wrangler 4.105.0

## Commands completed

- `npm ci` — ผ่านจาก v3.2 source workspace.
- `npm run security:scan` — ผ่าน; ไม่พบ credential literal หรือ private key ที่ commit ไว้.
- `npm test` — **27 files / 87 tests ผ่านทั้งหมด**.
- `npm run build` — ผ่าน; สร้าง hashed assets และ **ไม่มี production source map**.
- `npm run check` — ผ่าน; secret scan + tests + build + CSP/cache/source-map validation.
- `npm run test:e2e` — ผ่าน; desktop/mobile dashboard, Auto Trade Setup Wizard, step switching, custom confirmation dialog, tuned backtest, tuning import และ responsive navigation.
- `npx wrangler d1 migrations apply goldscope-autotrade --local` — migration 0001 และ 0002 รวม **65 SQL commands ผ่าน**.
- `npx wrangler deploy --dry-run` — ผ่าน; Worker bundle และ DO/D1/7 Queues/assets/4 vars resolve ครบ.
- `npm audit --omit=dev` — **0 production vulnerabilities**.

## Production-hardening coverage

- `/api/market` และ `/api/quote` คืน 401 ก่อนเรียก Twelve Data เมื่อไม่มี signed session.
- Static `_headers` มี CSP, `frame-ancestors 'none'`, `X-Frame-Options: DENY`, no-sniff และ cross-origin policies.
- Service Worker ใช้ cache generation `goldscope-autotrade-shell-v320`.
- Build validation ล้มเหลวทันทีหากพบ `.map`, CSP หาย หรือ cache generation เก่า.
- `window.confirm()` ถูกแทนด้วย in-app dialog ทั้งหมด; Kill Switch และ clear-data ใช้ typed confirmation.
- Auto Trade wizard ตรวจด้วย E2E ทั้ง desktop/mobile และรักษาค่าฟอร์มใน DOM เมื่อสลับขั้น.

## Existing safety coverage retained

- Data quality, duplicate/out-of-order/stale candle.
- News decay, deduplication และ event blackout.
- Calibration, P/L conversion, minimum-size risk.
- Daily/weekly loss, drawdown, margin usage และ reconciliation mismatch guards.
- Session signing, expiry, CSRF primitives และ secret scan.
- Order-intent state machine, deterministic idempotency และ duplicate queue delivery.
- Single-submit Broker flow, timeout-after-submit → `UNKNOWN`, Kill Switch before submit.
- Broker account switching, transaction-history reconciliation และ Forward Test.
- Queue retry/backoff, Cron no-active-account safety, model promotion/rollback และ drift fallback.

## Not executed

- Remote D1 migration/deployment เพราะไม่มี Cloudflare account/database ID ของผู้ใช้.
- Capital.com Demo order และ close-history reconciliation ด้วย credential จริง.
- News/Calendar/Telegram/Webhook provider จริง.
- 28-day Forward Test, 100 closed Demo trades, production load/penetration test.

ผลนี้ยืนยันโค้ดและแพ็กเกจที่ทดสอบได้ใน environment ปัจจุบัน ไม่ได้ยืนยัน Live readiness หรือ profitability.
