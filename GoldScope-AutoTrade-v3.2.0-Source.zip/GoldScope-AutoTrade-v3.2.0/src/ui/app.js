import { analyzeTimeframe, combineMarketBias, TIMEFRAME_LABELS } from '../core/market.js';
import { loadMarketData, healthCheck, TIMEFRAMES } from '../core/data.js';
import { generateCandidates } from '../core/strategies.js';
import { DEFAULT_SETTINGS, selectPlans, valuePerPriceUnitForSize } from '../core/risk.js';
import { executionCosts } from '../core/execution.js';
import { evaluatePlans, isTerminal, statusLabel } from '../core/plans.js';
import { runBacktest } from '../core/backtest.js';
import {
  buildAdaptiveModel, applyAdaptiveLearning, learningLeaderboard, mergeLearningRecords,
  createTuningProfile, validateTuningProfile
} from '../core/learning.js';
import { storage, downloadJson, downloadCsv, readJsonFile } from '../core/storage.js';
import { MarketChart } from './chart.js';
import { confirmDialog } from './dialog.js';
import { refreshIntervalMs, isDataStale, secondsUntilRefresh, dataAgeSeconds } from '../core/sync.js';
import {
  getAutoTradeStatus, autoTradeAction, saveAutoTradeConfig, getAuthSession, login, logout,
  getActiveAccountKey, setActiveAccountKey, getSystemHealth, getDeadLetters, retryDeadLetter,
  dismissDeadLetter, getNotificationEvents, getForwardTestStatus, reconcileAutoTrade
} from '../core/brokerApi.js';
import { DEFAULT_AUTO_TRADE_CONFIG } from '../core/autotrade.js';
import {
  loadAutoTradeDisplaySnapshot, saveAutoTradeDisplaySnapshot, clearAutoTradeDisplaySnapshot
} from '../core/autotradePrefs.js';

const icon = (name, size = 20) => {
  const paths = {
    dashboard: '<path d="M3 13h8V3H3v10Zm0 8h8v-6H3v6Zm10 0h8V11h-8v10Zm0-18v6h8V3h-8Z"/>',
    chart: '<path d="M3 3v18h18"/><path d="m7 16 4-5 4 3 5-7"/>',
    journal: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/>',
    test: '<path d="M9 3h6M10 9l-5 9a2 2 0 0 0 1.7 3h10.6A2 2 0 0 0 19 18l-5-9V3h-4v6Z"/><path d="M8.5 14h7"/>',
    bot: '<rect x="4" y="7" width="16" height="12" rx="3"/><path d="M9 11h.01M15 11h.01M8 15h8M12 7V4M9 4h6"/>',
    shield: '<path d="M12 3 20 7v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7l8-4Z"/><path d="m9 12 2 2 4-5"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    settings: '<path d="M12 15.5A3.5 3.5 0 1 0 12 8a3.5 3.5 0 0 0 0 7.5Z"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21h-4v-.09A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.2 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H2.4v-4h.09A1.7 1.7 0 0 0 4.2 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 8.6 4.2a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V2.4h4v.09A1.7 1.7 0 0 0 15 4.2a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 8.6a1.7 1.7 0 0 0 .6 1 1.7 1.7 0 0 0 1.1.4h.09v4h-.09a1.7 1.7 0 0 0-1.7 1Z"/>',
    refresh: '<path d="M20 11a8.1 8.1 0 1 0-2.4 5.8"/><path d="M20 4v7h-7"/>',
    download: '<path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M5 21h14"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
    gold: '<path d="m4 15 4-8h8l4 8-4 4H8l-4-4Z"/><path d="M8 7l4 12 4-12M4 15h16"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-9h.01"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    play: '<path d="m8 5 11 7-11 7V5Z"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2m-9 0 1 15h8l1-15M10 10v7m4-7v7"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    x: '<path d="m6 6 12 12M18 6 6 18"/>'
  };
  return `<svg aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name] || paths.info}</svg>`;
};

const fmtPrice = v => Number.isFinite(Number(v)) ? Number(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '—';
const fmtScore = v => Number.isFinite(Number(v)) ? Math.round(Number(v)) : '—';
const fmtPct = v => Number.isFinite(Number(v)) ? `${Number(v).toFixed(1)}%` : '—';
const fmtTime = v => v ? new Date(v).toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'short' }) : '—';
const esc = value => String(value ?? '').replace(/[&<>'"]/g, ch => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' })[ch]);
const sessionGet = key => { try { return sessionStorage.getItem(key) || ''; } catch { return ''; } };
const sessionSet = (key, value) => { try { sessionStorage.setItem(key, value); } catch {} };
const pageNames = { dashboard: 'ภาพรวมตลาด', analysis: 'การวิเคราะห์เชิงลึก', autotrade: 'Auto Trade', backtest: 'ทดสอบย้อนหลัง', journal: 'สมุดบันทึก', settings: 'ตั้งค่าระบบ' };
const APP_VERSION = '3.2.0';
const ALGORITHM_VERSION = '3.2.0';


function migrateSettings(saved = {}) {
  const next = { ...DEFAULT_SETTINGS, ...saved, dataPreference: saved.dataPreference || 'auto' };
  if (Number(saved.settingsVersion || 0) < 2) {
    const digits = Number.isFinite(Number(saved.brokerDigits)) ? Number(saved.brokerDigits) : 2;
    const pointSize = 10 ** -Math.max(0, Math.min(6, Math.round(digits)));
    if (!Number.isFinite(Number(saved.spreadPoints))) {
      next.spreadPoints = Number(saved.spread) > 0 ? Math.max(0, Math.round(Number(saved.spread) / pointSize)) : DEFAULT_SETTINGS.spreadPoints;
    }
    if (!Number.isFinite(Number(saved.slippagePoints))) {
      next.slippagePoints = Number(saved.slippage) > 0 ? Math.max(0, Math.round(Number(saved.slippage) / pointSize)) : DEFAULT_SETTINGS.slippagePoints;
    }
  }
  if (Number(saved.settingsVersion || 0) < 3) {
    // v1.5 introduces real fixed-lot risk caps. Replace untouched legacy defaults
    // with the personal $20 / 0.01-lot preset while preserving custom values.
    if (saved.accountSize === undefined || Number(saved.accountSize) === 1000) next.accountSize = 20;
    if (saved.riskPercent === undefined || Number(saved.riskPercent) === 0.5) next.riskPercent = 5;
    if (saved.profile === undefined || saved.profile === 'balanced') next.profile = 'scalp';
    next.positionSizingMode = saved.positionSizingMode || 'fixed';
    next.fixedLot = Number.isFinite(Number(saved.fixedLot)) ? Number(saved.fixedLot) : 0.01;
    next.maxLot = Number.isFinite(Number(saved.maxLot)) && Number(saved.maxLot) !== 1 ? Number(saved.maxLot) : 0.01;
    next.leverage = Number.isFinite(Number(saved.leverage)) ? Number(saved.leverage) : 500;
    next.targetRiskReward = Number.isFinite(Number(saved.targetRiskReward)) ? Number(saved.targetRiskReward) : 1.15;
    next.maxTargetRiskReward = Number.isFinite(Number(saved.maxTargetRiskReward)) ? Number(saved.maxTargetRiskReward) : 1.8;
    next.maxExpectedBarsToTp2 = Number.isFinite(Number(saved.maxExpectedBarsToTp2)) ? Number(saved.maxExpectedBarsToTp2) : 2.2;
    next.exitAtTarget = saved.exitAtTarget || 'tp2';
    next.learningDataPolicy = saved.learningDataPolicy || 'weighted-all';
    next.learningUseDemo = saved.learningUseDemo === undefined ? true : Boolean(saved.learningUseDemo);
    next.learningIncludeBreakeven = saved.learningIncludeBreakeven === undefined ? true : Boolean(saved.learningIncludeBreakeven);
    next.learningMinSamples = Number(saved.learningMinSamples) === 20 ? 8 : Number(next.learningMinSamples || 8);
    next.learningLookback = Number(saved.learningLookback) === 400 ? 800 : Number(next.learningLookback || 800);
    next.backtestMaxHoldBars = Number(saved.backtestMaxHoldBars) === 24 ? 12 : Number(next.backtestMaxHoldBars || 12);
  }
  if (Number(saved.settingsVersion || 0) < 4) {
    next.pnlReferenceSize = Number.isFinite(Number(saved.pnlReferenceSize))
      ? Number(saved.pnlReferenceSize)
      : Number(next.fixedLot || 0.01);
    next.pnlPerUsdMoveAtReferenceSize = Number.isFinite(Number(saved.pnlPerUsdMoveAtReferenceSize))
      ? Number(saved.pnlPerUsdMoveAtReferenceSize)
      : 0.01;
  }
  next.settingsVersion = 4;
  return next;
}

export class GoldScopeApp {
  constructor(root) {
    this.root = root;
    const savedSettings = storage.getSettings();
    const migratedSettings = migrateSettings(savedSettings);
    const autoTradeDisplaySnapshot = loadAutoTradeDisplaySnapshot();
    if (JSON.stringify(savedSettings) !== JSON.stringify(migratedSettings)) storage.saveSettings(migratedSettings);
    this.state = {
      page: 'dashboard',
      loading: true,
      mode: 'demo',
      health: null,
      datasets: {},
      analyses: {},
      bias: { direction: 0, strength: 0, conflict: 0, label: 'กำลังประเมิน' },
      candidates: [],
      plans: [],
      journal: storage.getJournal(),
      tuningState: storage.getTuningState(),
      learning: null,
      settings: migratedSettings,
      selectedTf: '15min',
      selectedPlanId: null,
      lastUpdated: null,
      errors: [],
      lastBacktest: storage.getBacktests()[0] || null,
      backtestTf: '15min',
      installPrompt: null,
      nextRefreshAt: null,
      refreshReason: null,
      online: navigator.onLine !== false,
      autoTrade: null,
      autoTradeError: null,
      autoTradeCloudLoaded: false,
      autoTradeDisplayConfig: autoTradeDisplaySnapshot?.config || null,
      autoTradeConfigCachedAt: autoTradeDisplaySnapshot?.savedAt || null,
      marketSource: 'mock',
      authenticated: false,
      authError: null,
      authExpiresAt: 0,
      accountKey: getActiveAccountKey(),
      systemHealth: null,
      deadLetters: [],
      notificationEvents: [],
      forwardTestStatus: null,
      autoTradeStep: sessionGet('goldscope:auto-step') || 'basic'
    };
    this.state.learning = buildAdaptiveModel(this.learningSourceRecords(), migratedSettings, 'demo');
    this.marketChart = null;
    this.refreshTimer = null;
    this.refreshPromise = null;
    this.syncHeartbeat = null;
    this.lastResumeCheck = 0;
  }

  async init() {
    this.renderShell();
    this.bindGlobalEvents();
    window.addEventListener('beforeinstallprompt', event => {
      event.preventDefault();
      this.state.installPrompt = event;
      this.renderTopbar();
    });
    this.bindLifecycleEvents();
    this.startSyncHeartbeat();
    await this.refreshAuthSession();
    await Promise.all([this.refresh({ reason: 'startup' }), this.refreshAutoTradeStatus()]);
  }

  renderShell() {
    this.root.innerHTML = `
      <div class="app">
        <aside class="sidebar">
          <div class="brand"><div class="brand-mark">${icon('gold',24)}</div><div><strong>GoldScope</strong><span>Personal XAU/USD Lab</span></div></div>
          <nav class="nav">${this.navButtons()}</nav>
          <div class="sidebar-footer">PWA วิเคราะห์และควบคุม Auto Trade ส่วนตัว<br>เริ่มต้น Paper mode และไม่มีการรับประกันผลลัพธ์<br><a class="chart-credit" href="https://www.tradingview.com/" target="_blank" rel="noopener noreferrer">Charts by TradingView</a></div>
        </aside>
        <main class="main">
          <header class="topbar" id="topbar"></header>
          <section class="content" id="content"></section>
        </main>
        <nav class="bottom-nav">${this.navButtons(true)}</nav>
        <div class="toast-stack" id="toasts"></div>
        <div id="loading"></div>
      </div>`;
    this.renderTopbar();
  }

  navButtons(mobile = false) {
    const items = [
      ['dashboard','dashboard','ภาพรวม'], ['analysis','chart','วิเคราะห์'], ['autotrade','bot','Auto'], ['backtest','test','Backtest'], ['journal','journal','บันทึก'], ['settings','settings','ตั้งค่า']
    ];
    return items.map(([page, ico, label]) => `<button class="nav-button ${this.state.page === page ? 'active' : ''}" data-page="${page}"><span class="nav-icon">${icon(ico, mobile ? 18 : 20)}</span><span>${label}</span></button>`).join('');
  }

  renderTopbar() {
    const el = document.getElementById('topbar');
    if (!el) return;
    const isMock = this.state.marketSource === 'mock';
    const sourceLabel = this.state.marketSource === 'capital'
      ? `Capital ${this.state.autoTrade?.config?.brokerEnvironment === 'live' ? 'Live' : 'Demo'}`
      : this.state.marketSource === 'twelvedata' ? 'Twelve Data' : 'ข้อมูลจำลอง';
    el.innerHTML = `
      <div class="mobile-brand"><div class="brand-mark" style="width:34px;height:34px;border-radius:11px">${icon('gold',19)}</div>GoldScope</div>
      <div class="page-title">${pageNames[this.state.page]}</div>
      <div class="top-actions">
        <div class="status-pill"><i class="status-dot ${isMock ? 'demo' : ''}"></i><span>${esc(sourceLabel)}</span></div>
        <div class="status-pill sync-pill" id="syncStatus">${esc(this.syncStatusText())}</div>
        ${this.state.installPrompt ? `<button class="ghost-button" id="installApp">ติดตั้งแอป</button>` : ''}
        <button class="icon-button" id="refreshButton" title="อัปเดตข้อมูลทันที">${icon('refresh',18)}</button>
      </div>`;
  }

  syncStatusText(now = Date.now()) {
    if (!this.state.online) return 'ออฟไลน์ • รอเชื่อมต่อ';
    if (this.refreshPromise) return 'กำลังอัปเดต…';
    const age = dataAgeSeconds(this.state.lastUpdated, now);
    if (age === null) return 'กำลังโหลดข้อมูล';
    const countdown = secondsUntilRefresh(this.state.nextRefreshAt, now);
    if (isDataStale(this.state.lastUpdated, this.state.settings, now)) return `ข้อมูลเก่า ${age}วิ • กำลังตามรอบ`;
    return `ล่าสุด ${age}วิ • รอบถัดไป ${countdown}วิ`;
  }

  updateSyncStatus() {
    const el = document.getElementById('syncStatus');
    if (el) el.textContent = this.syncStatusText();
  }

  startSyncHeartbeat() {
    clearInterval(this.syncHeartbeat);
    this.syncHeartbeat = setInterval(() => {
      this.updateSyncStatus();
      if (document.visibilityState === 'visible' && this.state.online && !this.refreshPromise && isDataStale(this.state.lastUpdated, this.state.settings)) {
        this.refresh({ silent: true, reason: 'heartbeat-catchup' });
      }
    }, 1000);
  }

  bindLifecycleEvents() {
    const resume = reason => {
      const now = Date.now();
      if (now - this.lastResumeCheck < 1200) return;
      this.lastResumeCheck = now;
      this.state.online = navigator.onLine !== false;
      if (!this.state.online) return this.updateSyncStatus();
      if (isDataStale(this.state.lastUpdated, this.state.settings, now)) {
        this.refresh({ silent: true, reason });
      } else {
        this.scheduleRefresh();
        this.updateSyncStatus();
      }
    };
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') resume('visibility-resume');
    });
    window.addEventListener('focus', () => resume('window-focus'));
    window.addEventListener('pageshow', event => {
      if (event.persisted || isDataStale(this.state.lastUpdated, this.state.settings)) resume('pageshow');
    });
    window.addEventListener('online', () => {
      this.state.online = true;
      this.toast('กลับมาออนไลน์ กำลังอัปเดตข้อมูลตลาด');
      this.refresh({ silent: true, reason: 'online' });
    });
    window.addEventListener('offline', () => {
      this.state.online = false;
      clearTimeout(this.refreshTimer);
      this.updateSyncStatus();
      this.toast('อุปกรณ์ออฟไลน์ ระบบจะอัปเดตทันทีเมื่อเชื่อมต่ออีกครั้ง');
    });
  }

  bindGlobalEvents() {
    this.root.addEventListener('click', async event => {
      const nav = event.target.closest('[data-page]');
      if (nav) {
        this.state.page = nav.dataset.page;
        this.marketChart?.destroy(); this.marketChart = null;
        this.renderShell(); this.bindPageEvents(); this.renderPage();
        if (this.state.page === 'autotrade') await this.refreshAutoTradeStatus();
        return;
      }
      if (event.target.closest('#refreshButton')) await this.refresh();
      if (event.target.closest('#installApp') && this.state.installPrompt) {
        await this.state.installPrompt.prompt();
        this.state.installPrompt = null; this.renderTopbar();
      }
    });
  }

  setLoading(show, text = 'กำลังประมวลผลข้อมูลตลาด…') {
    this.state.loading = show;
    const el = document.getElementById('loading');
    if (!el) return;
    el.innerHTML = show ? `<div class="loading-overlay"><div class="loading-card"><div class="spinner"></div><strong>${esc(text)}</strong><div class="card-subtitle">โปรดตรวจสอบแหล่งข้อมูลจริงก่อนนำแผนไปใช้</div></div></div>` : '';
  }

  toast(message) {
    const stack = document.getElementById('toasts');
    if (!stack) return;
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = message;
    stack.appendChild(el);
    setTimeout(() => el.remove(), 4200);
  }

  learningSourceRecords() {
    const tuning = this.state?.tuningState;
    const journal = this.state?.journal || storage.getJournal();
    if (!tuning?.records?.length) return journal;
    const activeSince = Number(tuning.activeSince || 0);
    const newJournal = journal.filter(row => Number(row.endedAt || 0) > activeSince);
    return mergeLearningRecords(tuning.records, newJournal);
  }


  applyAutoTradePayload(payload, { syncSettings = true } = {}) {
    if (!payload) return;
    this.state.autoTrade = { config: payload.config || {}, state: payload.state || {} };
    if (payload.config && Object.keys(payload.config).length) {
      const snapshot = saveAutoTradeDisplaySnapshot(payload.config);
      this.state.autoTradeDisplayConfig = snapshot.config;
      this.state.autoTradeConfigCachedAt = snapshot.savedAt;
      this.state.autoTradeCloudLoaded = true;
    }
    const cloudJournal = payload.state?.cloudJournal || [];
    if (cloudJournal.length) {
      storage.addJournal(cloudJournal);
      this.state.journal = storage.getJournal();
    }
    if (syncSettings && payload.config?.syncAlgorithm !== false) {
      const accountBalance = Number(payload.state?.brokerAccount?.balance);
      const shared = payload.config?.algorithmSettings || {};
      const next = {
        ...this.state.settings,
        ...shared,
        minScore: Number(payload.config?.minScore ?? shared.minScore ?? this.state.settings.minScore),
        fixedLot: Number(payload.config?.orderSize ?? shared.fixedLot ?? this.state.settings.fixedLot),
        riskPercent: Number(payload.config?.riskPercentPerTrade ?? shared.riskPercent ?? this.state.settings.riskPercent),
        maxLossUsd: Number(payload.config?.maxLossPerTradeUsd ?? shared.maxLossUsd ?? this.state.settings.maxLossUsd),
        pnlReferenceSize: Number(payload.config?.pnlReferenceSize ?? shared.pnlReferenceSize ?? this.state.settings.pnlReferenceSize),
        pnlPerUsdMoveAtReferenceSize: Number(payload.config?.pnlPerUsdMoveAtReferenceSize ?? shared.pnlPerUsdMoveAtReferenceSize ?? this.state.settings.pnlPerUsdMoveAtReferenceSize),
        exitAtTarget: payload.config?.takeProfitTarget || shared.exitAtTarget || this.state.settings.exitAtTarget,
        accountSize: Number.isFinite(accountBalance) && accountBalance > 0 ? accountBalance : Number(shared.accountSize || this.state.settings.accountSize)
      };
      this.state.settings = migrateSettings(next);
      storage.saveSettings(this.state.settings);
    }
    const learningMode = payload.config?.brokerEnvironment === 'live' ? 'live' : 'demo';
    this.state.learning = buildAdaptiveModel(this.learningSourceRecords(), this.state.settings, learningMode);
  }

  sharedAutoAlgorithmSettings(config = {}) {
    const accountBalance = Number(this.state.autoTrade?.state?.brokerAccount?.balance);
    return {
      ...this.state.settings,
      accountSize: Number.isFinite(accountBalance) && accountBalance > 0 ? accountBalance : Number(this.state.settings.accountSize || 20),
      minScore: Number(config.minScore ?? this.state.settings.minScore),
      fixedLot: Number(config.orderSize ?? this.state.settings.fixedLot),
      riskPercent: Number(config.riskPercentPerTrade ?? this.state.settings.riskPercent),
      maxLossUsd: Number(config.maxLossPerTradeUsd ?? this.state.settings.maxLossUsd),
      pnlReferenceSize: Number(config.pnlReferenceSize ?? this.state.settings.pnlReferenceSize ?? config.orderSize ?? 0.01),
      pnlPerUsdMoveAtReferenceSize: Number(config.pnlPerUsdMoveAtReferenceSize ?? this.state.settings.pnlPerUsdMoveAtReferenceSize ?? 0.01),
      exitAtTarget: config.takeProfitTarget || this.state.settings.exitAtTarget
    };
  }

  composeAutoTradeConfig(config = {}) {
    return {
      ...config,
      syncAlgorithm: true,
      algorithmSettings: this.sharedAutoAlgorithmSettings(config),
      learningRecords: this.learningSourceRecords().slice(0, 300)
    };
  }

  async refresh({ silent = false, reason = 'manual' } = {}) {
    if (this.refreshPromise) return this.refreshPromise;
    if (!this.state.online && this.state.settings.dataPreference !== 'demo') {
      this.updateSyncStatus();
      if (!silent) this.toast('อุปกรณ์ออฟไลน์ ยังไม่สามารถดึงข้อมูลตลาดได้');
      return null;
    }

    this.state.refreshReason = reason;
    clearTimeout(this.refreshTimer);
    this.state.nextRefreshAt = null;
    if (!silent) this.setLoading(true);
    this.updateSyncStatus();

    this.refreshPromise = (async () => {
      try {
        this.state.health = await healthCheck();
        const forceDemo = this.state.settings.dataPreference === 'demo';
        const preferBroker = this.state.settings.dataPreference !== 'twelve';
        const market = await loadMarketData({ forceDemo, outputsize: 1800, brokerAuthenticated: this.state.authenticated, preferBroker });
        const analyses = {};
        for (const [tf, dataset] of Object.entries(market.datasets)) {
          try { analyses[tf] = analyzeTimeframe(dataset.candles, tf); }
          catch (error) { market.errors.push({ timeframe: tf, message: error.message }); }
        }
        if (!analyses['15min']) throw new Error('ไม่สามารถวิเคราะห์ข้อมูลหลัก M15 ได้');
        this.state.mode = market.mode;
        this.state.marketSource = market.source || 'mock';
        if (market.account && Number.isFinite(Number(market.account.balance)) && Number(market.account.balance) > 0) {
          this.state.settings = migrateSettings({ ...this.state.settings, accountSize: Number(market.account.balance) });
          storage.saveSettings(this.state.settings);
        }
        this.state.datasets = market.datasets;
        this.state.analyses = analyses;
        this.state.errors = market.errors;
        this.state.bias = combineMarketBias(analyses);

        const oldPlans = storage.getPlans();
        const planIsCompatible = p => (p.dataMode || market.mode) === market.mode && p.algorithmVersion === ALGORITHM_VERSION && Number.isFinite(Number(p.score));
        const compatible = oldPlans.filter(planIsCompatible);
        const incompatible = oldPlans.filter(p => !planIsCompatible(p) && !isTerminal(p)).map(p => ({ ...p, status:'INVALIDATED', outcome:'ยกเลิกแผนเก่าหรือข้อมูลคะแนนไม่สมบูรณ์หลังอัปเดต Algorithm', endedAt:Date.now(), resultR:0 }));
        const evaluated = evaluatePlans(compatible, analyses);
        const ended = [...evaluated.filter(isTerminal), ...incompatible];
        if (ended.length) storage.addJournal(ended);
        const active = evaluated.filter(p => !isTerminal(p));

        this.state.journal = storage.getJournal();
        this.state.learning = buildAdaptiveModel(this.learningSourceRecords(), this.state.settings, market.mode);
        const generated = generateCandidates(analyses);
        const learnedCandidates = applyAdaptiveLearning(generated.candidates, this.state.learning, this.state.settings);
        this.state.candidates = learnedCandidates;
        this.state.bias = generated.bias;
        const newPlans = selectPlans(learnedCandidates, analyses, this.state.settings, active).map(p => ({ ...p, dataMode: market.mode }));
        this.state.plans = [...active, ...newPlans].slice(0, this.state.settings.maxPlans);
        storage.savePlans(this.state.plans);
        this.state.journal = storage.getJournal();
        this.state.lastUpdated = Date.now();
        if (!this.state.selectedPlanId || !this.state.plans.some(p => p.id === this.state.selectedPlanId)) {
          this.state.selectedPlanId = this.state.plans[0]?.id || null;
        }
        if (newPlans.length) {
          this.notifyNewPlans(newPlans);
          if (silent) this.toast(`พบแผนใหม่ ${newPlans.length} รายการ`);
        }
        return market;
      } catch (error) {
        this.toast(`อัปเดตไม่สำเร็จ: ${error.message}`);
        return null;
      } finally {
        this.setLoading(false);
      }
    })();

    try {
      return await this.refreshPromise;
    } finally {
      this.refreshPromise = null;
      this.state.refreshReason = null;
      this.renderTopbar();
      this.renderPage();
      this.scheduleRefresh();
    }
  }

  scheduleRefresh() {
    clearTimeout(this.refreshTimer);
    if (!this.state.online && this.state.settings.dataPreference !== 'demo') {
      this.state.nextRefreshAt = null;
      this.updateSyncStatus();
      return;
    }
    const delay = refreshIntervalMs(this.state.settings);
    this.state.nextRefreshAt = Date.now() + delay;
    this.refreshTimer = setTimeout(() => {
      if (document.visibilityState === 'hidden') {
        // Mobile browsers pause background timers. The visibility/focus handler
        // performs an immediate catch-up refresh when the user returns.
        this.scheduleRefresh();
        return;
      }
      this.refresh({ silent: true, reason: 'scheduled' });
    }, delay);
    this.updateSyncStatus();
  }

  notifyNewPlans(plans) {
    if (!this.state.settings.notifications || !('Notification' in window) || Notification.permission !== 'granted') return;
    for (const plan of plans.slice(0, 2)) {
      new Notification(`${plan.directionLabel} ${plan.timeframeLabel} • ${fmtScore(plan.score)}/100`, {
        body: `${plan.strategy} | Entry ${fmtPrice(plan.entryLow)}–${fmtPrice(plan.entryHigh)} | SL ${fmtPrice(plan.stopLoss)} | TP2 ${fmtPrice(plan.tp2)}`,
        icon: '/icons/icon-192.png'
      });
    }
  }

  renderPage() {
    const content = document.getElementById('content');
    if (!content) return;
    this.marketChart?.destroy(); this.marketChart = null;
    if (this.state.page === 'dashboard') content.innerHTML = this.dashboardHtml();
    if (this.state.page === 'analysis') content.innerHTML = this.analysisHtml();
    if (this.state.page === 'autotrade') content.innerHTML = this.autoTradeHtml();
    if (this.state.page === 'backtest') content.innerHTML = this.backtestHtml();
    if (this.state.page === 'journal') content.innerHTML = this.journalHtml();
    if (this.state.page === 'settings') content.innerHTML = this.settingsHtml();
    this.bindPageEvents();
    if (this.state.page === 'dashboard') this.mountChart();
  }

  bindPageEvents() {
    const content = document.getElementById('content');
    if (!content) return;
    content.querySelectorAll('[data-tf]').forEach(btn => btn.addEventListener('click', () => {
      this.state.selectedTf = btn.dataset.tf;
      this.renderPage();
    }));
    content.querySelectorAll('[data-plan]').forEach(card => card.addEventListener('click', event => {
      if (event.target.closest('button')) return;
      this.state.selectedPlanId = card.dataset.plan;
      const plan = this.state.plans.find(p => p.id === this.state.selectedPlanId);
      if (plan) this.state.selectedTf = plan.timeframe;
      this.renderPage();
    }));
    content.querySelectorAll('[data-cancel-plan]').forEach(btn => btn.addEventListener('click', () => this.cancelPlan(btn.dataset.cancelPlan)));
    content.querySelectorAll('[data-activate-plan]').forEach(btn => btn.addEventListener('click', () => this.manualActivate(btn.dataset.activatePlan)));
    content.querySelector('#runBacktest')?.addEventListener('click', () => this.executeBacktest());
    content.querySelector('#backtestTf')?.addEventListener('change', e => { this.state.backtestTf = e.target.value; });
    const autoTradeForm = content.querySelector('#autoTradeForm');
    autoTradeForm?.addEventListener('submit', e => this.saveAutoTradeSettings(e));
    autoTradeForm?.addEventListener('change', event => {
      if (event.target?.name !== 'liveUnlockPhrase') this.cacheAutoTradeForm(autoTradeForm);
    });
    content.querySelectorAll('[data-auto-step]').forEach(btn => btn.addEventListener('click', () => this.setAutoTradeStep(btn.dataset.autoStep)));
    content.querySelectorAll('[data-auto-next]').forEach(btn => btn.addEventListener('click', () => this.setAutoTradeStep(btn.dataset.autoNext)));
    content.querySelectorAll('[data-auto-prev]').forEach(btn => btn.addEventListener('click', () => this.setAutoTradeStep(btn.dataset.autoPrev)));
    content.querySelector('#authLogin')?.addEventListener('click', () => this.loginAutoTrade());
    content.querySelector('#authLogout')?.addEventListener('click', () => this.logoutAutoTrade());
    content.querySelector('#autoRunNow')?.addEventListener('click', () => this.runAutoTradeNow());
    content.querySelector('#autoPause')?.addEventListener('click', () => this.autoTradeCommand('pause', { reason:'หยุดจากโทรศัพท์' }, 'หยุด Auto Trade แล้ว'));
    content.querySelector('#autoKill')?.addEventListener('click', () => this.killAutoTrade());
    content.querySelector('#autoConfirm')?.addEventListener('click', e => this.confirmAutoTrade(e.currentTarget.dataset.signalId));
    content.querySelector('#brokerTest')?.addEventListener('click', () => this.testBrokerConnection());
    content.querySelector('#refreshAuto')?.addEventListener('click', () => this.refreshAutoTradeStatus(true));
    content.querySelector('#autoReconcile')?.addEventListener('click', () => this.reconcileNow());
    content.querySelectorAll('[data-dl-retry]').forEach(btn => btn.addEventListener('click', () => this.retryDeadLetterItem(btn.dataset.dlRetry)));
    content.querySelectorAll('[data-dl-dismiss]').forEach(btn => btn.addEventListener('click', () => this.dismissDeadLetterItem(btn.dataset.dlDismiss)));
    content.querySelector('#settingsForm')?.addEventListener('submit', e => this.saveSettings(e));
    content.querySelector('#enableNotifications')?.addEventListener('click', () => this.enableNotifications());
    content.querySelector('#exportAll')?.addEventListener('click', () => downloadJson(`goldscope-backup-${Date.now()}.json`, storage.exportAll()));
    content.querySelector('#exportTuning')?.addEventListener('click', () => this.exportTuningProfile());
    content.querySelector('#importTuning')?.addEventListener('click', () => content.querySelector('#tuningFile')?.click());
    content.querySelector('#tuningFile')?.addEventListener('change', async event => {
      const file = event.target.files?.[0];
      event.target.value = '';
      if (file) await this.importTuningProfile(file);
    });
    content.querySelector('#exportJournal')?.addEventListener('click', () => downloadCsv(`goldscope-journal-${Date.now()}.csv`, this.state.journal));
    content.querySelector('#clearData')?.addEventListener('click', () => this.clearData());
    content.querySelector('#resetLearning')?.addEventListener('click', () => this.resetLearning());
  }

  setAutoTradeStep(step) {
    const allowed = ['basic','risk','forward','advanced'];
    if (!allowed.includes(step)) return;
    this.state.autoTradeStep = step;
    sessionSet('goldscope:auto-step', step);
    document.querySelectorAll('[data-auto-step]').forEach(button => {
      const active = button.dataset.autoStep === step;
      button.classList.toggle('active', active);
      button.setAttribute('aria-selected', String(active));
    });
    document.querySelectorAll('[data-auto-panel]').forEach(panel => panel.classList.toggle('active', panel.dataset.autoPanel === step));
    document.querySelector('.auto-setup')?.scrollIntoView({ behavior:'smooth', block:'start' });
  }

  mountChart() {
    const container = document.getElementById('marketChart');
    const analysis = this.state.analyses[this.state.selectedTf];
    if (!container || !analysis) return;
    this.marketChart = new MarketChart(container);
    const plan = this.state.plans.find(p => p.id === this.state.selectedPlanId && p.timeframe === this.state.selectedTf);
    this.marketChart.setData(analysis, plan || null);
  }

  dashboardHtml() {
    const selectedAnalysis = this.state.analyses[this.state.selectedTf] || this.state.analyses['15min'];
    const price = this.state.analyses['1min']?.snapshot.close ?? selectedAnalysis?.snapshot.close;
    const selectedPlan = this.state.plans.find(p => p.id === this.state.selectedPlanId);
    const modeNotice = this.state.marketSource === 'mock' ? `<div class="notice">${icon('info',19)}<div><strong>กำลังใช้กราฟจำลอง</strong><br>เข้าสู่ระบบหรือเลือกข้อมูล Capital.com/Twelve Data ก่อนใช้แผนกับ Broker</div></div>` : this.state.marketSource === 'capital' && this.state.mode === 'demo' ? `<div class="notice">${icon('info',19)}<div><strong>กำลังใช้ราคาจริงจาก Capital.com Demo API</strong><br>กราฟจะขยับตามตลาดจริง แต่คำสั่งและผลลัพธ์อยู่ในบัญชี Demo</div></div>` : '';
    return `${modeNotice}
      <div class="grid grid-4">
        ${this.metric('ราคาล่าสุด', fmtPrice(price), `XAU/USD • ${this.state.marketSource === 'capital' ? `CAPITAL ${String(this.state.autoTrade?.config?.brokerEnvironment || 'demo').toUpperCase()}` : this.state.marketSource === 'twelvedata' ? 'TWELVE DATA' : 'SIMULATED'}`, this.state.bias.direction > 0 ? 'up' : this.state.bias.direction < 0 ? 'down' : '')}
        ${this.metric('Bias รวม', this.state.bias.label, `ความแข็งแรง ${this.state.bias.strength}/100`, this.state.bias.direction > 0 ? 'up' : this.state.bias.direction < 0 ? 'down' : '', true)}
        ${this.metric('สภาวะ M15', this.state.analyses['15min']?.regime || '—', `กรอบเวลาขัดแย้ง ${this.state.bias.conflict}%`, '', true)}
        ${this.metric('แผนที่ผ่านเกณฑ์', `${this.state.plans.length}/${this.state.settings.maxPlans}`, `Candidate ${this.state.candidates.length} รายการ • ขั้นต่ำ ${this.state.settings.minScore}`, '')}
        ${this.metric('Adaptive Learning', this.state.learning?.status || 'รอข้อมูล', `${this.state.learning?.eligibleTrades || 0} ผลที่ใช้เรียนรู้ • ความเชื่อมั่น ${this.state.learning?.overall?.confidence || 0}%`, (this.state.learning?.overall?.expectancyR || 0) > 0 ? 'up' : (this.state.learning?.overall?.expectancyR || 0) < 0 ? 'down' : '', true)}
      </div>
      <div class="grid dashboard-layout" style="margin-top:16px">
        <div class="card chart-card">
          <div class="chart-toolbar">
            <div><div class="card-title">กราฟ XAU/USD</div><div class="card-subtitle">EMA20 / EMA50 • คลิกแผนเพื่อแสดง Entry, SL และ TP</div></div>
            <div class="segmented">${TIMEFRAMES.map(tf => `<button data-tf="${tf}" class="${this.state.selectedTf === tf ? 'active' : ''}">${TIMEFRAME_LABELS[tf]}</button>`).join('')}</div>
          </div>
          <div id="marketChart" class="chart-wrap"></div>
        </div>
        <div class="card">
          <div class="card-header"><div><div class="card-title">แผนที่ดีที่สุด</div><div class="card-subtitle">ระบบเติมแผนใหม่เมื่อแผนเดิมสิ้นสุด</div></div><span class="badge gold">สูงสุด ${this.state.settings.maxPlans}</span></div>
          <div class="plan-list">${this.plansHtml()}</div>
        </div>
      </div>
      <div class="grid grid-2" style="margin-top:16px">
        <div class="card"><div class="card-header"><div><div class="card-title">ภาพรวมหลายกรอบเวลา</div><div class="card-subtitle">ทิศทาง คะแนนแรง แนวโน้ม และความผันผวน</div></div></div>${this.timeframeTable()}</div>
        <div class="card card-pad">${selectedPlan ? this.planDetail(selectedPlan) : this.noPlanDetail()}</div>
      </div>`;
  }

  metric(label, value, foot, className = '', small = false) {
    return `<div class="card metric-card"><div class="metric-label">${esc(label)}</div><div class="metric-value ${small ? 'small' : ''} ${className}">${esc(value)}</div><div class="metric-foot">${esc(foot)}</div></div>`;
  }

  plansHtml() {
    if (!this.state.plans.length) return `<div class="empty-state"><strong>ยังไม่มีแผนที่ผ่านเกณฑ์</strong>ระบบจะไม่สร้างแผนคุณภาพต่ำเพื่อให้ครบจำนวน</div>`;
    return this.state.plans.map(plan => {
      const selected = plan.id === this.state.selectedPlanId;
      return `<article class="plan-card ${selected ? 'selected' : ''}" data-plan="${esc(plan.id)}">
        <div class="plan-top"><div><div class="plan-direction ${plan.direction === 1 ? 'up' : 'down'}">${plan.directionLabel} <span style="color:var(--muted);font-size:12px">${plan.timeframeLabel}</span></div><div class="plan-strategy">${esc(plan.strategy)}</div></div><span class="badge ${plan.direction === 1 ? 'buy' : 'sell'}">${statusLabel(plan.status)}</span></div>
        <div class="plan-price-grid">
          <div class="price-cell"><span>Entry zone</span><strong>${fmtPrice(plan.entryLow)}–${fmtPrice(plan.entryHigh)}</strong></div>
          <div class="price-cell"><span>Stop loss</span><strong class="down">${fmtPrice(plan.stopLoss)}</strong></div>
          <div class="price-cell"><span>TP2</span><strong class="up">${fmtPrice(plan.tp2)}</strong></div>
        </div>
        <div class="plan-meta"><span class="badge gold">Score ${fmtScore(plan.score)}</span><span class="badge">${Number(plan.lot || plan.theoreticalLot || 0).toFixed(3)} lot</span><span class="badge ${Number(plan.estimatedLossPercent || 0) > 5 ? 'warn' : ''}">SL ≈ $${Number(plan.estimatedLossUsd || 0).toFixed(2)} (${Number(plan.estimatedLossPercent || 0).toFixed(1)}%)</span><span class="badge">TP2 ≈ +$${Number(plan.estimatedTp2ProfitUsd || 0).toFixed(2)}</span><span class="badge">R:R ${plan.riskReward}</span><span class="badge ${plan.riskLevel === 'สูง' ? 'warn' : ''}">เสี่ยง${plan.riskLevel}</span><span class="badge">ปิดหลัก ${(plan.exitAtTarget || 'tp2').toUpperCase()}</span><span class="badge">≈ ${Number(plan.expectedBarsToTp2 || 0).toFixed(1)} แท่ง</span>${Math.abs(Number(plan.adaptiveAdjustment || 0)) >= 0.1 ? `<span class="badge ${plan.adaptiveAdjustment < 0 ? 'warn' : 'buy'}">เรียนรู้ ${plan.adaptiveAdjustment > 0 ? '+' : ''}${Number(plan.adaptiveAdjustment).toFixed(1)}</span>` : ''}${Number.isFinite(plan.learnedWinRate) ? `<span class="badge">Win est. ${Number(plan.learnedWinRate).toFixed(1)}%</span>` : ''}${plan.counterTrend ? '<span class="badge warn">สวนแนวโน้ม</span>' : ''}</div>
        <div class="plan-actions">${plan.status === 'WAITING_ENTRY' ? `<button class="ghost-button" data-activate-plan="${esc(plan.id)}">ผมเข้าแล้ว</button>` : ''}<button class="danger-button" data-cancel-plan="${esc(plan.id)}">ยกเลิก</button></div>
      </article>`;
    }).join('');
  }

  timeframeTable() {
    return `<div class="table-wrap"><table class="tf-table"><thead><tr><th>TF</th><th>ทิศ</th><th>แรง</th><th>Buy/Sell</th><th>Regime</th><th>ADX</th></tr></thead><tbody>${TIMEFRAMES.map(tf => {
      const a = this.state.analyses[tf]; if (!a) return '';
      return `<tr><td><strong>${a.label}</strong></td><td class="${a.direction > 0 ? 'up' : a.direction < 0 ? 'down' : 'neutral'}">${a.direction > 0 ? 'ขึ้น' : a.direction < 0 ? 'ลง' : 'กลาง'}</td><td>${Math.round(a.directionStrength)}</td><td><span class="up">${Number(a.snapshot.buyPressure || 50).toFixed(0)}</span>/<span class="down">${Number(a.snapshot.sellPressure || 50).toFixed(0)}</span></td><td>${esc(a.regime)}</td><td>${a.snapshot.adx?.toFixed(1) ?? '—'}</td></tr>`;
    }).join('')}</tbody></table></div>`;
  }

  planDetail(plan) {
    return `<div class="card-title">รายละเอียดแผนที่เลือก</div><div class="card-subtitle">${plan.directionLabel} ${plan.timeframeLabel} • ${esc(plan.strategy)} • หมดอายุ ${fmtTime(plan.expiresAt)}</div>
      <div class="grid grid-3" style="margin-top:14px">
        <div class="price-cell"><span>TP1</span><strong>${fmtPrice(plan.tp1)}</strong></div><div class="price-cell"><span>TP2</span><strong>${fmtPrice(plan.tp2)}</strong></div><div class="price-cell"><span>TP3</span><strong>${fmtPrice(plan.tp3)}</strong></div>
      </div>
      <div class="detail-box"><h4>เงื่อนไขเข้า</h4><div style="font-size:13px;line-height:1.6">${esc(plan.trigger)}</div></div>
      <div class="detail-box"><h4>เหตุผลสนับสนุน</h4><ul class="detail-list">${plan.evidence.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>
      <div class="detail-box"><h4>คำเตือน</h4><ul class="detail-list warning-list">${(plan.warnings.length ? plan.warnings : ['ไม่มีคำเตือนเพิ่มเติม แต่ยังมีความเสี่ยงจากตลาดเสมอ']).map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>
      <div class="detail-box"><h4>แรงซื้อ/ขายและต้นทุนเข้าออร์เดอร์</h4><div style="font-size:13px;line-height:1.65">Buy pressure <strong class="up">${Number(plan.buyPressure || 50).toFixed(1)}%</strong> • Sell pressure <strong class="down">${Number(plan.sellPressure || 50).toFixed(1)}%</strong> • ความเชื่อมั่น proxy ${Number(plan.pressureConfidence || 0).toFixed(0)}%<br>Spread <strong>${Math.round(Number(plan.spreadPoints || 0))} points ($${Number(plan.spreadUsd || 0).toFixed(3)})</strong> • Slippage/กดมือรวม <strong>$${(Number(plan.slippageUsd || 0)+Number(plan.manualBufferUsd || 0)).toFixed(3)}</strong><br>SL ประมาณ <strong>${Math.round(Number(plan.stopPoints || 0))} points</strong> • ต้นทุนคิดเป็น <strong>${Number(plan.executionCostPercent || 0).toFixed(1)}%</strong> ของความเสี่ยง • TP2 ประมาณ ${Number(plan.expectedBarsToTp2 || 0).toFixed(1)} แท่ง</div></div>
      <div class="detail-box"><h4>Adaptive Learning</h4><div style="font-size:13px;line-height:1.65">คะแนนฐาน <strong>${Number(plan.baseScore ?? plan.score).toFixed(0)}</strong> • ปรับจากสถิติ <strong class="${Number(plan.adaptiveAdjustment || 0) > 0 ? 'up' : Number(plan.adaptiveAdjustment || 0) < 0 ? 'down' : ''}">${Number(plan.adaptiveAdjustment || 0) > 0 ? '+' : ''}${Number(plan.adaptiveAdjustment || 0).toFixed(1)}</strong><br>${Number.isFinite(plan.learnedWinRate) ? `Win rate แบบปรับความเชื่อมั่น <strong>${Number(plan.learnedWinRate).toFixed(1)}%</strong> • Expectancy <strong>${Number(plan.learnedExpectancyR || 0).toFixed(3)}R</strong><br>` : ''}<span class="card-subtitle">อ้างอิงประมาณ ${Math.round(Number(plan.learningSamples || 0))} ตัวอย่าง • ความเชื่อมั่น ${Number(plan.learningConfidence || 0).toFixed(0)}% • ไม่ใช่การรับประกันผล</span></div></div>
      <div class="detail-box"><h4>ขนาดออร์เดอร์และผลกระทบต่อพอร์ต</h4><div style="font-size:13px;line-height:1.65">Lot ที่ใช้ <strong>${Number(plan.lot || plan.theoreticalLot || 0).toFixed(3)}</strong> • มูลค่าต่อราคาขยับ $1 <strong>$${Number(plan.valuePerPriceUnit || 0).toFixed(2)}</strong><br>หากโดน SL คาดว่า <strong class="down">-$${Number(plan.estimatedLossUsd || 0).toFixed(2)} (${Number(plan.estimatedLossPercent || 0).toFixed(1)}%)</strong> • มาร์จินประมาณ <strong>$${Number(plan.estimatedMarginUsd || 0).toFixed(2)}</strong> ที่ 1:${Number(plan.leverage || 1)}<br>กำไรประมาณ TP1 <strong class="up">+$${Number(plan.estimatedTp1ProfitUsd || 0).toFixed(2)}</strong> • TP2 <strong class="up">+$${Number(plan.estimatedTp2ProfitUsd || 0).toFixed(2)}</strong> • TP3 <strong class="up">+$${Number(plan.estimatedTp3ProfitUsd || 0).toFixed(2)}</strong><br><span class="card-subtitle">เป้าหมายปิดหลัก ${(plan.exitAtTarget || 'tp2').toUpperCase()} • ต้องตรวจ Contract Specification และราคาจริงก่อนเปิดออร์เดอร์</span></div></div>`;
  }

  noPlanDetail() {
    return `<div class="empty-state"><strong>ไม่มีแผนที่เลือก</strong>ตลาดอาจยังไม่มีจังหวะที่ผ่านคะแนนและ R:R ขั้นต่ำ</div>`;
  }

  analysisHtml() {
    const cards = TIMEFRAMES.map(tf => {
      const a = this.state.analyses[tf];
      if (!a) return '';
      const s = a.snapshot;
      const components = [
        ['Trend', Math.min(100, Math.abs(a.directionScore.net) * 1.4)],
        ['Momentum', Math.min(100, Math.abs((s.rsi - 50) * 2) + Math.min(35, Math.abs(s.roc || 0) * 7))],
        ['Buy/Sell pressure', Math.min(100, Math.abs(Number(s.pressureNet || 0)))],
        ['Structure', a.structure.direction ? 78 : 35],
        ['Volatility', (s.atrPercentile || .5) * 100],
        ['Efficiency', (s.efficiency || 0) * 100]
      ];
      return `<div class="card analysis-section">
        <div class="plan-top"><div><div class="card-title">${a.label} • ${a.direction > 0 ? 'ขาขึ้น' : a.direction < 0 ? 'ขาลง' : 'เป็นกลาง'}</div><div class="card-subtitle">${esc(a.regime)} • ${esc(a.structure.label)}</div></div><span class="badge ${a.direction > 0 ? 'buy' : a.direction < 0 ? 'sell' : ''}">${Math.round(a.directionStrength)}/100</span></div>
        ${components.map(([name, value]) => `<div class="analysis-row"><span>${name}</span><div class="score-bar"><i style="width:${Math.max(0, Math.min(100, value))}%"></i></div><strong>${Math.round(value)}</strong></div>`).join('')}
        <div class="detail-box"><h4>Indicator snapshot</h4><div class="grid grid-3" style="font-size:12px;line-height:1.8"><div>RSI <strong>${s.rsi?.toFixed(1)}</strong><br>ADX <strong>${s.adx?.toFixed(1)}</strong><br>CCI <strong>${s.cci?.toFixed(1)}</strong></div><div>ATR <strong>${fmtPrice(s.atr)}</strong><br>Stoch K <strong>${s.stochasticK?.toFixed(1)}</strong><br>ROC <strong>${s.roc?.toFixed(2)}%</strong></div><div>EMA20 <strong>${fmtPrice(s.ema20)}</strong><br>EMA50 <strong>${fmtPrice(s.ema50)}</strong><br>EMA200 <strong>${fmtPrice(s.ema200)}</strong></div></div><div style="font-size:12px;line-height:1.8;margin-top:10px">แรงซื้อ <strong class="up">${Number(s.buyPressure || 50).toFixed(1)}%</strong> • แรงขาย <strong class="down">${Number(s.sellPressure || 50).toFixed(1)}%</strong> • Shift <strong>${Number(s.pressureShift || 0).toFixed(1)}</strong> • Confidence <strong>${Number(s.pressureConfidence || 0).toFixed(0)}%</strong></div></div>
        <div class="detail-box"><h4>โครงสร้างและระดับ</h4><div style="font-size:12px;line-height:1.75">Swing high: <strong>${fmtPrice(a.structure.lastHigh)}</strong> • Swing low: <strong>${fmtPrice(a.structure.lastLow)}</strong><br>${a.structure.breakType ? `เหตุการณ์ล่าสุด: <strong>${esc(a.structure.breakType)}</strong><br>` : ''}แนวรับใกล้: <strong>${a.levels.supports.slice(0,3).map(x => fmtPrice(x.price)).join(', ') || '—'}</strong><br>แนวต้านใกล้: <strong>${a.levels.resistances.slice(0,3).map(x => fmtPrice(x.price)).join(', ') || '—'}</strong><br>FVG ที่ยังไม่เต็ม: <strong>${a.fvgs.length}</strong></div></div>
      </div>`;
    }).join('');
    return `<div class="notice">${icon('info',19)}<div>คะแนนเป็น “คุณภาพเงื่อนไข” ไม่ใช่เปอร์เซ็นต์รับประกันชนะ ระบบใช้หลายเทคนิคเพื่อลดสัญญาณขัดแย้งและจะหักคะแนนเมื่อข้อมูลเก่า ผันผวนสูง หรือสวนกรอบเวลาใหญ่</div></div><div class="grid grid-2">${cards}</div>`;
  }

  backtestHtml() {
    const result = this.state.lastBacktest;
    const summary = result?.summary;
    return `<div class="card card-pad">
      <div class="plan-top"><div><h2 class="section-title" style="margin-bottom:4px">Walk-forward backtest</h2><div class="card-subtitle">ใช้ Base Algorithm + Adaptive Learning ปัจจุบันแบบแช่แข็งตลอดการทดสอบ คิด spread/slippage และถือหนึ่งแผนต่อครั้ง</div></div><div class="actions-row" style="margin-top:0"><select id="backtestTf" style="background:var(--surface-2);color:var(--text);border:1px solid var(--border);border-radius:10px;padding:9px 12px">${['5min','15min','1h'].map(tf => `<option value="${tf}" ${this.state.backtestTf === tf ? 'selected' : ''}>${TIMEFRAME_LABELS[tf]}</option>`).join('')}</select><button class="primary-button" id="runBacktest">${icon('play',16)} ทดสอบค่าจูนปัจจุบัน</button></div></div>
      <div class="notice" style="margin:18px 0 0">${icon('info',18)}<div>Model ปัจจุบัน <strong>${esc(this.state.learning?.fingerprint || '—')}</strong> • ข้อมูลจูน ${this.state.learning?.eligibleTrades || 0} ผล • ความเชื่อมั่น ${Number(this.state.learning?.overall?.confidence || 0).toFixed(0)}%<br>ผล Backtest จะไม่ถูกนำกลับไปเรียนรู้ เพื่อป้องกันการวนจูนกับข้อมูลชุดเดียว และยังไม่จำลอง spread ที่เปลี่ยนทุก tick หรือข่าวฉับพลัน</div></div>
    </div>
    ${summary ? `<div class="grid grid-4" style="margin-top:16px">
      ${this.metric('จำนวนเทรด', String(summary.trades), `${result.timeframe} • ${result.candles} candles • ปรับคะแนน ${result.adaptive?.adjustedTrades || 0} เทรด`)}
      ${this.metric('Win rate', fmtPct(summary.winRate), `${summary.wins} ชนะ / ${summary.losses} แพ้`, summary.winRate >= 50 ? 'up' : 'down')}
      ${this.metric('Profit factor', String(summary.profitFactor), `Expectancy ${summary.expectancyR}R`, summary.profitFactor >= 1 ? 'up' : 'down')}
      ${this.metric('Net / Drawdown', `${summary.netR}R`, `Max DD ${summary.maxDrawdownR}R`, summary.netR > 0 ? 'up' : 'down')}
    </div>
    <div class="grid grid-2" style="margin-top:16px">
      <div class="card card-pad"><div class="card-title">Equity curve (R)</div><div class="card-subtitle">เส้นทุนสะสมตามลำดับแผน</div>${this.equitySvg(summary.curve)}</div>
      <div class="card"><div class="card-header"><div><div class="card-title">รายการล่าสุด</div><div class="card-subtitle">แสดงสูงสุด 30 รายการ</div></div></div><div class="table-wrap" style="max-height:320px"><table class="data-table"><thead><tr><th>เวลา</th><th>Setup</th><th>ทิศ</th><th>Score</th><th>Learn</th><th>ผล</th><th>R</th></tr></thead><tbody>${result.trades.slice(-30).reverse().map(t => `<tr><td>${fmtTime(t.entryTime*1000)}</td><td>${esc(t.setup)}</td><td class="${t.direction==='BUY'?'up':'down'}">${t.direction}</td><td>${fmtScore(t.score)}</td><td class="${Number(t.adaptiveAdjustment||0)>0?'up':Number(t.adaptiveAdjustment||0)<0?'down':''}">${Number(t.adaptiveAdjustment||0)>0?'+':''}${Number(t.adaptiveAdjustment||0).toFixed(1)}</td><td>${t.outcome}</td><td class="${t.resultR>0?'up':t.resultR<0?'down':''}">${t.resultR}</td></tr>`).join('')}</tbody></table></div></div>
    </div>` : `<div class="card empty-state" style="margin-top:16px"><strong>ยังไม่มีผล Backtest</strong>เลือกกรอบเวลาแล้วกดเริ่มทดสอบ</div>`}`;
  }

  equitySvg(curve) {
    if (!curve?.length) return '<div class="empty-state">ไม่มีข้อมูล</div>';
    const width = 720, height = 210, pad = 18;
    const values = curve.map(p => p.equity);
    const min = Math.min(0, ...values), max = Math.max(0, ...values);
    const span = Math.max(1, max - min);
    const points = curve.map((p, i) => {
      const x = pad + i / Math.max(1, curve.length - 1) * (width - pad * 2);
      const y = height - pad - (p.equity - min) / span * (height - pad * 2);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');
    const zeroY = height - pad - (0 - min) / span * (height - pad * 2);
    return `<svg class="equity-chart" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none"><line x1="${pad}" y1="${zeroY}" x2="${width-pad}" y2="${zeroY}" stroke="rgba(255,255,255,.12)" stroke-dasharray="4 5"/><polyline fill="none" stroke="#e7b83f" stroke-width="3" points="${points}" vector-effect="non-scaling-stroke"/></svg>`;
  }

  journalHtml() {
    const j = this.state.journal;
    const learning = this.state.learning || buildAdaptiveModel(this.learningSourceRecords(), this.state.settings, this.state.mode);
    const leaders = learningLeaderboard(learning, 12);
    const completed = j.filter(p => p.resultR > 0).length;
    const stopped = j.filter(p => p.resultR < 0).length;
    const netR = j.reduce((s,p) => s + (Number(p.resultR) || 0), 0);
    const modelClass = learning.overall.expectancyR > 0 ? 'up' : learning.overall.expectancyR < 0 ? 'down' : '';
    return `<div class="grid grid-4">
      ${this.metric('แผนที่จบแล้ว', String(j.length), 'เก็บในอุปกรณ์นี้')}
      ${this.metric('ผลบวก', String(completed), j.length ? fmtPct(completed/j.length*100) : '0%', 'up')}
      ${this.metric('ผลลบ', String(stopped), j.length ? fmtPct(stopped/j.length*100) : '0%', 'down')}
      ${this.metric('ผลรวมจำลอง', `${netR.toFixed(2)}R`, 'ไม่ใช่ผลกำไรเงินจริง', netR>0?'up':netR<0?'down':'')}
    </div>
    <div class="card card-pad" style="margin-top:16px">
      <div class="card-header"><div><div class="card-title">Adaptive Learning model</div><div class="card-subtitle">เรียนรู้จากแผนที่ถึง TP/SL แล้วเท่านั้น และปรับคะแนนของแผนในอนาคต</div></div><span class="badge gold">${esc(learning.status)}</span></div>
      <div class="grid grid-4" style="margin-top:14px">
        ${this.metric('ผลที่ใช้เรียนรู้', String(learning.eligibleTrades), `น้ำหนักจริง ${Number(learning.effectiveTrades || 0).toFixed(1)} • ละเว้น ${learning.excludedTrades}`)}
        ${this.metric('Win rate ปรับแล้ว', `${learning.overall.winRate.toFixed(1)}%`, `ดิบ ${learning.overall.rawWinRate.toFixed(1)}%`, modelClass)}
        ${this.metric('Expectancy ปรับแล้ว', `${learning.overall.expectancyR.toFixed(3)}R`, `ดิบ ${learning.overall.rawExpectancyR.toFixed(3)}R`, modelClass)}
        ${this.metric('ความเชื่อมั่นโมเดล', `${learning.overall.confidence.toFixed(0)}%`, `ขั้นต่ำ ${learning.minimumSamples} • lookback ${learning.lookback}`)}
      </div>
      <div class="notice" style="margin-top:14px">${icon('info',18)}<div>ระบบใช้ Bayesian shrinkage, น้ำหนักข้อมูลล่าสุด และน้ำหนักตามแหล่งข้อมูล โดย Live = 100%, Mixed = ${Number(this.state.settings.learningMixedWeight || 0).toFixed(2)}, Demo = ${Number(this.state.settings.learningDemoWeight || 0).toFixed(2)} พร้อมจำกัดการปรับคะแนนไม่เกิน ±${this.state.settings.learningMaxAdjustment} คะแนน</div></div>
      <div class="table-wrap" style="max-height:320px;margin-top:12px"><table class="data-table"><thead><tr><th>กลุ่มรูปแบบ</th><th>ตัวอย่าง/น้ำหนัก</th><th>Win rate</th><th>Expectancy</th><th>PF</th><th>ความเชื่อมั่น</th><th>ปรับคะแนน</th></tr></thead><tbody>${leaders.length ? leaders.map(row => `<tr><td>${esc(row.label)}</td><td>${row.samples} / ${Number(row.effectiveSamples || row.samples).toFixed(1)}</td><td>${row.winRate.toFixed(1)}%</td><td class="${row.expectancyR>0?'up':row.expectancyR<0?'down':''}">${row.expectancyR.toFixed(3)}R</td><td>${row.profitFactor.toFixed(2)}</td><td>${row.confidence.toFixed(0)}%</td><td class="${row.adjustment>0?'up':row.adjustment<0?'down':''}">${row.adjustment>0?'+':''}${row.adjustment.toFixed(2)}</td></tr>`).join('') : '<tr><td colspan="7" style="text-align:center;padding:28px;color:var(--muted)">ยังมีข้อมูลไม่พอสำหรับแสดงกลุ่มที่นำไปปรับคะแนน</td></tr>'}</tbody></table></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="card-header"><div><div class="card-title">Trade journal</div><div class="card-subtitle">บันทึกผลของแผนระบบอัตโนมัติ</div></div><div class="actions-row" style="margin-top:0"><button class="ghost-button" id="exportJournal">${icon('download',16)} CSV</button></div></div>
      <div class="table-wrap" style="max-height:640px"><table class="data-table"><thead><tr><th>สิ้นสุด</th><th>แผน</th><th>TF</th><th>ทิศ</th><th>Entry</th><th>SL</th><th>TP2</th><th>ผล</th><th>R</th><th>Score</th><th>Learn</th></tr></thead><tbody>${j.length ? j.map(p => `<tr><td>${fmtTime(p.endedAt)}</td><td>${esc(p.strategy)}</td><td>${p.timeframeLabel}</td><td class="${p.direction===1?'up':'down'}">${p.directionLabel}</td><td>${fmtPrice(p.entry)}</td><td>${fmtPrice(p.stopLoss)}</td><td>${fmtPrice(p.tp2)}</td><td>${esc(p.outcome || statusLabel(p.status))}</td><td class="${p.resultR>0?'up':p.resultR<0?'down':''}">${p.resultR ?? '—'}</td><td>${fmtScore(p.score)}</td><td>${Number(p.adaptiveAdjustment || 0)>0?'+':''}${Number(p.adaptiveAdjustment || 0).toFixed(1)}</td></tr>`).join('') : '<tr><td colspan="11" style="text-align:center;padding:40px;color:var(--muted)">ยังไม่มีประวัติ</td></tr>'}</tbody></table></div>
    </div>`;
  }

  async refreshAuthSession() {
    try {
      const session = await getAuthSession();
      this.state.authenticated = true;
      this.state.authExpiresAt = Number(session.expiresAt || 0);
      this.state.accountKey = session.accountKey || getActiveAccountKey();
      this.state.authError = null;
      return true;
    } catch (error) {
      this.state.authenticated = false;
      this.state.authExpiresAt = 0;
      this.state.authError = error.code === 'AUTH_NOT_CONFIGURED' ? error.message : null;
      return false;
    }
  }

  async loginAutoTrade() {
    const password = String(document.querySelector('[name="adminPassword"]')?.value || '');
    if (!password) return this.toast('กรอกรหัสผ่านผู้ดูแลระบบ');
    this.setLoading(true, 'กำลังเข้าสู่ระบบอย่างปลอดภัย…');
    try {
      const session = await login(password);
      this.state.authenticated = true;
      this.state.authExpiresAt = Number(session.expiresAt || 0);
      this.state.accountKey = session.accountKey || getActiveAccountKey();
      this.state.authError = null;
      const input = document.querySelector('[name="adminPassword"]');
      if (input) input.value = '';
      await this.refreshAutoTradeStatus();
      this.toast('เข้าสู่ระบบแล้ว');
    } catch (error) {
      this.state.authenticated = false;
      this.state.authError = error.message;
      this.toast(`เข้าสู่ระบบไม่สำเร็จ: ${error.message}`);
    } finally {
      this.setLoading(false);
      this.renderPage();
    }
  }

  async logoutAutoTrade() {
    try { await logout(); } catch {}
    this.state.authenticated = false;
    this.state.autoTrade = null;
    this.state.autoTradeCloudLoaded = false;
    this.state.authExpiresAt = 0;
    this.toast('ออกจากระบบแล้ว');
    this.renderPage();
  }

  async refreshAutoTradeStatus(showToast = false) {
    if (!this.state.authenticated && !(await this.refreshAuthSession())) {
      this.state.autoTradeError = 'กรุณาเข้าสู่ระบบเพื่ออ่านสถานะ Cloud Auto';
      if (showToast) this.toast(this.state.autoTradeError);
      if (this.state.page === 'autotrade') this.renderPage();
      return;
    }
    try {
      const results = await Promise.allSettled([
        getAutoTradeStatus(), getSystemHealth(), getDeadLetters(), getNotificationEvents(30), getForwardTestStatus()
      ]);
      if (results[0].status === 'rejected') throw results[0].reason;
      this.applyAutoTradePayload(results[0].value);
      if (results[1].status === 'fulfilled') this.state.systemHealth = results[1].value;
      if (results[2].status === 'fulfilled') this.state.deadLetters = results[2].value.items || [];
      if (results[3].status === 'fulfilled') this.state.notificationEvents = results[3].value.items || [];
      if (results[4].status === 'fulfilled') this.state.forwardTestStatus = results[4].value;
      this.state.autoTradeError = null;
      if (showToast) this.toast('อัปเดตสถานะ Auto Trade และระบบ Cloud แล้ว');
    } catch (error) {
      if (error.status === 401) this.state.authenticated = false;
      this.state.autoTradeError = error.message;
      if (showToast) this.toast(`อ่านสถานะ Auto Trade ไม่สำเร็จ: ${error.message}`);
    }
    if (this.state.page === 'autotrade') this.renderPage();
  }

  cacheAutoTradeForm(form) {
    if (!form) return null;
    const numeric = ['minScore','maxOpenPositions','maxTradesPerDay','maxLossPerTradeUsd','riskPercentPerTrade','maxDailyLossUsd','maxConsecutiveLosses','cooldownMinutes','maxSpreadUsd','entryToleranceUsd','orderSize','pnlReferenceSize','pnlPerUsdMoveAtReferenceSize','requireFreshCandleSeconds','maxWeeklyLossUsd','maxDrawdownPercent','maxMarginUsagePercent','maxReconciliationMismatch','forwardTestSlippageUsd','modelDriftRecentTrades','modelDriftBaselineTrades'];
    const base = {
      ...DEFAULT_AUTO_TRADE_CONFIG,
      ...(this.state.autoTradeDisplayConfig || {}),
      ...(this.state.autoTrade?.config || {})
    };
    const data = new FormData(form);
    for (const [key, value] of data.entries()) {
      if (key === 'liveUnlockPhrase') continue;
      base[key] = numeric.includes(key) ? Number(value) : value;
    }
    base.enabled = Boolean(form.elements.enabled?.checked);
    base.useBrokerMinimumSize = Boolean(form.elements.useBrokerMinimumSize?.checked);
    base.forwardTestEnabled = Boolean(form.elements.forwardTestEnabled?.checked);
    base.pauseAdaptiveOnDrift = Boolean(form.elements.pauseAdaptiveOnDrift?.checked);
    const snapshot = saveAutoTradeDisplaySnapshot(base);
    this.state.autoTradeDisplayConfig = snapshot.config;
    this.state.autoTradeConfigCachedAt = snapshot.savedAt;
    return snapshot.config;
  }

  async saveAutoTradeSettings(event) {
    event.preventDefault();
    if (!this.state.authenticated) return this.toast('เข้าสู่ระบบก่อนบันทึก Cloud Auto');
    const form = event.currentTarget;
    this.cacheAutoTradeForm(form);
    const data = new FormData(form);
    const current = this.state.autoTrade?.config || {};
    const numeric = ['minScore','maxOpenPositions','maxTradesPerDay','maxLossPerTradeUsd','riskPercentPerTrade','maxDailyLossUsd','maxConsecutiveLosses','cooldownMinutes','maxSpreadUsd','entryToleranceUsd','orderSize','pnlReferenceSize','pnlPerUsdMoveAtReferenceSize','requireFreshCandleSeconds','maxWeeklyLossUsd','maxDrawdownPercent','maxMarginUsagePercent','maxReconciliationMismatch','forwardTestSlippageUsd','modelDriftRecentTrades','modelDriftBaselineTrades'];
    const config = { ...current };
    let unlockPhrase = '';
    for (const [key, value] of data.entries()) {
      if (key === 'liveUnlockPhrase') { unlockPhrase = String(value || ''); continue; }
      config[key] = numeric.includes(key) ? Number(value) : value;
    }
    config.enabled = Boolean(form.elements.enabled?.checked);
    config.useBrokerMinimumSize = Boolean(form.elements.useBrokerMinimumSize?.checked);
    config.forwardTestEnabled = Boolean(form.elements.forwardTestEnabled?.checked);
    config.pauseAdaptiveOnDrift = Boolean(form.elements.pauseAdaptiveOnDrift?.checked);
    config.syncAlgorithm = true;
    config.liveTradingUnlocked = false;
    config.liveUnlockPhrase = '';
    Object.assign(config, this.composeAutoTradeConfig(config));
    this.setLoading(true, 'กำลังบันทึก Auto Trade บน Cloudflare…');
    try {
      let payload = await saveAutoTradeConfig(config);
      this.applyAutoTradePayload(payload);
      if (config.brokerEnvironment === 'live' && ['confirm','auto'].includes(config.executionMode) && unlockPhrase === 'LIVE') {
        payload = await autoTradeAction('live-unlock', { body: { phrase: unlockPhrase, expiresMinutes: 15 } });
        this.applyAutoTradePayload(payload);
      }
      this.toast(config.brokerEnvironment === 'live' && config.executionMode !== 'paper' ? 'บันทึกแล้ว ระบบจะปลดล็อก Live ได้ต่อเมื่อ Readiness Gate ผ่าน' : 'บันทึกการตั้งค่า Auto Trade แล้ว');
    } catch (error) {
      this.toast(`บันทึกไม่สำเร็จ: ${error.message}${error.requestId ? ` • ${error.requestId}` : ''}`);
    } finally {
      this.setLoading(false);
      this.renderPage();
    }
  }

  async autoTradeCommand(path, body = {}, successMessage = 'ดำเนินการแล้ว') {
    if (!this.state.authenticated) return this.toast('เข้าสู่ระบบก่อนสั่งงาน Auto Trade');
    this.setLoading(true, 'กำลังสั่งงาน Auto Trade…');
    try {
      const payload = await autoTradeAction(path, { body });
      this.applyAutoTradePayload(payload);
      this.toast(successMessage);
    } catch (error) {
      if (error.status === 401) this.state.authenticated = false;
      this.toast(`คำสั่งไม่สำเร็จ: ${error.message}${error.requestId ? ` • ${error.requestId}` : ''}`);
    } finally {
      this.setLoading(false);
      this.renderPage();
    }
  }

  async runAutoTradeNow() {
    await this.autoTradeCommand('run', { trigger:'manual' }, 'สแกนและประมวลผล Auto Trade แล้ว');
  }

  async confirmAutoTrade(signalId) {
    if (!signalId) return this.toast('ไม่พบสัญญาณที่รอยืนยัน');
    const ok = await confirmDialog({
      title: 'ยืนยันส่งคำสั่งไปยัง Broker',
      message: 'ระบบจะตรวจราคา สถานะตลาด Position ที่เปิดอยู่ และ Risk Gate ซ้ำอีกครั้งก่อนส่ง',
      detail: 'หากราคาออกนอก Entry zone หรือข้อมูลไม่สด ระบบจะยกเลิกโดยไม่ส่งคำสั่ง',
      confirmLabel: 'ตรวจและส่งคำสั่ง'
    });
    if (!ok) return;
    window.__goldscopeCriticalAction = true;
    try { await this.autoTradeCommand('confirm', { signalId }, 'ส่งสัญญาณยืนยันไปยัง Broker แล้ว'); }
    finally { window.__goldscopeCriticalAction = false; window.dispatchEvent(new Event('goldscope:critical-action-complete')); }
  }

  async reconcileNow() {
    if (!this.state.authenticated) return this.toast('เข้าสู่ระบบก่อนตรวจสอบ Broker');
    this.setLoading(true, 'กำลัง Reconcile กับ Broker…');
    try { await reconcileAutoTrade(); await this.refreshAutoTradeStatus(); this.toast('ตรวจสอบสถานะ Broker และ Order Intent แล้ว'); }
    catch (error) { this.toast(`Reconcile ไม่สำเร็จ: ${error.message}`); }
    finally { this.setLoading(false); this.renderPage(); }
  }

  async retryDeadLetterItem(id) {
    if (!(await confirmDialog({ title: 'ส่ง Dead Letter กลับเข้าคิว', message: 'ระบบจะสร้างข้อความใหม่และยังคงตรวจ idempotency ก่อนทำงาน', confirmLabel: 'ส่งกลับเข้าคิว' }))) return;
    try { await retryDeadLetter(id); await this.refreshAutoTradeStatus(); this.toast('ส่ง Dead Letter กลับเข้าคิวแล้ว'); }
    catch (error) { this.toast(`Retry ไม่สำเร็จ: ${error.message}`); }
  }

  async dismissDeadLetterItem(id) {
    if (!(await confirmDialog({ title: 'ปิดรายการ Dead Letter', message: 'รายการนี้จะถูกทำเครื่องหมายว่าไม่ต้องดำเนินการต่อ แต่ประวัติ audit ยังถูกเก็บไว้', confirmLabel: 'ปิดรายการ' }))) return;
    try { await dismissDeadLetter(id); await this.refreshAutoTradeStatus(); this.toast('ปิดรายการ Dead Letter แล้ว'); }
    catch (error) { this.toast(`ปิดรายการไม่สำเร็จ: ${error.message}`); }
  }

  async killAutoTrade() {
    const ok = await confirmDialog({
      title: 'เปิดใช้ Kill Switch',
      message: 'ระบบจะหยุดคำสั่งใหม่ ยกเลิก Intent ที่ยังไม่ส่ง ล้างสัญญาณรอ และล็อก Live mode',
      detail: 'สถานะที่เปิดอยู่ใน Broker จะไม่ถูกปิดอัตโนมัติ และระบบยังคง Reconcile ต่อ',
      confirmLabel: 'หยุดระบบทันที',
      danger: true,
      requireText: 'KILL'
    });
    if (!ok) return;
    await this.autoTradeCommand('kill', {}, 'หยุดฉุกเฉินและล็อก Live mode แล้ว');
  }

  async testBrokerConnection() {
    if (!this.state.authenticated) return this.toast('เข้าสู่ระบบก่อนทดสอบ Broker');
    const form = document.getElementById('autoTradeForm');
    this.setLoading(true, 'กำลังตรวจบัญชีและตลาด Gold ที่ Capital.com…');
    try {
      const payload = await autoTradeAction('broker-test', {
        body: {
          environment: form?.elements?.brokerEnvironment?.value || 'demo',
          epic: form?.elements?.instrumentEpic?.value || '',
          searchTerm: form?.elements?.instrumentSearch?.value || 'Gold',
          accountId: form?.elements?.accountId?.value || ''
        }
      });
      if (payload.accountKey) {
        this.state.accountKey = setActiveAccountKey(payload.accountKey);
        const config = this.composeAutoTradeConfig({
          ...(this.state.autoTrade?.config || DEFAULT_AUTO_TRADE_CONFIG),
          brokerEnvironment: payload.environment,
          accountId: payload.account?.accountId || '',
          instrumentEpic: payload.market?.epic || ''
        });
        const saved = await saveAutoTradeConfig(config);
        this.applyAutoTradePayload(saved);
      }
      this.toast(`เชื่อมต่อสำเร็จ: ${payload.market?.epic || 'Gold'} • Balance ${payload.account?.balance ?? '—'} ${payload.account?.currency || ''} • State แยกที่ ${payload.accountKey || 'บัญชีนี้'}`);
    } catch (error) {
      this.toast(`เชื่อมต่อ Broker ไม่สำเร็จ: ${error.message}`);
    } finally {
      this.setLoading(false);
      this.renderPage();
    }
  }

  autoTradeHtml() {
    const payload = this.state.autoTrade || {};
    const cloudConfig = payload.config && Object.keys(payload.config).length ? payload.config : null;
    const cachedConfig = this.state.autoTradeDisplayConfig || null;
    const config = {
      ...DEFAULT_AUTO_TRADE_CONFIG,
      ...(cachedConfig || {}),
      ...(cloudConfig || {})
    };
    const state = payload.state || {};
    const account = state.brokerAccount || {};
    const daily = state.daily || {};
    const signal = state.pendingSignal || (state.status === 'AWAITING_CONFIRMATION' ? state.lastSignal : null);
    const plan = signal?.plan;
    const paper = state.paperPosition;
    const brokerReady = Boolean(this.state.health?.brokerConfigured);
    const authReady = Boolean(this.state.health?.authenticationConfigured);
    const modeClass = config.brokerEnvironment === 'live' && config.executionMode !== 'paper' ? 'down' : config.executionMode === 'auto' ? 'gold' : config.executionMode === 'confirm' ? 'gold' : 'up';
    const learning = state.learningSummary || {};
    const logs = (state.logs || []).slice(0, 30);
    const operations = this.state.systemHealth?.operations || {};
    const deadLetters = this.state.deadLetters || [];
    const forward = this.state.forwardTestStatus?.stored || state.forwardTest || {};
    const providers = operations.providers || [];
    const loginRequired = !this.state.authenticated;
    const configSource = cloudConfig ? 'Cloudflare' : cachedConfig ? 'ค่าล่าสุดในอุปกรณ์' : 'ค่าเริ่มต้น';
    const wizardStep = ['basic','risk','forward','advanced'].includes(this.state.autoTradeStep) ? this.state.autoTradeStep : 'basic';
    const wizardSteps = [
      ['basic','1','พื้นฐาน','เชื่อมบัญชีและเลือกโหมด'],
      ['risk','2','ความเสี่ยง','กำหนดเพดานการขาดทุน'],
      ['forward','3','Forward Test','ทดสอบแบบ Shadow'],
      ['advanced','4','ขั้นสูง','Drift, Live และคำสั่งระบบ']
    ];
    const cachedNotice = !cloudConfig && cachedConfig
      ? `<div class="notice">${icon('info',19)}<div><strong>กำลังแสดงค่าที่จำไว้ในอุปกรณ์</strong><br>บันทึกล่าสุด ${fmtTime(this.state.autoTradeConfigCachedAt)} • เข้าสู่ระบบแล้วกดอัปเดตเพื่อยืนยันค่าจริงจาก Cloudflare รหัสผ่านและคำปลดล็อก LIVE จะไม่ถูกเก็บใน localStorage</div></div>`
      : '';
    const setupNotice = this.state.autoTradeError && !loginRequired
      ? `<div class="notice danger-notice">${icon('info',19)}<div><strong>ยังอ่าน Auto Trade backend ไม่ได้</strong><br>${esc(this.state.autoTradeError)} — ตรวจ Worker, Durable Object และเครือข่าย</div></div>`
      : !brokerReady || !authReady
        ? `<div class="notice">${icon('info',19)}<div><strong>ยังตั้งค่า Cloudflare Secrets ไม่ครบ</strong><br>ต้องมี ADMIN_CREDENTIAL_HASH, SESSION_SIGNING_SECRET และ Capital.com secrets โดยเริ่มทดสอบจาก Demo เท่านั้น</div></div>`
        : loginRequired && !cachedConfig
          ? `<div class="notice">${icon('info',19)}<div><strong>เข้าสู่ระบบเพื่อโหลดค่าจริงจาก Cloudflare</strong><br>Session ใช้ cookie แบบ HttpOnly และมีอายุจำกัด</div></div>`
          : '';

    return `${cachedNotice}${setupNotice}
      <div class="auto-hero card card-pad">
        <div><span class="badge ${modeClass}">${esc(String(config.executionMode || 'paper').toUpperCase())}</span><h2>Cloud Auto Trade</h2><p>Cloudflare สแกนทุก 1 นาที แม้ปิดหน้าจอโทรศัพท์ • Broker: Capital.com REST API • ค่าเริ่มต้น Paper mode</p></div>
        <div class="actions-row" style="margin-top:0"><button class="ghost-button" id="refreshAuto">${icon('refresh',16)} อัปเดต</button><button class="danger-button" id="autoKill">KILL SWITCH</button></div>
      </div>
      <div class="grid grid-4" style="margin-top:16px">
        ${this.metric('สถานะระบบ', state.status || 'ยังไม่เชื่อม', state.lastDecision || 'รอตั้งค่า', state.status === 'ERROR' || state.status === 'KILLED' ? 'down' : state.status === 'POSITION_OPEN' || state.status === 'ORDER_SENT' ? 'up' : '', true)}
        ${this.metric('บัญชี Broker', Number.isFinite(Number(account.balance)) ? `${Number(account.balance).toFixed(2)} ${account.currency || ''}` : 'ยังไม่อ่าน', `${account.accountName || account.accountId || 'ยังไม่ทราบบัญชี'} • ${String(config.brokerEnvironment).toUpperCase()} • Available ${Number.isFinite(Number(account.available)) ? Number(account.available).toFixed(2) : '—'}`, '', true)}
        ${this.metric('ผลวันนี้', `${Number(daily.realizedPnlUsd || 0) >= 0 ? '+' : ''}$${Number(daily.realizedPnlUsd || 0).toFixed(2)}`, `${daily.trades || 0}/${config.maxTradesPerDay} trades • สัปดาห์ ${Number(state.weekly?.realizedPnlUsd || 0).toFixed(2)} USD • DD ${Number(state.currentDrawdownPercent || 0).toFixed(1)}%`, Number(daily.realizedPnlUsd || 0) > 0 ? 'up' : Number(daily.realizedPnlUsd || 0) < 0 ? 'down' : '')}
        ${this.metric('ตลาด', state.resolvedEpic || 'Gold', `${state.market?.marketStatus || 'รอข้อมูล'} • Spread $${Number(state.market?.spreadUsd || 0).toFixed(3)} • Risk/order ≤ $${Number(config.maxLossPerTradeUsd || 0).toFixed(2)}`, Number(state.market?.spreadUsd || 0) > Number(config.maxSpreadUsd || .8) ? 'down' : '', true)}
      </div>
      <div class="grid grid-4" style="margin-top:16px">
        ${this.metric('Forward Test', `${forward.closed || 0}/${forward.signals || 0} ปิด`, `Expectancy ${Number(forward.expectancyR || 0).toFixed(3)}R • ${Number(forward.days || 0).toFixed(1)} วัน • P/L ${Number(forward.pnl || 0).toFixed(2)}`, Number(forward.expectancyR || 0) > 0 ? 'up' : Number(forward.expectancyR || 0) < 0 ? 'down' : '')}
        ${this.metric('Execution Safety', `${Object.keys(state.orderIntents || {}).length} intents`, `รอส่ง ${Object.keys(state.pendingExecutions || {}).length} • mismatch ${state.reconciliationMismatch || 0}/${config.maxReconciliationMismatch} • drift ${state.modelDrift?.status || 'รอข้อมูล'}`, Number(state.reconciliationMismatch || 0) > Number(config.maxReconciliationMismatch || 1) || state.modelDrift?.status === 'DRIFT' ? 'down' : '')}
        ${this.metric('Cloud Health', operations.configured ? 'D1 ออนไลน์' : 'รอตรวจ', `Providers ${providers.length} • Queue types ${Object.keys(operations.queues || {}).length}`, operations.deadLetters > 0 ? 'down' : 'up')}
        ${this.metric('Dead Letter', `${deadLetters.length} รายการ`, deadLetters.length ? 'ควรตรวจสอบก่อนเปิด Live' : 'ไม่มีงานล้มเหลวค้าง', deadLetters.length ? 'down' : 'up')}
      </div>

      <div class="grid grid-2" style="margin-top:16px">
        <form class="card card-pad auto-setup" id="autoTradeForm">
          <div class="auto-setup-heading">
            <div><h2 class="section-title">ตั้งค่า Auto Trade แบบเป็นขั้นตอน</h2><div class="card-subtitle">ค่าที่แสดงจาก: <strong>${esc(configSource)}</strong>${cloudConfig ? ' • ตรงกับ Cloud Bot ล่าสุด' : ' • ใช้ช่วยจำจนกว่าจะโหลด Cloudflare'}</div></div>
            <span class="badge gold">ขั้น ${wizardSteps.findIndex(([key]) => key === wizardStep) + 1}/4</span>
          </div>
          <nav class="setup-steps" aria-label="ขั้นตอนตั้งค่า Auto Trade">
            ${wizardSteps.map(([key,number,label,description]) => `<button type="button" class="setup-step ${wizardStep===key?'active':''}" data-auto-step="${key}" aria-selected="${wizardStep===key}"><span>${number}</span><div><strong>${label}</strong><small>${description}</small></div></button>`).join('')}
          </nav>

          <section class="setup-panel ${wizardStep==='basic'?'active':''}" data-auto-panel="basic">
            <div class="setup-panel-title"><div><span>ขั้นที่ 1</span><h3>บัญชี โหมด และตลาด</h3><p>เริ่มจาก Paper หรือ Capital.com Demo ก่อน ระบบไม่เปิด Live เป็นค่าเริ่มต้น</p></div></div>
            <div class="form-grid">
              ${!this.state.authenticated ? this.textField('adminPassword','รหัสผ่านผู้ดูแล','','password','ใช้สร้าง session ชั่วคราวและไม่เก็บใน localStorage') : `<div class="field field-wide"><label>Session</label><div class="notice"><div><strong>เข้าสู่ระบบแล้ว</strong><br>บัญชีสถานะ: ${esc(this.state.accountKey)} • หมดอายุ ${fmtTime(this.state.authExpiresAt)}</div></div></div>`}
              ${this.checkboxField('enabled','เปิดวงจร Auto Trade',config.enabled,'เมื่อเปิดแล้ว Cron จะสแกนทุก 1 นาที แม้ปิด PWA')}
              ${this.selectField('executionMode','โหมดส่งคำสั่ง',config.executionMode,[['paper','Paper — จำลองใน GoldScope'],['confirm','Confirm — ต้องกดยืนยัน'],['auto','Auto — ส่ง Broker อัตโนมัติ']],'Demo รองรับ Confirm และ Auto; Live ต้องผ่าน Readiness Gate')}
              ${this.selectField('brokerEnvironment','บัญชี Capital.com',config.brokerEnvironment,[['demo','Demo API — เงินจำลอง'],['live','Live API —เงินจริง']],'Demo และ Live แยก state, ledger และ model')}
              ${this.textField('accountId','Capital.com Account ID',config.accountId || '','text','กรอกบัญชีที่ต้องการใช้จริงเพื่อป้องกันส่งผิดบัญชี')}
              ${this.textField('instrumentSearch','คำค้นตลาด',config.instrumentSearch || 'Gold','text','ระบบค้น Epic ของ Gold อัตโนมัติ')}
              ${this.textField('instrumentEpic','Epic (เว้นว่างได้)',config.instrumentEpic || '','text','กรอกเมื่อบัญชีใช้ Epic เฉพาะ')}
              ${this.selectField('timeframe','กรอบเวลาหลัก',config.timeframe,[['1min','M1'],['5min','M5 — แนะนำ'],['15min','M15'],['1h','H1']])}
              ${this.numberField('minScore','คะแนนขั้นต่ำ',config.minScore,60,95,1,'คะแนนต่ำกว่านี้จะเป็น WAIT/NO_TRADE')}
            </div>
            <div class="setup-actions">
              <div>${!this.state.authenticated ? '<button class="primary-button" type="button" id="authLogin">เข้าสู่ระบบ</button>' : '<button class="ghost-button" type="button" id="authLogout">ออกจากระบบ</button>'}<button class="ghost-button" type="button" id="brokerTest">ทดสอบ Broker</button></div>
              <button class="primary-button" type="button" data-auto-next="risk">ถัดไป: ความเสี่ยง</button>
            </div>
          </section>

          <section class="setup-panel ${wizardStep==='risk'?'active':''}" data-auto-panel="risk">
            <div class="setup-panel-title"><div><span>ขั้นที่ 2</span><h3>ขนาดคำสั่งและ Risk Guard</h3><p>ระบบจะงดเทรดหากขนาดขั้นต่ำของ Broker ทำให้ความเสี่ยงเกินเพดาน</p></div></div>
            <div class="form-grid">
              ${this.numberField('orderSize','ขนาดคำสั่ง Broker',config.orderSize,.0001,100000,.0001,'ใช้หน่วย size ตาม Specification ของ Capital.com ไม่ตีความเป็น MT5 lot โดยอัตโนมัติ')}
              ${this.numberField('pnlReferenceSize','ขนาดอ้างอิง P/L',config.pnlReferenceSize || config.orderSize,.0001,100000,.0001,'ปกติใส่เท่ากับขนาดคำสั่ง')}
              ${this.numberField('pnlPerUsdMoveAtReferenceSize','P/L เมื่อทองขยับ $1',config.pnlPerUsdMoveAtReferenceSize,.000001,100000,.000001,'ต้องผ่าน Broker calibration ก่อนใช้เงินจริง')}
              ${this.checkboxField('useBrokerMinimumSize','อนุญาตขั้นต่ำของ Broker',config.useBrokerMinimumSize,'ระบบยังคงบล็อกหากขั้นต่ำทำให้เสี่ยงเกินเพดาน')}
              ${this.selectField('takeProfitTarget','เป้าหมายปิด',config.takeProfitTarget,[['tp1','TP1 เร็ว'],['tp2','TP2 แนะนำ'],['tp3','TP3 ไกล']])}
              ${this.numberField('maxSpreadUsd','Spread สูงสุด ($ ราคา)',config.maxSpreadUsd,.01,20,.01)}
              ${this.numberField('entryToleranceUsd','เผื่อ Entry zone ($)',config.entryToleranceUsd,0,5,.01)}
              ${this.numberField('maxTradesPerDay','เทรดสูงสุด/วัน',config.maxTradesPerDay,1,20,1)}
              ${this.numberField('maxLossPerTradeUsd','ขาดทุนสูงสุดต่อออเดอร์ (USD)',config.maxLossPerTradeUsd,.05,1000,.05,'ใช้ค่าต่ำกว่าระหว่างเพดาน USD และเปอร์เซ็นต์บัญชี')}
              ${this.numberField('riskPercentPerTrade','ความเสี่ยงสูงสุดต่อออเดอร์ (%)',config.riskPercentPerTrade,.1,100,.1)}
              ${this.numberField('maxDailyLossUsd','ขาดทุนสูงสุด/วัน (USD)',config.maxDailyLossUsd,.1,1000,.1)}
              ${this.numberField('maxWeeklyLossUsd','ขาดทุนสูงสุด/สัปดาห์ (USD)',config.maxWeeklyLossUsd,.1,100000,.1)}
              ${this.numberField('maxDrawdownPercent','Drawdown สูงสุด (%)',config.maxDrawdownPercent,1,100,.1)}
              ${this.numberField('maxMarginUsagePercent','ใช้ Margin สูงสุด (%)',config.maxMarginUsagePercent,1,100,.1)}
              ${this.numberField('maxConsecutiveLosses','แพ้ติดสูงสุด',config.maxConsecutiveLosses,1,10,1)}
              ${this.numberField('maxReconciliationMismatch','Mismatch สูงสุด',config.maxReconciliationMismatch,0,100,1,'เกินค่านี้จะหยุดเปิดออเดอร์ใหม่')}
              ${this.numberField('cooldownMinutes','พักหลังเทรด (นาที)',config.cooldownMinutes,0,1440,1)}
            </div>
            <div class="setup-actions"><button class="ghost-button" type="button" data-auto-prev="basic">ย้อนกลับ</button><button class="primary-button" type="button" data-auto-next="forward">ถัดไป: Forward Test</button></div>
          </section>

          <section class="setup-panel ${wizardStep==='forward'?'active':''}" data-auto-panel="forward">
            <div class="setup-panel-title"><div><span>ขั้นที่ 3</span><h3>Forward Test และการประเมินก่อน Demo Auto</h3><p>ใช้ข้อมูลจริงและจำลอง fill โดยไม่ส่ง Broker order เพิ่ม</p></div></div>
            <div class="form-grid">
              ${this.checkboxField('forwardTestEnabled','เปิด Forward Test แบบ Shadow',config.forwardTestEnabled,'บันทึกผลแยกจาก Paper, Demo และ Live')}
              ${this.numberField('forwardTestSlippageUsd','Slippage สมมติ ($)',config.forwardTestSlippageUsd,0,10,.01)}
            </div>
            <div class="setup-summary-grid">
              <div><span>Signals</span><strong>${forward.signals || 0}</strong></div>
              <div><span>Closed</span><strong>${forward.closed || 0}</strong></div>
              <div><span>Expectancy</span><strong class="${Number(forward.expectancyR||0)>0?'up':Number(forward.expectancyR||0)<0?'down':''}">${Number(forward.expectancyR || 0).toFixed(3)}R</strong></div>
              <div><span>ระยะเวลา</span><strong>${Number(forward.days || 0).toFixed(1)} วัน</strong></div>
            </div>
            <div class="notice">${icon('info',18)}<div>Forward Test ที่ดีต้องใช้ข้อมูลหลาย regime และหัก spread/slippage แล้ว ผลบวกช่วงสั้นไม่ถือว่า Live Ready</div></div>
            <div class="setup-actions"><button class="ghost-button" type="button" data-auto-prev="risk">ย้อนกลับ</button><button class="primary-button" type="button" data-auto-next="advanced">ถัดไป: ขั้นสูง</button></div>
          </section>

          <section class="setup-panel ${wizardStep==='advanced'?'active':''}" data-auto-panel="advanced">
            <div class="setup-panel-title"><div><span>ขั้นที่ 4</span><h3>Adaptive Safety และคำสั่งระบบ</h3><p>ส่วนนี้เหมาะสำหรับผู้ใช้ที่เข้าใจ Drift, Reconciliation และ Live Readiness</p></div></div>
            <div class="form-grid">
              ${this.checkboxField('pauseAdaptiveOnDrift','หยุด Adaptive เมื่อพบ Model Drift',config.pauseAdaptiveOnDrift,'กลับไปใช้กลยุทธ์ฐานโดยไม่เพิ่มความเสี่ยง')}
              ${this.numberField('modelDriftRecentTrades','ผลล่าสุดสำหรับตรวจ Drift',config.modelDriftRecentTrades,5,500,1)}
              ${this.numberField('modelDriftBaselineTrades','ผลฐานเปรียบเทียบ',config.modelDriftBaselineTrades,20,2000,1)}
              ${this.textField('liveUnlockPhrase','ปลดล็อกบัญชีจริง',config.liveUnlockPhrase || '','text','พิมพ์ LIVE เฉพาะเมื่อเลือก Live + Confirm/Auto และ Readiness Gate ผ่าน')}
            </div>
            <div class="advanced-actions">
              <button class="ghost-button" type="button" id="autoRunNow">${icon('play',16)} สแกนตอนนี้</button>
              <button class="ghost-button" type="button" id="autoReconcile">ตรวจ Broker</button>
              <button class="danger-button" type="button" id="autoPause">${icon('pause',16)} หยุด Auto</button>
            </div>
            <div class="setup-actions"><button class="ghost-button" type="button" data-auto-prev="forward">ย้อนกลับ</button><button class="primary-button" type="submit">${icon('check',16)} บันทึกการตั้งค่าทั้งหมด</button></div>
          </section>

          <div class="auto-form-footer">
            <div><strong>${esc(String(config.executionMode || 'paper').toUpperCase())} • ${esc(String(config.brokerEnvironment || 'demo').toUpperCase())}</strong><small>Cloudflare เป็นค่าจริงที่ใช้รันบอท ส่วนค่าที่จำในอุปกรณ์ใช้ช่วยกรอกเท่านั้น</small></div>
            <button class="primary-button" type="submit">${icon('check',16)} บันทึก</button>
          </div>
          <div class="disclaimer"><strong>Demo Auto:</strong> เลือก Auto + Demo API เพื่อส่งคำสั่งด้วยเงินจำลอง ส่วน Live ต้องเลือก Live API พิมพ์ <strong>LIVE</strong> และผ่าน Readiness Gate ครบ ระบบแยกยอดและสถิติตาม environment + accountId</div>
        </form>

        <div class="stack">
          <div class="card card-pad"><h2 class="section-title">สถานะคำสั่ง</h2>
            ${paper ? `<div class="trade-ticket"><span class="badge ${paper.direction===1?'buy':'sell'}">PAPER ${esc(paper.directionLabel)}</span><h3>${esc(state.resolvedEpic || 'Gold')} @ ${fmtPrice(paper.entry)}</h3><div class="plan-price-grid"><div class="price-cell"><span>SL</span><strong class="down">${fmtPrice(paper.stopLoss)}</strong></div><div class="price-cell"><span>TP</span><strong class="up">${fmtPrice(paper.takeProfit)}</strong></div><div class="price-cell"><span>Size</span><strong>${Number(paper.size).toFixed(4)}</strong></div></div></div>` : ''}
            ${plan ? `<div class="trade-ticket"><span class="badge ${plan.direction===1?'buy':'sell'}">รอยืนยัน ${esc(plan.directionLabel)}</span><h3>${esc(plan.strategy)} • Score ${fmtScore(plan.score)}</h3><div class="plan-price-grid"><div class="price-cell"><span>Entry</span><strong>${fmtPrice(plan.entryLow)}–${fmtPrice(plan.entryHigh)}</strong></div><div class="price-cell"><span>SL</span><strong class="down">${fmtPrice(plan.stopLoss)}</strong></div><div class="price-cell"><span>${esc(String(config.takeProfitTarget).toUpperCase())}</span><strong class="up">${fmtPrice(plan[config.takeProfitTarget] || plan.tp2)}</strong></div></div><button class="primary-button" id="autoConfirm" data-signal-id="${esc(signal.id)}" style="margin-top:12px">ยืนยันส่งคำสั่ง</button></div>` : ''}
            ${!paper && !plan ? `<div class="empty-state"><strong>ยังไม่มีสถานะหรือสัญญาณรอยืนยัน</strong>${esc(state.lastDecision || 'ระบบจะอัปเดตจาก Cron ทุก 1 นาที')}</div>` : ''}
          </div>
          <div class="card card-pad"><div class="card-header"><div><h2 class="section-title" style="margin-bottom:4px">บันทึก Cloud Bot</h2><div class="card-subtitle">Cloud Journal ${(state.cloudJournal || []).length} รายการ • Adaptive ${esc(learning.status || 'รอข้อมูล')} • Drift ${esc(state.modelDrift?.status || 'รอข้อมูล')} • Model ${esc(learning.fingerprint || '—')}</div></div></div><div class="auto-log">${logs.length ? logs.map(row => `<div class="auto-log-row ${esc(row.level)}"><time>${fmtTime(row.at)}</time><span>${esc(row.message)}</span></div>`).join('') : '<div class="empty-state">ยังไม่มีบันทึก</div>'}</div></div>
          <div class="card card-pad"><h2 class="section-title">Dead Letter Queue</h2><div class="card-subtitle">งานที่ลองซ้ำครบแล้วจะมารอให้ผู้ใช้ตรวจสอบ ไม่ส่ง Broker ซ้ำทันที</div><div class="auto-log">${deadLetters.length ? deadLetters.slice(0,20).map(item => `<div class="auto-log-row error"><time>${fmtTime(item.received_at)}</time><span><strong>${esc(item.event_type)}</strong> • ${esc(item.error?.code || item.error?.message || 'ล้มเหลว')}<br><button class="ghost-button" data-dl-retry="${esc(item.id)}">ลองใหม่</button> <button class="ghost-button" data-dl-dismiss="${esc(item.id)}">ปิดรายการ</button></span></div>`).join('') : '<div class="empty-state">ไม่มี Dead Letter ค้าง</div>'}</div></div>
        </div>
      </div>`;
  }

  settingsHtml() {
    const s = this.state.settings;
    const cost = executionCosts(s);
    const tuning = this.state.tuningState;
    const tuningCount = tuning?.records?.length || 0;
    const price = Number(this.state.analyses['1min']?.snapshot.close ?? this.state.analyses['15min']?.snapshot.close ?? 0);
    const previewLot = s.positionSizingMode === 'fixed' ? Number(s.fixedLot || s.lotStep || 0.01) : Number(s.lotStep || 0.01);
    const valuePerDollar = valuePerPriceUnitForSize(previewLot, s);
    const percentBudget = Number(s.accountSize || 0) * Number(s.riskPercent || 0) / 100;
    const riskBudget = Number(s.maxLossUsd || 0) > 0 ? Math.min(percentBudget || Number(s.maxLossUsd), Number(s.maxLossUsd)) : percentBudget;
    const costAtLot = cost.totalUsd * valuePerDollar;
    const maxStopDistance = valuePerDollar > 0 ? Math.max(0, riskBudget / valuePerDollar - cost.totalUsd) : 0;
    const margin = price > 0 ? price * Number(s.contractSize || 100) * previewLot / Math.max(1, Number(s.leverage || 1)) : 0;
    const reasonMap = {
      'not-final-trade':'ยังไม่จบด้วย TP/SL', 'before-reset':'เก่ากว่าจุดรีเซ็ต',
      'data-policy':'ไม่ตรงนโยบายแหล่งข้อมูล', 'breakeven-disabled':'ปิดการใช้ 0R',
      'outside-lookback':'เกินจำนวนย้อนหลัง', 'invalid-result':'ผลไม่สมบูรณ์'
    };
    const exclusions = Object.entries(this.state.learning?.exclusionReasons || {})
      .filter(([key, count]) => key !== 'used' && count > 0)
      .map(([key, count]) => `${reasonMap[key] || key} ${count}`)
      .join(' • ') || 'ไม่มีรายการที่ถูกละเว้น';

    return `<form id="settingsForm">
      <div class="notice">${icon('info',19)}<div><strong>มูลค่าการขยับราคาตั้งค่าได้ตามบัญชีจริง</strong><br>ที่ขนาด ${previewLot} เมื่อราคาทองขยับ $1 ระบบจะคำนวณ P/L ประมาณ <strong>$${valuePerDollar.toFixed(4)}</strong> ตามค่าที่กำหนดด้านล่าง ส่วน Contract size ใช้ประเมินมาร์จินแยกต่างหาก</div></div>
      <div class="grid grid-2">
        <div class="card card-pad"><h2 class="section-title">1. บัญชี, Lot และเพดานขาดทุน</h2>
          <div class="risk-preview">
            <div><span>มูลค่าต่อราคาขยับ $1</span><strong>$${valuePerDollar.toFixed(2)}</strong></div>
            <div><span>งบขาดทุนสูงสุด/แผน</span><strong>$${riskBudget.toFixed(2)}</strong></div>
            <div><span>SL ราคาสูงสุดหลังหักต้นทุน</span><strong>$${maxStopDistance.toFixed(2)}</strong></div>
            <div><span>มาร์จินประมาณการ</span><strong>${price ? `$${margin.toFixed(2)}` : 'รอราคา'}</strong></div>
          </div>
          <div class="form-grid">
            ${this.numberField('accountSize','ยอดเงินในบัญชี (USD)',s.accountSize,1,10000000,1,'ใช้คำนวณเพดานขาดทุนและสัดส่วนมาร์จิน')}
            ${this.selectField('positionSizingMode','วิธีเลือก Lot',s.positionSizingMode,[['fixed','Lot คงที่ — ใช้ค่าที่กำหนด'],['risk','คำนวณ Lot จากงบเสี่ยง']],'โหมด Lot คงที่จะตัดแผนทันทีเมื่อ SL ทำให้ขาดทุนเกินงบ')}
            ${this.numberField('fixedLot','Lot ที่ต้องการใช้',s.fixedLot,.001,100,.001,'สำหรับพอร์ตนี้ตั้ง 0.01; ต้องตรงกับขั้นต่ำของโบรกเกอร์')}
            ${this.numberField('pnlReferenceSize','ขนาดอ้างอิงสำหรับ P/L',s.pnlReferenceSize,.0001,100000,.0001,'ตัวอย่าง 0.01')}
            ${this.numberField('pnlPerUsdMoveAtReferenceSize','P/L เมื่อราคาทองขยับ $1 ที่ขนาดอ้างอิง',s.pnlPerUsdMoveAtReferenceSize,.000001,100000,.000001,'ถ้า 0.01 size ขยับ $1 แล้วพอร์ตเปลี่ยน $0.01 ให้ใส่ 0.01')}
            ${this.numberField('riskPercent','ขาดทุนสูงสุดต่อแผน (% พอร์ต)',s.riskPercent,.05,50,.05,'พอร์ต $20 กับ 0.01 lot มีความเสี่ยงสูง ระบบจะไม่ฝืนออกแผนเมื่อเกินค่านี้')}
            ${this.numberField('maxLossUsd','เพดานขาดทุนเป็น USD (0 = ใช้ %)',s.maxLossUsd,0,1000000,.01,'ถ้ากำหนด ระบบใช้ค่าที่ต่ำกว่าระหว่าง % และ USD')}
            ${this.numberField('leverage','Leverage ของบัญชี (เช่น 500)',s.leverage,1,5000,1,'ใช้ประเมินมาร์จินเท่านั้น ไม่ได้เปลี่ยนกำไร/ขาดทุนต่อ $1')}
            ${this.numberField('maxMarginUsagePercent','ใช้มาร์จินได้สูงสุด (% พอร์ต)',s.maxMarginUsagePercent,5,100,1,'เกินค่านี้ระบบจะไม่ออกแผน')}
            ${this.numberField('contractSize','Contract size สำหรับประเมินมาร์จิน',s.contractSize,.01,10000,.01,'ไม่ใช้คำนวณ P/L เมื่อกำหนดมูลค่าต่อ $1 ด้านบนแล้ว')}
          </div>
        </div>

        <div class="card card-pad"><h2 class="section-title">2. เป้าหมายทำกำไรระยะสั้น</h2><div class="form-grid">
          ${this.selectField('profile','รูปแบบการเทรด',s.profile,[['scalp','Scalp พอร์ตเล็ก — แนะนำ'],['conservative','ระวังความผันผวน'],['balanced','สมดุล'],['opportunity','เปิดกว้างขึ้น']],'Scalp จะปฏิเสธโครงสร้างที่ต้องใช้ SL ไกลแทนการขยาย SL')}
          ${this.numberField('minScore','คะแนนสัญญาณขั้นต่ำ',s.minScore,50,95,1,'สูงขึ้น = สัญญาณน้อยลง แต่คัดกรองเข้มขึ้น')}
          ${this.numberField('targetRiskReward','R:R เป้าหมายหลัก',s.targetRiskReward,.5,4,.05,'ระบบปรับขึ้น/ลงเล็กน้อยตามคะแนน แนวโน้ม ATR และแนวรับต้าน ไม่ใช่ TP ระยะตายตัว')}
          ${this.numberField('minRiskReward','R:R สุทธิต่ำสุดที่ยอมรับ',s.minRiskReward,.5,4,.05,'คำนวณหลังหัก spread/slippage/buffer')}
          ${this.numberField('maxTargetRiskReward','R:R สูงสุดของเป้าหมาย',s.maxTargetRiskReward,.5,5,.05,'ป้องกันเป้าหมายไกลเกินสำหรับการทำกำไรสั้น')}
          ${this.selectField('exitAtTarget','เป้าหมายปิดแผนหลัก',s.exitAtTarget,[['tp1','TP1 — เร็วที่สุด'],['tp2','TP2 — แนะนำสำหรับ Scalp'],['tp3','TP3 — ถือ Runner']],'แผนจะถือว่าสำเร็จเมื่อถึงเป้าหมายนี้ ไม่จำเป็นต้องรอ TP3 เสมอ')}
          ${this.numberField('minExpectedBarsToTp2','ระยะเวลาขั้นต่ำถึง TP2 (แท่ง)',s.minExpectedBarsToTp2,.05,10,.05,'กันเป้าหมายชิดจนต้นทุนกินกำไร')}
          ${this.numberField('maxExpectedBarsToTp2','ระยะเวลาสูงสุดถึง TP2 (แท่ง)',s.maxExpectedBarsToTp2,.1,30,.1,'เกินค่านี้จะไม่ออกแผน เพื่อคงลักษณะระยะสั้น')}
          ${this.numberField('minTargetAtr','TP ขั้นต่ำเทียบ ATR',s.minTargetAtr,.1,5,.05,'ระยะ TP ปรับตามความผันผวนจริง')}
          ${this.numberField('maxTargetAtr','TP สูงสุดเทียบ ATR',s.maxTargetAtr,.2,10,.05,'จำกัดไม่ให้ TP ไกลเกินสภาวะตลาด')}
          ${this.numberField('backtestMaxHoldBars','ถือสูงสุดใน Backtest (แท่ง)',s.backtestMaxHoldBars,1,100,1,'Backtest ใช้ Risk/TP engine เดียวกับหน้าแผนจริง')}
        </div></div>

        <div class="card card-pad"><h2 class="section-title">3. ต้นทุนโบรกเกอร์</h2><div class="form-grid">
          ${this.selectField('brokerDigits','ทศนิยมราคา XAU/USD',String(s.brokerDigits),[['2','2 ตำแหน่ง: 1 point = 0.01'],['3','3 ตำแหน่ง: 1 point = 0.001']],'ดูจากราคาใน MT5 เช่น 2350.25 = 2 ตำแหน่ง')}
          ${this.numberField('spreadPoints','Spread ที่ใช้คำนวณ (points)',s.spreadPoints,0,5000,1,`ระยะราคา $${cost.spreadUsd.toFixed(3)} • ที่ ${previewLot} lot คิดเป็นประมาณ $${(cost.spreadUsd*valuePerDollar).toFixed(2)}`)}
          ${this.numberField('slippagePoints','Slippage เผื่อ (points)',s.slippagePoints,0,2000,1,`ระยะราคา $${cost.slippageUsd.toFixed(3)}`)}
          ${this.numberField('manualEntryBufferPoints','เผื่อกดออร์เดอร์ช้า (points)',s.manualEntryBufferPoints,0,2000,1,`ระยะราคา $${cost.manualBufferUsd.toFixed(3)}`)}
          ${this.numberField('maxExecutionCostPercent','ต้นทุนสูงสุดต่อระยะเสี่ยง (%)',s.maxExecutionCostPercent,5,65,1,'เกินค่านี้จะตัดแผน ไม่ขยาย SL เพื่อฝืนให้ผ่าน')}
          ${this.numberField('minStopAtrMultiplier','SL ขั้นต่ำเทียบ ATR',s.minStopAtrMultiplier ?? .9,0,5,.05,'0.90 = ระยะ SL ต้องไม่น้อยกว่า 0.9 ATR; ช่วยกัน SL แคบเกินจาก noise')}
          ${this.numberField('minStopPoints','SL ขั้นต่ำเพิ่มเติม (points)',s.minStopPoints,0,10000,1,'ตั้ง 0 เพื่อใช้ ATR + โครงสร้าง + ต้นทุนอัตโนมัติ')}
          ${this.numberField('lotStep','Lot step ของโบรกเกอร์',s.lotStep,.001,100,.001)}
          ${this.numberField('maxLot','Lot สูงสุดที่ระบบอนุญาต',s.maxLot,.001,1000,.001)}
        </div><div class="card-subtitle" style="margin-top:12px">ต้นทุนรวมที่ตั้งไว้ = ระยะราคา $${cost.totalUsd.toFixed(3)} หรือประมาณ <strong>$${costAtLot.toFixed(2)}</strong> ที่ ${previewLot} lot</div></div>

        <div class="card card-pad"><h2 class="section-title">4. Adaptive Learning ที่ใช้ข้อมูลมากขึ้น</h2><div class="form-grid">
          ${this.checkboxField('adaptiveLearning','เปิดการปรับคะแนนจากผลย้อนหลัง',s.adaptiveLearning,'ปรับเฉพาะคะแนน ไม่สามารถข้ามเพดานความเสี่ยงของบัญชี')}
          ${this.checkboxField('learningUseDemo','อนุญาต Demo/Mixed แบบลดน้ำหนัก',s.learningUseDemo,'ข้อมูล Live มีน้ำหนัก 100%; Demo/Mixed ใช้น้ำหนักตามที่กำหนดด้านล่าง')}
          ${this.checkboxField('learningIncludeBreakeven','ใช้ผล 0R / Breakeven ในการเรียนรู้',s.learningIncludeBreakeven,'ช่วยลดการทิ้งข้อมูล แต่แผนยกเลิกหรือหมดอายุยังไม่ถูกนับเป็นผลการเทรด')}
          ${this.selectField('learningDataPolicy','นโยบายแหล่งข้อมูล',s.learningDataPolicy,[['weighted-all','ใช้ทุกโหมดแบบถ่วงน้ำหนัก — แนะนำ'],['same-mode','ใช้เฉพาะโหมดเดียวกับปัจจุบัน'],['live-only','ใช้ Live เท่านั้น']])}
          ${this.numberField('learningDemoWeight','น้ำหนักข้อมูล Demo',s.learningDemoWeight,.05,1,.05,'0.35 = Demo 1 ผลมีน้ำหนักเท่ากับ Live 0.35 ผล')}
          ${this.numberField('learningMixedWeight','น้ำหนักข้อมูล Mixed',s.learningMixedWeight,.05,1,.05)}
          ${this.numberField('learningMinSamples','น้ำหนักตัวอย่างอ้างอิง',s.learningMinSamples,4,200,1,'เริ่มปรับแบบจำกัดเมื่อมีประมาณ 35% ของค่านี้')}
          ${this.numberField('learningMaxAdjustment','ปรับคะแนนสูงสุด (±)',s.learningMaxAdjustment,1,15,.5,'ไม่ให้ผลระยะสั้นครอบงำ Algorithm หลัก')}
          ${this.numberField('learningLookback','เก็บผลย้อนหลังสูงสุด',s.learningLookback,50,2000,10,'ข้อมูลล่าสุดมีน้ำหนักมากกว่า')}
        </div>
        <div class="actions-row"><button type="button" class="primary-button" id="exportTuning">${icon('download',16)} ส่งออกค่าจูน</button><button type="button" class="ghost-button" id="importTuning">นำเข้าค่าจูน</button><input id="tuningFile" type="file" accept="application/json,.json" hidden><button type="button" class="danger-button" id="resetLearning">รีเซ็ตการเรียนรู้</button></div>
        <div class="card-subtitle">สถานะ: ${esc(this.state.learning?.status || 'รอข้อมูล')} • ใช้ ${this.state.learning?.eligibleTrades || 0} ผล (น้ำหนัก ${this.state.learning?.effectiveTrades || 0}) • Model ${esc(this.state.learning?.fingerprint || '—')}${tuning ? ` • ฐานนำเข้า ${tuningCount} ผล` : ''}</div>
        <div class="notice" style="margin-top:12px">${icon('info',18)}<div><strong>เหตุผลข้อมูลที่ไม่ได้ใช้:</strong> ${esc(exclusions)}<br>ระบบไม่ลบ Trade Journal; ใช้วิธีลดน้ำหนักข้อมูลจำลองแทนการตัดทิ้งทั้งหมด และยังคงไม่ใช้แผนยกเลิก/หมดอายุเพราะไม่มีผลกำไรขาดทุนจริงให้เรียนรู้</div></div></div>

        <div class="card card-pad"><h2 class="section-title">5. แหล่งข้อมูลและการสแกน</h2><div class="form-grid">
          ${this.selectField('dataPreference','โหมดข้อมูล',s.dataPreference,[['auto','อัตโนมัติ: Capital.com → Twelve Data → จำลอง'],['twelve','ใช้ Twelve Data ก่อน'],['demo','ข้อมูลจำลองเท่านั้น']],'เมื่อเข้าสู่ระบบด้วย session แล้ว ระบบใช้แท่งราคา Capital.com environment เดียวกับ Auto Trade เพื่อให้กราฟ แผน และ Backtest สอดคล้องกัน')}
          ${this.numberField('refreshSeconds','อัปเดตทุก (วินาที)',s.refreshSeconds,30,600,1,'ข้อมูลฟรีเหมาะกับ 60 วินาทีขึ้นไป')}
          ${this.numberField('maxPlans','จำนวนแผนสูงสุด',s.maxPlans,1,5,1,'พอร์ตเล็กแนะนำ 1–3 แผน')}
        </div><div class="actions-row"><button type="button" class="ghost-button" id="enableNotifications">${icon('bell',16)} เปิดการแจ้งเตือน</button><button type="button" class="ghost-button" id="exportAll">${icon('download',16)} สำรองข้อมูล JSON</button><button type="button" class="danger-button" id="clearData">${icon('trash',16)} ล้างข้อมูลในเครื่อง</button></div><div class="hr"></div><div class="disclaimer"><strong>แหล่งข้อมูลปัจจุบัน:</strong> ${esc(this.state.marketSource || 'mock')}<br><strong>การทำงานร่วมกัน:</strong> เมื่อเชื่อม Capital.com แล้ว หน้า Dashboard, Analysis, Backtest และ Auto Trade ใช้ค่าจูนกลางและ Cloud Journal ร่วมกัน ผล Auto ที่ปิดแล้วจะถูกนำเข้า Journal/Adaptive Learning อัตโนมัติ</div></div>
      </div>
      <div class="actions-row"><button class="primary-button" type="submit">${icon('check',16)} บันทึกและคำนวณใหม่</button></div>
    </form>`;
  }

  textField(name, label, value, type = 'text', help = '') {
    return `<div class="field"><label for="${name}">${label}</label><input id="${name}" name="${name}" type="${type}" value="${esc(value)}" autocomplete="off">${help ? `<small>${help}</small>` : ''}</div>`;
  }

  numberField(name, label, value, min, max, step, help = '') {
    return `<div class="field"><label for="${name}">${label}</label><input id="${name}" name="${name}" type="number" value="${esc(value)}" min="${min}" max="${max}" step="${step}" required>${help ? `<small>${help}</small>` : ''}</div>`;
  }

  selectField(name, label, value, options, help = '') {
    return `<div class="field"><label for="${name}">${label}</label><select id="${name}" name="${name}">${options.map(([v,l]) => `<option value="${v}" ${value===v?'selected':''}>${l}</option>`).join('')}</select>${help ? `<small>${help}</small>` : ''}</div>`;
  }

  checkboxField(name, label, checked, help = '') {
    return `<div class="field checkbox-field"><label for="${name}" style="display:flex;align-items:flex-start;gap:10px;cursor:pointer"><input id="${name}" name="${name}" type="checkbox" ${checked ? 'checked' : ''} style="width:auto;margin-top:3px"><span>${label}${help ? `<small style="display:block;margin-top:5px">${help}</small>` : ''}</span></label></div>`;
  }

  cancelPlan(id) {
    const plan = this.state.plans.find(p => p.id === id);
    if (!plan) return;
    const ended = { ...plan, status:'CANCELLED', outcome:'ผู้ใช้ยกเลิก', resultR:0, endedAt:Date.now() };
    storage.addJournal([ended]);
    this.state.plans = this.state.plans.filter(p => p.id !== id);
    storage.savePlans(this.state.plans);
    this.state.journal = storage.getJournal();
    this.toast('ยกเลิกแผนแล้ว ระบบจะหาแผนทดแทนรอบถัดไป');
    this.renderPage();
    this.refresh({ silent: true });
  }

  manualActivate(id) {
    this.state.plans = this.state.plans.map(p => p.id === id ? { ...p, status:'ACTIVE', activatedAt:Date.now(), manualActivation:true } : p);
    storage.savePlans(this.state.plans);
    this.toast('บันทึกว่าเข้าเทรดแล้ว');
    this.renderPage();
  }

  async executeBacktest() {
    const data = this.state.datasets[this.state.backtestTf]?.candles;
    if (!data?.length) return this.toast('ไม่มีข้อมูลสำหรับ Backtest');
    this.setLoading(true, `กำลังทดสอบ ${TIMEFRAME_LABELS[this.state.backtestTf]} ด้วย Algorithm ที่จูนแล้ว…`);
    await new Promise(resolve => setTimeout(resolve, 30));
    try {
      const result = runBacktest(data, this.state.backtestTf, this.state.settings, this.state.learning);
      this.state.lastBacktest = result;
      storage.saveBacktest(result);
      this.toast(`Backtest เสร็จ: ${result.summary.trades} trades, ${result.summary.netR}R`);
    } catch (error) {
      this.toast(`Backtest ล้มเหลว: ${error.message}`);
    } finally {
      this.setLoading(false);
      this.renderPage();
    }
  }

  async saveSettings(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const numeric = ['refreshSeconds','maxPlans','minScore','minRiskReward','targetRiskReward','maxTargetRiskReward','minTargetAtr','maxTargetAtr','brokerDigits','spreadPoints','slippagePoints','manualEntryBufferPoints','maxExecutionCostPercent','minExpectedBarsToTp2','maxExpectedBarsToTp2','minStopPoints','minStopAtrMultiplier','accountSize','fixedLot','riskPercent','maxLossUsd','pnlReferenceSize','pnlPerUsdMoveAtReferenceSize','contractSize','leverage','maxMarginUsagePercent','lotStep','maxLot','backtestMaxHoldBars','learningMinSamples','learningMaxAdjustment','learningLookback','learningDemoWeight','learningMixedWeight'];
    const next = { ...this.state.settings };
    for (const [key, value] of form.entries()) next[key] = numeric.includes(key) ? Number(value) : value;
    next.adaptiveLearning = Boolean(event.currentTarget.elements.adaptiveLearning?.checked);
    next.learningUseDemo = Boolean(event.currentTarget.elements.learningUseDemo?.checked);
    next.learningIncludeBreakeven = Boolean(event.currentTarget.elements.learningIncludeBreakeven?.checked);
    next.settingsVersion = 4;
    this.state.settings = next;
    storage.saveSettings(next);
    if (this.state.authenticated && this.state.autoTrade?.config) {
      try {
        const current = this.state.autoTrade.config;
        const synced = this.composeAutoTradeConfig({
          ...current,
          minScore: Number(next.minScore),
          orderSize: Number(next.fixedLot),
          riskPercentPerTrade: Number(next.riskPercent),
          maxLossPerTradeUsd: Number(next.maxLossUsd || current.maxLossPerTradeUsd || 1),
          pnlReferenceSize: Number(next.pnlReferenceSize || next.fixedLot || current.orderSize || 0.01),
          pnlPerUsdMoveAtReferenceSize: Number(next.pnlPerUsdMoveAtReferenceSize || current.pnlPerUsdMoveAtReferenceSize || 0.01),
          takeProfitTarget: next.exitAtTarget || current.takeProfitTarget
        });
        const payload = await saveAutoTradeConfig(synced);
        this.applyAutoTradePayload(payload);
        this.toast('บันทึกค่ากลางและซิงก์ Auto Trade แล้ว');
      } catch (error) {
        this.toast(`บันทึกในเครื่องแล้ว แต่ซิงก์ Cloud Auto ไม่สำเร็จ: ${error.message}`);
      }
    } else {
      this.toast('บันทึกการตั้งค่าแล้ว');
    }
    await this.refresh();
  }

  async enableNotifications() {
    if (!('Notification' in window)) return this.toast('อุปกรณ์นี้ไม่รองรับ Notification API');
    const result = await Notification.requestPermission();
    this.state.settings.notifications = result === 'granted';
    storage.saveSettings(this.state.settings);
    this.toast(result === 'granted' ? 'เปิดการแจ้งเตือนแล้ว' : 'ไม่ได้รับสิทธิ์แจ้งเตือน');
  }

  exportTuningProfile() {
    const profile = createTuningProfile(
      this.learningSourceRecords(), this.state.settings, this.state.mode, this.state.learning, APP_VERSION
    );
    const stamp = new Date().toISOString().slice(0, 10);
    downloadJson(`goldscope-tuning-${stamp}.json`, profile);
    this.toast(`ส่งออกค่าจูนแล้ว ${profile.records.length} ผล • ${profile.model.fingerprint}`);
  }

  async importTuningProfile(file) {
    try {
      const raw = await readJsonFile(file);
      const profile = validateTuningProfile(raw);
      const ok = await confirmDialog({
        title: 'นำเข้าค่าจูนและโมเดล',
        message: `นำเข้าค่าจูน ${profile.records.length} ผล จากรุ่น ${profile.appVersion}`,
        detail: `Model ${profile.model.fingerprint || 'ไม่ระบุ'}
ค่า Algorithm/Risk ในไฟล์จะถูกใช้ทันที และผลใหม่จะต่อยอดจากฐานที่นำเข้า`,
        confirmLabel: 'นำเข้าค่าจูน'
      });
      if (!ok) return;

      const nextSettings = migrateSettings({
        ...this.state.settings,
        ...profile.algorithmSettings,
        ...profile.learningSettings,
        adaptiveLearning: true,
        learningResetAt: 0
      });
      const now = Date.now();
      const tuningState = {
        schema: profile.schema,
        schemaVersion: profile.schemaVersion,
        appVersion: profile.appVersion,
        sourceExportedAt: profile.exportedAt,
        sourceFingerprint: profile.model.fingerprint,
        activeSince: now,
        importedAt: new Date(now).toISOString(),
        records: profile.records
      };
      storage.saveTuningState(tuningState);
      storage.saveSettings(nextSettings);
      this.state.tuningState = tuningState;
      this.state.settings = nextSettings;
      this.state.learning = buildAdaptiveModel(this.learningSourceRecords(), nextSettings, this.state.mode);
      this.toast(`นำเข้าค่าจูนสำเร็จ ใช้ Model ${this.state.learning.fingerprint}`);
      await this.refresh({ silent: true });
    } catch (error) {
      this.toast(`นำเข้าค่าจูนไม่สำเร็จ: ${error.message}`);
    }
  }

  async resetLearning() {
    const ok = await confirmDialog({ title: 'รีเซ็ตการเรียนรู้', message: 'ล้างฐานค่าจูนที่นำเข้าและเริ่มสะสมสถิติใหม่ โดยยังเก็บ Trade Journal เดิมไว้', confirmLabel: 'รีเซ็ตการเรียนรู้', danger: true });
    if (!ok) return;
    storage.clearTuningState();
    this.state.tuningState = null;
    this.state.settings = { ...this.state.settings, learningResetAt: Date.now() };
    storage.saveSettings(this.state.settings);
    this.state.learning = buildAdaptiveModel(this.learningSourceRecords(), this.state.settings, this.state.mode);
    this.toast('รีเซ็ตฐานการเรียนรู้แล้ว Journal เดิมยังอยู่แต่ผลเก่าจะไม่ถูกใช้จูน');
    await this.refresh({ silent: true });
  }

  async clearData() {
    const ok = await confirmDialog({ title: 'ล้างข้อมูลในอุปกรณ์', message: 'การตั้งค่า แผน ประวัติ และผล Backtest ในอุปกรณ์นี้จะถูกลบทั้งหมด', confirmLabel: 'ล้างข้อมูล', danger: true, requireText: 'DELETE' });
    if (!ok) return;
    storage.clearAll();
    clearAutoTradeDisplaySnapshot();
    location.reload();
  }
}
