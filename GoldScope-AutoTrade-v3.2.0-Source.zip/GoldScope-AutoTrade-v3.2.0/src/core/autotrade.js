import { ALGORITHM_SETTING_KEYS, LEARNING_SETTING_KEYS, mergeLearningRecords } from './learning.js';

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const finite = value => Number.isFinite(Number(value));
const numberOr = (value, fallback) => finite(value) ? Number(value) : fallback;
const round = (value, digits = 2) => Number(Number(value).toFixed(digits));

export const AUTO_TRADE_SCHEMA = 5;

export const DEFAULT_AUTO_TRADE_CONFIG = {
  schema: AUTO_TRADE_SCHEMA,
  enabled: false,
  executionMode: 'paper', // paper | confirm | auto
  broker: 'capital',
  brokerEnvironment: 'demo', // demo | live
  accountId: '',
  instrumentSearch: 'Gold',
  instrumentEpic: '',
  timeframe: '5min',
  scanTimeframes: ['1min', '5min', '15min', '1h'],
  minScore: 78,
  maxOpenPositions: 1,
  maxTradesPerDay: 3,
  maxLossPerTradeUsd: 1,
  riskPercentPerTrade: 5,
  maxDailyLossUsd: 1,
  maxConsecutiveLosses: 2,
  maxPendingOrders: 1,
  maxTradesPerHour: 2,
  maxWeeklyLossUsd: 4,
  maxDrawdownPercent: 20,
  maxMarginUsagePercent: 35,
  maxReconciliationMismatch: 1,
  maxBrokerLatencyMs: 5000,
  maxApiErrorStreak: 5,
  cooldownMinutes: 45,
  maxSpreadUsd: 0.8,
  entryToleranceUsd: 0.2,
  orderSize: 0.01,
  pnlReferenceSize: 0.01,
  pnlPerUsdMoveAtReferenceSize: 0.01,
  useBrokerMinimumSize: false,
  takeProfitTarget: 'tp2',
  requireFreshCandleSeconds: 180,
  minimumDataQualityScore: 70,
  forwardTestEnabled: true,
  forwardTestSlippageUsd: 0.05,
  pauseAdaptiveOnDrift: true,
  modelDriftRecentTrades: 20,
  modelDriftBaselineTrades: 100,
  newsRiskMode: 'RISK_FILTER',
  pauseMinutesBeforeHighImpact: 30,
  pauseMinutesAfterHighImpact: 30,
  closeOrReduceBeforeEvent: 'NONE',
  allowPositionManagementDuringBlackout: true,
  requireLiveReadiness: true,
  minimumClosedDemoTrades: 100,
  minimumForwardTestDays: 28,
  maximumCriticalExecutionErrors: 0,
  maximumDuplicateOrders: 0,
  maximumUnresolvedOrderIntents: 0,
  syncAlgorithm: true,
  algorithmSettings: {},
  learningRecords: [],
  liveTradingUnlocked: false,
  liveUnlockPhrase: '',
  pauseReason: '',
  updatedAt: 0
};

function sanitizeSharedSettings(input = {}) {
  const keys = new Set([...ALGORITHM_SETTING_KEYS, ...LEARNING_SETTING_KEYS, 'learningResetAt']);
  return Object.fromEntries(Object.entries(input || {})
    .filter(([key, value]) => keys.has(key) && ['string', 'number', 'boolean'].includes(typeof value)));
}

export function normalizeAutoTradeConfig(input = {}) {
  const merged = { ...DEFAULT_AUTO_TRADE_CONFIG, ...(input || {}) };
  const rawMode = merged.executionMode === 'live' ? 'auto' : merged.executionMode;
  const executionMode = ['paper', 'confirm', 'auto'].includes(rawMode) ? rawMode : 'paper';
  const brokerEnvironment = ['demo', 'live'].includes(merged.brokerEnvironment) ? merged.brokerEnvironment : 'demo';
  const timeframe = ['1min', '5min', '15min', '1h', '4h'].includes(merged.timeframe) ? merged.timeframe : '5min';
  const target = ['tp1', 'tp2', 'tp3'].includes(merged.takeProfitTarget) ? merged.takeProfitTarget : 'tp2';
  const scanTimeframes = [...new Set(Array.isArray(merged.scanTimeframes) ? merged.scanTimeframes : DEFAULT_AUTO_TRADE_CONFIG.scanTimeframes)]
    .filter(tf => ['1min', '5min', '15min', '1h', '4h'].includes(tf));
  if (!scanTimeframes.includes(timeframe)) scanTimeframes.push(timeframe);

  const migratedPerTrade = finite(merged.maxLossPerTradeUsd)
    ? Number(merged.maxLossPerTradeUsd)
    : Math.max(0.1, Math.min(Number(merged.maxDailyLossUsd || 1), 1));

  return {
    ...merged,
    schema: AUTO_TRADE_SCHEMA,
    enabled: Boolean(merged.enabled),
    executionMode,
    broker: 'capital',
    brokerEnvironment,
    accountId: String(merged.accountId || '').slice(0, 120),
    instrumentSearch: String(merged.instrumentSearch || 'Gold').slice(0, 80),
    instrumentEpic: String(merged.instrumentEpic || '').slice(0, 100),
    timeframe,
    scanTimeframes,
    minScore: clamp(numberOr(merged.minScore, 78), 50, 100),
    maxOpenPositions: clamp(Math.trunc(numberOr(merged.maxOpenPositions, 1)), 1, 3),
    maxTradesPerDay: clamp(Math.trunc(numberOr(merged.maxTradesPerDay, 3)), 1, 20),
    maxLossPerTradeUsd: clamp(migratedPerTrade, 0.05, 100000),
    riskPercentPerTrade: clamp(numberOr(merged.riskPercentPerTrade, 5), 0.1, 100),
    maxDailyLossUsd: clamp(numberOr(merged.maxDailyLossUsd, 1), 0.1, 100000),
    maxConsecutiveLosses: clamp(Math.trunc(numberOr(merged.maxConsecutiveLosses, 2)), 1, 10),
    maxPendingOrders: clamp(Math.trunc(numberOr(merged.maxPendingOrders, 1)), 1, 20),
    maxTradesPerHour: clamp(Math.trunc(numberOr(merged.maxTradesPerHour, 2)), 1, 60),
    maxWeeklyLossUsd: clamp(numberOr(merged.maxWeeklyLossUsd, 4), 0.1, 1000000),
    maxDrawdownPercent: clamp(numberOr(merged.maxDrawdownPercent, 20), 1, 100),
    maxMarginUsagePercent: clamp(numberOr(merged.maxMarginUsagePercent, 35), 1, 100),
    maxReconciliationMismatch: clamp(Math.trunc(numberOr(merged.maxReconciliationMismatch, 1)), 0, 100),
    maxBrokerLatencyMs: clamp(Math.trunc(numberOr(merged.maxBrokerLatencyMs, 5000)), 250, 60000),
    maxApiErrorStreak: clamp(Math.trunc(numberOr(merged.maxApiErrorStreak, 5)), 1, 100),
    cooldownMinutes: clamp(Math.trunc(numberOr(merged.cooldownMinutes, 45)), 0, 1440),
    maxSpreadUsd: clamp(numberOr(merged.maxSpreadUsd, 0.8), 0.01, 100),
    entryToleranceUsd: clamp(numberOr(merged.entryToleranceUsd, 0.2), 0, 100),
    orderSize: clamp(numberOr(merged.orderSize, 0.01), 0.0001, 1000000),
    pnlReferenceSize: clamp(numberOr(merged.pnlReferenceSize, 0.01), 0.0001, 1000000),
    pnlPerUsdMoveAtReferenceSize: clamp(numberOr(merged.pnlPerUsdMoveAtReferenceSize, 0.01), 0.000001, 1000000),
    useBrokerMinimumSize: merged.useBrokerMinimumSize === true,
    takeProfitTarget: target,
    requireFreshCandleSeconds: clamp(Math.trunc(Number(merged.requireFreshCandleSeconds || 180)), 30, 86400),
    minimumDataQualityScore: clamp(Math.trunc(numberOr(merged.minimumDataQualityScore, 70)), 0, 100),
    forwardTestEnabled: merged.forwardTestEnabled !== false,
    forwardTestSlippageUsd: clamp(numberOr(merged.forwardTestSlippageUsd, 0.05), 0, 100),
    pauseAdaptiveOnDrift: merged.pauseAdaptiveOnDrift !== false,
    modelDriftRecentTrades: clamp(Math.trunc(numberOr(merged.modelDriftRecentTrades, 20)), 5, 500),
    modelDriftBaselineTrades: clamp(Math.trunc(numberOr(merged.modelDriftBaselineTrades, 100)), 20, 2000),
    newsRiskMode: ['OFF', 'INFORMATION_ONLY', 'RISK_FILTER', 'FULL_SIGNAL_ADJUSTMENT'].includes(merged.newsRiskMode) ? merged.newsRiskMode : 'RISK_FILTER',
    pauseMinutesBeforeHighImpact: clamp(Math.trunc(numberOr(merged.pauseMinutesBeforeHighImpact, 30)), 0, 1440),
    pauseMinutesAfterHighImpact: clamp(Math.trunc(numberOr(merged.pauseMinutesAfterHighImpact, 30)), 0, 1440),
    closeOrReduceBeforeEvent: ['NONE', 'REDUCE', 'CLOSE'].includes(merged.closeOrReduceBeforeEvent) ? merged.closeOrReduceBeforeEvent : 'NONE',
    allowPositionManagementDuringBlackout: merged.allowPositionManagementDuringBlackout !== false,
    requireLiveReadiness: merged.requireLiveReadiness !== false,
    minimumClosedDemoTrades: clamp(Math.trunc(numberOr(merged.minimumClosedDemoTrades, 100)), 0, 100000),
    minimumForwardTestDays: clamp(Math.trunc(numberOr(merged.minimumForwardTestDays, 28)), 0, 3650),
    maximumCriticalExecutionErrors: clamp(Math.trunc(numberOr(merged.maximumCriticalExecutionErrors, 0)), 0, 1000),
    maximumDuplicateOrders: clamp(Math.trunc(numberOr(merged.maximumDuplicateOrders, 0)), 0, 1000),
    maximumUnresolvedOrderIntents: clamp(Math.trunc(numberOr(merged.maximumUnresolvedOrderIntents, 0)), 0, 1000),
    syncAlgorithm: merged.syncAlgorithm !== false,
    algorithmSettings: sanitizeSharedSettings(merged.algorithmSettings),
    learningRecords: mergeLearningRecords(merged.learningRecords).slice(0, 300),
    liveTradingUnlocked: Boolean(merged.liveTradingUnlocked),
    liveUnlockPhrase: String(merged.liveUnlockPhrase || ''),
    pauseReason: String(merged.pauseReason || '').slice(0, 240),
    updatedAt: Number(merged.updatedAt || Date.now())
  };
}

export function utcDayKey(timestamp = Date.now()) {
  return new Date(timestamp).toISOString().slice(0, 10);
}

export function utcWeekKey(timestamp = Date.now()) {
  const date = new Date(timestamp);
  const day = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const week = Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
  return `${date.getUTCFullYear()}-W${String(week).padStart(2, '0')}`;
}

export function emptyWeeklyState(now = Date.now()) {
  return { week: utcWeekKey(now), trades: 0, realizedPnlUsd: 0 };
}

export function emptyDailyState(now = Date.now(), startBalance = null) {
  return {
    day: utcDayKey(now),
    trades: 0,
    realizedPnlUsd: 0,
    consecutiveLosses: 0,
    lastTradeAt: 0,
    startBalance: finite(startBalance) ? Number(startBalance) : null
  };
}

export function defaultAutoTradeState(now = Date.now()) {
  return {
    schema: AUTO_TRADE_SCHEMA,
    status: 'IDLE',
    lastRunAt: 0,
    lastSuccessAt: 0,
    lastError: null,
    lastDecision: 'ยังไม่เคยสแกน',
    resolvedEpic: null,
    brokerAccount: null,
    activeAccountKey: null,
    accountLedgers: {},
    pendingSignal: null,
    paperPosition: null,
    lastClosedTrade: null,
    lastBrokerOrder: null,
    trackedBrokerOrders: {},
    cloudJournal: [],
    learningSummary: null,
    modelDrift: { status: 'INSUFFICIENT_DATA', pauseAdaptive: false, reasons: [] },
    dataQuality: null,
    newsContext: null,
    liveReadiness: null,
    liveUnlock: null,
    brokerSession: null,
    executionLock: null,
    orderIntents: {},
    duplicateOrderCount: 0,
    criticalExecutionErrors: 0,
    apiErrorStreak: 0,
    lastProcessedCandles: {},
    forwardTest: { startedAt: 0, days: 0, signals: 0, open: 0, closed: 0, pnl: 0, expectancyR: 0 },
    forwardPositions: {},
    pendingExecutions: {},
    weekly: emptyWeeklyState(now),
    peakBalance: null,
    currentDrawdownPercent: 0,
    marginUsagePercent: 0,
    reconciliationMismatch: 0,
    systemVersion: '3.2.0',
    daily: emptyDailyState(now),
    logs: []
  };
}

export function accountLedgerKey(environment, account = {}) {
  const id = String(account?.accountId || account?.accountName || 'unknown').trim() || 'unknown';
  return `capital:${environment === 'live' ? 'live' : 'demo'}:${id}`;
}

export function syncActiveAccountLedger(stateInput = {}) {
  const state = { ...stateInput };
  if (!state.activeAccountKey) return state;
  return {
    ...state,
    accountLedgers: {
      ...(state.accountLedgers || {}),
      [state.activeAccountKey]: { ...(state.daily || emptyDailyState()) }
    }
  };
}

export function activateAccountLedger(stateInput = {}, environment = 'demo', account = {}, now = Date.now()) {
  let state = { ...defaultAutoTradeState(now), ...(stateInput || {}) };
  state.accountLedgers = { ...(state.accountLedgers || {}) };
  const key = accountLedgerKey(environment, account);
  const current = state.accountLedgers[key];
  const balance = finite(account?.balance) ? Number(account.balance) : null;
  const ledger = current?.day === utcDayKey(now)
    ? { ...emptyDailyState(now, balance), ...current }
    : emptyDailyState(now, balance);
  if (!finite(ledger.startBalance) && finite(balance)) ledger.startBalance = balance;
  state.activeAccountKey = key;
  state.daily = ledger;
  state.accountLedgers[key] = ledger;
  return state;
}

export function rolloverDailyState(stateInput = {}, now = Date.now()) {
  let state = { ...defaultAutoTradeState(now), ...(stateInput || {}) };
  const day = utcDayKey(now);
  if (state.daily?.day !== day) state.daily = emptyDailyState(now, state.brokerAccount?.balance);
  if (state.weekly?.week !== utcWeekKey(now)) state.weekly = emptyWeeklyState(now);
  return syncActiveAccountLedger(state);
}

export function appendAutoTradeLog(stateInput, level, message, details = null, now = Date.now()) {
  const state = rolloverDailyState(stateInput, now);
  const entry = {
    id: `${now}-${Math.random().toString(36).slice(2, 8)}`,
    at: now,
    level: ['info', 'warn', 'error', 'trade'].includes(level) ? level : 'info',
    message: String(message || ''),
    details: details ?? null
  };
  return { ...state, logs: [entry, ...(state.logs || [])].slice(0, 100) };
}

export function appendCloudJournal(stateInput, trade) {
  if (!trade || !Number(trade.endedAt || trade.closedAt)) return stateInput;
  const state = { ...stateInput };
  const record = {
    ...trade,
    endedAt: Number(trade.endedAt || trade.closedAt),
    source: trade.source || 'cloud-autotrade'
  };
  const key = `${record.id || record.planId || record.dealId || 'trade'}-${record.endedAt}`;
  const current = Array.isArray(state.cloudJournal) ? state.cloudJournal : [];
  const filtered = current.filter(row => `${row.id || row.planId || row.dealId || 'trade'}-${Number(row.endedAt || row.closedAt)}` !== key);
  return { ...state, cloudJournal: [record, ...filtered].slice(0, 500) };
}

export function evaluateEntryWindow(plan, price, tolerance = 0) {
  if (!plan || !finite(price)) return { eligible: false, reason: 'invalid-plan-or-price' };
  const low = Math.min(Number(plan.entryLow), Number(plan.entryHigh)) - Math.max(0, Number(tolerance || 0));
  const high = Math.max(Number(plan.entryLow), Number(plan.entryHigh)) + Math.max(0, Number(tolerance || 0));
  const value = Number(price);
  return {
    eligible: value >= low - 1e-9 && value <= high + 1e-9,
    reason: value < low ? 'price-below-entry-window' : value > high ? 'price-above-entry-window' : 'inside-entry-window',
    low: round(low, 3),
    high: round(high, 3),
    price: round(value, 3)
  };
}

export function checkRiskGuards({ config: configInput, state: stateInput, openPositions = 0, pendingOrders = 0, spreadUsd = 0, brokerLatencyMs = 0, now = Date.now() }) {
  const config = normalizeAutoTradeConfig(configInput);
  const state = rolloverDailyState(stateInput, now);
  const reasons = [];

  if (!config.enabled) reasons.push('ระบบ Auto Trade ปิดอยู่');
  if (openPositions >= config.maxOpenPositions) reasons.push('มีสถานะเปิดครบจำนวนสูงสุดแล้ว');
  if (pendingOrders >= config.maxPendingOrders && config.maxPendingOrders >= 0) reasons.push('มีคำสั่งรอครบจำนวนสูงสุดแล้ว');
  if (state.daily.trades >= config.maxTradesPerDay) reasons.push('ถึงจำนวนเทรดสูงสุดต่อวันแล้ว');
  if (state.daily.realizedPnlUsd <= -Math.abs(config.maxDailyLossUsd)) reasons.push('ถึงขีดจำกัดขาดทุนสะสมต่อวันแล้ว');
  if (Number(state.weekly?.realizedPnlUsd || 0) <= -Math.abs(config.maxWeeklyLossUsd)) reasons.push('ถึงขีดจำกัดขาดทุนสะสมต่อสัปดาห์แล้ว');
  if (Number(state.currentDrawdownPercent || 0) >= config.maxDrawdownPercent) reasons.push('Drawdown ถึงขีดจำกัดแล้ว');
  if (Number(state.marginUsagePercent || 0) >= config.maxMarginUsagePercent) reasons.push('การใช้ Margin ถึงขีดจำกัดแล้ว');
  if (Number(state.reconciliationMismatch || 0) > config.maxReconciliationMismatch) reasons.push('พบความคลาดเคลื่อนจาก Broker เกินขีดจำกัด');
  if (state.daily.consecutiveLosses >= config.maxConsecutiveLosses) reasons.push('แพ้ต่อเนื่องถึงขีดจำกัดแล้ว');
  if (Number(spreadUsd || 0) > config.maxSpreadUsd) reasons.push('Spread สูงกว่าค่าที่อนุญาต');
  if (Number(brokerLatencyMs || 0) > config.maxBrokerLatencyMs) reasons.push('Broker latency สูงกว่าค่าที่อนุญาต');
  if (Number(state.apiErrorStreak || 0) >= config.maxApiErrorStreak) reasons.push('Broker/API ผิดพลาดต่อเนื่องถึงขีดจำกัด');
  if (state.dataQuality && Number(state.dataQuality.score || 0) < config.minimumDataQualityScore) reasons.push('คุณภาพข้อมูลตลาดต่ำกว่าเกณฑ์');
  if (state.newsContext?.blackout?.blocked && ['RISK_FILTER', 'FULL_SIGNAL_ADJUSTMENT'].includes(config.newsRiskMode)) reasons.push('อยู่ในช่วงหยุดเปิดออเดอร์ก่อน/หลังข่าวสำคัญ');
  const cooldownMs = config.cooldownMinutes * 60_000;
  if (cooldownMs > 0 && state.daily.lastTradeAt > 0 && now - state.daily.lastTradeAt < cooldownMs) reasons.push('ยังอยู่ในช่วงพักหลังเทรดล่าสุด');
  const canSendRealOrder = config.brokerEnvironment === 'live' && ['confirm', 'auto'].includes(config.executionMode);
  const unlock = state.liveUnlock;
  const sessionUnlock = unlock?.active === true && Number(unlock.expiresAt || 0) > now && unlock.accountKey === state.activeAccountKey;
  const legacyUnlock = config.liveTradingUnlocked && config.liveUnlockPhrase === 'LIVE';
  if (canSendRealOrder && !(sessionUnlock || legacyUnlock)) reasons.push('การส่งคำสั่งเงินจริงยังไม่ถูกปลดล็อกด้วยคำว่า LIVE');
  if (canSendRealOrder && config.requireLiveReadiness && state.liveReadiness?.passed !== true) reasons.push('Live Readiness Gate ยังไม่ผ่าน');

  return { allowed: reasons.length === 0, reasons, state };
}

export function createPaperPosition(plan, price, size, now = Date.now()) {
  if (!plan || !finite(price) || !finite(size)) throw new Error('ข้อมูลเปิด Paper position ไม่ครบ');
  const targetKey = ['tp1', 'tp2', 'tp3'].includes(plan.exitAtTarget) ? plan.exitAtTarget : 'tp2';
  const direction = Number(plan.direction) === -1 ? -1 : 1;
  const entry = Number(price);
  const valuePerPriceUnit = Number(plan.valuePerPriceUnit || 1);
  const initialRiskUsd = Math.abs(entry - Number(plan.stopLoss)) * valuePerPriceUnit;
  return {
    id: `paper-${now}`,
    planId: plan.id,
    openedAt: now,
    direction,
    directionLabel: direction === -1 ? 'SELL' : 'BUY',
    size: Number(size),
    entry,
    entryLow: Number(plan.entryLow ?? entry),
    entryHigh: Number(plan.entryHigh ?? entry),
    stopLoss: Number(plan.stopLoss),
    tp1: Number(plan.tp1),
    tp2: Number(plan.tp2),
    tp3: Number(plan.tp3),
    takeProfit: Number(plan[targetKey] ?? plan.tp2),
    targetKey,
    strategy: plan.strategy,
    strategyKey: plan.strategyKey,
    timeframe: plan.timeframe,
    timeframeLabel: plan.timeframeLabel || plan.timeframe,
    score: Number(plan.score),
    adaptiveAdjustment: Number(plan.adaptiveAdjustment || 0),
    regime: plan.regime || 'unknown',
    valuePerPriceUnit,
    initialRiskUsd: round(initialRiskUsd, 4),
    dataMode: plan.dataMode || 'demo',
    status: 'OPEN'
  };
}

export function evaluatePaperPosition(position, candle, now = Date.now()) {
  if (!position || position.status !== 'OPEN' || !candle) return { closed: false, position };
  const high = Number(candle.high);
  const low = Number(candle.low);
  if (![high, low].every(Number.isFinite)) return { closed: false, position };
  const isBuy = Number(position.direction) === 1;
  const hitStop = isBuy ? low <= position.stopLoss : high >= position.stopLoss;
  const hitTarget = isBuy ? high >= position.takeProfit : low <= position.takeProfit;
  if (!hitStop && !hitTarget) return { closed: false, position };

  const exitReason = hitStop ? 'STOP_LOSS' : 'TAKE_PROFIT';
  const exitPrice = hitStop ? Number(position.stopLoss) : Number(position.takeProfit);
  const pnlUsd = (exitPrice - Number(position.entry)) * Number(position.direction) * Number(position.valuePerPriceUnit || 1);
  const riskUsd = Math.max(0.0001, Number(position.initialRiskUsd || Math.abs(Number(position.entry) - Number(position.stopLoss)) * Number(position.valuePerPriceUnit || 1)));
  return {
    closed: true,
    position: {
      ...position,
      status: hitStop ? 'STOPPED' : 'COMPLETED',
      closedAt: now,
      endedAt: now,
      exitPrice: round(exitPrice, 3),
      exitReason,
      outcome: hitStop ? 'SL' : String(position.targetKey || 'TP').toUpperCase(),
      pnlUsd: round(pnlUsd, 2),
      resultR: round(pnlUsd / riskUsd, 4)
    }
  };
}

export function recordClosedTrade(stateInput, trade, now = Date.now(), { countTrade = true } = {}) {
  let state = rolloverDailyState(stateInput, now);
  const pnl = Number(trade?.pnlUsd || trade?.realizedPnlEstimateUsd || 0);
  state = {
    ...state,
    lastClosedTrade: trade,
    daily: {
      ...state.daily,
      trades: Number(state.daily.trades || 0) + (countTrade ? 1 : 0),
      realizedPnlUsd: round(Number(state.daily.realizedPnlUsd || 0) + pnl, 2),
      consecutiveLosses: pnl < 0 ? Number(state.daily.consecutiveLosses || 0) + 1 : pnl > 0 ? 0 : Number(state.daily.consecutiveLosses || 0),
      lastTradeAt: Number(trade?.closedAt || trade?.endedAt || now)
    },
    weekly: {
      ...(state.weekly || emptyWeeklyState(now)),
      trades: Number(state.weekly?.trades || 0) + (countTrade ? 1 : 0),
      realizedPnlUsd: round(Number(state.weekly?.realizedPnlUsd || 0) + pnl, 2)
    }
  };
  state = appendCloudJournal(state, trade);
  state = syncActiveAccountLedger(state);
  return appendAutoTradeLog(state, 'trade', `${trade.directionLabel || ''} ปิด ${trade.exitReason || trade.outcome || ''} ${pnl >= 0 ? '+' : ''}$${round(pnl, 2)}`, trade, now);
}
