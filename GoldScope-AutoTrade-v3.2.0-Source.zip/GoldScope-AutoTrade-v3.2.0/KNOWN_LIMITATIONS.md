# Known Limitations — v3.2.0

ระบบรุ่นนี้ปิดช่องว่างด้าน execution, Queue, Forward Test, reconciliation และ observability ไปมากแล้ว แต่ยังมีข้อจำกัดที่ต้องยืนยันบนระบบจริง:

1. **ยังไม่ได้ส่ง Capital.com Demo order ด้วย credential ของผู้ใช้ใน environment นี้** จึงต้องทำ Broker test, calibration, accepted/rejected/timeout และ close-history drill หลัง Deploy.
2. Capital.com history payload อาจต่างตามประเภทบัญชี/ภูมิภาค แม้ adapter จะ match `dealId/dealReference/reference` แบบเข้มงวด ต้องตรวจรายการจริงก่อนอนุญาตให้ reconciliation test ผ่าน.
3. News/Economic provider เป็น generic licensed-provider adapter; ต้องเลือกผู้ให้บริการที่มีสิทธิ์ใช้งานและ map schema/limits จริง. ระบบจะทำงานแบบ `NOT_CONFIGURED` อย่างปลอดภัยเมื่อไม่มี provider.
4. Backtest ยังเป็น candle simulation ไม่ใช่ tick/order-book replay; partial fill, financing, historical variable spread และ liquidity depth ยังจำลองได้ไม่เต็มรูปแบบ.
5. Parameter-sensitivity grid และ walk-forward visualization ยังไม่ละเอียดเท่าระบบวิจัยเฉพาะทาง แม้ core มี walk-forward, frozen adaptive model, Monte Carlo และ cost/spread/slippage/delay stress test.
6. Champion/Challenger มี promotion/rollback rules และ D1 event schema; runtime ตรวจ performance/regime drift และหยุด Adaptive adjustment ได้แล้ว แต่ automated retraining และ automatic promotion ยังไม่เปิดใช้ เพื่อไม่ให้โมเดลเปลี่ยนเองโดยไม่มีการตรวจสอบ.
7. Notification ภายนอกรองรับ Telegram และ generic webhook; ยังไม่มีมาตรฐาน Web Push แบบ VAPID สำหรับแจ้งเตือนเมื่อ PWA ปิด. Browser notification ใช้ได้เมื่อ PWA เปิดและผู้ใช้ให้สิทธิ์.
8. GoldScope รุ่นนี้ออกแบบสำหรับ XAU/USD บัญชีเดียวต่อ state object; portfolio exposure ระหว่างหลาย symbol/broker ยังไม่ใช่ระบบ portfolio risk เต็มรูปแบบ.
9. ระบบไม่ลดหรือปิด position ก่อนข่าวแรงโดยอัตโนมัติเป็นค่าเริ่มต้น เพราะเป็นการกระทำที่มีความเสี่ยง; ระหว่าง blackout ยัง reconcile/จัดการ SL/TP/Kill Switch ได้.
10. ยังไม่ได้ทำ remote Cloudflare load test, external penetration test, chaos test บน production account หรือทดสอบต่อเนื่องหลายสัปดาห์.
11. Live Readiness ยังไม่ผ่านจนกว่าจะมี Demo closed trades, Forward Test days, verified reconciliation, calibration และ out-of-sample metrics ตาม checklist.
12. ไม่มีระบบใดรับประกัน positive expectancy ในอนาคต ผลต้องประเมินหลัง spread, slippage, commission และต้นทุนจริงของบัญชีผู้ใช้.
