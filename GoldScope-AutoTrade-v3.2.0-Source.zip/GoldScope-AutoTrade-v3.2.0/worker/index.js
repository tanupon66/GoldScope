import { AutoTradeState } from './state.js';
import { CapitalClient, capitalConfigured } from './capital.js';
import {
  AuthState, authenticateRequest, clearSessionCookie, createSessionToken, hashIdentifier,
  securityHeaders, sessionCookie, verifyAdminCredential
} from './security.js';
import {
  auditLog, claimQueueMessage, completeQueueMessage, dbConfigured, listActiveAccounts, listAutomationTargets,
  upsertAccount, markAccountScan, persistMarketSnapshot, persistMarketCandles, persistNewsContext,
  recordDeadLetter, listDeadLetters, getDeadLetter, markDeadLetter, operationalHealth,
  createNotificationEvent, completeNotificationEvent, listNotificationEvents, recordProviderHealth, systemEvent,
  forwardTestSummary
} from './db.js';
import { loadNewsContext } from './news.js';
import { normalizeQueueEnvelope, queueIdempotencyKey, retryDelaySeconds } from '../src/core/queue.js';
import { deliverNotification, notificationEnvelope } from './notifications.js';

const APP_VERSION = '3.2.0';
const ALLOWED_INTERVALS = new Set(['1min', '5min', '15min', '1h', '4h']);
const MAX_OUTPUT = 5000;
const TTL_BY_INTERVAL = { '1min': 45, '5min': 180, '15min': 480, '1h': 1200, '4h': 3600 };

function requestId(request) {
  return request.headers.get('cf-ray') || request.headers.get('x-request-id') || crypto.randomUUID();
}

function json(data, status = 200, options = {}) {
  const payload = data?.requestId ? data : { ...data, requestId: options.requestId || data?.requestId || crypto.randomUUID() };
  return new Response(JSON.stringify(payload), {
    status,
    headers: securityHeaders({
      'content-type': 'application/json; charset=utf-8',
      'cache-control': options.cacheControl || 'no-store',
      ...(options.headers || {})
    })
  });
}

function apiError(code, message, status, requestIdValue, retryable = false, details = undefined) {
  return json({ ok: false, code, message, retryable, ...(details === undefined ? {} : { details }) }, status, { requestId: requestIdValue });
}

function normalizeSymbol(value) {
  const symbol = (value || 'XAU/USD').toUpperCase().trim();
  return symbol === 'XAUUSD' ? 'XAU/USD' : symbol;
}

function normalizeCandles(values = []) {
  const seen = new Set();
  return values.map(row => ({
    time: Math.floor(new Date(`${String(row.datetime || '').replace(' ', 'T')}Z`).getTime() / 1000),
    datetime: row.datetime,
    open: Number(row.open), high: Number(row.high), low: Number(row.low), close: Number(row.close), volume: Number(row.volume || 0)
  })).filter(c => {
    if (!Number.isFinite(c.time) || ![c.open, c.high, c.low, c.close].every(Number.isFinite) || seen.has(c.time)) return false;
    seen.add(c.time);
    return true;
  }).sort((a, b) => a.time - b.time);
}

async function twelveData(path, params, env, cacheTtl, rid) {
  if (!env.TWELVE_DATA_API_KEY) return apiError('API_KEY_MISSING', 'ยังไม่ได้ตั้งค่า TWELVE_DATA_API_KEY', 503, rid, false);
  const target = new URL(`https://api.twelvedata.com/${path}`);
  Object.entries(params).forEach(([key, value]) => target.searchParams.set(key, String(value)));
  target.searchParams.set('apikey', env.TWELVE_DATA_API_KEY);
  const cache = caches.default;
  const cacheKey = new Request(target.toString().replace(env.TWELVE_DATA_API_KEY, 'SECRET'));
  const cached = await cache.match(cacheKey);
  if (cached) return new Response(cached.body, cached);
  let upstream;
  try {
    upstream = await fetch(target, { headers: { 'user-agent': `GoldScope-AutoTrade/${APP_VERSION}` }, cf: { cacheEverything: false } });
  } catch {
    return apiError('UPSTREAM_UNREACHABLE', 'ไม่สามารถเชื่อมต่อผู้ให้บริการข้อมูลตลาดได้', 502, rid, true);
  }
  const payload = await upstream.json().catch(() => null);
  if (!upstream.ok || !payload || payload.status === 'error' || payload.code) {
    return apiError(payload?.code || 'UPSTREAM_ERROR', payload?.message || `Market data error (${upstream.status})`, upstream.status === 429 ? 429 : 502, rid, upstream.status === 429 || upstream.status >= 500);
  }
  const response = json(payload, 200, { requestId: rid, cacheControl: `public, max-age=${cacheTtl}` });
  await cache.put(cacheKey, response.clone());
  return response;
}

async function handleMarket(url, env, rid) {
  const symbol = normalizeSymbol(url.searchParams.get('symbol'));
  if (symbol !== 'XAU/USD') return apiError('SYMBOL_NOT_ALLOWED', 'รองรับ XAU/USD เท่านั้น', 400, rid);
  const interval = url.searchParams.get('interval') || '5min';
  if (!ALLOWED_INTERVALS.has(interval)) return apiError('INTERVAL_NOT_ALLOWED', 'กรอบเวลาไม่รองรับ', 400, rid);
  const outputsize = Math.min(MAX_OUTPUT, Math.max(100, Number(url.searchParams.get('outputsize') || 800)));
  const upstream = await twelveData('time_series', { symbol, interval, outputsize, timezone: 'UTC', format: 'JSON' }, env, TTL_BY_INTERVAL[interval], rid);
  if (!upstream.ok) return upstream;
  const data = await upstream.json();
  return json({ ok: true, source: 'twelvedata', symbol, interval, meta: data.meta || {}, candles: normalizeCandles(data.values), receivedAt: new Date().toISOString() }, 200, { requestId: rid });
}

async function handleQuote(url, env, rid) {
  const symbol = normalizeSymbol(url.searchParams.get('symbol'));
  if (symbol !== 'XAU/USD') return apiError('SYMBOL_NOT_ALLOWED', 'รองรับ XAU/USD เท่านั้น', 400, rid);
  const upstream = await twelveData('quote', { symbol, timezone: 'UTC' }, env, 20, rid);
  if (!upstream.ok) return upstream;
  const data = await upstream.json();
  return json({ ok: true, source: 'twelvedata', symbol, price: Number(data.close || data.price), open: Number(data.open), high: Number(data.high), low: Number(data.low), previousClose: Number(data.previous_close), percentChange: Number(data.percent_change), datetime: data.datetime || null, receivedAt: new Date().toISOString() }, 200, { requestId: rid });
}

function sanitizeAccountKey(value) {
  const raw = String(value || '').trim();
  if (/^capital:(demo|live):[A-Za-z0-9._:-]{1,120}$/.test(raw)) return raw;
  return 'capital:demo:setup';
}

function accountKeyFromRequest(request, url) {
  return sanitizeAccountKey(request.headers.get('x-account-key') || url.searchParams.get('accountKey') || 'capital:demo:setup');
}

function autoStub(env, accountKey) {
  const id = env.AUTO_TRADE_STATE.idFromName(sanitizeAccountKey(accountKey));
  return env.AUTO_TRADE_STATE.get(id);
}

function authStub(env) {
  const id = env.AUTH_STATE.idFromName('admin');
  return env.AUTH_STATE.get(id);
}

async function isRevoked(env, sid) {
  if (!env.AUTH_STATE || !sid) return false;
  const response = await authStub(env).fetch(`https://auth.internal/is-revoked?sid=${encodeURIComponent(sid)}`);
  return Boolean((await response.json().catch(() => ({}))).revoked);
}

async function requireAuth(request, env, rid, { csrf = false } = {}) {
  const auth = await authenticateRequest(request, env, { requireCsrf: csrf, expectedVersion: APP_VERSION });
  if (!auth.ok) return { response: apiError(auth.code || 'UNAUTHORIZED', auth.code === 'CSRF_INVALID' ? 'CSRF token ไม่ถูกต้อง' : 'Session หมดอายุหรือไม่ถูกต้อง', auth.code === 'CSRF_INVALID' ? 403 : 401, rid) };
  if (await isRevoked(env, auth.payload.sid)) return { response: apiError('SESSION_REVOKED', 'Session ถูกยกเลิกแล้ว', 401, rid) };
  return { auth };
}

function sameOrigin(request) {
  const origin = request.headers.get('origin');
  return !origin || origin === new URL(request.url).origin;
}

async function handleLogin(request, env, rid) {
  if (!sameOrigin(request)) return apiError('ORIGIN_NOT_ALLOWED', 'อนุญาตเฉพาะ same-origin', 403, rid);
  if (!env.ADMIN_CREDENTIAL_HASH || !env.SESSION_SIGNING_SECRET) return apiError('AUTH_NOT_CONFIGURED', 'ยังไม่ได้ตั้งค่า ADMIN_CREDENTIAL_HASH และ SESSION_SIGNING_SECRET', 503, rid);
  const body = await request.json().catch(() => ({}));
  const password = String(body.password || '');
  if (password.length < 1 || password.length > 512) return apiError('LOGIN_INPUT_INVALID', 'ข้อมูลเข้าสู่ระบบไม่ถูกต้อง', 400, rid);
  const ip = request.headers.get('cf-connecting-ip') || 'unknown';
  const key = await hashIdentifier(ip, env.SESSION_SIGNING_SECRET);
  const limiter = authStub(env);
  const check = await limiter.fetch('https://auth.internal/check', { method: 'POST', body: JSON.stringify({ key }) });
  const checkBody = await check.json();
  if (!checkBody.allowed) return apiError('LOGIN_LOCKED', 'กรอกรหัสผิดหลายครั้ง กรุณาลองใหม่ภายหลัง', 429, rid, true, { retryAfterMs: checkBody.retryAfterMs });
  const valid = await verifyAdminCredential(password, env.ADMIN_CREDENTIAL_HASH);
  if (!valid) {
    await limiter.fetch('https://auth.internal/fail', { method: 'POST', body: JSON.stringify({ key }) });
    await auditLog(env, { action: 'LOGIN_FAILED', requestId: rid, ipHash: key });
    return apiError('LOGIN_FAILED', 'รหัสผ่านไม่ถูกต้อง', 401, rid);
  }
  await limiter.fetch('https://auth.internal/success', { method: 'POST', body: JSON.stringify({ key }) });
  const created = await createSessionToken({ secret: env.SESSION_SIGNING_SECRET, ttlSeconds: Number(env.SESSION_TTL_SECONDS || 900), version: APP_VERSION });
  await auditLog(env, { action: 'LOGIN', requestId: rid, ipHash: key, actor: created.payload.sid });
  return json({ ok: true, authenticated: true, csrfToken: created.payload.csrf, expiresAt: created.payload.exp * 1000, version: APP_VERSION }, 200, {
    requestId: rid,
    headers: { 'set-cookie': sessionCookie(created.token, created.payload.exp - created.payload.iat) }
  });
}

async function handleSession(request, env, rid) {
  const required = await requireAuth(request, env, rid);
  if (required.response) return required.response;
  return json({ ok: true, authenticated: true, csrfToken: required.auth.payload.csrf, expiresAt: required.auth.payload.exp * 1000, version: APP_VERSION }, 200, { requestId: rid });
}

async function handleLogout(request, env, rid) {
  const required = await requireAuth(request, env, rid, { csrf: true });
  if (required.response) return required.response;
  await authStub(env).fetch('https://auth.internal/revoke', {
    method: 'POST',
    body: JSON.stringify({ sid: required.auth.payload.sid, expiresAt: required.auth.payload.exp * 1000 })
  });
  await auditLog(env, { action: 'LOGOUT', requestId: rid, actor: required.auth.payload.sid });
  return json({ ok: true }, 200, { requestId: rid, headers: { 'set-cookie': clearSessionCookie() } });
}

async function proxyAuto(request, env, path, rid, authPayload, accountKey, method = request.method) {
  const headers = {
    'content-type': 'application/json',
    'x-request-id': rid,
    'x-session-id': authPayload?.sid || '',
    'x-session-exp': String(authPayload?.exp || 0),
    'x-state-object-key': sanitizeAccountKey(accountKey)
  };
  const init = { method, headers };
  if (!['GET', 'HEAD'].includes(method)) init.body = await request.text();
  return autoStub(env, accountKey).fetch(`https://auto.internal${path}`, init);
}

async function handleBrokerTest(request, env, rid, authPayload, stateObjectKey) {
  if (!capitalConfigured(env)) return apiError('BROKER_SECRETS_MISSING', 'ยังไม่ได้ตั้งค่า Capital.com secrets', 503, rid);
  const body = await request.json().catch(() => ({}));
  const environment = body.environment === 'live' ? 'live' : 'demo';
  try {
    const client = new CapitalClient(env, environment);
    const account = await client.accountSummary(body.accountId || '');
    const market = await client.resolveGoldMarket(body.epic || '', body.searchTerm || 'Gold');
    if (!account?.accountId) return apiError('BROKER_ACCOUNT_MISSING', 'Broker ไม่ส่ง accountId กลับมา', 502, rid);
    const accountKey = `capital:${environment}:${account.accountId}`;
    await upsertAccount(env, { accountKey, broker: 'capital', environment, accountId: account.accountId, symbol: market.epic, active: false, stateObjectKey: sanitizeAccountKey(stateObjectKey) });
    await auditLog(env, { action: 'BROKER_TEST', requestId: rid, actor: authPayload.sid, accountKey, payload: { environment, epic: market.epic } });
    return json({
      ok: true,
      accountKey,
      environment,
      account: { accountId: account.accountId, currency: account.currency, balance: account.balance, available: account.available, status: account.status },
      market: {
        epic: market.epic,
        instrumentName: market.details?.instrument?.name || market.details?.instrumentName,
        marketStatus: market.details?.snapshot?.marketStatus,
        minDealSize: market.details?.dealingRules?.minDealSize,
        minStopDistance: market.details?.dealingRules?.minStopOrProfitDistance,
        tickSize: market.details?.instrument?.lotSize || market.details?.instrument?.scalingFactor || null
      },
      brokerLatencyMs: client.lastLatencyMs
    }, 200, { requestId: rid });
  } catch (error) {
    return apiError(error?.code || 'BROKER_TEST_FAILED', String(error?.message || 'ทดสอบ Broker ไม่สำเร็จ').replace(/CST|X-SECURITY-TOKEN|password/gi, '[REDACTED]'), 502, rid, Boolean(error?.status === 429 || error?.status >= 500));
  }
}

async function handleLegacyMigration(request, env, rid, authPayload, targetAccountKey) {
  const body = await request.json().catch(() => ({}));
  const legacyKey = 'primary';
  const source = env.AUTO_TRADE_STATE.get(env.AUTO_TRADE_STATE.idFromName(legacyKey));
  const sourceResponse = await source.fetch('https://auto.internal/status', { headers: { 'x-request-id': rid } });
  const legacy = await sourceResponse.json().catch(() => ({}));
  if (!sourceResponse.ok || legacy.ok === false) return apiError('LEGACY_STATE_UNAVAILABLE', 'ไม่สามารถอ่าน Durable Object v2 ชื่อ primary ได้', 404, rid);
  const preview = {
    source: legacyKey,
    target: targetAccountKey,
    executionMode: legacy.config?.executionMode || 'paper',
    environment: legacy.config?.brokerEnvironment || 'demo',
    cloudJournalEntries: Array.isArray(legacy.state?.cloudJournal) ? legacy.state.cloudJournal.length : 0,
    learningRecords: Array.isArray(legacy.config?.learningRecords) ? legacy.config.learningRecords.length : 0,
    accountLedgers: Object.keys(legacy.state?.accountLedgers || {}).length
  };
  if (body.confirm !== 'MIGRATE_V2') return json({ ok: true, dryRun: true, preview, instruction: 'ส่ง confirm=MIGRATE_V2 เพื่อเริ่มย้ายข้อมูล' }, 200, { requestId: rid });
  const target = autoStub(env, targetAccountKey);
  const imported = await target.fetch('https://auto.internal/import-legacy', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-request-id': rid, 'x-session-id': authPayload.sid },
    body: JSON.stringify({ legacy, sourceKey: legacyKey })
  });
  const result = await imported.json().catch(() => ({}));
  if (!imported.ok || result.ok === false) return apiError(result.code || 'LEGACY_IMPORT_FAILED', result.message || 'ย้ายข้อมูล v2 ไม่สำเร็จ', 500, rid);
  await auditLog(env, { action: 'MIGRATE_V2_STATE', requestId: rid, actor: authPayload.sid, accountKey: targetAccountKey, payload: preview });
  return json({ ok: true, migrated: true, preview, result }, 200, { requestId: rid });
}

function queueEnvelope(eventType, accountKey, payload = {}, correlationId = null, stateObjectKey = null, bucket = null) {
  const objectKey = sanitizeAccountKey(stateObjectKey || accountKey);
  const now = Date.now();
  return {
    messageId: crypto.randomUUID(), eventType,
    accountKey: sanitizeAccountKey(accountKey || objectKey), stateObjectKey: objectKey,
    createdAt: now, attempt: 0, correlationId: correlationId || crypto.randomUUID(),
    idempotencyKey: queueIdempotencyKey(eventType, objectKey, bucket ?? Math.floor(now / 60_000)),
    payloadVersion: 1, payload
  };
}

function queueBinding(env, eventType) {
  if (eventType === 'INGEST_MARKET') return env.MARKET_INGESTION_QUEUE;
  if (eventType === 'INGEST_NEWS') return env.NEWS_INGESTION_QUEUE;
  if (eventType === 'ANALYZE_SIGNAL') return env.SIGNAL_ANALYSIS_QUEUE;
  if (eventType === 'EXECUTE_ORDER') return env.ORDER_EXECUTION_QUEUE;
  if (eventType === 'RECONCILE_ACCOUNT') return env.BROKER_RECONCILIATION_QUEUE;
  if (eventType === 'DELIVER_NOTIFICATION') return env.NOTIFICATION_DELIVERY_QUEUE;
  return null;
}

async function sendQueue(env, message, options = undefined) {
  const queue = queueBinding(env, message.eventType);
  if (!queue) throw Object.assign(new Error(`Queue binding missing for ${message.eventType}`), { code: 'QUEUE_BINDING_MISSING' });
  await queue.send(message, options);
}

async function internalAutoFetch(env, stateObjectKey, path, message, body = null) {
  const response = await autoStub(env, stateObjectKey).fetch(`https://auto.internal${path}`, {
    method: body === null ? 'GET' : 'POST',
    headers: {
      'content-type': 'application/json', 'x-request-id': message.correlationId,
      'x-state-object-key': stateObjectKey
    },
    body: body === null ? undefined : JSON.stringify(body)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok === false) {
    const error = new Error(payload.message || `Internal Auto Trade failed (${response.status})`);
    error.code = payload.code || 'AUTO_INTERNAL_FAILED';
    error.retryable = response.status === 429 || response.status >= 500;
    throw error;
  }
  return payload;
}

async function runQueueMessage(rawMessage, env, deliveryAttempt = 0) {
  const message = normalizeQueueEnvelope(rawMessage, deliveryAttempt);
  const claim = await claimQueueMessage(env, message);
  if (!claim.claimed) return { replayed: true, status: claim.status || 'ALREADY_PROCESSING' };
  const startedAt = Date.now();
  try {
    if (message.eventType === 'INGEST_MARKET') {
      const result = await internalAutoFetch(env, message.stateObjectKey, '/market-data?outputsize=900', message);
      const quality = result.market?.dataQuality?.score ?? null;
      await persistMarketSnapshot(env, {
        accountKey: message.accountKey, provider: 'capital', symbol: result.epic,
        bid: result.market?.bid, ask: result.market?.ask, spread: result.market?.spreadUsd,
        marketStatus: result.market?.marketStatus, receivedAt: Date.now(), qualityScore: quality,
        payload: { environment: result.environment, accountId: result.account?.accountId }
      });
      for (const [timeframe, dataset] of Object.entries(result.datasets || {})) {
        await persistMarketCandles(env, {
          provider: 'capital', environment: result.environment, symbol: result.epic,
          timeframe, candles: dataset.candles || [], qualityScore: quality
        });
      }
      await recordProviderHealth(env, { component: `market:${message.stateObjectKey}`, status: 'HEALTHY', latencyMs: Date.now() - startedAt });
    } else if (message.eventType === 'INGEST_NEWS') {
      const status = await internalAutoFetch(env, message.stateObjectKey, '/status', message);
      const context = await loadNewsContext(env, status.config || {}, Date.now());
      await persistNewsContext(env, context);
      await recordProviderHealth(env, {
        component: 'news', status: context.errors?.length ? 'DEGRADED' : (context.configured ? 'HEALTHY' : 'NOT_CONFIGURED'),
        latencyMs: Date.now() - startedAt, metadata: { errors: context.errors || [] }
      });
    } else if (message.eventType === 'ANALYZE_SIGNAL') {
      const result = await internalAutoFetch(env, message.stateObjectKey, '/run', message, { trigger: 'cron' });
      await markAccountScan(env, { accountKey: message.stateObjectKey, ok: result.state?.status !== 'ERROR', errorCode: result.state?.lastError?.code || null });
      if (['RECONCILIATION_REQUIRED', 'ERROR'].includes(result.state?.status) || Number(result.state?.reconciliationMismatch || 0) > 0) {
        const reconcile = queueEnvelope('RECONCILE_ACCOUNT', message.accountKey, { reason: result.state?.status }, message.correlationId, message.stateObjectKey, `${message.idempotencyKey}:reconcile`);
        await sendQueue(env, reconcile, { delaySeconds: 60 });
      }
    } else if (message.eventType === 'EXECUTE_ORDER') {
      const result = await internalAutoFetch(env, message.stateObjectKey, '/execute-order', message, { idempotencyKey: message.payload.idempotencyKey });
      if (result.state?.status === 'RECONCILIATION_REQUIRED') {
        const reconcile = queueEnvelope('RECONCILE_ACCOUNT', message.accountKey, { idempotencyKey: message.payload.idempotencyKey }, message.correlationId, message.stateObjectKey, `${message.payload.idempotencyKey}:reconcile`);
        await sendQueue(env, reconcile, { delaySeconds: 30 });
      }
    } else if (message.eventType === 'RECONCILE_ACCOUNT') {
      await internalAutoFetch(env, message.stateObjectKey, '/run', message, { trigger: 'reconcile' });
    } else if (message.eventType === 'DELIVER_NOTIFICATION') {
      const event = notificationEnvelope(message.payload.eventType || 'SYSTEM_EVENT', message.payload, message.accountKey, message.correlationId);
      const dedupeKey = `${event.eventType}:${event.accountKey || 'global'}:${Math.floor(event.createdAt / 300000)}`;
      const created = await createNotificationEvent(env, { ...event, channel: 'multi', dedupeKey, payload: event.payload });
      if (created.created) {
        try {
          const delivery = await deliverNotification(env, event);
          await completeNotificationEvent(env, created.id, delivery.sent ? 'SENT' : 'SKIPPED', { ...event.payload, delivery });
        } catch (error) {
          await completeNotificationEvent(env, created.id, 'FAILED', { ...event.payload, error: { code: error?.code, message: String(error?.message || error) } });
          throw error;
        }
      }
    } else {
      throw Object.assign(new Error(`Unknown queue event ${message.eventType}`), { code: 'QUEUE_EVENT_UNKNOWN' });
    }
    await completeQueueMessage(env, message.messageId, 'COMPLETED');
    await systemEvent(env, { event: `QUEUE_${message.eventType}_COMPLETED`, correlationId: message.correlationId, accountKey: message.accountKey, durationMs: Date.now() - startedAt });
    return { completed: true };
  } catch (error) {
    await completeQueueMessage(env, message.messageId, 'RETRY_PENDING', { code: error?.code || 'QUEUE_FAILED', message: String(error?.message || error) });
    await systemEvent(env, { level: 'ERROR', event: `QUEUE_${message.eventType}_FAILED`, correlationId: message.correlationId, accountKey: message.accountKey, durationMs: Date.now() - startedAt, payload: { code: error?.code || null } });
    throw error;
  }
}

async function withSecurityHeaders(response) {
  const headers = new Headers(response.headers);
  for (const [key, value] of Object.entries(securityHeaders())) headers.set(key, value);
  const url = new URL(response.url || 'https://asset.internal/');
  if (headers.get('content-type')?.includes('text/html')) headers.set('cache-control', 'no-cache, no-store, must-revalidate');
  if (url.pathname.endsWith('/sw.js')) headers.set('cache-control', 'no-cache, no-store, must-revalidate');
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

export { AutoTradeState, AuthState };

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const rid = requestId(request);
    try {
      if (url.pathname === '/api/auth/login' && request.method === 'POST') return handleLogin(request, env, rid);
      if (url.pathname === '/api/auth/session' && request.method === 'GET') return handleSession(request, env, rid);
      if (url.pathname === '/api/auth/logout' && request.method === 'POST') return handleLogout(request, env, rid);

      if (url.pathname === '/api/health') {
        return json({
          ok: true, app: 'GoldScope AutoTrade', version: APP_VERSION,
          marketDataConfigured: Boolean(env.TWELVE_DATA_API_KEY),
          brokerConfigured: capitalConfigured(env),
          authenticationConfigured: Boolean(env.ADMIN_CREDENTIAL_HASH && env.SESSION_SIGNING_SECRET),
          durableObjectConfigured: Boolean(env.AUTO_TRADE_STATE && env.AUTH_STATE),
          d1Configured: dbConfigured(env),
          queuesConfigured: Boolean(env.SIGNAL_ANALYSIS_QUEUE),
          now: new Date().toISOString()
        }, 200, { requestId: rid });
      }
      if (url.pathname.startsWith('/api/')) {
        const csrf = !['GET', 'HEAD', 'OPTIONS'].includes(request.method);
        if (csrf && !sameOrigin(request)) return apiError('ORIGIN_NOT_ALLOWED', 'อนุญาตเฉพาะ same-origin', 403, rid);
        const required = await requireAuth(request, env, rid, { csrf });
        if (required.response) return required.response;
        const accountKey = accountKeyFromRequest(request, url);

        if (url.pathname === '/api/market' && request.method === 'GET') return handleMarket(url, env, rid);
        if (url.pathname === '/api/quote' && request.method === 'GET') return handleQuote(url, env, rid);

        if (url.pathname === '/api/system/health' && request.method === 'GET') {
          const [accounts, operations] = await Promise.all([listActiveAccounts(env), operationalHealth(env)]);
          return json({
            ok: true, version: APP_VERSION, accounts, operations,
            d1: dbConfigured(env), queues: Boolean(env.SIGNAL_ANALYSIS_QUEUE && env.ORDER_EXECUTION_QUEUE && env.BROKER_RECONCILIATION_QUEUE),
            currentAccountKey: accountKey, now: Date.now()
          }, 200, { requestId: rid });
        }
        if (url.pathname === '/api/system/dead-letters' && request.method === 'GET') {
          return json({ ok: true, items: await listDeadLetters(env, { status: url.searchParams.get('status') || 'OPEN', limit: Number(url.searchParams.get('limit') || 50) }) }, 200, { requestId: rid });
        }
        if (url.pathname === '/api/system/dead-letters/retry' && request.method === 'POST') {
          const body = await request.json().catch(() => ({}));
          const item = await getDeadLetter(env, body.id);
          if (!item) return apiError('DEAD_LETTER_NOT_FOUND', 'ไม่พบ Dead Letter', 404, rid);
          const replay = normalizeQueueEnvelope({ ...item.payload, messageId: crypto.randomUUID(), createdAt: Date.now(), attempt: 0,
            idempotencyKey: `${item.payload.idempotencyKey || item.id}:manual-retry:${Date.now()}` });
          await sendQueue(env, replay);
          await markDeadLetter(env, item.id, 'RETRIED');
          await auditLog(env, { action: 'DEAD_LETTER_RETRY', requestId: rid, actor: required.auth.payload.sid, accountKey: replay.accountKey, payload: { id: item.id, eventType: replay.eventType } });
          return json({ ok: true, replay }, 200, { requestId: rid });
        }
        if (url.pathname === '/api/system/dead-letters/dismiss' && request.method === 'POST') {
          const body = await request.json().catch(() => ({}));
          if (!(await markDeadLetter(env, body.id, 'DISMISSED'))) return apiError('DEAD_LETTER_NOT_FOUND', 'ไม่พบ Dead Letter', 404, rid);
          await auditLog(env, { action: 'DEAD_LETTER_DISMISS', requestId: rid, actor: required.auth.payload.sid, payload: { id: body.id } });
          return json({ ok: true }, 200, { requestId: rid });
        }
        if (url.pathname === '/api/system/notifications' && request.method === 'GET') {
          return json({ ok: true, items: await listNotificationEvents(env, accountKey, Number(url.searchParams.get('limit') || 50)) }, 200, { requestId: rid });
        }
        if (url.pathname === '/api/forward-test/status' && request.method === 'GET') {
          const [remote, stored] = await Promise.all([
            proxyAuto(request, env, '/forward-test/status', rid, required.auth.payload, accountKey, 'GET'),
            forwardTestSummary(env, accountKey)
          ]);
          const payload = await remote.json().catch(() => ({}));
          return json({ ok: remote.ok, state: payload.forwardTest || {}, positions: payload.positions || [], stored }, remote.status, { requestId: rid });
        }
        if (url.pathname === '/api/news/context' && request.method === 'GET') {
          const context = await loadNewsContext(env, { newsRiskMode: url.searchParams.get('mode') || 'RISK_FILTER' });
          return json({ ok: true, ...context }, 200, { requestId: rid });
        }
        if (url.pathname === '/api/system/migrate-v2' && request.method === 'POST') return handleLegacyMigration(request, env, rid, required.auth.payload, accountKey);
        if (url.pathname === '/api/autotrade/broker-test' && request.method === 'POST') return handleBrokerTest(request, env, rid, required.auth.payload, accountKey);
        if (url.pathname === '/api/autotrade/status' && request.method === 'GET') return proxyAuto(request, env, '/status', rid, required.auth.payload, accountKey, 'GET');
        if (url.pathname === '/api/autotrade/config' && request.method === 'GET') return proxyAuto(request, env, '/status', rid, required.auth.payload, accountKey, 'GET');
        if (url.pathname === '/api/autotrade/market-data' && request.method === 'GET') {
          const outputsize = Math.min(1000, Math.max(100, Number(url.searchParams.get('outputsize') || 900)));
          return proxyAuto(request, env, `/market-data?outputsize=${outputsize}`, rid, required.auth.payload, accountKey, 'GET');
        }
        if (url.pathname === '/api/autotrade/reconcile' && request.method === 'POST') {
          const synthetic = new Request(request.url, { method: 'POST', headers: request.headers, body: JSON.stringify({ trigger: 'reconcile' }) });
          const response = await proxyAuto(synthetic, env, '/run', rid, required.auth.payload, accountKey, 'POST');
          await auditLog(env, { action: 'AUTOTRADE_RECONCILE', requestId: rid, actor: required.auth.payload.sid, accountKey });
          return response;
        }
        const writes = {
          '/api/autotrade/config': '/config',
          '/api/autotrade/run': '/run',
          '/api/autotrade/confirm': '/confirm',
          '/api/autotrade/pause': '/pause',
          '/api/autotrade/kill': '/kill',
          '/api/autotrade/reset': '/reset',
          '/api/autotrade/live-unlock': '/live-unlock',
          '/api/autotrade/calibration': '/calibration'
        };
        if (writes[url.pathname]) {
          const response = await proxyAuto(request, env, writes[url.pathname], rid, required.auth.payload, accountKey, request.method === 'PUT' ? 'PUT' : 'POST');
          await auditLog(env, { action: `AUTOTRADE_${writes[url.pathname].slice(1).toUpperCase()}`, requestId: rid, actor: required.auth.payload.sid, accountKey });
          return response;
        }
        return apiError('NOT_FOUND', 'API route not found', 404, rid);
      }
      return withSecurityHeaders(await env.ASSETS.fetch(request));
    } catch (error) {
      return apiError(error?.code || 'INTERNAL_ERROR', 'ระบบขัดข้องและไม่ได้ส่งคำสั่งซ้ำอัตโนมัติ', 500, rid, false);
    }
  },

  async scheduled(controller, env, ctx) {
    ctx.waitUntil((async () => {
      const minuteBucket = Math.floor(Date.now() / 60_000);
      const targets = await listAutomationTargets(env);
      if (!targets.length) {
        await systemEvent(env, { event: 'CRON_SKIPPED_NO_ACTIVE_ACCOUNTS', payload: { cron: controller.cron || null } });
        return;
      }
      for (const target of targets) {
        const accountKey = target.account_key || target.stateObjectKey;
        const stateObjectKey = target.stateObjectKey || target.state_object_key || accountKey;
        await sendQueue(env, queueEnvelope('ANALYZE_SIGNAL', accountKey, { cron: controller.cron || null }, null, stateObjectKey, minuteBucket));
        if (minuteBucket % 5 === 0) {
          await Promise.all([
            sendQueue(env, queueEnvelope('INGEST_MARKET', accountKey, { cron: controller.cron || null }, null, stateObjectKey, Math.floor(minuteBucket / 5))),
            sendQueue(env, queueEnvelope('INGEST_NEWS', accountKey, { cron: controller.cron || null }, null, stateObjectKey, Math.floor(minuteBucket / 5)))
          ]);
        }
      }
    })());
  },

  async queue(batch, env) {
    const isDeadLetterBatch = String(batch.queue || '').includes('dead-letter');
    for (const queueMessage of batch.messages) {
      const normalized = (() => {
        try { return normalizeQueueEnvelope(queueMessage.body, queueMessage.attempts || 0); }
        catch { return { ...(queueMessage.body || {}), attempt: queueMessage.attempts || 0 }; }
      })();
      if (isDeadLetterBatch) {
        await recordDeadLetter(env, normalized, { code: 'MAX_RETRIES_EXCEEDED', queue: batch.queue });
        if (normalized.messageId) await completeQueueMessage(env, normalized.messageId, 'DEAD_LETTERED', { queue: batch.queue });
        queueMessage.ack();
        continue;
      }
      try {
        await runQueueMessage(normalized, env, queueMessage.attempts || 0);
        queueMessage.ack();
      } catch (error) {
        const attempts = Number(queueMessage.attempts || normalized.attempt || 0);
        queueMessage.retry({ delaySeconds: retryDelaySeconds(attempts) });
      }
    }
  }

};
