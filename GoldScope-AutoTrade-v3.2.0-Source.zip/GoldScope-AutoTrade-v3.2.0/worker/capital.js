const LIVE_BASE = 'https://api-capital.backend-capital.com';
const DEMO_BASE = 'https://demo-api-capital.backend-capital.com';

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const SESSION_MAX_AGE_MS = 8 * 60_000;

function retryDelay(response, attempt) {
  const retryAfter = Number(response?.headers?.get?.('retry-after'));
  if (Number.isFinite(retryAfter) && retryAfter >= 0) return Math.min(30_000, retryAfter * 1000);
  return Math.min(5000, 300 * (2 ** attempt) + Math.floor(Math.random() * 200));
}

async function fetchWithTimeout(url, init = {}, timeoutMs = 10_000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort('timeout'), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function parseJson(text) {
  try { return JSON.parse(text); } catch { return { raw: text }; }
}

function asError(payload, response, fallback) {
  const code = payload?.errorCode || payload?.code || `HTTP_${response.status}`;
  const message = payload?.errorMessage || payload?.message || payload?.error || fallback || response.statusText;
  const error = new Error(`${code}: ${message}`);
  error.code = code;
  error.status = response.status;
  error.payload = payload;
  return error;
}

export function extractCapitalDealId(confirmation = {}) {
  const affected = Array.isArray(confirmation?.affectedDeals) ? confirmation.affectedDeals : [];
  return affected.find(item => item?.status === 'OPENED' && item?.dealId)?.dealId
    || affected.find(item => item?.dealId)?.dealId
    || confirmation?.dealId
    || null;
}

export function capitalConfigured(env = {}) {
  return Boolean(env.CAPITAL_API_KEY && env.CAPITAL_IDENTIFIER && env.CAPITAL_API_PASSWORD);
}

export class CapitalClient {
  constructor(env, environment = 'demo', session = null) {
    this.env = env;
    this.environment = environment === 'live' ? 'live' : 'demo';
    this.base = this.environment === 'live' ? LIVE_BASE : DEMO_BASE;
    this.session = session?.cst && session?.securityToken ? { ...session } : null;
    this.lastLatencyMs = 0;
  }

  exportSession() {
    return this.session ? { ...this.session, environment: this.environment } : null;
  }

  async login() {
    if (!capitalConfigured(this.env)) throw new Error('ยังไม่ได้ตั้งค่า CAPITAL_API_KEY, CAPITAL_IDENTIFIER และ CAPITAL_API_PASSWORD');
    const startedAt = Date.now();
    const response = await fetchWithTimeout(`${this.base}/api/v1/session`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'X-CAP-API-KEY': this.env.CAPITAL_API_KEY,
        'user-agent': 'GoldScope-AutoTrade/3.2.0'
      },
      body: JSON.stringify({
        identifier: this.env.CAPITAL_IDENTIFIER,
        password: this.env.CAPITAL_API_PASSWORD,
        encryptedPassword: false
      })
    }, Number(this.env.BROKER_TIMEOUT_MS || 10_000));
    this.lastLatencyMs = Date.now() - startedAt;
    const text = await response.text();
    const payload = parseJson(text);
    if (!response.ok) throw asError(payload, response, 'เข้าสู่ Capital.com API ไม่สำเร็จ');
    const cst = response.headers.get('cst');
    const securityToken = response.headers.get('x-security-token');
    if (!cst || !securityToken) throw new Error('Capital.com ไม่ส่ง session token กลับมา');
    this.session = { cst, securityToken, createdAt: Date.now(), account: payload };
    return this.session;
  }

  async request(path, { method = 'GET', body, query, attempt = 0 } = {}) {
    const safeMethod = ['GET', 'HEAD'].includes(method);
    if (!this.session || Date.now() - Number(this.session.createdAt || 0) > SESSION_MAX_AGE_MS) await this.login();
    const url = new URL(`${this.base}/api/v1${path}`);
    Object.entries(query || {}).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, String(value));
    });
    const startedAt = Date.now();
    const response = await fetchWithTimeout(url, {
      method,
      headers: {
        'content-type': 'application/json',
        'X-CAP-API-KEY': this.env.CAPITAL_API_KEY,
        CST: this.session.cst,
        'X-SECURITY-TOKEN': this.session.securityToken,
        'user-agent': 'GoldScope-AutoTrade/3.2.0'
      },
      body: body === undefined ? undefined : JSON.stringify(body)
    }, Number(this.env.BROKER_TIMEOUT_MS || 10_000));
    this.lastLatencyMs = Date.now() - startedAt;
    const text = await response.text();
    const payload = text ? parseJson(text) : {};
    const refreshedCst = response.headers.get('cst');
    const refreshedToken = response.headers.get('x-security-token');
    if (this.session && (refreshedCst || refreshedToken)) {
      this.session = {
        ...this.session,
        cst: refreshedCst || this.session.cst,
        securityToken: refreshedToken || this.session.securityToken,
        createdAt: Date.now()
      };
    }
    if (!response.ok) {
      const expired = response.status === 401 || ['error.security.client-token-invalid', 'error.security.account-token-invalid'].includes(payload?.errorCode);
      if (expired && safeMethod && attempt < 1) {
        this.session = null;
        await this.login();
        return this.request(path, { method, body, query, attempt: attempt + 1 });
      }
      if ((response.status === 429 || response.status >= 500) && safeMethod && attempt < 2) {
        await sleep(retryDelay(response, attempt));
        return this.request(path, { method, body, query, attempt: attempt + 1 });
      }
      const error = asError(payload, response, `Capital.com request failed: ${path}`);
      if (!safeMethod && (expired || response.status === 429 || response.status >= 500)) error.reconciliationRequired = true;
      throw error;
    }
    return { payload, headers: response.headers };
  }

  async getAccounts() {
    return (await this.request('/accounts')).payload;
  }

  async switchAccount(accountId) {
    const target = String(accountId || '').trim();
    if (!target) return this.session?.account || null;
    if (!this.session) await this.login();
    if (String(this.session?.account?.accountId || '') === target) return this.session.account;
    const { payload } = await this.request('/session', { method: 'PUT', body: { accountId: target } });
    this.session = {
      ...this.session,
      createdAt: Date.now(),
      account: { ...(this.session?.account || {}), ...(payload || {}), accountId: target }
    };
    return this.session.account;
  }

  async ensureAccount(accountId) {
    const target = String(accountId || '').trim();
    if (!target) return this.session?.account || null;
    const accounts = (await this.getAccounts()).accounts || [];
    const match = accounts.find(item => String(item.accountId) === target);
    if (!match) {
      const error = new Error(`ไม่พบบัญชี Capital.com accountId=${target} ใน environment ${this.environment}`);
      error.code = 'BROKER_ACCOUNT_NOT_FOUND';
      throw error;
    }
    await this.switchAccount(target);
    return match;
  }

  async accountSummary(preferredAccountId = '') {
    if (preferredAccountId) await this.ensureAccount(preferredAccountId);
    const payload = await this.getAccounts();
    const accounts = payload.accounts || [];
    const activeId = String(preferredAccountId || this.session?.account?.accountId || '');
    const account = accounts.find(item => String(item.accountId) === activeId) || accounts.find(item => item.status === 'ENABLED') || accounts[0] || null;
    if (!account) return null;
    return {
      accountId: account.accountId,
      accountName: account.accountName || null,
      currency: account.currency || null,
      balance: Number(account.balance?.balance ?? account.balance ?? 0),
      deposit: Number(account.balance?.deposit ?? 0),
      profitLoss: Number(account.balance?.profitLoss ?? 0),
      available: Number(account.balance?.available ?? 0),
      status: account.status || null,
      preferred: Boolean(account.preferred)
    };
  }

  async searchMarkets(searchTerm = 'Gold') {
    return (await this.request('/markets', { query: { searchTerm } })).payload.markets || [];
  }

  async marketDetails(epic) {
    return (await this.request(`/markets/${encodeURIComponent(epic)}`)).payload;
  }

  async resolveGoldMarket(preferredEpic = '', searchTerm = 'Gold') {
    if (preferredEpic) {
      try {
        const details = await this.marketDetails(preferredEpic);
        return { epic: preferredEpic, details };
      } catch {
        // Demo and Live accounts can expose different epics. Fall back to search safely.
      }
    }
    const markets = await this.searchMarkets(searchTerm);
    if (!markets.length) throw new Error(`ไม่พบตลาดจากคำค้น ${searchTerm}`);
    const ranked = markets.slice().sort((a, b) => {
      const score = item => {
        const name = String(item.instrumentName || '').toLowerCase();
        const epic = String(item.epic || '').toLowerCase();
        let value = 0;
        if (name === 'gold') value += 10;
        if (name.includes('gold')) value += 5;
        if (epic === 'gold') value += 8;
        if (item.marketStatus === 'TRADEABLE' || item.snapshot?.marketStatus === 'TRADEABLE') value += 3;
        return value;
      };
      return score(b) - score(a);
    });
    const epic = ranked[0].epic;
    return { epic, details: await this.marketDetails(epic), alternatives: ranked.slice(0, 5) };
  }

  async prices(epic, resolution = 'MINUTE_5', max = 500) {
    return (await this.request(`/prices/${encodeURIComponent(epic)}`, { query: { resolution, max: Math.min(1000, Math.max(10, max)) } })).payload;
  }

  async positions() {
    return (await this.request('/positions')).payload.positions || [];
  }

  async confirmation(dealReference) {
    return (await this.request(`/confirms/${encodeURIComponent(dealReference)}`)).payload;
  }

  async activityHistory({ dealId = '', lastPeriod = 86400, detailed = true, filter = '' } = {}) {
    return (await this.request('/history/activity', {
      query: {
        dealId: dealId || undefined,
        lastPeriod: Math.min(86400, Math.max(1, Number(lastPeriod || 86400))),
        detailed: detailed ? 'true' : 'false',
        filter: filter || undefined
      }
    })).payload;
  }

  async transactionHistory({ lastPeriod = 86400, type = 'TRADE' } = {}) {
    return (await this.request('/history/transactions', {
      query: {
        lastPeriod: Math.min(86400, Math.max(1, Number(lastPeriod || 86400))),
        type: type || undefined
      }
    })).payload;
  }

  async workingOrders() {
    return (await this.request('/workingorders')).payload.workingOrders || [];
  }

  async healthCheck(preferredAccountId = '') {
    const startedAt = Date.now();
    const account = await this.accountSummary(preferredAccountId);
    return { ok: Boolean(account?.accountId), account, latencyMs: Date.now() - startedAt, environment: this.environment };
  }

  async waitForConfirmation(dealReference, attempts = 4) {
    let last = null;
    for (let index = 0; index < attempts; index += 1) {
      if (index) await sleep(350 * index);
      try {
        last = await this.confirmation(dealReference);
        if (last?.dealStatus || last?.status || last?.affectedDeals?.length) return last;
      } catch (error) {
        if (index === attempts - 1) throw error;
      }
    }
    return last;
  }

  async createPosition({ epic, direction, size, stopLevel, profitLevel }) {
    const payload = {
      epic,
      direction: direction === 'SELL' ? 'SELL' : 'BUY',
      size: Number(size),
      guaranteedStop: false,
      stopLevel: Number(stopLevel),
      profitLevel: Number(profitLevel)
    };
    const created = (await this.request('/positions', { method: 'POST', body: payload })).payload;
    let confirmation = null;
    let confirmationError = null;
    if (created.dealReference) {
      try { confirmation = await this.waitForConfirmation(created.dealReference); }
      catch (error) { confirmationError = { code: error?.code || 'CONFIRMATION_FAILED', message: String(error?.message || error) }; }
    }
    return { request: payload, created, confirmation, confirmationError };
  }

  async closePosition(dealId) {
    const created = (await this.request(`/positions/${encodeURIComponent(dealId)}`, { method: 'DELETE' })).payload;
    const confirmation = created.dealReference ? await this.waitForConfirmation(created.dealReference) : null;
    return { created, confirmation };
  }
}

export const CAPITAL_RESOLUTION = {
  '1min': 'MINUTE',
  '5min': 'MINUTE_5',
  '15min': 'MINUTE_15',
  '1h': 'HOUR',
  '4h': 'HOUR_4'
};

function mid(price = {}) {
  const bid = Number(price.bid);
  const ask = Number(price.ask);
  if (Number.isFinite(bid) && Number.isFinite(ask)) return (bid + ask) / 2;
  return Number.isFinite(bid) ? bid : ask;
}

export function normalizeCapitalCandles(payload = {}) {
  return (payload.prices || []).map(row => {
    const rawTime = row.snapshotTimeUTC || row.snapshotTime;
    const timestamp = /z$|[+-]\d\d:?\d\d$/i.test(String(rawTime)) ? rawTime : `${rawTime}Z`;
    return {
      time: Math.floor(new Date(timestamp).getTime() / 1000),
      datetime: rawTime,
      open: mid(row.openPrice),
      high: mid(row.highPrice),
      low: mid(row.lowPrice),
      close: mid(row.closePrice),
      volume: Number(row.lastTradedVolume || 0),
      bidClose: Number(row.closePrice?.bid),
      askClose: Number(row.closePrice?.ask)
    };
  }).filter(candle => Number.isFinite(candle.time) && [candle.open, candle.high, candle.low, candle.close].every(Number.isFinite))
    .sort((a, b) => a.time - b.time);
}

export function marketSnapshot(details = {}) {
  const snapshot = details.snapshot || {};
  const bid = Number(snapshot.bid);
  const ask = Number(snapshot.offer ?? snapshot.ask);
  return {
    bid,
    ask,
    mid: Number.isFinite(bid) && Number.isFinite(ask) ? (bid + ask) / 2 : Number.isFinite(bid) ? bid : ask,
    spreadUsd: Number.isFinite(bid) && Number.isFinite(ask) ? Math.max(0, ask - bid) : 0,
    marketStatus: snapshot.marketStatus || null,
    updateTime: snapshot.updateTime || null,
    instrumentName: details.instrument?.name || details.instrumentName || null,
    minDealSize: Number(details.dealingRules?.minDealSize?.value ?? 0),
    minDealSizeUnit: details.dealingRules?.minDealSize?.unit || null,
    minStopDistance: details.dealingRules?.minStopOrProfitDistance || null
  };
}
