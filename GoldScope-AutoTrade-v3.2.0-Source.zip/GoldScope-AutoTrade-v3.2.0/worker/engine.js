import { analyzeTimeframe } from '../src/core/market.js';
import { generateCandidates } from '../src/core/strategies.js';
import { DEFAULT_SETTINGS, selectPlans } from '../src/core/risk.js';
import { buildAdaptiveModel, applyAdaptiveLearning, mergeLearningRecords } from '../src/core/learning.js';
import {
  normalizeAutoTradeConfig, defaultAutoTradeState, rolloverDailyState, appendAutoTradeLog,
  checkRiskGuards, evaluateEntryWindow, createPaperPosition, evaluatePaperPosition, recordClosedTrade,
  activateAccountLedger, syncActiveAccountLedger
} from '../src/core/autotrade.js';
import { CapitalClient, CAPITAL_RESOLUTION, normalizeCapitalCandles, marketSnapshot, capitalConfigured, extractCapitalDealId } from './capital.js';
import { closedCandlesOnly, inspectCandleQuality, spreadQuality } from '../src/core/dataQuality.js';
import { createIdempotencyKey, createOrderIntent, transitionOrderIntent, isRetryBlockedOrderIntent, isTerminalOrderIntent } from '../src/core/idempotency.js';
import { evaluateLiveReadiness } from '../src/core/readiness.js';
import { loadNewsContext } from './news.js';
import { createForwardPosition, evaluateForwardPosition, summarizeForwardPositions } from '../src/core/forwardTest.js';
import { evaluateAdaptiveDrift } from '../src/core/modelDrift.js';

const round = (value, digits = 2) => Number(Number(value).toFixed(digits));

function publicPlan(plan) {
  if (!plan) return null;
  const keys = [
    'id','strategy','strategyKey','timeframe','timeframeLabel','direction','directionLabel','score','baseScore','qualityLabel',
    'entryLow','entryHigh','entry','stopLoss','tp1','tp2','tp3','exitAtTarget','riskReward','riskLevel','lot',
    'estimatedLossUsd','estimatedLossPercent','estimatedMarginUsd','valuePerPriceUnit','pnlReferenceSize','pnlPerUsdMoveAtReferenceSize','warnings','createdAt','expiresAt',
    'adaptiveAdjustment','learningSamples','learningConfidence','learnedWinRate','learnedExpectancyR','regime',
    'algorithmVersion','strategyVersion','modelVersion','adaptiveModelPaused','modelDrift','reasonsSupporting','reasonsAgainst','blockingReasons'
  ];
  return Object.fromEntries(keys.map(key => [key, plan[key]]));
}

function targetFromPlan(plan, config) {
  const key = ['tp1', 'tp2', 'tp3'].includes(config.takeProfitTarget) ? config.takeProfitTarget : 'tp2';
  return Number(plan[key] ?? plan.tp2);
}

function sizeForMarket(config, snapshot) {
  const requested = Number(config.orderSize || 0.01);
  const minimum = Number(snapshot.minDealSize || 0);
  if (minimum > requested && !config.useBrokerMinimumSize) {
    throw new Error(`ขนาดที่ตั้ง ${requested} ต่ำกว่าขั้นต่ำ Broker ${minimum}; ระบบไม่ปรับขึ้นเองเพื่อป้องกันความเสี่ยง`);
  }
  return minimum > requested ? minimum : requested;
}

function brokerMinimumStopPoints(snapshot, settings) {
  const digits = Math.max(0, Math.min(6, Math.trunc(Number(settings.brokerDigits ?? 2))));
  const pointSize = 10 ** -digits;
  const rule = snapshot?.minStopDistance;
  const value = Number(rule?.value ?? rule ?? 0);
  if (!(value > 0)) return 0;
  const unit = String(rule?.unit || '').toUpperCase();
  if (unit.includes('POINT')) return Math.ceil(value);
  if (unit.includes('PERCENT')) {
    const distance = Math.abs(Number(snapshot.mid || 0)) * value / 100;
    return Math.ceil(distance / pointSize);
  }
  return Math.ceil(value / pointSize);
}

export function settingsForEngine(configInput, accountBalance, snapshot, effectiveOrderSize = null) {
  const config = normalizeAutoTradeConfig(configInput);
  const shared = config.syncAlgorithm ? (config.algorithmSettings || {}) : {};
  const base = { ...DEFAULT_SETTINGS, ...shared };
  const digits = Math.max(0, Math.min(6, Math.trunc(Number(base.brokerDigits ?? 2))));
  const pointSize = 10 ** -digits;
  const spreadPoints = Math.max(0, Math.round(Number(snapshot.spreadUsd || 0) / pointSize));
  const size = Number(effectiveOrderSize || config.orderSize || base.fixedLot || 0.01);
  const brokerStopFloor = brokerMinimumStopPoints(snapshot, base);
  return {
    ...base,
    maxPlans: Math.max(1, Number(base.maxPlans || 3)),
    minScore: config.minScore,
    accountSize: Math.max(0.01, Number(accountBalance || base.accountSize || 20)),
    positionSizingMode: 'fixed',
    fixedLot: size,
    lotStep: Math.min(Number(base.lotStep || size), size),
    maxLot: Math.max(size, Number(base.maxLot || size)),
    riskPercent: config.riskPercentPerTrade,
    maxLossUsd: config.maxLossPerTradeUsd,
    pnlReferenceSize: config.pnlReferenceSize,
    pnlPerUsdMoveAtReferenceSize: config.pnlPerUsdMoveAtReferenceSize,
    brokerDigits: digits,
    spreadPoints,
    slippagePoints: Math.max(0, Number(base.slippagePoints ?? 5)),
    manualEntryBufferPoints: Math.max(0, Number(base.manualEntryBufferPoints ?? 5)),
    minStopPoints: Math.max(Number(base.minStopPoints || 0), brokerStopFloor),
    refreshSeconds: 60
  };
}

function safeAccount(account, environment = null) {
  if (!account) return null;
  return {
    accountId: account.accountId || null,
    accountName: account.accountName || null,
    environment,
    currency: account.currency,
    balance: round(account.balance || 0),
    available: round(account.available || 0),
    profitLoss: round(account.profitLoss || 0),
    status: account.status,
    preferred: account.preferred
  };
}

function learningSummary(model) {
  if (!model) return null;
  return {
    status: model.status,
    enabled: model.enabled,
    eligibleTrades: model.eligibleTrades,
    effectiveTrades: model.effectiveTrades,
    fingerprint: model.fingerprint,
    overall: model.overall ? {
      confidence: model.overall.confidence,
      expectancyR: model.overall.expectancyR,
      winRate: model.overall.winRate,
      adjustment: model.overall.adjustment
    } : null
  };
}

function brokerTradeRecord(tracked, verifiedPnl, now, verification = {}) {
  const risk = Math.max(0.0001, Number(tracked.initialRiskUsd || 0));
  const resultR = risk > 0 ? round(verifiedPnl / risk, 4) : 0;
  const loss = verifiedPnl < 0;
  return {
    ...tracked,
    id: tracked.id || `broker-${tracked.dealId || tracked.at}`,
    closedAt: now,
    endedAt: now,
    verifiedPnl: true,
    pnlUsd: round(verifiedPnl, 4),
    resultR,
    status: loss ? 'STOPPED' : 'COMPLETED',
    outcome: loss ? 'Broker loss/SL' : verifiedPnl > 0 ? 'Broker profit/TP' : 'Breakeven',
    exitReason: verification.exitReason || 'BROKER_CLOSED_VERIFIED',
    brokerVerification: verification,
    dataMode: tracked.environment === 'live' ? 'live' : 'demo',
    source: 'cloud-autotrade'
  };
}

function transactionRows(payload = {}) {
  return payload.transactions || payload.activities || payload.activity || payload.data || [];
}

function exactBrokerHistoryMatch(rows, tracked) {
  const identifiers = new Set([tracked.dealId, tracked.dealReference, tracked.orderIntentId].filter(Boolean).map(String));
  return (rows || []).find(row => {
    const candidates = [row.reference, row.dealId, row.dealReference, row.positionId, row.activity?.dealId]
      .filter(Boolean).map(String);
    return candidates.some(value => identifiers.has(value));
  }) || null;
}

function verifiedPnlFromRow(row, accountCurrency) {
  if (!row) return null;
  const currency = row.currency || row.profitAndLossCurrency || row.details?.currency || accountCurrency || null;
  if (accountCurrency && currency && String(currency) !== String(accountCurrency)) return null;
  const values = [row.profitAndLoss, row.pnl, row.amount, row.details?.profitAndLoss, row.details?.amount];
  const value = values.map(Number).find(Number.isFinite);
  if (!Number.isFinite(value)) return null;
  return { value, currency, row };
}

async function reconcileTrackedBrokerTrade(stateInput, positions, account, client, now, services = {}) {
  let state = { ...stateInput };
  const tracked = state.trackedBrokerOrders?.[state.activeAccountKey] || state.lastBrokerOrder;
  if (!tracked?.dealId || tracked.closedAt) return state;
  if (tracked.accountKey && state.activeAccountKey && tracked.accountKey !== state.activeAccountKey) return state;
  const openDealIds = new Set((positions || []).map(item => item.position?.dealId || item.dealId).filter(Boolean).map(String));
  if (openDealIds.has(String(tracked.dealId)) || now - Number(tracked.at || 0) < 15_000) return state;

  let verified = null;
  let activity = null;
  try {
    const [transactions, activities] = await Promise.all([
      client.transactionHistory({ lastPeriod: 86400, type: 'TRADE' }),
      client.activityHistory({ dealId: tracked.dealId, lastPeriod: 86400, detailed: true })
    ]);
    const transaction = exactBrokerHistoryMatch(transactionRows(transactions), tracked);
    activity = exactBrokerHistoryMatch(transactionRows(activities), tracked);
    verified = verifiedPnlFromRow(transaction, account?.currency);
  } catch (error) {
    if (services.persistReconciliation) await services.persistReconciliation({
      accountKey: state.activeAccountKey, orderIntentId: tracked.orderIntentId, dealId: tracked.dealId,
      dealReference: tracked.dealReference, result: 'HISTORY_LOOKUP_FAILED', source: 'capital-history',
      payload: { code: error?.code || null, message: String(error?.message || error) }
    });
  }

  if (verified) {
    const trade = brokerTradeRecord(tracked, verified.value, now, {
      source: 'capital-transaction-history', currency: verified.currency, activity,
      exitReason: activity?.source || activity?.status || 'BROKER_CLOSED_VERIFIED'
    });
    state = recordClosedTrade(state, trade, now, { countTrade: false });
    state.lastBrokerOrder = trade;
    state.trackedBrokerOrders = { ...(state.trackedBrokerOrders || {}), [state.activeAccountKey]: trade };
    state.reconciliationMismatch = Math.max(0, Number(state.reconciliationMismatch || 0) - 1);
    state.safetyTests = { ...(state.safetyTests || {}), reconciliation: true, reconciliationTestedAt: now };
    const key = tracked.idempotencyKey;
    if (key && state.orderIntents?.[key]) {
      try {
        state.orderIntents = { ...state.orderIntents, [key]: transitionOrderIntent(state.orderIntents[key], 'CLOSED', {
          reason: 'verified-by-broker-history', dealId: tracked.dealId, response: { transaction: verified.row, activity }
        }, now) };
        await persistIntent(services, state.orderIntents[key]);
      } catch { /* retain state when legacy intent transition cannot be applied */ }
    }
    if (services.persistJournal) await services.persistJournal({ ...trade, accountKey: state.activeAccountKey });
    if (services.persistReconciliation) await services.persistReconciliation({
      accountKey: state.activeAccountKey, orderIntentId: tracked.orderIntentId, dealId: tracked.dealId,
      dealReference: tracked.dealReference, result: 'CLOSED_VERIFIED', verifiedPnl: verified.value,
      currency: verified.currency, source: 'capital-transaction-history', payload: { transaction: verified.row, activity }
    });
    if (services.notify) await services.notify('POSITION_CLOSED', {
      accountKey: state.activeAccountKey, dealId: tracked.dealId, pnlUsd: verified.value, currency: verified.currency
    });
    return appendAutoTradeLog(state, 'trade', `ยืนยันผลปิดจาก Broker แล้ว ${verified.value >= 0 ? '+' : ''}${round(verified.value, 2)} ${verified.currency || ''}`, trade, now);
  }

  const alreadyPending = tracked.status === 'RECONCILIATION_REQUIRED';
  const pending = {
    ...tracked,
    status: 'RECONCILIATION_REQUIRED',
    reconciliationReason: 'POSITION_DISAPPEARED_WITHOUT_EXACT_HISTORY_MATCH',
    balanceObserved: Number(account?.balance || 0),
    reconciliationRequestedAt: alreadyPending ? tracked.reconciliationRequestedAt : now
  };
  state = {
    ...state,
    lastBrokerOrder: pending,
    trackedBrokerOrders: { ...(state.trackedBrokerOrders || {}), [state.activeAccountKey]: pending },
    reconciliationMismatch: alreadyPending ? Number(state.reconciliationMismatch || 0) : Number(state.reconciliationMismatch || 0) + 1,
    safetyTests: { ...(state.safetyTests || {}), reconciliation: false }
  };
  if (services.persistReconciliation && !alreadyPending) await services.persistReconciliation({
    accountKey: state.activeAccountKey, orderIntentId: tracked.orderIntentId, dealId: tracked.dealId,
    dealReference: tracked.dealReference, result: 'RECONCILIATION_REQUIRED', source: 'capital-history',
    payload: { reason: pending.reconciliationReason }
  });
  return appendAutoTradeLog(state, 'warn', 'สถานะหายจากรายการเปิด แต่ยังไม่พบประวัติที่ตรง dealId จึงบล็อกออเดอร์ใหม่และไม่เดา P/L', pending, now);
}

async function persistIntent(services, intent) {
  if (services?.persistIntent) await services.persistIntent(intent);
}

async function checkpoint(services, config, state) {
  if (services?.checkpoint) await services.checkpoint(config, state);
}

function unresolvedIntents(state) {
  const unresolvedStates = new Set(['CREATED', 'RISK_APPROVED', 'QUEUED', 'SUBMITTING', 'SUBMITTED', 'UNKNOWN', 'RECONCILIATION_REQUIRED', 'CLOSING']);
  return Object.values(state.orderIntents || {}).filter(intent => unresolvedStates.has(intent?.state));
}

function reconcileOrderIntents(stateInput, positions = [], epic = '', now = Date.now()) {
  let state = { ...stateInput, orderIntents: { ...(stateInput.orderIntents || {}) } };
  const candidates = (positions || []).filter(item => (item.market?.epic || item.position?.epic) === epic);
  for (const [key, intent] of Object.entries(state.orderIntents)) {
    if (!['UNKNOWN', 'RECONCILIATION_REQUIRED', 'SUBMITTED', 'BROKER_ACCEPTED'].includes(intent?.state)) continue;
    const dealId = intent.dealId;
    const exact = dealId ? candidates.find(item => String(item.position?.dealId || item.dealId) === String(dealId)) : null;
    const approximate = exact || candidates.find(item => {
      const position = item.position || item;
      return String(position.direction || '').toUpperCase() === String(intent.direction || '').toUpperCase()
        && Math.abs(Number(position.size || 0) - Number(intent.size || 0)) < 1e-8;
    });
    if (approximate) {
      const position = approximate.position || approximate;
      try {
        let updated = intent;
        if (updated.state === 'SUBMITTED') updated = transitionOrderIntent(updated, 'BROKER_ACCEPTED', { reason: 'broker-position-found' }, now);
        if (['UNKNOWN', 'RECONCILIATION_REQUIRED'].includes(updated.state)) updated = transitionOrderIntent(updated, 'OPEN', { reason: 'reconciled-open-position' }, now);
        else if (updated.state === 'BROKER_ACCEPTED') updated = transitionOrderIntent(updated, 'OPEN', { reason: 'broker-position-open' }, now);
        state.orderIntents[key] = { ...updated, dealId: position.dealId || updated.dealId || null };
      } catch { /* preserve current intent */ }
    } else if (now - Number(intent.updatedAt || intent.createdAt || 0) > 120_000 && intent.state !== 'RECONCILIATION_REQUIRED') {
      try { state.orderIntents[key] = transitionOrderIntent(intent, 'RECONCILIATION_REQUIRED', { reason: 'position-not-found-after-timeout' }, now); }
      catch { /* terminal/invalid state */ }
    }
  }
  return state;
}

function orderTrackingRecord({ config, plan, epic, signal, account, intent, result, dealId, orderSize, entry, target, initialRiskUsd, valuePerPriceUnit, now }) {
  return {
    id: `broker-${now}`, planId: plan.id, signalId: signal.id, at: now, openedAt: now,
    environment: config.brokerEnvironment, accountKey: intent.accountKey, epic,
    direction: Number(plan.direction) === -1 ? -1 : 1, directionLabel: plan.directionLabel,
    size: orderSize, entry, entryLow: Number(plan.entryLow), entryHigh: Number(plan.entryHigh),
    stopLevel: Number(plan.stopLoss), stopLoss: Number(plan.stopLoss), profitLevel: target,
    tp1: Number(plan.tp1), tp2: Number(plan.tp2), tp3: Number(plan.tp3), strategy: plan.strategy,
    strategyKey: plan.strategyKey, strategyVersion: intent.strategyVersion, modelVersion: intent.modelVersion,
    timeframe: plan.timeframe, timeframeLabel: plan.timeframeLabel || plan.timeframe, score: Number(plan.score),
    adaptiveAdjustment: Number(plan.adaptiveAdjustment || 0), regime: plan.regime || 'unknown', valuePerPriceUnit,
    initialRiskUsd: round(initialRiskUsd, 4), dealReference: result?.created?.dealReference || null,
    confirmation: result?.confirmation || null, dealId, idempotencyKey: intent.idempotencyKey,
    orderIntentId: intent.id, balanceBefore: Number(account?.balance || 0),
    dataMode: config.brokerEnvironment === 'live' ? 'live' : 'demo'
  };
}

async function processBrokerSubmission({ client, config, state, pending, now, services = {} }) {
  let intent = state.orderIntents?.[pending.idempotencyKey];
  if (!intent || intent.state !== 'QUEUED') return { ...state, status: 'IDEMPOTENT_REPLAY', lastDecision: 'Order Intent ไม่อยู่ในสถานะ QUEUED จึงไม่ส่งซ้ำ' };
  intent = transitionOrderIntent(intent, 'SUBMITTING', { reason: 'order-execution-consumer-started' }, now);
  state.orderIntents = { ...state.orderIntents, [pending.idempotencyKey]: intent };
  await persistIntent(services, intent);
  await checkpoint(services, config, state);

  let result;
  try {
    result = await client.createPosition(pending.request);
  } catch (error) {
    intent = transitionOrderIntent(intent, 'UNKNOWN', {
      reason: 'broker-submit-result-unknown',
      lastError: { code: error?.code || 'BROKER_SUBMIT_UNKNOWN', message: String(error?.message || error) }
    }, Date.now());
    state.orderIntents[pending.idempotencyKey] = intent;
    delete state.pendingExecutions[pending.idempotencyKey];
    state.criticalExecutionErrors = Number(state.criticalExecutionErrors || 0) + 1;
    await persistIntent(services, intent);
    await checkpoint(services, config, state);
    if (services.notify) await services.notify('ORDER_RESULT_UNKNOWN', { accountKey: state.activeAccountKey, idempotencyKey: pending.idempotencyKey });
    return { ...state, status: 'RECONCILIATION_REQUIRED', lastDecision: 'ไม่ทราบผลส่งคำสั่ง ระบบจะ Reconcile และไม่ส่งซ้ำ' };
  }

  if (result.created?.dealReference) intent = transitionOrderIntent(intent, 'SUBMITTED', {
    dealReference: result.created.dealReference,
    response: { created: result.created, confirmation: result.confirmation || null, confirmationError: result.confirmationError || null }
  }, Date.now());
  const rejected = result.confirmation?.dealStatus === 'REJECTED' || result.confirmation?.status === 'REJECTED';
  if (rejected) {
    intent = transitionOrderIntent(intent, 'BROKER_REJECTED', { reason: result.confirmation?.reason || 'broker-rejected' }, Date.now());
    state.orderIntents[pending.idempotencyKey] = intent;
    delete state.pendingExecutions[pending.idempotencyKey];
    await persistIntent(services, intent);
    await checkpoint(services, config, state);
    if (services.notify) await services.notify('ORDER_REJECTED', { accountKey: state.activeAccountKey, reason: result.confirmation?.reason || null });
    return { ...state, status: 'ORDER_REJECTED', lastDecision: 'Broker ปฏิเสธคำสั่ง' };
  }
  const dealId = extractCapitalDealId(result.confirmation);
  if (!result.confirmation || result.confirmationError) {
    intent = transitionOrderIntent(intent, 'UNKNOWN', {
      dealReference: result.created?.dealReference || null,
      reason: result.confirmationError?.code || 'confirmation-not-available'
    }, Date.now());
    state.orderIntents[pending.idempotencyKey] = intent;
    delete state.pendingExecutions[pending.idempotencyKey];
    await persistIntent(services, intent);
    await checkpoint(services, config, state);
    return { ...state, status: 'RECONCILIATION_REQUIRED', lastDecision: 'Broker รับคำขอแล้วแต่ยังยืนยันผลไม่ได้ ระบบจะ Reconcile' };
  }
  intent = transitionOrderIntent(intent, 'BROKER_ACCEPTED', { dealReference: result.created?.dealReference || null, dealId }, Date.now());
  if (dealId) intent = transitionOrderIntent(intent, 'OPEN', { reason: 'broker-confirmed-open' }, Date.now());
  state.orderIntents[pending.idempotencyKey] = intent;
  delete state.pendingExecutions[pending.idempotencyKey];
  await persistIntent(services, intent);

  const tracked = orderTrackingRecord({ ...pending, config, intent, result, dealId, now });
  state.pendingSignal = null;
  state.daily = { ...state.daily, trades: Number(state.daily.trades || 0) + 1, lastTradeAt: now };
  state.lastBrokerOrder = tracked;
  state.trackedBrokerOrders = { ...(state.trackedBrokerOrders || {}), [state.activeAccountKey]: tracked };
  state = syncActiveAccountLedger(state);
  const label = `${config.executionMode === 'auto' ? 'AUTO' : 'CONFIRM'} ${config.brokerEnvironment.toUpperCase()}`;
  state = appendAutoTradeLog(state, 'trade', `${label} ${pending.plan.directionLabel} ${pending.epic} size ${pending.orderSize}`, tracked);
  await checkpoint(services, config, state);
  if (services.notify) await services.notify('ORDER_SENT', { accountKey: state.activeAccountKey, dealId, dealReference: result.created?.dealReference, epic: pending.epic });
  return { ...state, status: 'ORDER_SENT', lastSuccessAt: now, lastDecision: `ส่งคำสั่ง ${label} และตรวจ confirmation แล้ว` };
}

async function submitBrokerOrder({ client, config, state, plan, epic, snapshot, signal, account, now, services = {} }) {
  const target = targetFromPlan(plan, config);
  const orderSize = sizeForMarket(config, snapshot);
  if (!(orderSize > 0)) throw new Error('ขนาดออเดอร์ไม่ถูกต้อง');
  const entry = Number(signal.currentPrice || plan.entry || (Number(plan.entryLow) + Number(plan.entryHigh)) / 2);
  const valuePerPriceUnit = Number(plan.valuePerPriceUnit || 1);
  const calculatedRiskUsd = Math.abs(entry - Number(plan.stopLoss)) * valuePerPriceUnit;
  const initialRiskUsd = Math.max(0.0001, Number.isFinite(Number(plan.estimatedLossUsd)) ? Number(plan.estimatedLossUsd) : calculatedRiskUsd);
  const percentBudget = Math.max(0, Number(account?.balance || 0)) * Number(config.riskPercentPerTrade || 0) / 100;
  const riskBudget = Math.min(Number(config.maxLossPerTradeUsd || Infinity), percentBudget > 0 ? percentBudget : Infinity);
  if (Number.isFinite(riskBudget) && initialRiskUsd > riskBudget + 0.005) {
    throw new Error(`งดส่งคำสั่ง: SL ตามโครงสร้างเสี่ยงประมาณ $${round(initialRiskUsd, 2)} เกินเพดานต่อออเดอร์ $${round(riskBudget, 2)}; ระบบไม่บีบ SL ให้แคบ`);
  }

  const modelVersion = state.learningSummary?.fingerprint || 'base-model';
  const strategyVersion = plan.algorithmVersion || '3.2.0';
  const idempotencyKey = createIdempotencyKey({
    broker: 'capital', environment: config.brokerEnvironment, accountId: account?.accountId || config.accountId || 'unknown',
    symbol: epic, strategyVersion, modelVersion, timeframe: plan.timeframe,
    closedCandleTime: signal.candleTime, direction: plan.directionLabel, signalId: signal.id
  });
  const existing = state.orderIntents?.[idempotencyKey];
  if (isRetryBlockedOrderIntent(existing)) {
    state.duplicateOrderCount = Number(state.duplicateOrderCount || 0) + 1;
    state = appendAutoTradeLog(state, 'warn', `ป้องกันคำสั่งซ้ำ: ${idempotencyKey}`, { state: existing.state, signalId: signal.id });
    return { ...state, status: 'IDEMPOTENT_REPLAY', lastDecision: 'สัญญาณนี้มี Order Intent อยู่แล้ว จึงไม่ส่งซ้ำ' };
  }

  let intent = createOrderIntent({ idempotencyKey, signal, accountKey: state.activeAccountKey, requestId: services.requestId, now });
  intent = {
    ...intent, direction: plan.directionLabel, size: orderSize, symbol: epic, strategyVersion, modelVersion,
    timeframe: plan.timeframe, closedCandleTime: signal.candleTime,
    request: { epic, direction: plan.directionLabel, size: orderSize, stopLevel: plan.stopLoss, profitLevel: target }
  };
  intent = transitionOrderIntent(intent, 'RISK_APPROVED', { reason: 'deterministic-risk-engine-approved' }, now);
  intent = transitionOrderIntent(intent, 'QUEUED', { reason: services.enqueueOrder ? 'queued-for-single-submit' : 'direct-single-submit' }, now);
  const pending = {
    idempotencyKey, config, plan, epic, snapshot, signal, account, orderSize, entry, target, initialRiskUsd, valuePerPriceUnit,
    request: intent.request, createdAt: now
  };
  state.orderIntents = { ...(state.orderIntents || {}), [idempotencyKey]: intent };
  state.pendingExecutions = { ...(state.pendingExecutions || {}), [idempotencyKey]: pending };
  state.lastExecutedSignalId = signal.id;
  await persistIntent(services, intent);
  await checkpoint(services, config, state);

  if (services.enqueueOrder) {
    await services.enqueueOrder({ idempotencyKey, signalId: signal.id, accountKey: state.activeAccountKey });
    return { ...state, status: 'ORDER_QUEUED', lastDecision: 'ผ่าน Risk Engine แล้วและเข้าคิวส่งคำสั่งแบบครั้งเดียว' };
  }
  return processBrokerSubmission({ client, config, state, pending, now, services });
}

export async function executeQueuedOrder({ env, config: configInput, state: stateInput, idempotencyKey, services = {} }) {
  const now = Date.now();
  const config = normalizeAutoTradeConfig(configInput);
  let state = rolloverDailyState({ ...defaultAutoTradeState(now), ...(stateInput || {}) }, now);
  const pending = state.pendingExecutions?.[idempotencyKey];
  if (!pending) return { config, state: { ...state, status: 'IDEMPOTENT_REPLAY', lastDecision: 'ไม่พบ pending execution หรือถูกประมวลผลแล้ว' } };
  let intent = state.orderIntents?.[idempotencyKey];
  if (!intent || intent.state !== 'QUEUED') return { config, state: { ...state, status: 'IDEMPOTENT_REPLAY', lastDecision: 'Order Intent ไม่อยู่ในสถานะ QUEUED จึงไม่ส่งซ้ำ' } };

  const blockExecution = async (code, message, details = null) => {
    try { intent = transitionOrderIntent(intent, 'FAILED', { reason: code, lastError: { code, message, details } }, Date.now()); }
    catch { /* preserve safer non-send state */ }
    state.orderIntents = { ...(state.orderIntents || {}), [idempotencyKey]: intent };
    state.pendingExecutions = { ...(state.pendingExecutions || {}) };
    delete state.pendingExecutions[idempotencyKey];
    state = appendAutoTradeLog(state, 'warn', `ยกเลิกออเดอร์ก่อนส่ง: ${message}`, { code, details });
    await persistIntent(services, intent);
    await checkpoint(services, config, state);
    if (services.notify) await services.notify('ORDER_BLOCKED_BEFORE_SUBMIT', { accountKey: state.activeAccountKey, idempotencyKey, code, message });
    return { config, state: { ...state, status: 'ORDER_BLOCKED', lastDecision: message } };
  };

  if (!config.enabled || state.status === 'KILLED') return blockExecution('SYSTEM_DISABLED', 'ระบบถูกหยุดหรือ Kill Switch ทำงานแล้ว');
  if (!['confirm', 'auto'].includes(config.executionMode)) return blockExecution('EXECUTION_MODE_CHANGED', 'โหมดส่งคำสั่งถูกเปลี่ยนก่อน Queue ทำงาน');
  if (config.brokerEnvironment !== pending.config?.brokerEnvironment) return blockExecution('ENVIRONMENT_CHANGED', 'Broker environment เปลี่ยนหลังสร้าง Intent');
  if (config.accountId && pending.account?.accountId && String(config.accountId) !== String(pending.account.accountId)) {
    return blockExecution('ACCOUNT_CHANGED', 'Account ID เปลี่ยนหลังสร้าง Intent');
  }

  const client = new CapitalClient(env, config.brokerEnvironment, state.brokerSession);
  const account = await client.accountSummary(config.accountId || pending.account?.accountId || '');
  const resolved = await client.resolveGoldMarket(pending.epic || config.instrumentEpic || '', config.instrumentSearch);
  const snapshot = marketSnapshot(resolved.details);
  const [positions, workingOrders] = await Promise.all([client.positions(), client.workingOrders().catch(() => [])]);
  state.brokerSession = client.exportSession();
  state.brokerAccount = safeAccount(account, config.brokerEnvironment);
  state.market = snapshot;
  state.resolvedEpic = resolved.epic;

  if (resolved.epic !== pending.epic) return blockExecution('SYMBOL_CHANGED', 'Epic ที่ Broker ตอบกลับไม่ตรงกับ Intent เดิม', { expected: pending.epic, actual: resolved.epic });
  if (snapshot.marketStatus && snapshot.marketStatus !== 'TRADEABLE') return blockExecution('MARKET_NOT_TRADEABLE', `ตลาดไม่พร้อมส่งคำสั่ง (${snapshot.marketStatus})`);
  const sourceTime = Date.parse(snapshot.updateTime || '');
  if (Number.isFinite(sourceTime) && now - sourceTime > config.requireFreshCandleSeconds * 1000) {
    return blockExecution('STALE_BROKER_QUOTE', 'ราคา Broker เก่าเกินเกณฑ์ก่อนส่งคำสั่ง', { updateTime: snapshot.updateTime });
  }

  const goldPositions = positions.filter(item => (item.market?.epic || item.position?.epic) === pending.epic);
  const goldWorkingOrders = workingOrders.filter(item => (item.marketData?.epic || item.market?.epic || item.workingOrderData?.epic || item.epic) === pending.epic);
  const otherPending = unresolvedIntents(state).filter(item => item.idempotencyKey !== idempotencyKey).length;
  const guard = checkRiskGuards({
    config, state, openPositions: goldPositions.length, pendingOrders: otherPending + goldWorkingOrders.length,
    spreadUsd: snapshot.spreadUsd, brokerLatencyMs: client.lastLatencyMs, now
  });
  state = guard.state;
  if (!guard.allowed) return blockExecution('RISK_RECHECK_FAILED', guard.reasons.join(' • '), { reasons: guard.reasons });

  const entryCheck = evaluateEntryWindow(pending.plan, Number(snapshot.mid), config.entryToleranceUsd);
  if (!entryCheck.eligible) return blockExecution('ENTRY_WINDOW_EXPIRED', 'ราคาล่าสุดออกจาก Entry zone แล้ว', entryCheck);
  const latestRiskUsd = Math.abs(Number(snapshot.mid) - Number(pending.plan.stopLoss)) * Number(pending.valuePerPriceUnit || 1);
  const percentBudget = Math.max(0, Number(account?.balance || 0)) * Number(config.riskPercentPerTrade || 0) / 100;
  const riskBudget = Math.min(Number(config.maxLossPerTradeUsd || Infinity), percentBudget > 0 ? percentBudget : Infinity);
  if (Number.isFinite(riskBudget) && latestRiskUsd > riskBudget + 0.005) {
    return blockExecution('LATEST_PRICE_RISK_EXCEEDED', `ราคาล่าสุดทำให้ความเสี่ยงประมาณ $${round(latestRiskUsd, 2)} เกินเพดาน $${round(riskBudget, 2)}`);
  }

  const refreshedPending = {
    ...pending, account, snapshot, entry: Number(snapshot.mid), initialRiskUsd: latestRiskUsd,
    request: { ...pending.request, epic: resolved.epic }
  };
  state.pendingExecutions = { ...(state.pendingExecutions || {}), [idempotencyKey]: refreshedPending };
  state = await processBrokerSubmission({ client, config, state, pending: refreshedPending, now, services });
  state.brokerSession = client.exportSession();
  return { config, state };
}

export async function loadBrokerMarketData({ env, config: configInput, outputsize = 900 }) {
  const config = normalizeAutoTradeConfig(configInput);
  if (!capitalConfigured(env)) throw new Error('ยังไม่ได้ตั้งค่า Capital.com API secrets');
  const client = new CapitalClient(env, config.brokerEnvironment);
  const account = await client.accountSummary(config.accountId);
  const resolved = await client.resolveGoldMarket(config.instrumentEpic || '', config.instrumentSearch);
  const datasets = {};
  const errors = [];
  for (const timeframe of ['1min', '5min', '15min', '1h', '4h']) {
    try {
      const max = timeframe === '1min' ? Math.min(Number(outputsize || 900), 700) : Math.min(Number(outputsize || 900), 1000);
      const payload = await client.prices(resolved.epic, CAPITAL_RESOLUTION[timeframe], max);
      const candles = normalizeCapitalCandles(payload);
      if (candles.length < 30) throw new Error('ข้อมูลไม่พอ');
      datasets[timeframe] = {
        ok: true,
        source: 'capital',
        environment: config.brokerEnvironment,
        symbol: resolved.epic,
        interval: timeframe,
        candles,
        receivedAt: new Date().toISOString()
      };
    } catch (error) {
      errors.push({ timeframe, message: String(error?.message || error) });
    }
  }
  if (Object.keys(datasets).length < 3) throw new Error('ข้อมูล Capital.com ไม่พอสำหรับหน้าวิเคราะห์');
  return {
    ok: true,
    source: 'capital',
    mode: config.brokerEnvironment === 'live' ? 'live' : 'demo',
    environment: config.brokerEnvironment,
    epic: resolved.epic,
    account: safeAccount(account, config.brokerEnvironment),
    market: marketSnapshot(resolved.details),
    datasets,
    errors,
    receivedAt: new Date().toISOString()
  };
}

export async function runAutoTradeCycle({ env, config: configInput, state: stateInput, trigger = 'manual', confirmedPlanId = null, services = {} }) {
  const now = Date.now();
  const config = normalizeAutoTradeConfig(configInput);
  let state = rolloverDailyState({ ...defaultAutoTradeState(now), ...(stateInput || {}) }, now);
  state = { ...state, status: 'SCANNING', lastRunAt: now, lastError: null };

  if (!config.enabled) {
    return { state: { ...state, status: 'PAUSED', lastDecision: config.pauseReason || 'ระบบ Auto Trade ปิดอยู่' }, config };
  }

  try {
    if (!capitalConfigured(env)) {
      state = appendAutoTradeLog(state, 'warn', 'ยังไม่ได้ตั้งค่า Capital.com API secrets');
      return { state: { ...state, status: 'NEEDS_SETUP', lastDecision: 'ตั้งค่า Broker secrets ก่อนใช้งาน' }, config };
    }

    const client = new CapitalClient(env, config.brokerEnvironment, state.brokerSession);
    const account = await client.accountSummary(config.accountId);
    state.brokerSession = client.exportSession();
    state = activateAccountLedger(state, config.brokerEnvironment, account || {}, now);
    state.brokerAccount = safeAccount(account, config.brokerEnvironment);
    const balance = Number(account?.balance || 0);
    state.peakBalance = Math.max(Number(state.peakBalance || 0), balance);
    state.currentDrawdownPercent = state.peakBalance > 0 ? round(Math.max(0, (state.peakBalance - balance) / state.peakBalance * 100), 4) : 0;
    const deposit = Math.max(0, Number(account?.deposit || 0));
    state.marginUsagePercent = balance > 0 ? round(Math.min(100, deposit / balance * 100), 4) : 0;

    const resolved = await client.resolveGoldMarket(config.instrumentEpic || state.resolvedEpic || '', config.instrumentSearch);
    const epic = resolved.epic;
    const details = resolved.details;
    const snapshot = marketSnapshot(details);
    state.resolvedEpic = epic;
    state.market = snapshot;

    if (snapshot.marketStatus && snapshot.marketStatus !== 'TRADEABLE') {
      state = appendAutoTradeLog(state, 'info', `ตลาด ${epic} ยังไม่เปิด (${snapshot.marketStatus})`, snapshot);
      return { state: { ...state, status: 'MARKET_CLOSED', lastDecision: `ตลาด ${snapshot.marketStatus || 'ปิด'}` }, config };
    }

    const [positions, workingOrders] = await Promise.all([client.positions(), client.workingOrders().catch(() => [])]);
    state.brokerSession = client.exportSession();
    const goldPositions = positions.filter(item => (item.market?.epic || item.position?.epic) === epic);
    const goldWorkingOrders = workingOrders.filter(item => (item.marketData?.epic || item.market?.epic || item.workingOrderData?.epic || item.epic) === epic);
    state = reconcileOrderIntents(state, positions, epic, now);
    if (config.executionMode !== 'paper') state = await reconcileTrackedBrokerTrade(state, positions, account, client, now, services);

    if (config.executionMode === 'paper' && state.paperPosition) {
      const latestPayload = await client.prices(epic, 'MINUTE', 5);
      const latestCandles = normalizeCapitalCandles(latestPayload);
      const evaluated = evaluatePaperPosition(state.paperPosition, latestCandles.at(-1), now);
      if (evaluated.closed) {
        state.paperPosition = null;
        state = recordClosedTrade(state, evaluated.position, now, { countTrade: false });
      }
    }

    state.newsContext = await loadNewsContext(env, config, now);
    const closedDemoTrades = (state.cloudJournal || []).filter(item => item.dataMode === 'demo').length;
    const unresolved = unresolvedIntents(state).length;
    state.liveReadiness = evaluateLiveReadiness({
      calibrationPassed: state.calibration?.passed === true,
      closedDemoTrades,
      forwardTestDays: Number(state.forwardTest?.days || 0),
      criticalExecutionErrors: Number(state.criticalExecutionErrors || 0),
      duplicateOrders: Number(state.duplicateOrderCount || 0),
      unresolvedOrderIntents: unresolved,
      outOfSampleExpectancy: Number(state.modelMetrics?.outOfSampleExpectancy || 0),
      maximumDrawdownPercent: Number(state.modelMetrics?.maximumDrawdownPercent ?? Infinity),
      killSwitchTestPassed: state.safetyTests?.killSwitch === true,
      reconciliationTestPassed: state.safetyTests?.reconciliation === true,
      configFrozen: state.configFrozen === true
    }, config);
    if (config.brokerEnvironment === 'live' && state.liveUnlock?.sessionId && services.isSessionRevoked) {
      const revoked = await services.isSessionRevoked(state.liveUnlock.sessionId);
      if (revoked) state.liveUnlock = null;
    }

    const openCount = config.executionMode === 'paper' ? (state.paperPosition ? 1 : 0) : goldPositions.length;
    // The broker/account calls above succeeded. Clear the transient API error streak before a new decision.
    state.apiErrorStreak = 0;

    if (trigger === 'reconcile') {
      return { state: { ...state, status: 'RECONCILED', lastSuccessAt: now, lastDecision: 'ตรวจสถานะ Broker และ Order Intent แล้ว' }, config };
    }

    if (trigger === 'confirm') {
      const confirmGuard = checkRiskGuards({
        config, state, openPositions: openCount, pendingOrders: unresolved + goldWorkingOrders.length,
        spreadUsd: snapshot.spreadUsd, brokerLatencyMs: client.lastLatencyMs, now
      });
      state = confirmGuard.state;
      if (!confirmGuard.allowed) {
        const reason = confirmGuard.reasons.join(' • ');
        state = appendAutoTradeLog(state, 'info', `งดส่งคำสั่งยืนยัน: ${reason}`);
        return { state: { ...state, status: config.enabled ? 'GUARDED' : 'PAUSED', lastDecision: reason }, config };
      }
      if (config.executionMode !== 'confirm') throw new Error('รับคำสั่งยืนยันได้เฉพาะโหมด Confirm');
      const signal = state.pendingSignal;
      if (!signal || signal.id !== confirmedPlanId) throw new Error('สัญญาณยืนยันไม่ตรงหรือไม่มีสัญญาณรออยู่');
      if (now > Number(signal.expiresAt || 0)) {
        state.pendingSignal = null;
        throw new Error('สัญญาณหมดอายุแล้ว');
      }
      if (signal.epic !== epic) throw new Error('ตลาดของสัญญาณไม่ตรงกับตลาดปัจจุบัน');
      const plan = signal.plan;
      const currentPrice = Number(snapshot.mid);
      const entryCheck = evaluateEntryWindow(plan, currentPrice, config.entryToleranceUsd);
      if (!entryCheck.eligible) {
        state.pendingSignal = { ...signal, currentPrice: round(currentPrice, 3), entryCheck };
        state = appendAutoTradeLog(state, 'warn', 'ยังไม่ส่งคำสั่ง: ราคาออกจาก Entry zone หลังผู้ใช้กดยืนยัน', state.pendingSignal);
        return { state: { ...state, status: 'WAITING_ENTRY', lastDecision: 'ราคาออกจาก Entry zone จึงยกเลิกการส่งรอบนี้' }, config };
      }
      state = await submitBrokerOrder({ client, config, state, plan, epic, snapshot, signal, account, now, services });
      return { state, config };
    }

    const analyses = {};
    const datasets = {};
    for (const timeframe of config.scanTimeframes) {
      const payload = await client.prices(epic, CAPITAL_RESOLUTION[timeframe], timeframe === '1min' ? 500 : 800);
      const normalized = normalizeCapitalCandles(payload);
      const closed = closedCandlesOnly(normalized, timeframe, now);
      const quality = inspectCandleQuality(closed, timeframe, {
        nowMs: now,
        staleAfterSeconds: config.requireFreshCandleSeconds,
        minimumScore: config.minimumDataQualityScore,
        minimumCandles: 80
      });
      if (timeframe === config.timeframe) {
        state.dataQuality = { ...quality, spreadQuality: spreadQuality(snapshot.spreadUsd, config.maxSpreadUsd) };
      }
      if (!quality.ok) continue;
      datasets[timeframe] = quality.candles;
      analyses[timeframe] = analyzeTimeframe(quality.candles, timeframe);
    }
    if (config.forwardTestEnabled && Object.keys(state.forwardPositions || {}).length && datasets['1min']?.length) {
      const nextForward = { ...(state.forwardPositions || {}) };
      for (const [id, position] of Object.entries(nextForward)) {
        if (position.status !== 'OPEN') continue;
        const evaluated = evaluateForwardPosition(position, datasets['1min'], now);
        nextForward[id] = evaluated.position;
        if (evaluated.closed && services.closeForward) await services.closeForward(evaluated.position);
      }
      state.forwardPositions = nextForward;
      state.forwardTest = summarizeForwardPositions(nextForward, now);
    }

    if (!analyses[config.timeframe]) {
      const reason = state.dataQuality?.reasons?.join(' • ') || `ข้อมูล ${config.timeframe} ไม่พอสำหรับวิเคราะห์`;
      state = appendAutoTradeLog(state, 'warn', `NO_TRADE: ${reason}`);
      return { state: { ...state, status: 'DATA_BLOCKED', lastDecision: reason }, config };
    }

    const guard = checkRiskGuards({
      config, state, openPositions: openCount, pendingOrders: unresolved + goldWorkingOrders.length,
      spreadUsd: snapshot.spreadUsd, brokerLatencyMs: client.lastLatencyMs, now
    });
    state = guard.state;
    if (!guard.allowed) {
      const reason = guard.reasons.join(' • ');
      state = appendAutoTradeLog(state, 'info', `งดเปิดออเดอร์: ${reason}`);
      return { state: { ...state, status: config.enabled ? 'GUARDED' : 'PAUSED', lastDecision: reason }, config };
    }

    const newest = datasets[config.timeframe].at(-1);
    const candleAgeSeconds = newest ? Math.max(0, Math.floor(now / 1000 - newest.time)) : Infinity;
    if (candleAgeSeconds > config.requireFreshCandleSeconds) {
      state = appendAutoTradeLog(state, 'warn', `ข้อมูลแท่งล่าสุดเก่า ${candleAgeSeconds} วินาที`);
      return { state: { ...state, status: 'STALE_DATA', lastDecision: 'ข้อมูลตลาดเก่าเกินเกณฑ์' }, config };
    }
    if (trigger === 'cron' && Number(state.lastProcessedCandles?.[config.timeframe] || 0) === Number(newest.time)) {
      return { state: { ...state, status: 'WATCHING', lastDecision: 'แท่งปิดล่าสุดถูกประมวลผลแล้ว' }, config };
    }
    state.lastProcessedCandles = { ...(state.lastProcessedCandles || {}), [config.timeframe]: newest.time };

    const effectiveOrderSize = sizeForMarket(config, snapshot);
    const riskSettings = settingsForEngine(config, account?.balance || 20, snapshot, effectiveOrderSize);
    const generated = generateCandidates(analyses);
    const records = mergeLearningRecords(config.learningRecords, state.cloudJournal);
    const previousDriftStatus = state.modelDrift?.status;
    const drift = evaluateAdaptiveDrift(records, {
      recentWindow: config.modelDriftRecentTrades,
      baselineWindow: config.modelDriftBaselineTrades
    });
    state.modelDrift = drift;
    const model = buildAdaptiveModel(records, riskSettings, config.brokerEnvironment === 'live' ? 'live' : 'demo');
    const adaptivePaused = config.pauseAdaptiveOnDrift && drift.pauseAdaptive;
    const decisionModel = adaptivePaused ? { ...model, enabled: false, status: 'หยุด Adaptive ชั่วคราวเพราะตรวจพบ model drift' } : model;
    state.learningSummary = { ...learningSummary(decisionModel), drift };
    if (adaptivePaused && previousDriftStatus !== 'DRIFT') {
      state = appendAutoTradeLog(state, 'warn', 'หยุด Adaptive adjustment ชั่วคราว: ผลช่วงล่าสุดเสื่อมลงหรือ regime เปลี่ยนมาก', drift);
      if (services.notify) await services.notify('MODEL_DRIFT_PAUSED', { accountKey: state.activeAccountKey, drift });
    }
    const learned = applyAdaptiveLearning(generated.candidates, decisionModel, riskSettings);
    const preferred = learned.filter(item => item.timeframe === config.timeframe);
    const ordered = [...preferred, ...learned.filter(item => item.timeframe !== config.timeframe)];
    const plans = selectPlans(ordered, analyses, riskSettings, []);
    const plan = plans.find(item => item.timeframe === config.timeframe) || plans[0] || null;
    if (!plan) {
      state = appendAutoTradeLog(state, 'info', `รอบนี้ไม่มีสัญญาณที่ผ่านคะแนน โครงสร้าง SL และเพดานขาดทุนต่อออเดอร์ $${config.maxLossPerTradeUsd}`);
      return { state: { ...state, status: 'WATCHING', lastDecision: 'ไม่มีสัญญาณที่ผ่านเกณฑ์', lastSignal: null }, config };
    }

    const currentPrice = Number(snapshot.mid || newest.close);
    const entryCheck = evaluateEntryWindow(plan, currentPrice, config.entryToleranceUsd);
    const signal = {
      id: `${plan.id}-${newest.time}`,
      createdAt: now,
      candleTime: newest.time,
      epic,
      currentPrice: round(currentPrice, 3),
      spreadUsd: round(snapshot.spreadUsd, 3),
      plan: publicPlan({ ...plan, dataMode: config.executionMode === 'paper' ? 'demo' : config.brokerEnvironment }),
      entryCheck,
      expiresAt: Number(plan.expiresAt || now + 15 * 60_000)
    };
    signal.plan = {
      ...signal.plan,
      modelVersion: model.fingerprint || 'base-model',
      strategyVersion: plan.algorithmVersion || '3.2.0',
      adaptiveModelPaused: adaptivePaused,
      modelDrift: drift,
      reasonsSupporting: plan.evidence || [],
      reasonsAgainst: [...(plan.warnings || []), ...(adaptivePaused ? ['หยุด Adaptive adjustment ชั่วคราวเพราะ Model Drift'] : [])],
      blockingReasons: []
    };
    state.lastSignal = signal;
    if (services.persistSignal) await services.persistSignal({
      id: signal.id, accountKey: state.activeAccountKey, symbol: epic, timeframe: plan.timeframe,
      closedCandleTime: signal.candleTime, direction: plan.directionLabel, decision: entryCheck.eligible ? plan.directionLabel : 'WAIT',
      baseScore: Number(plan.baseScore || plan.score || 0), finalScore: Number(plan.score || 0), confidence: Number(plan.learningConfidence || 0),
      expectedR: Number(plan.riskReward || 0), strategyVersion: signal.plan.strategyVersion,
      modelVersion: signal.plan.modelVersion, configVersion: state.configVersion, explanation: signal.plan,
      newsContext: state.newsContext, createdAt: now
    });

    if (config.forwardTestEnabled && entryCheck.eligible) {
      const forward = createForwardPosition({
        signal: { ...signal, newsContext: state.newsContext },
        plan: { ...plan, exitAtTarget: config.takeProfitTarget, strategyVersion: signal.plan.strategyVersion, modelVersion: signal.plan.modelVersion },
        spread: snapshot.spreadUsd, slippageUsd: config.forwardTestSlippageUsd, now,
        accountKey: state.activeAccountKey, configVersion: state.configVersion
      });
      if (!state.forwardPositions?.[forward.id]) {
        state.forwardPositions = { ...(state.forwardPositions || {}), [forward.id]: forward };
        state.forwardTest = summarizeForwardPositions(state.forwardPositions, now);
        if (services.persistForward) await services.persistForward(forward);
      }
    }

    if (!entryCheck.eligible) {
      state.pendingSignal = signal;
      state = appendAutoTradeLog(state, 'info', `พบสัญญาณ ${plan.directionLabel} ${plan.score}/100 แต่ราคายังไม่เข้าโซน`, signal);
      return { state: { ...state, status: 'WAITING_ENTRY', lastDecision: 'รอราคาเข้า Entry zone' }, config };
    }

    if (state.lastExecutedSignalId === signal.id && trigger !== 'confirm') {
      return { state: { ...state, status: 'WATCHING', lastDecision: 'สัญญาณนี้ถูกประมวลผลแล้ว' }, config };
    }

    if (config.executionMode === 'confirm' && trigger !== 'confirm') {
      state.pendingSignal = signal;
      state = appendAutoTradeLog(state, 'trade', `รอยืนยัน ${plan.directionLabel} ${epic} คะแนน ${plan.score}`, signal);
      return { state: { ...state, status: 'AWAITING_CONFIRMATION', lastDecision: 'รอผู้ใช้ยืนยันจากโทรศัพท์' }, config };
    }

    if (config.executionMode === 'paper') {
      const paper = createPaperPosition({ ...plan, dataMode: 'demo', exitAtTarget: config.takeProfitTarget }, currentPrice, effectiveOrderSize, now);
      state.paperPosition = paper;
      state.pendingSignal = null;
      state.lastExecutedSignalId = signal.id;
      state.daily = { ...state.daily, trades: Number(state.daily.trades || 0) + 1, lastTradeAt: now };
      state = syncActiveAccountLedger(state);
      state = appendAutoTradeLog(state, 'trade', `Paper ${paper.directionLabel} ${epic} @ ${paper.entry}`, paper);
      return { state: { ...state, status: 'POSITION_OPEN', lastSuccessAt: now, lastDecision: 'เปิด Paper position แล้ว' }, config };
    }

    state = await submitBrokerOrder({ client, config, state, plan, epic, snapshot, signal, account, now, services });
    return { state, config };
  } catch (error) {
    state.apiErrorStreak = Number(state.apiErrorStreak || 0) + 1;
    state = appendAutoTradeLog(state, 'error', String(error?.message || error), { code: error?.code || null });
    return {
      state: { ...state, status: 'ERROR', lastError: { message: String(error?.message || error), code: error?.code || null, at: now }, lastDecision: 'เกิดข้อผิดพลาด ระบบไม่ส่งคำสั่งซ้ำอัตโนมัติ' },
      config
    };
  }
}
