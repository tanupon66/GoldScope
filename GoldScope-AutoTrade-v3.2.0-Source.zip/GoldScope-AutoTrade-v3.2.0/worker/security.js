const encoder = new TextEncoder();
const decoder = new TextDecoder();
const SESSION_COOKIE = 'gs_session';
const DEFAULT_SESSION_SECONDS = 15 * 60;

function toBase64Url(bytes) {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
}

function fromBase64Url(value) {
  const padded = String(value || '').replaceAll('-', '+').replaceAll('_', '/') + '==='.slice((String(value || '').length + 3) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, char => char.charCodeAt(0));
}

export function timingSafeEqualBytes(leftInput, rightInput) {
  const left = leftInput instanceof Uint8Array ? leftInput : new Uint8Array(leftInput || []);
  const right = rightInput instanceof Uint8Array ? rightInput : new Uint8Array(rightInput || []);
  let mismatch = left.length ^ right.length;
  const max = Math.max(left.length, right.length);
  for (let index = 0; index < max; index += 1) mismatch |= (left[index % Math.max(left.length, 1)] || 0) ^ (right[index % Math.max(right.length, 1)] || 0);
  return mismatch === 0;
}

async function hmac(secret, value) {
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(value)));
}

async function sha256(value) {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(value)));
}

export async function hashIdentifier(value, secret = 'goldscope') {
  return toBase64Url(await hmac(secret, String(value || 'unknown'))).slice(0, 32);
}

export async function verifyAdminCredential(password, encodedHash) {
  const parts = String(encodedHash || '').split('$');
  if (parts.length !== 4 || parts[0] !== 'pbkdf2-sha256') return false;
  const iterations = Number(parts[1]);
  if (!Number.isInteger(iterations) || iterations < 100_000 || iterations > 2_000_000) return false;
  let salt;
  let expected;
  try {
    salt = fromBase64Url(parts[2]);
    expected = fromBase64Url(parts[3]);
  } catch {
    return false;
  }
  const key = await crypto.subtle.importKey('raw', encoder.encode(String(password || '')), 'PBKDF2', false, ['deriveBits']);
  const derived = new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, expected.length * 8));
  return timingSafeEqualBytes(derived, expected);
}

export async function createSessionToken({ secret, subject = 'admin', ttlSeconds = DEFAULT_SESSION_SECONDS, version = '3.2.0' } = {}) {
  if (!secret) throw new Error('SESSION_SIGNING_SECRET_MISSING');
  const now = Math.floor(Date.now() / 1000);
  const payload = {
    sub: subject,
    sid: crypto.randomUUID(),
    csrf: toBase64Url(crypto.getRandomValues(new Uint8Array(24))),
    iat: now,
    exp: now + Math.max(60, Math.min(Number(ttlSeconds || DEFAULT_SESSION_SECONDS), 24 * 60 * 60)),
    ver: version
  };
  const encoded = toBase64Url(encoder.encode(JSON.stringify(payload)));
  const signature = toBase64Url(await hmac(secret, encoded));
  return { token: `${encoded}.${signature}`, payload };
}

export async function verifySessionToken(token, secret, nowSeconds = Math.floor(Date.now() / 1000)) {
  if (!token || !secret) return { ok: false, code: 'SESSION_MISSING' };
  const [encoded, signature, extra] = String(token).split('.');
  if (!encoded || !signature || extra) return { ok: false, code: 'SESSION_MALFORMED' };
  const expected = await hmac(secret, encoded);
  let actual;
  try { actual = fromBase64Url(signature); } catch { return { ok: false, code: 'SESSION_MALFORMED' }; }
  if (!timingSafeEqualBytes(expected, actual)) return { ok: false, code: 'SESSION_INVALID' };
  let payload;
  try { payload = JSON.parse(decoder.decode(fromBase64Url(encoded))); } catch { return { ok: false, code: 'SESSION_MALFORMED' }; }
  if (!payload?.sid || !payload?.csrf || !Number.isFinite(Number(payload.exp))) return { ok: false, code: 'SESSION_INVALID' };
  if (Number(payload.exp) <= nowSeconds) return { ok: false, code: 'SESSION_EXPIRED', payload };
  return { ok: true, payload };
}

export function cookieValue(request, name = SESSION_COOKIE) {
  const cookie = request.headers.get('cookie') || '';
  for (const part of cookie.split(';')) {
    const [key, ...rest] = part.trim().split('=');
    if (key === name) return decodeURIComponent(rest.join('='));
  }
  return '';
}

export function sessionCookie(token, maxAgeSeconds = DEFAULT_SESSION_SECONDS) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${Math.max(0, Math.trunc(maxAgeSeconds))}`;
}

export function clearSessionCookie() {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}

export async function authenticateRequest(request, env, { requireCsrf = false, expectedVersion = null } = {}) {
  const verified = await verifySessionToken(cookieValue(request), env.SESSION_SIGNING_SECRET);
  if (!verified.ok) return verified;
  if (expectedVersion && verified.payload.ver !== expectedVersion) return { ok: false, code: 'SESSION_VERSION_MISMATCH', payload: verified.payload };
  if (requireCsrf) {
    const supplied = request.headers.get('x-csrf-token') || '';
    if (!timingSafeEqualBytes(encoder.encode(supplied), encoder.encode(verified.payload.csrf))) return { ok: false, code: 'CSRF_INVALID', payload: verified.payload };
  }
  return verified;
}

export function securityHeaders(extra = {}) {
  return {
    'x-content-type-options': 'nosniff',
    'x-frame-options': 'DENY',
    'referrer-policy': 'no-referrer',
    'permissions-policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    'cross-origin-opener-policy': 'same-origin',
    'cross-origin-resource-policy': 'same-origin',
    'content-security-policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; manifest-src 'self'; worker-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
    ...extra
  };
}

export class AuthState {
  constructor(ctx) {
    this.ctx = ctx;
  }

  async fetch(request) {
    const url = new URL(request.url);
    const body = request.method === 'POST' ? await request.json().catch(() => ({})) : {};
    const now = Date.now();
    const attempts = (await this.ctx.storage.get('attempts')) || {};
    const revoked = (await this.ctx.storage.get('revoked')) || {};
    for (const [sid, expiresAt] of Object.entries(revoked)) if (Number(expiresAt) <= now) delete revoked[sid];

    if (url.pathname === '/check') {
      const item = attempts[body.key] || { failures: 0, lockedUntil: 0 };
      return Response.json({ ok: true, allowed: Number(item.lockedUntil || 0) <= now, retryAfterMs: Math.max(0, Number(item.lockedUntil || 0) - now), failures: Number(item.failures || 0) });
    }
    if (url.pathname === '/fail') {
      const current = attempts[body.key] || { failures: 0, lockedUntil: 0 };
      const failures = Number(current.failures || 0) + 1;
      const lockedUntil = failures >= 5 ? now + Math.min(30 * 60_000, 60_000 * 2 ** Math.min(8, failures - 5)) : 0;
      attempts[body.key] = { failures, lockedUntil, updatedAt: now };
      await this.ctx.storage.put('attempts', attempts);
      return Response.json({ ok: true, failures, lockedUntil });
    }
    if (url.pathname === '/success') {
      delete attempts[body.key];
      await this.ctx.storage.put('attempts', attempts);
      return Response.json({ ok: true });
    }
    if (url.pathname === '/revoke') {
      if (body.sid) revoked[body.sid] = Number(body.expiresAt || now + 24 * 60 * 60_000);
      await this.ctx.storage.put('revoked', revoked);
      return Response.json({ ok: true });
    }
    if (url.pathname === '/is-revoked') {
      const sid = url.searchParams.get('sid') || body.sid;
      await this.ctx.storage.put('revoked', revoked);
      return Response.json({ ok: true, revoked: Boolean(sid && Number(revoked[sid] || 0) > now) });
    }
    return Response.json({ ok: false, code: 'NOT_FOUND' }, { status: 404 });
  }
}
